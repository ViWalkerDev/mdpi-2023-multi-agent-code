// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Agent.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_AGENT_AGENT_H_INCLUDED
#define NANOMAP_AGENT_AGENT_H_INCLUDED
#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
#include <iomanip>
#include <chrono>
#include <iostream>
#include <string>

#include "nanomap/agent/AgentData.h"
#include "nanomap/sensor/Sensor.h"
#include "nanomap/map/Map.h"
#include "nanomap/nanomap.h"


/******************************************************************************
This class defines a basic agent. It is used for single body UAVs with one or
more FIXED sensors and doesn't currently contain more advanced robotics kinematics like
Joint and Link definitions. update the UAV pose, then use the class to update the
sensor poses and pass a map file to the sensors to update the map with the new
sensor views. This also uses a map file to generate observation distances for
deeprl. Rays for an agent are generally loaded from a file and are precomputed.
however, a spherical observation sphere of radius r is generated if file not provided.
*******************************************************************************/

namespace nanomap{
  namespace agent{

  class Agent{

    public:

      Agent(std::shared_ptr<nanomap::agent::AgentData> agentData, std::vector<std::shared_ptr<nanomap::sensor::Sensor>> sensors, std::shared_ptr<nanomap::map::Map> map)
      :_agentData(agentData)
      ,_map(map)
      {
        for(int x = 0; x < sensors.size(); x++){
          _sensors.push_back(sensors[x]);
        }
      }

      virtual void resetAgent(){}
      virtual void resetAgentMap(){}
      virtual void updateAgentObservations(){}
      virtual void updateAgentEnvironmentObservations(){}
      virtual void updateAgentSearchObservations(){}
      virtual bool isGoalReached(){}
      virtual bool isTerminal(){}
      virtual bool isCollided(){}
      virtual bool needsMapReset(){}
      virtual int getGoalSearchCount(){}
      virtual Eigen::ArrayXf getObservations(){}
      virtual Eigen::ArrayXf getGoalObservations(){}
      virtual Eigen::ArrayXf getObservationCloud(){}
      virtual void setPriorKnowledge(float radius, openvdb::FloatGrid::Ptr grid){}
      virtual int& voxelCount(){}
      virtual bool getAgentCollision(Eigen::Vector3f updatedXYZ){}
      virtual void setPriorKnowledge(openvdb::FloatGrid::Ptr grid){}
      virtual bool isSearchGoalComplete(Eigen::Vector3f position){}

      virtual std::vector<Eigen::Vector3f> getLocalGoalsFromWorldGoals(std::vector<Eigen::Vector3f> worldGoals){
        Eigen::Quaternionf inverseRotation = _agentData->pose().orientation.normalized().inverse();
        Eigen::Vector3f worldTargetDelta;
        Eigen::Vector3f localTargetDelta;
        std::vector<Eigen::Vector3f> localGoals;
        for(auto goal : worldGoals){
          worldTargetDelta = goal - _agentData->pose().position;       
          localTargetDelta = inverseRotation*worldTargetDelta;
          localGoals.push_back(localTargetDelta); 
        }
        return localGoals;
      }
      virtual std::tuple<int, int, int, std::vector<Eigen::Vector3f>> getSearchGoals(int clusterIndex){}

      virtual std::tuple<int, int, int, std::vector<Eigen::Vector3f>> getTransitGoalsForCluster(int clusterIndex){}
      
      virtual std::vector<Eigen::Vector3f> getSearchGoalsVec(int clusterIndex){}

      virtual std::vector<Eigen::Vector3f> getTransitGoalsVec(int clusterIndex){}


      virtual std::vector<std::pair<Pose, int>>  getTrajectoryGoals(){}

      void updatePose(Pose pose){
        _agentData->pose() = pose;
        int index = 0;
        //Eigen::Matrix<float, 3, 3> defaultFrameTransform;
        //Currently not setup up correctly. Supposed to get relative transform of sensor from agent origin, and transform accordingly, as of now
        //only sets sensor pose to equal agentPose
        for(auto itr = _sensors.begin(); itr != _sensors.end(); itr++){
          (*itr)->sensorData()->updatePose(pose);
          (*itr)->sensorData()->rotateView();
        }
      }

      Eigen::Array<float, 7, 1> getPoseAsFloat(){
        Eigen::Array<float, 7, 1> poseAsFloat;
        poseAsFloat(0) = _agentData->pose().position.x();
        poseAsFloat(1) = _agentData->pose().position.y();
        poseAsFloat(2) = _agentData->pose().position.z();
        poseAsFloat(3) = _agentData->pose().orientation.w();
        poseAsFloat(4) = _agentData->pose().orientation.x();
        poseAsFloat(5) = _agentData->pose().orientation.y();
        poseAsFloat(6) = _agentData->pose().orientation.z();
        return poseAsFloat;
      }

      std::vector<std::shared_ptr<nanomap::sensor::Sensor>> sensors(){return _sensors;}
      std::shared_ptr<nanomap::sensor::Sensor> sensor(int index){return _sensors[index];}
      std::shared_ptr<nanomap::agent::AgentData> agentData(){return _agentData;}
      std::shared_ptr<nanomap::map::Map> map(){return _map;}

      
      
    protected:

      //Agent Data, contains pose, and other lookup info. 
      std::shared_ptr<nanomap::agent::AgentData> _agentData;

      //The sensors this agent owns
      std::vector<std::shared_ptr<nanomap::sensor::Sensor>> _sensors;      

      //The agent's occupancy map
      std::shared_ptr<nanomap::map::Map> _map;

    };
  }
}
#endif
