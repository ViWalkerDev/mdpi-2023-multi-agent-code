// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Agent.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_AGENT_AGENTDATA_H_INCLUDED
#define NANOMAP_AGENT_AGENTDATA_H_INCLUDED
#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
#include <iomanip>
#include <chrono>
#include <iostream>
#include <string>

#include "nanomap/nanomap.h"


/******************************************************************************
This class defines a basic agent. It is used for single body UAVs with one or
more FIXED sensors and doesn't currently contain more advanced robotics kinematics like
Joint and Link definitions. update the UAV pose, then use the class to update the
sensor poses and pass a map file to the sensors to update the map with the new
sensor views. This also uses a map file to generate observation distances for
deeprl. Rays for an agent are generally loaded from a file and are precomputed.
however, a spherical observation sphere of radius r is generated if file not provided.
*******************************************************************************/

namespace nanomap{
  namespace agent{

  class AgentData{

    public:
      AgentData(){}
      AgentData(std::string agentName, int agentId, bool isRandomSpawn, Pose pose)
      :_agentName(agentName)
      ,_agentId(agentId)
      ,_isRandomSpawn(isRandomSpawn)
      ,_pose(pose)
      {}

    std::string& agentName(){return _agentName;}
    int& agentId(){return _agentId;}
    bool& spawnRandom(){return _isRandomSpawn;}
    //Pose& spawn(){return _spawn;}
    Pose& pose(){return _pose;}

    private:
      std::string _agentName;
      int _agentId;
      bool _isRandomSpawn;
      //Pose _spawn;
      Pose _pose;
    };
  }
}
#endif
