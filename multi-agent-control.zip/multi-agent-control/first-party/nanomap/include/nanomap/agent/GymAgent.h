// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Agent.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_AGENT_GYMAGENT_H_INCLUDED
#define NANOMAP_AGENT_GYMAGENT_H_INCLUDED
#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
#include <iomanip>
#include <chrono>
#include <iostream>
#include <string>

#include <openvdb/Types.h>
#include <openvdb/Grid.h>
#include <openvdb/openvdb.h>
#include <openvdb/tree/Tree.h>
#include <openvdb/tools/ValueTransformer.h>
#include <openvdb/math/Ray.h>
#include <openvdb/tools/Morphology.h>
#include <openvdb/math/DDA.h>



#include "nanomap/agent/Agent.h"
#include "nanomap/agent/GymData.h"
#include "nanomap/agent/AgentData.h"
#include "nanomap/sensor/Sensor.h"
#include "nanomap/manager/PlannerManager.h"
#include "nanomap/map/Map.h"
#include "nanomap/nanomap.h"


/******************************************************************************
This class defines a basic agent. It is used for single body UAVs with one or
more FIXED sensors and doesn't currently contain more advanced robotics kinematics like
Joint and Link definitions. update the UAV pose, then use the class to update the
sensor poses and pass a map file to the sensors to update the map with the new
sensor views. This also uses a map file to generate observation distances for
deeprl. Rays for an agent are generally loaded from a file and are precomputed.
however, a spherical observation sphere of radius r is generated if file not provided.
*******************************************************************************/

namespace nanomap{
  namespace agent{
    using LeafNodeT = openvdb::FloatGrid::TreeType::LeafNodeType;
  class GymAgent : public Agent{

    public:

      GymAgent(std::shared_ptr<nanomap::agent::AgentData> agentData, std::shared_ptr<nanomap::agent::GymData> gymData, std::vector<std::shared_ptr<nanomap::sensor::Sensor>> sensors, 
                std::shared_ptr<nanomap::map::Map> map, std::shared_ptr<nanomap::manager::PlannerManager> plannerManager, openvdb::FloatGrid::Ptr simGrid)
      :Agent(agentData, sensors, map), _plannerManager(plannerManager), _gymData(gymData), _simGrid(simGrid)
      {
        _gymData->setPlanner(plannerManager);
      }

      void resetTransitAgent(){
        _map->clearMap();
        //get new random path via planner manager.
        _gymData->_goals = _plannerManager->getRandomPath(_gymData->_minPathSteps);
        //Set last goal location to beginning of path
        bool isNewGoal = _gymData->getNewGoal();
        //_gymData->trimCloseGoals();
        //Set pose as last goal location ie the beginning of the path
        _agentData->pose() = _gymData->_lastGoalLocation;
        //TEMPORARY FOR TRAINING< NEED TO MAKE PERMANENT ANOTHER WAY. VERY HACKY. DO NOT DO THIS!
        _gymData->_goals[0].first = _gymData->_lastGoalLocation;
        //update observations and goals
        updateAgentObservations();
      }    

      int getGoalSearchCount(){
        return _gymData->_goalSearchCount;
      }

  void resetAgent(){
        _map->clearMap();
        
        std::tie(_gymData->_startIndex,_gymData->_destIndex) = _plannerManager->getRandomPairWithMinDistance(15.0);
        _gymData->_destPosition = _plannerManager->getPositionFromGlobalIndex(_gymData->_destIndex);
        _agentData->pose().position = _plannerManager->getPositionFromGlobalIndex(_gymData->_startIndex);
        _gymData->_clusterPath = _plannerManager->clusterPathBetweenGlobalIndexPair(_gymData->_startIndex, _gymData->_destIndex);
        _gymData->_currentCluster = _plannerManager->getClusterFromPosition(_agentData->pose().position);
        int targetClusterIndex = 0;
        for(int cluster : _gymData->_clusterPath){
          if(cluster != _gymData->_currentCluster){
            _gymData->_targetCluster = cluster;
            _gymData->_targetClusterIndex = targetClusterIndex; 
            break;
          }
          targetClusterIndex++;
        }
        // std::cout << "current cluster" << _gymData->_currentCluster << std::endl;
        // std::cout << "target cluster" << _gymData->_targetCluster << std::endl;
        // std::cout << "targetClusterIndex" << _gymData->_targetClusterIndex << std::endl;
        // std::cout << "clusterPathsize" << _gymData->_clusterPath.size() << std::endl;

        _gymData->_goalObs.resize(3);
        _gymData->_transitGoal = _plannerManager->getClusterBoundaryAverage(_gymData->_targetCluster);
        updateAgentObservations();
        //updateAgentSearchObservations();
      }


      // void resetAgent(){
      //   _map->clearMap();
      //   _gymData->_searchTargets.clear();
      //   _gymData->_searchTargets.resize(5);
      //   _gymData->_searchDeltas.clear();
      //   _gymData->_searchDeltas.resize(5);
      //   _gymData->_goalObs.resize(5*3);
      //   _gymData->_searchTargetsEmpty = true;
      //   int numClusters = _plannerManager->getClusterCount();
      //   _gymData->_searchedClusters.clear();
      //   _gymData->_searchedClusters.resize(numClusters, false);
      //   int randomStartCluster = rand()%numClusters;
      //   _gymData->_searchTargetsEmpty = true;
      //   //_gymData->_goals.clear();
      //   //std::vector<Eigen::Vector3f> goalPositions = _plannerManager->getClusterSearchNodesInWorld(randomStartCluster);
      //   // for(auto position : goalPositions){
      //   //   nanomap::Pose pose;
      //   //   pose.position = position;
      //   //   _gymData->_goals.push_back(std::make_pair(pose, 0));
      //   // }
      //   _gymData->_currentCluster = randomStartCluster;
      //   //int numStartGoals = goalPositions.size();
      //   //int randomStartGoal = rand()%numStartGoals;
      //   // _gymData->_searchGoalIndex = randomStartGoal;
      //   // _gymData->_lastGoalLocation = _gymData->_goals[randomStartGoal].first;
      //   _agentData->pose().position = _plannerManager->getRandomPositionInCluster(_gymData->_currentCluster);
      //   //updateAgentSearchObservations();
      // }


      bool needsMapReset(){
        return _gymData->_needsMapReset;
      }

      void resetAgentMap(){
        _gymData->_needsMapReset = false;
        _map->clearMap();
        _gymData->_goals.clear();
        std::vector<Eigen::Vector3f> goalPositions = _plannerManager->getClusterSearchNodesInWorld(_gymData->_currentCluster);
        for(auto position : goalPositions){
          nanomap::Pose pose;
          pose.position = position;
          _gymData->_goals.push_back(std::make_pair(pose, 0));
        }
        bool newGoal = _gymData->getNewSearchGoal(_agentData->pose());
       //_gymData->_searchGoalIndex = randomStartGoal;
       //_gymData->_lastGoalLocation = _gymData->_goals[randomStartGoal].first;
       //_agentData->pose() = _gymData->_lastGoalLocation;
       //updateAgentSearchObservations();
      }

      std::vector<std::pair<Pose, int>> getTrajectoryGoals(){return _gymData->_goals;}

      bool isSearchGoalComplete(Eigen::Vector3f position){
        bool isGoalComplete = _plannerManager->isSearchGoalComplete(position, _map);
        return isGoalComplete;
      }


      

      virtual std::tuple<int, int, int, std::vector<Eigen::Vector3f>> getSearchGoals(int clusterIndex){
        std::vector<Eigen::Vector3f> goalTargets = calculateGlobalSearchGoals(clusterIndex);
        int numGoalsRemaining = goalTargets.size();
        int status = 0; 
        return std::make_tuple(numGoalsRemaining, status, clusterIndex, goalTargets);
      }

      virtual std::vector<Eigen::Vector3f> getSearchGoalsVec(int clusterIndex){
        return calculateGlobalSearchGoals(clusterIndex); 
      }

      std::vector<Eigen::Vector3f> calculateGlobalSearchGoals(int clusterIndex){
        return _plannerManager->getWorldSearchGoalsForCluster(clusterIndex);
      }

      virtual std::tuple<int, int, int,  std::vector<Eigen::Vector3f>> getTransitGoalsForCluster(int clusterIndex){
        std::vector<Eigen::Vector3f> goalTargets = calculateGlobalTransitGoalsForClusterIndex(clusterIndex);
        int numGoalsRemaining = goalTargets.size();
        int status = 0;
        return std::make_tuple(numGoalsRemaining, status, clusterIndex, goalTargets);
      }

      virtual std::vector<Eigen::Vector3f> getTransitGoalsVec(int clusterIndex){
        return calculateGlobalTransitGoalsForClusterIndex(clusterIndex);
      }

      std::vector<Eigen::Vector3f> calculateGlobalTransitGoalsForClusterIndex(int clusterIndex){
        return _plannerManager->getWorldPathToClusterFromWorldPosition(clusterIndex, _agentData->pose().position);
      }

      Eigen::ArrayXf getObservations(){return _gymData->_observationsNormalised;}
      Eigen::ArrayXf getGoalObservations(){return _gymData->_goalObs;}
      //Eigen::ArrayXf getTransitObservations(){return _gymData->_transitObs;}

      void updateAgentObservations(){
        //std::cout << "calculating collisions" << std::endl;
        // std::cout << "2" << std::endl;
        calculateCollisions();
        if(!(_gymData->_isCollided)){
          // std::cout << "2" << std::endl;
          //std::cout << "NOT COLLIDED!" << std::endl;
          //std::cout << "calculating observations" << std::endl;
          calculateEnvironmentObservations();
          // std::cout << "2" << std::endl;
          //std::cout << "normalising observations" << std::endl;
          _gymData->normalizeEnvironmentObservations();
          // std::cout << "2" << std::endl;
          //std::cout << "processing goal observations" << std::endl;
          _gymData->processTransitGoalObservations(_agentData->pose());
        // std::cout << "2" << std::endl;
        }
      }


      void updateAgentEnvironmentObservations(){
        //std::cout << "calculating collisions" << std::endl;
        calculateCollisions();
        if(!(_gymData->_isCollided)){
          //std::cout << "NOT COLLIDED!" << std::endl;
          //std::cout << "calculating observations" << std::endl;
          calculateEnvironmentObservations();
          //std::cout << "normalising observations" << std::endl;
          _gymData->normalizeEnvironmentObservations();
          //std::cout << "processing goal observations" << std::endl;
        }
      }

      void updateAgentTransitObservations(){
        //std::cout << "calculating collisions" << std::endl;
        _gymData->processTransitGoalObservations(_agentData->pose());
      }








      void updateAgentSearchObservations(){
        //std::cout << "calculating collisions" << std::endl;
        calculateCollisions();
        if(!(_gymData->_isCollided)){
          //std::cout << "NOT COLLIDED!" << std::endl;
          //std::cout << "calculating observations" << std::endl;
          calculateEnvironmentObservations();
          //std::cout << "normalising observations" << std::endl;
          _gymData->normalizeEnvironmentObservations();
          //std::cout << "processing goal observations" << std::endl;
          _gymData->processSearchGoalObservations(_agentData->pose(), _map);
        }
      }

      // Eigen::ArrayXf getObservationCloud(){
      //   for(int x = 0; _gymData->_numObs; x++){
      //     (_gymData->_observationCloud)(x*3+0) = _gymData->_observationRays.col(x)(0)*(_gymData->_observationsNormalised(x*2))*(_gymData->_lenObs)*(_gymData->_gridRes);
      //     (_gymData->_observationCloud)(x*3+1) = _gymData->_observationRays.col(x)(1)*(_gymData->_observationsNormalised(x*2))*(_gymData->_lenObs)*(_gymData->_gridRes);
      //     (_gymData->_observationCloud)(x*3+2) = _gymData->_observationRays.col(x)(2)*(_gymData->_observationsNormalised(x*2))*(_gymData->_lenObs)*(_gymData->_gridRes);
      //   }
      //   return Eigen::ArrayXf(_gymData->_observationCloud);
      // }


      Eigen::ArrayXf getObservationCloud(){return _gymData->_observationCloud;}

      bool isTerminal(){return _gymData->_isTerminal;}

      bool isCollided(){return _gymData->_isCollided;}

      bool getAgentCollision(Eigen::Vector3f updateXYZ){
        return getNextCollision(updateXYZ);
      }

      bool isGoalReached(){if(_gymData->_goalReached == true || _gymData->_goalSearched == true){
                          return true;
                          }else{
                          return false;
                          }
      }

      int& voxelCount(){return _gymData->_voxelCount;}

      void calculateEnvironmentObservations(){
        //Using constructed map from agent _map for observations, ray cast using observation rays object

        openvdb::FloatGrid::Ptr occGrid = _map->occupiedGrid();
        std::shared_ptr<openvdb::FloatGrid::Accessor> occAccPtr = _map->occAccessor();
        openvdb::math::Ray<double> ray;
        openvdb::math::DDA<openvdb::math::Ray<double> ,0> dda;
        nanomap::Pose pose = _agentData->pose();
        openvdb::Vec3d ray_origin_world(pose.position(0), pose.position(1), pose.position(2));
        openvdb::Vec3d ray_origin_index(occGrid->worldToIndex(ray_origin_world));
        openvdb::Vec3d ray_direction;
        bool max_range_ray;
        openvdb::Vec3d x;
        double ray_length;
        float max_time = _gymData->_lenObs;
        float pointx, pointy, pointz;
        Eigen::Matrix<float,3,3> rotation = pose.orientation.toRotationMatrix();

        // Raycasting of every point in the input cloud
        int numObs = _gymData->_observationRays.cols();
        for (int i = 0; i < numObs; i++)
        {
          pointx = _gymData->_observationRays.col(i)(0);
          pointy = _gymData->_observationRays.col(i)(1);
          pointz = _gymData->_observationRays.col(i)(2);
          max_range_ray = false;
          Eigen::Vector3f point(pointx, pointy, pointz);
          Eigen::Vector3f rotatedPoint = pose.orientation*point;
          ray_direction = openvdb::Vec3d(rotatedPoint(0), rotatedPoint(1), rotatedPoint(2));
          // ray_direction = openvdb::Vec3d(
          //   rotation(0,0)*pointx+rotation(0,1)*pointy+rotation(0,2)*pointz,
          //               rotation(1,0)*pointx+rotation(1,1)*pointy+rotation(1,2)*pointz,
          //               rotation(2,0)*pointx+rotation(2,1)*pointy+rotation(2,2)*pointz);
          ray_direction.normalize();
          ray.setEye(ray_origin_index);
          ray.setDir(ray_direction);
          dda.init(ray,0,max_time);
          openvdb::Coord voxel = dda.voxel();
          bool hit = false;
          //bool unknown = false;
          float voxel_value = _map->logOddsMissThreshold();
          float tempValue;
          //Step over ray, and if ray hits a voxel that isn't considered empty (voxel < logMissThreshold))
          while(dda.step()){
            voxel = dda.voxel();
            //Is voxel considered occupied?
            if(occAccPtr->isValueOn(voxel)){
              //voxel_value = occAccPtr->getValue(voxel);
              hit = true;
              _gymData->_hazardObservations(i) = dda.time();
              _gymData->_unknownObservations(i) = max_time;
              break;
            }else{
            //else is voxel considered Unknown?
            tempValue = occAccPtr->getValue(voxel);
              if(tempValue > voxel_value){
                //voxel_value = tempValue;
                // if(voxel_value == 0.0){
                //   voxel_value = 0.1;
                // }
                hit = true;
                _gymData->_hazardObservations(i) = dda.time();
                _gymData->_unknownObservations(i) = dda.time();
                break;   
              }
            //Voxel is considered empty, continue raycast
            
            }
          }
          if(hit == false){
            _gymData->_unknownObservations(i) = max_time;
            _gymData->_hazardObservations(i) = max_time;
          }
            // //Observation ray hit an occupied cell
            // if(voxel_value < _map->logOddsMissThreshold()){

            // }else if(voxel_value >= _map->logOddsMissThreshold() && voxel_value)
            // _gymData->_observations(i*2) = dda.time();
            // _gymData->_observations(i*2+1) = voxel_value;
          }
        }

      bool getNextCollision(Eigen::Vector3f updateXYZ){
        //performs collision calculate for a potential maneuvre
        //In future, might move this to calculation on the GPU, for now though CPU only. 
        //Using the sim grid ptr from _plannerManager for collisions, ray cast using observation rays
        
        //Detecting collisions with occupied voxels
        //openvdb::FloatGrid::Ptr simGrid = _simGrid;
        openvdb::FloatGrid::Accessor simGridAcc = _simGrid->getAccessor();
        openvdb::math::Ray<double> ray;
        openvdb::math::DDA<openvdb::math::Ray<double> ,0> dda;
        nanomap::Pose pose = _agentData->pose();
        pose.position.x()+=updateXYZ(0);
        pose.position.y()+=updateXYZ(1);
        pose.position.z()+=updateXYZ(2);
        // std::cout << pose.position.x() << " / " 
        //           << pose.position.y() << " / " 
        //           << pose.position.z() << " / " 
        //           << std::endl;        
        openvdb::Vec3d ray_origin_world(pose.position(0), pose.position(1), pose.position(2));
        openvdb::Vec3d ray_origin_index(_simGrid->worldToIndex(ray_origin_world));
        openvdb::Vec3d ray_direction;
        bool max_range_ray;
        openvdb::Vec3d x;
        double ray_length;
        float max_time = _gymData->_collisionDist;
        float pointx, pointy, pointz;
        Eigen::Matrix<float,3,3> rotation = pose.orientation.toRotationMatrix();
        bool hit = false;
        // Raycasting of every point in the input cloud
        for (int i = 0; i < _gymData->_observationRays.cols(); i++)
        {
          pointx = _gymData->_observationRays.col(i)(0);
          pointy = _gymData->_observationRays.col(i)(1);
          pointz = _gymData->_observationRays.col(i)(2);
          max_range_ray = false;
          ray_direction = openvdb::Vec3d(
            rotation(0,0)*pointx+rotation(0,1)*pointy+rotation(0,2)*pointz,
                        rotation(1,0)*pointx+rotation(1,1)*pointy+rotation(1,2)*pointz,
                        rotation(2,0)*pointx+rotation(2,1)*pointy+rotation(2,2)*pointz);
          //pointx = _gymData->_observationRays.col(i)(0);
          // pointy = _gymData->_observationRays.col(i)(1);
          // pointz = _gymData->_observationRays.col(i)(2);
          // max_range_ray = false;
          // Eigen::Vector3f point(pointx, pointy, pointz);
          // Eigen::Vector3f rotatedPoint = pose.orientation*point;
          // ray_direction = openvdb::Vec3d(rotatedPoint(0), rotatedPoint(1), rotatedPoint(2));
          ray_direction.normalize();
          ray.setEye(ray_origin_index);
          ray.setDir(ray_direction);
          dda.init(ray,0,max_time);
          openvdb::Coord voxel = dda.voxel();
          hit = false;
          //float value = _map->logOddsMissThreshold();
          //float tempValue;
          //Step over ray, and if ray hits a voxel that isn't considered empty (voxel < logMissThreshold))
          while(dda.step()){
            voxel = dda.voxel();
            //Is voxel considered occupied?
            if(simGridAcc.isValueOn(voxel)){
              hit = true;
              break;
            }
          }
          if(hit == true){
            return hit;
          }
        }
        return hit;
      }      

      void calculateCollisions(){
        //In future, might move this to calculation on the GPU, for now though CPU only. 
        //Using the sim grid ptr from _plannerManager for collisions, ray cast using observation rays
        
        //Detecting collisions with occupied voxels
        //openvdb::FloatGrid::Ptr simGrid = _simGrid;
        openvdb::FloatGrid::Accessor simGridAcc = _simGrid->getAccessor();
        openvdb::math::Ray<double> ray;
        openvdb::math::DDA<openvdb::math::Ray<double> ,0> dda;
        nanomap::Pose pose = _agentData->pose();
        openvdb::Vec3d ray_origin_world(pose.position(0), pose.position(1), pose.position(2));
        openvdb::Vec3d ray_origin_index(_simGrid->worldToIndex(ray_origin_world));
        openvdb::Vec3d ray_direction;
        bool max_range_ray;
        openvdb::Vec3d x;
        double ray_length;
        float max_time = _gymData->_collisionDist;
        float pointx, pointy, pointz;
        Eigen::Matrix<float,3,3> rotation = pose.orientation.toRotationMatrix();
        _gymData->_isCollided = false;
        _gymData->_isTerminal = false;
        // Raycasting of every point in the input cloud
        for (int i = 0; i < _gymData->_observationRays.cols(); i++)
        {
          pointx = _gymData->_observationRays.col(i)(0);
          pointy = _gymData->_observationRays.col(i)(1);
          pointz = _gymData->_observationRays.col(i)(2);
          max_range_ray = false;
          ray_direction = openvdb::Vec3d(
            rotation(0,0)*pointx+rotation(0,1)*pointy+rotation(0,2)*pointz,
                        rotation(1,0)*pointx+rotation(1,1)*pointy+rotation(1,2)*pointz,
                        rotation(2,0)*pointx+rotation(2,1)*pointy+rotation(2,2)*pointz);
          //pointx = _gymData->_observationRays.col(i)(0);
          // pointy = _gymData->_observationRays.col(i)(1);
          // pointz = _gymData->_observationRays.col(i)(2);
          // max_range_ray = false;
          // Eigen::Vector3f point(pointx, pointy, pointz);
          // Eigen::Vector3f rotatedPoint = pose.orientation*point;
          // ray_direction = openvdb::Vec3d(rotatedPoint(0), rotatedPoint(1), rotatedPoint(2));
          ray_direction.normalize();
          ray.setEye(ray_origin_index);
          ray.setDir(ray_direction);
          dda.init(ray,0,max_time);
          openvdb::Coord voxel = dda.voxel();
          bool hit = false;
          //float value = _map->logOddsMissThreshold();
          //float tempValue;
          //Step over ray, and if ray hits a voxel that isn't considered empty (voxel < logMissThreshold))
          while(dda.step()){
            voxel = dda.voxel();
            //Is voxel considered occupied?
            if(simGridAcc.isValueOn(voxel)){
              hit = true;
              break;
            }
          }
          if(hit == true){
            _gymData->_isCollided = true;
            _gymData->_isTerminal = true;
            break;
          }
        }
      }

    void setPriorKnowledge(float radius, openvdb::FloatGrid::Ptr grid){
      if(radius <= 0.0){
        setPriorKnowledge(grid);
      }else{
        //get the bounding box that encloses the sphere of with size radius.
        //Loop over all voxels in provided grid. 
        //Check distance between voxel and agent Pose. 
        //If less than radius, perform check active state and value
        //  if active, set them as obstacle. 
        //  if not active, and value < 0.0, set as free. 
        float occThreshold = _map->occupiedClampingThreshold();
        float emptyThreshold = _map->emptyClampingThreshold();
        auto setObstacle = [occThreshold](float& voxel_value, bool& active) {
          voxel_value = occThreshold;
          active = true;
        };
        auto setFree = [emptyThreshold](float& voxel_value, bool& active) {
          voxel_value = emptyThreshold;
          active = false;
        };
        openvdb::Coord voxelOffset = openvdb::Coord::round(grid->worldToIndex(openvdb::Vec3d(radius, radius, radius)));
        openvdb::Vec3d vecPose = openvdb::Vec3d(_agentData->pose().position(0),_agentData->pose().position(1),_agentData->pose().position(2));
        openvdb::Coord voxelPose = openvdb::Coord::round(grid->worldToIndex(vecPose));
        openvdb::Coord minimumCoord = voxelPose-voxelOffset;
        openvdb::Coord maximumCoord = voxelPose+voxelOffset;
        openvdb::CoordBBox bbox(minimumCoord, maximumCoord);
        auto newacc = grid->getAccessor();
        std::set<LeafNodeT*> visitedLeafNodes;
        for(auto iter = bbox.begin(); iter != bbox.end(); ++iter){
          //Check distance from pose
          openvdb::Vec3d position = grid->indexToWorld(*iter);
          if((vecPose-position).length()<radius){
            //Voxel is close enough
            //check the value of the voxel
            float value;
            if(newacc.probeValue(*iter,value)){
              //voxel is on, and is therefore an obstacle
              visitedLeafNodes.insert(_map->knownAccessor()->touchLeaf(*iter));
              _map->knownAccessor()->setValueOn(*iter);
              _map->occAccessor()->modifyValueAndActiveState(*iter, setObstacle);
            }else if(value < 0.0){
              //Voxel isn't on and has the value required to be considered known free space.
              visitedLeafNodes.insert(_map->knownAccessor()->touchLeaf(*iter));
              _map->knownAccessor()->setValueOn(*iter); 
              _map->occAccessor()->modifyValueAndActiveState(*iter, setFree);  
            }
          }
        }
        int totalVoxelCount = 8*8*8;
        for(auto leafPointer : visitedLeafNodes){
          int knownVoxelCount = leafPointer->onVoxelCount();
          float knownRatio = (float)knownVoxelCount/(float)totalVoxelCount;
          if(knownRatio > 0.85){
                    //         openvdb::Coord indexCoord = openvdb::Coord(iter.getCoord().x()/_plannerConfig->leafEdge, 
        //                                                   iter.getCoord().y()/_plannerConfig->leafEdge, 
        //                                                   iter.getCoord().z()/_plannerConfig->leafEdge);
        //         //In a tile/leaf, do planner map construction logic.
        //         //auto worldCoord = targetGrid->indexToWorld(iter.getCoord());
        //         //openvdb::Coord indexCoord = openvdb::Coord(std::floor(_plannerGrid->worldToIndex(worldCoord).x()),
        //         //                                          std::floor(_plannerGrid->worldToIndex(worldCoord).y()),
        //         //                                          std::floor(_plannerGrid->worldToIndex(worldCoord).z()));
            // openvdb::Coord indexCoord = leafPointer->getNodeBoundingBox().min();
            // auto worldSpaceCoord = _map->knownGrid()->indexToWorld(indexCoord);
            // openvdb::Coord searchSpaceCoord = openvdb::Coord(std::floor(_map->searchGrid()->worldToIndex(worldSpaceCoord).x()),
            //                                                  std::floor(_map->searchGrid()->worldToIndex(worldSpaceCoord).y()),
            //                                                   std::floor(_map->searchGrid()->worldToIndex(worldSpaceCoord).z()));
            openvdb::Coord indexCoord = leafPointer->getNodeBoundingBox().min();
            openvdb::Coord searchCoord = openvdb::Coord(indexCoord.x()/8, 
                                          indexCoord.y()/8, 
                                          indexCoord.z()/8);
            _map->searchAccessor()->setValueOn(searchCoord);
          }
        }
      }
    }

    void setPriorKnowledge(openvdb::FloatGrid::Ptr grid){
      //For the sim grids the agent assumes unoccupied cells have negative value
      //loop over all values in the sim grid and set the corresponding agent map voxels as obstacles or free
      //depending on whether they are free or occupied. 
      //This is expensive. We don't usually want to call this method. 
        float occThreshold = _map->occupiedClampingThreshold();
        float emptyThreshold = _map->emptyClampingThreshold();
        auto setObstacle = [occThreshold](float& voxel_value, bool& active) {
          voxel_value = occThreshold;
          active = true;
        };
        auto setFree = [emptyThreshold](float& voxel_value, bool& active) {
          voxel_value = emptyThreshold;
          active = false;
        };
        auto newacc = grid->getAccessor();

        openvdb::FloatGrid::ValueOnIter oniter = grid->beginValueOn();

          for (oniter; oniter.test(); ++oniter) {

            _map->occAccessor()->modifyValueAndActiveState(oniter.getCoord(), setObstacle);

          }
          openvdb::FloatGrid::ValueOffIter offiter = grid->beginValueOff();
          for (offiter; offiter.test(); ++offiter) {

            if(newacc.getValue(offiter.getCoord()) < 0.0){
              //std::cout << newacc.getValue(offiter.getCoord()) << std::endl;
              _map->occAccessor()->modifyValueAndActiveState(offiter.getCoord(), setFree);
            }
          }
    }

    protected:

      std::shared_ptr<nanomap::manager::PlannerManager> _plannerManager;

      openvdb::FloatGrid::Ptr _simGrid;

      std::shared_ptr<nanomap::agent::GymData> _gymData;

    };
  }
}
#endif
