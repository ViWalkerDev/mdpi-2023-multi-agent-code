// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Agent.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_AGENT_GYMDATA_H_INCLUDED
#define NANOMAP_AGENT_GYMDATA_H_INCLUDED
#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
#include <iomanip>
#include <chrono>
#include <iostream>
#include <string>

#include "nanomap/map/Map.h"
#include "nanomap/nanomap.h"


/******************************************************************************
This class defines a basic agent. It is used for single body UAVs with one or
more FIXED sensors and doesn't currently contain more advanced robotics kinematics like
Joint and Link definitions. update the UAV pose, then use the class to update the
sensor poses and pass a map file to the sensors to update the map with the new
sensor views. This also uses a map file to generate observation distances for
deeprl. Rays for an agent are generally loaded from a file and are precomputed.
however, a spherical observation sphere of radius r is generated if file not provided.
*******************************************************************************/

namespace nanomap{
  namespace agent{


  using ValueT  = float;


  using EigenVec = Eigen::Matrix<ValueT, 3, 1>;
  using EigenMat = Eigen::Matrix<ValueT, 3, 3>;
  using Quaternion = Eigen::Quaternion<ValueT>;

  class GymData{

    public:
      Agent(openvdb::FloatGrid::Ptr& simGrid, std::string agentFile,
          float mappingRes, float gridRes, float probHitThres, float probMissThres)
          :_mappingRes(mappingRes)
          ,_gridRes(gridRes)
          ,_probHitThres(probHitThres)
          ,_probMissThres(probMissThres)
        {

        _lenObs = lenObs;////_mappingRes;
        _numObs = numObs;
        _collisionDist = (float)(collisionDist/_gridRes);
        _observationRays(3,_numObs);
        _observationNorms(2,_numObs);
        _observations(_numObs*2);
        _collisions(_numObs);
        generateObservationSphere(_numObs, _collisionDist, _lenObs,
                                                     _observationRays, _observationNorms);
      }
      void updatePose(Pose pose){
        _pose = pose;
        int index = 0;
        Eigen::Matrix<float, 3, 3> defaultFrameTransform;
        for(auto itr = _sensorOrigins.begin(); itr != _sensorOrigins.end(); itr++){
          index = std::distance(_sensorOrigins.begin(), itr);
          _sensorPoses[index].position = _pose.position;
          _sensorPoses[index].orientation = _pose.orientation*((*itr).orientation);
        }
      }

      Eigen::Vector3f sphericalCoordinate(float x, float y){
        Eigen::Vector3f point;
        point(0)= std::cos(x)*std::cos(y);
        point(1)= std::sin(x)*std::cos(y);
        point(2)= std::sin(y);
        return point;
      }

      Eigen::Matrix<float,3,Eigen::Dynamic> normalisedSphere(int n, float x){
        Eigen::Matrix<float, 3, Eigen::Dynamic> sphere_points(3,n);
        float start = (-1.0+1.0/(n-1.0));
        float increment = (2.0-2.0/(n-1.0))/(n-1.0);
        float s,j,k;
        for(int i = 0; i < n; i++){
          s = start+i*increment;
          j = s*x;
          k = (M_PI/2.0)*std::copysign(1.0,s)*(1.0-std::sqrt(1.0-std::abs(s)));
          sphere_points.col(i) = sphericalCoordinate(j, k);
          sphere_points.col(i).normalize();
        }
        return sphere_points;
      }





          Eigen::Matrix<float, 3, Eigen::Dynamic> generateSphere(int n){
            //std::cout << "1" << std::endl;

            return normalisedSphere(n, (0.1+1.2*n));
          }




          void generateObservationSphere(int numObs, float collisionDist, float lenObs,
                                                Eigen::Matrix<float, 3, Eigen::Dynamic>& observationRays,
                                                Eigen::Matrix<float, 2, Eigen::Dynamic>& observationNorms){
            observationRays = generateSphere(numObs);
            Eigen::Matrix<float, 2, Eigen::Dynamic> norms(2,numObs);
            for(int x = 0; x < numObs; x++){
              norms.col(x) = Eigen::Matrix<float, 2, 1>(collisionDist,lenObs);
            }
            observationNorms = norms;
          }

      Pose pose(){return _pose;}

      std::vector<Pose> sensorOrigins(){return _sensorOrigins;}
      std::vector<Pose> sensorPoses(){return _sensorPoses;}
      void clearSensors(){_sensorPoses.clear();
                          _sensorNames.clear();
                          _sensorOrigins.clear();}

      void updateAgentCollisions(){
        _isCollided = false;
        for(int x = 0; x < _numObs; x++){
          if(_collisions(x)*_gridRes < 0.2){
            _isCollided = true;
            _isTerminal = true;
            return;
          }
        }
      }

      void normalizeDistObservations(){
          float voxelDistLength = _lenObs/_mappingRes;
          for(int x = 0; x < _numObs; x++){
            _observations(x) = (_observations(x)*2-voxelDistLength)/voxelDistLength;
            if(_observations(x)>1.0){
              _observations(x) = 1.0;
            }else{
              if(_observations(x)<-1.0){
                _observations(x) = -1.0;
              }
            }
          }
      }


      void processGoalObservations(){
        updateDeltas();
        //Check to see if goal reached.
        _goalReached = false;
        _isTerminal = false;
        if(isGoalReached()){
          _goalReached = true;
          //If goal reached update trajectory goals and reward
          _isTerminal = getNewGoal();
          if(!_isTerminal){
            updateDeltas();
            updateGoalObservations();
          }
        }else{
          updateGoalObservations();
        
        }
      }

      bool getNewGoal(){
        bool newGoal = false;
        if(_trajectoryGoals.size()>1){
          _lastGoalLocation = _trajectoryGoals[0].first;
          _trajectoryGoals.erase(_trajectoryGoals.begin());
          newGoal = true;
        }
        return newGoal;
      }
      
      void updateGoalObservations(){
        _goalObs(0) = _targetDeltaPose.position(0)/5.0; // target x delta
        _goalObs(1) = _targetDeltaPose.position(1)/5.0; // target y delta
        _goalObs(2) = _targetDeltaPose.position(2)/5.0; // target y delta
        _goalObs(3) = _targetRotationDelta.w(); // target quat w delta
        _goalObs(4) = _targetRotationDelta.x(); // target quat x delta
        _goalObs(5) = _targetRotationDelta.y(); // target quat y delta
        _goalObs(6) = _targetRotationDelta.z(); // target quat z delta
        if(_trajectoryGoals[0].second == 1){
          _goalObs(7) = 1; // target rotation flag
        }else{
          _goalObs(7) = 0;
        }
        _goalObs(8) = _preferredDeltaPose.position(0);//preferred x delta
        _goalObs(9) = _preferredDeltaPose.position(1);//preferred y delta
        _goalObs(10) = _preferredDeltaPose.position(2); //preferred z delta
        for(int x = 0; x < 11; x++){
          if(_goalObs(x) > 1.0){
            _goalObs(x) = 1.0;
          }else if(_goalObs(x) < -1.0){
            _goalObs(x) = -1.0;
          }
        }
      }

      bool isGoalReached(){
        if(std::abs(_targetDeltaPose.position(0)) < 0.1 && 
            std::abs(_targetDeltaPose.position(1)) < 0.1 &&
            std::abs(_targetDeltaPose.position(2)) < 0.1){
          //GOAL IS REACHED! NOW WE CHECK TO SEE IF IT IS A TRAJECTORY GOAL
          
          if(_trajectoryGoals[0].second == 1){
            //We have to check if orientation is reached
            float quatDiff = std::abs(_trajectoryGoals[0].first.orientation.dot(_pose.orientation)); 
            if(quatDiff <= 1-0.05){
              //Trajectory OrientationDoesn't Match
              return false;
            }
          }
          //Goals reached return true
          return true;
        }else{
          return false;
        }
      }

      void updateDeltas(){
        //Deltas are in local UAV space, and so must be calculated according to the agent orientation
        //This means rotating the global space coordinate by the
        //Get closest point on preferred path 
        EigenVec pointOnPath;
        EigenVec path = _trajectoryGoals[0].first.position - _lastGoalLocation.position;
        EigenVec pointInPathSpace = _pose.position - _lastGoalLocation.position;
        float pathLength = path.norm();
        float t = pointInPathSpace.dot(path)/pathLength;
        if(t<0){
          t = 0.0;
        }else if(t>1){
          t = 1.0;
        }
        pointOnPath = _lastGoalLocation.position+t*path;

        EigenVec worldTargetDelta;
        EigenVec localTargetDelta;
        EigenVec worldPreferredDelta;
        EigenVec localPreferredDelta;
        EigenMat inverseRotation = _pose.orientation.toRotationMatrix().transpose();
        //float yawTargetDelta = 0.0;
        _targetRotationDelta = Eigen::Quaternionf(1,0,0,0);
        //GET world space delta for target and preferred path 
        worldTargetDelta = _trajectoryGoals[0].first.position - _pose.position;
        worldPreferredDelta = pointOnPath - _pose.position;
        //Then rotate world space delta by the inverse of the agent pose.
        localTargetDelta = worldTargetDelta.transpose()*inverseRotation;
        localPreferredDelta = worldPreferredDelta.transpose()*inverseRotation;
        _previousDeltaPose.position = _targetDeltaPose.position;
        _targetDeltaPose.position = localTargetDelta;
        _preferredDeltaPose.position = localPreferredDelta;
        _deltaChange = _previousDeltaPose.position.norm() - _targetDeltaPose.position.norm();
        //This gives the delta in the agent space. 
        //Then we need the delta for the target yaw but only if it exists
        if(_trajectoryGoals[0].second == 1){
          //Rotation diff = Final orientiation*currentorientation^-1
          _targetRotationDelta = 
                    _trajectoryGoals[0].first.orientation*_pose.orientation.inverse();
          _targetRotationDelta.normalize();
        }
      }

      void clearObservationRays(){ _observationNorms.resize(0,0);
                                    _observationRays.resize(0,0);}
      Eigen::Matrix<float, 3, Eigen::Dynamic> observationRays(){return _observationRays;}
      Eigen::Matrix<float, 2, Eigen::Dynamic> observationNorms(){return _observationNorms;}
      void resetAgent(){clearSensors();
                        clearObservationRays();}
      Pose sensorPose(int index){return _sensorPoses[index];}

      std::shared_ptr<Map> map(){return _map;}
      std::vector<std::string> sensorNames() {return _sensorNames;}
      int getId(){return _agentId;}
      std::string getName(){return _agentName;}
      bool spawnRandom(){return _spawnRandom;}
      Eigen::Matrix<float, 3, Eigen::Dynamic> _observationRays;
      //goal obs are:
      // x, y, z delta from target position, and quaternion delta from target heading, flag for if yaw matters for reward
      // x, y, z, delta from closest position on target path
      // 3 + 4 + 1 +3
      Eigen::Array<float, 11, 1> _goalObs;
      Eigen::ArrayXd _observations;
      Eigen::ArrayXd _collisions;
      float _collisionDist;
      int _numObs;
      float _lenObs;
      float _gridRes, _mappingRes, _probHitThres, _probMissThres;
      Pose _pose;
      Eigen::Quaternionf _targetRotationDelta;
      Pose _targetDeltaPose;
      Pose _previousDeltaPose;
      float _deltaChange;
      Pose _preferredDeltaPose;
      //float _reward;
      //float _goalReachedReward;
      //float _approachingReward;
      //float _pathReward;
      bool _intermediateGoalReached = false;
      bool _finalGoalReached = false;
      //Eigen::ArrayXd<float> _goalObs;
      bool _goalReached;
      bool _isTerminal;
      bool _isCollided;
      Pose _lastGoalLocation;
      std::vector<std::pair<Pose, int>> _trajectoryGoals;
    protected:
      std::string _agentName;
      int _agentId;

      

      bool _spawnRandom;

      Eigen::Matrix<float, 2, Eigen::Dynamic> _observationNorms;
      
      

      std::vector<std::string> _sensorNames;
      std::vector<Pose> _sensorOrigins;
      std::vector<Pose> _sensorPoses;
      std::shared_ptr<Map> _map;

    };
  }
}
#endif
