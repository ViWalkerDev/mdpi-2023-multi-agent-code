// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Agent.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_AGENT_GYMDATA_H_INCLUDED
#define NANOMAP_AGENT_GYMDATA_H_INCLUDED
#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
#include <iomanip>
#include <chrono>
#include <iostream>
#include <string>
#include "nanomap/manager/PlannerManager.h"
#include "nanomap/map/Map.h"
#include "nanomap/nanomap.h"



/******************************************************************************
This class defines a basic agent. It is used for single body UAVs with one or
more FIXED sensors and doesn't currently contain more advanced robotics kinematics like
Joint and Link definitions. update the UAV pose, then use the class to update the
sensor poses and pass a map file to the sensors to update the map with the new
sensor views. This also uses a map file to generate observation distances for
deeprl. Rays for an agent are generally loaded from a file and are precomputed.
however, a spherical observation sphere of radius r is generated if file not provided.
*******************************************************************************/

namespace nanomap{
  namespace agent{


  using ValueT  = float;


  using EigenVec = Eigen::Matrix<ValueT, 3, 1>;
  using EigenMat = Eigen::Matrix<ValueT, 3, 3>;
  using Quaternion = Eigen::Quaternion<ValueT>;

  class GymData{
    public:

      GymData(int numObs, float lenObs, float collisionDist, float gridRes, int minPathSteps)
          :_numObs(numObs)
          ,_lenObs((float)(lenObs/gridRes))
          ,_collisionDist((float)(collisionDist/gridRes))
          ,_gridRes(gridRes)
          ,_minPathSteps(minPathSteps)
          ,_plannerManager(NULL)
        {
        _observationRays.resize(3,_numObs);
        _observationNorms.resize(2,_numObs);
        _hazardObservations.resize(_numObs);
        _unknownObservations.resize(_numObs);
        _observationsNormalised.resize(_numObs*2);

        //_observationCloud = std::make_shared<Eigen::ArrayXf>(Eigen::ArrayXf(_numObs*3));
        _observationCloud.resize(_numObs*6);
        _collisions.resize(_numObs);
        generateObservationSphere(_numObs, _collisionDist, _lenObs,
                                                     _observationRays, _observationNorms);
      }

      Eigen::Vector3f sphericalCoordinate(float x, float y){
        Eigen::Vector3f point;
        point(0)= std::cos(x)*std::cos(y);
        point(1)= std::sin(x)*std::cos(y);
        point(2)= std::sin(y);
        return point;
      }

      Eigen::Matrix<float,3,Eigen::Dynamic> normalisedSphere(int n, float x){
        Eigen::Matrix<float, 3, Eigen::Dynamic> sphere_points(3,n);
        float start = (-1.0+1.0/(n-1.0));
        float increment = (2.0-2.0/(n-1.0))/(n-1.0);
        float s,j,k;
        for(int i = 0; i < n; i++){
          s = start+i*increment;
          j = s*x;
          k = (M_PI/2.0)*std::copysign(1.0,s)*(1.0-std::sqrt(1.0-std::abs(s)));
          sphere_points.col(i) = sphericalCoordinate(j, k);
          sphere_points.col(i).normalize();
        }
        return sphere_points;
      }





      Eigen::Matrix<float, 3, Eigen::Dynamic> generateSphere(int n){
            //std::cout << "1" << std::endl;

          return normalisedSphere(n, (0.1+1.2*n));
      }

      void generateObservationSphere(int numObs, float collisionDist, float lenObs,
                                            Eigen::Matrix<float, 3, Eigen::Dynamic>& observationRays,
                                            Eigen::Matrix<float, 2, Eigen::Dynamic>& observationNorms){
        observationRays = generateSphere(numObs);
        Eigen::Matrix<float, 2, Eigen::Dynamic> norms(2,numObs);
        for(int x = 0; x < numObs; x++){
          norms.col(x) = Eigen::Matrix<float, 2, 1>(collisionDist,lenObs);
        }
        observationNorms = norms;
      }

      // void updateAgentCollisions(){
      //   _isCollided = false;
      //   for(int x = 0; x < _numObs; x++){
      //     if(_collisions(x)*_gridRes < 0.2){
      //       _isCollided = true;
      //       _isTerminal = true;
      //       return;
      //     }
      //   }
      // }

      // void normalizeDistObservations(){
      //     float voxelDistLength = _lenObs/_gridRes;
      //     for(int x = 0; x < _numObs; x++){
      //       _observations(x) = (_observations(x)*2-voxelDistLength)/voxelDistLength;
      //       if(_observations(x)>1.0){
      //         _observations(x) = 1.0;
      //       }else{
      //         if(_observations(x)<-1.0){
      //           _observations(x) = -1.0;
      //         }
      //       }
      //     }
      // }
      void normalizeEnvironmentObservations(){
        float value;
        bool _isTooCloseToHazard = false;
        //std::cout << "_numObs = " << _numObs << std::endl;
        //std::cout << "_lenObservations = " << _observations.cols() << std::endl;
        //std::cout << "_lenObservations = " << _observations.rows() << std::endl;
        for(int x = 0; x < _numObs; x++){
          //Distance Measurements
          //value = _observations(x)-_collisionDist;
          value = _unknownObservations(x);
          _observationsNormalised(x) = (value/_lenObs);        
          if(_observationsNormalised(x) < 0.0){
            _observationsNormalised(x) = 0.0;
          }else if(_observationsNormalised(x) > 1.0){
            _observationsNormalised(x) = 1.0;
          }
        }
        for(int x = 0; x < _numObs; x++){
          //Distance Measurements
          //value = _observations(x)-_collisionDist;
          value = _hazardObservations(x);
          _observationsNormalised(_numObs+x) = (value/_lenObs);        
          if(_observationsNormalised(_numObs+x) < 0.0){
            _observationsNormalised(_numObs+x) = 0.0;
          }else if(_observationsNormalised(_numObs+x) > 1.0){
            _observationsNormalised(_numObs+x) = 1.0;
          }
          
        }
        // float offsetClamp = occClamp - missThreshold;
        // //std::cout << "offsetClamp = " << offsetClamp << std::endl;
        // //std::cout << "occClamp = " << occClamp << std::endl;
        // //std::cout << "missThres = " << missThreshold << std::endl;
        // for(int x = 1; x < _numObs*2; x+=2){
        //   value = _observations(x)-missThreshold;
        //   _observationsNormalised(x) = (value/offsetClamp)*2-1.0;
        //   if(_observationsNormalised(x) < -1.0){
        //     _observationsNormalised(x) = -1.0;
        //   }else if(_observationsNormalised(x) > 1.0){
        //     _observationsNormalised(x) = 1.0;
        //   }
        // }
        for(int x = 0; x < _numObs; x++){
          (_observationCloud)(x*3+0) = _observationRays.col(x)(0)*(_unknownObservations(x))*(_gridRes);
          (_observationCloud)(x*3+1) = _observationRays.col(x)(1)*(_unknownObservations(x))*(_gridRes);
          (_observationCloud)(x*3+2) = _observationRays.col(x)(2)*(_unknownObservations(x))*(_gridRes);

          (_observationCloud)(_numObs*3+(x*3+0)) = _observationRays.col(x)(0)*(_hazardObservations(x))*(_gridRes);
          (_observationCloud)(_numObs*3+(x*3+1)) = _observationRays.col(x)(1)*(_hazardObservations(x))*(_gridRes);
          (_observationCloud)(_numObs*3+(x*3+2)) = _observationRays.col(x)(2)*(_hazardObservations(x))*(_gridRes);
        }
      }

      // void processTransitGoalObservations(nanomap::Pose pose){
      //   //std::cout << "updating deltas for provided pose" << std::endl;
      //   updateDeltas(pose);
      //   //Check to see if goal reached.
      //   _goalReached = false;
      //   _isTerminal = false;
      //   if(isGoalReached()){
      //     _goalReached = true;
      //     //If goal reached update trajectory goals and reward
      //     //_isTerminal = !getNewGoal();
      //     //if(!_isTerminal){
      //     updateDeltas(pose);
      //     updateGoalObservations();
      //     //}
      //   }else{
      //     updateGoalObservations();
        
      //   }
      // }

      int _startIndex, _destIndex, _currentCluster, _targetCluster, _targetClusterIndex;
      EigenVec _destPosition, _targetBoundaryAverage;
      std::vector<int> _clusterPath;
      EigenVec _transitGoal;
      void getNewTransitGoal(EigenVec position){
        _startIndex = _plannerManager->getGlobalIndexFromPosition(position);
        _destIndex = _plannerManager->getRandomDestinationWithMinDistanceAndPosition(15.0, position);
        _destPosition = _plannerManager->getPositionFromGlobalIndex(_destIndex);
        _clusterPath = _plannerManager->clusterPathBetweenGlobalIndexPair(_startIndex, _destIndex);
        _currentCluster = _plannerManager->getClusterFromPosition(position);
        int targetClusterIndex = 0;
        for(int cluster : _clusterPath){
          if(cluster != _currentCluster){
            _targetCluster = cluster;
            _targetClusterIndex = targetClusterIndex; 
            break;
          }
          targetClusterIndex++;
          _transitGoal = _plannerManager->getClusterBoundaryAverage(_targetCluster);
        }

      }

      std::pair<bool, bool> isTransitGoalReached(EigenVec position){
        _currentCluster =  _plannerManager->getClusterFromPosition(position);
        bool smallGoalReached = false;
        if(_targetCluster == _currentCluster){
          if(_targetCluster==_clusterPath.back()){
            //final cluster
            _transitGoal = _destPosition;
          }else{
            smallGoalReached = true;
            _targetClusterIndex++;
            _targetCluster = _clusterPath[_targetClusterIndex];
            _transitGoal = _plannerManager->getClusterBoundaryAverage(_targetCluster);
            
          }
        }
        if((_destPosition-position).norm() < 1.0){
          return std::make_pair(smallGoalReached, true);
        }else{
          return std::make_pair(smallGoalReached, false);
        }
      }



      void processTransitGoalObservations(nanomap::Pose pose){
        //std::cout << "updating deltas for provided pose" << std::endl;
        //updateDeltas(pose);
        //Check to see if goal reached.
        _goalReached = false;
        _isTerminal = false;
        //std::cout << "here1" << std::endl;
        bool smallGoalReached, finalGoalReached;
        std::tie(smallGoalReached, finalGoalReached) = isTransitGoalReached(pose.position);
        if(smallGoalReached){
          _goalReached = true;
          if(finalGoalReached){
            getNewTransitGoal(pose.position);
          }//If goal reached update trajectory goals and reward
          //_isTerminal = !getNewGoal();
          //if(!_isTerminal){
          //}
        }
        //std::cout << "here2" << std::endl;
        updateTransitDeltas(pose);
        //std::cout << "here3" << std::endl;
        updateTransitGoalObservations();
          
      }

      


      void processSearchGoalObservations(nanomap::Pose pose, std::shared_ptr<nanomap::map::Map> map){
        //std::cout << "updating deltas for provided pose" << std::endl;
        //updateSearchDeltas(pose);
        //Check to see if goal reached.
        //_goalSearched = false;
        //_isTerminal = false; 
        //_needsMapReset = false;
        // if(isGoalSearched(map)){
        //   _goalSearched = true;
        //   bool newGoal = getNewSearchGoal(pose);
        //   _needsMapReset = !newGoal;
        //   // if(!newGoal){
        //   //   map->clearMap();
        //   // }
        //   //If goal reached update trajectory goals and reward
        //   //_isTerminal = !getNewGoal();
        //   //if(!_isTerminal){
        //   updateSearchDeltas(pose);
        //   updateSearchGoalObservations();
        //   //}
        // }else{
        updateSearchTargets(pose, map);
        updateSearchDeltas(pose);
        updateSearchGoalObservations();
        
        }
        //return _needsMapReset; 

      void trimCloseGoals(){
        std::vector<std::pair<Pose, int>> newTrajectoryGoals;
        newTrajectoryGoals.push_back(_goals[0]);
        Pose currentGoal = newTrajectoryGoals[0].first;
        int newGoalCount = 1;
        for(int x = 1; x < _goals.size(); x++){
          Eigen::Vector3f poseDelta = _goals[x].first.position - currentGoal.position;
          if(poseDelta.norm() >= 0.9){
            newTrajectoryGoals.push_back(_goals[x]);
            currentGoal = newTrajectoryGoals[newGoalCount].first;
            newGoalCount++;
          }
        }
        _goals = newTrajectoryGoals;
        if(_goals.size() < 4){
          getNewGoal();
        }
      }

      int getNearestSearchGoalIndex(Eigen::Vector3f position){
        int nearestSearchGoalIndex = -1;
        float nearestGoalDist = FLT_MAX;
        int goalIndex = 0;
        for(auto goalPair : _goals){
          Eigen::Vector3f goalPosition = goalPair.first.position;
          float dist = _plannerManager->getDistanceBetweenPositions(position, goalPosition);
          if(dist < nearestGoalDist){
            nearestSearchGoalIndex = goalIndex;
            nearestGoalDist = dist;
          }
          goalIndex++;
        }
        return nearestSearchGoalIndex;
      }

      bool getNewSearchGoal(nanomap::Pose pose){
        bool newGoal = true;
        // //std::cout << "Trajectory Size = " << _goals.size() << std::endl;
        // if(_goals.size()>1){
  
        //   _lastGoalLocation = _goals[_searchGoalIndex].first;
        //   _goals.erase(_goals.begin()+_searchGoalIndex);
        //   _searchGoalIndex = getNearestSearchGoalIndex(pose.position);
        // }else{
        //   //We serached all the goals in this cluster. 
        //   _previousCluster = _currentCluster;
        //   _searchedClusters.insert(_currentCluster);
        //   std::vector<int> neighbourClusters = _plannerManager->getClusterNeighbours(_currentCluster);
        //   std::vector<int> unsearchedNeighbours;
        //   for(int x = 0; x < neighbourClusters.size(); x++){
        //     //if neighbour cluster isn't already searched add to unsearched neighbours
        //     if(_searchedClusters.find(neighbourClusters[x]) == _searchedClusters.end()){
        //       unsearchedNeighbours.push_back(neighbourClusters[x]);
        //     }
        //   }
        //   if(unsearchedNeighbours.size() == 0){
        //     return false;
        //   }
        //   //_lastGoalLocation = _goals[0].first;
        //   //_goals.erase(_goals.begin());
        //   //nanomap::Pose currentFinalGoal = _goals[0].first;
        //   //int finalGoalCoord = _plannerManager->getGlobalIndexFromCoord(_plannerManager->getPlannerCoordFromWorldVec(openvdb::Vec3d(currentFinalGoal.position.x(),
        //   //                                                                                currentFinalGoal.position.y(),
        //   //                                                                                currentFinalGoal.position.z()))); 
        //   int closestCluster = _plannerManager->getNearestClusterFromList(pose.position, unsearchedNeighbours);
        //   _currentCluster = closestCluster;
        //   std::vector<Eigen::Vector3f> newSearchGoals = _plannerManager->getClusterSearchNodesInWorld(_currentCluster);
          

        //   // std::vector<std::pair<Pose, int>> newTrajectory = _plannerManager->getRandomPathWithStart(8, finalGoalCoord);
        //   _goals.clear();
        //   for(auto position : newSearchGoals){
        //     nanomap::Pose goalPose;
        //     goalPose.position = position;
        //     _goals.push_back(std::make_pair(goalPose, 0));
        //   }
        //   _searchGoalIndex = getNearestSearchGoalIndex(pose.position);
        //   //trimCloseGoals();
        // }
        return newGoal;
      }

      bool getNewGoal(){
        bool newGoal = true;
        //std::cout << "Trajectory Size = " << _goals.size() << std::endl;
        if(_goals.size()>2){
          _lastGoalLocation = _goals[0].first;
          _goals.erase(_goals.begin());
        }else{
          _lastGoalLocation = _goals[0].first;
          _goals.erase(_goals.begin());
          nanomap::Pose currentFinalGoal = _goals[0].first;
          int finalGoalCoord = _plannerManager->getGlobalIndexFromCoord(_plannerManager->getPlannerCoordFromWorldVec(openvdb::Vec3d(currentFinalGoal.position.x(),
                                                                                          currentFinalGoal.position.y(),
                                                                                          currentFinalGoal.position.z()))); 
          std::vector<std::pair<Pose, int>> newTrajectory = _plannerManager->getRandomPathWithStart(8, finalGoalCoord);
          for(int x = 0; x < newTrajectory.size(); x++){
            _goals.push_back(newTrajectory[x]);
          }
          //trimCloseGoals();
        }
        return newGoal;
      }
      
      void updateTransitGoalObservations(){
        _goalObs(0) = _transitDelta(0)/20.0;
        _goalObs(1) = _transitDelta(1)/20.0;
        _goalObs(2) = _transitDelta(2)/20.0;
        for(int x = 0; x < 3; x++){
          if(_goalObs(x) > 1.0){
            _goalObs(x) = 1.0;
          }else if(_goalObs(x) < -1.0){
            _goalObs(x) = -1.0;
          }
        }
      }
        

      void updateGoalObservations(){
        _goalObs(0) = _firstTargetDeltaPose.position(0)/10.0; // target x delta
        _goalObs(1) = _firstTargetDeltaPose.position(1)/10.0; // target y delta
        _goalObs(2) = _firstTargetDeltaPose.position(2)/10.0; // target y delta
        // _goalObs(3) = _targetRotationDelta.w(); // target quat w delta
        // _goalObs(4) = _targetRotationDelta.x(); // target quat x delta
        // _goalObs(5) = _targetRotationDelta.y(); // target quat y delta
        // _goalObs(6) = _targetRotationDelta.z(); // target quat z delta
        _goalObs(3) = _secondTargetDeltaPose.position(0)/10.0; // target quat w delta
        _goalObs(4) = _secondTargetDeltaPose.position(1)/10.0; // target quat x delta
        _goalObs(5) = _secondTargetDeltaPose.position(2)/10.0; // target quat y delta
        _goalObs(6) = 0.0; // target quat z delta
        if(_goals[0].second == 1){
          _goalObs(7) = 1; // target rotation flag
        }else{
          _goalObs(7) = 0;
        }
        _goalObs(8) = 0.0;//preferred x delta
        _goalObs(9) = 0.0;//preferred y delta
        _goalObs(10) = 0.0; //preferred z delta
        
        // _goalObs(8) = _preferredDeltaPose.position(0);//preferred x delta
        // _goalObs(9) = _preferredDeltaPose.position(1);//preferred y delta
        // _goalObs(10) = _preferredDeltaPose.position(2); //preferred z delta
        bool normalize = false;
        for(int x = 0; x < 3; x++){
          if(_goalObs(x) > 1.0 || _goalObs(x) < -1.0){
            normalize = true;
            break;
          }
        }
        if(normalize){
          Eigen::Vector3f vec = Eigen::Vector3f(_goalObs(0), _goalObs(1), _goalObs(2)).normalized();
          _goalObs(0) = vec(0);
          _goalObs(1) = vec(1);
          _goalObs(2) = vec(2);
        }

        normalize = false;
        for(int x = 3; x < 6; x++){
          if(_goalObs(x) > 1.0){
            normalize = true;
            break;
          }
        }
        if(normalize){
          Eigen::Vector3f vec = Eigen::Vector3f(_goalObs(3), _goalObs(4), _goalObs(5)).normalized();
          _goalObs(3) = vec(0);
          _goalObs(4) = vec(1);
          _goalObs(5) = vec(2);
        }




        for(int x = 6; x < 11; x++){
          if(_goalObs(x) > 1.0){
            _goalObs(x) = 1.0;
          }else if(_goalObs(x) < -1.0){
            _goalObs(x) = -1.0;
          }
        }
      }

      void updateSearchGoalObservations(){
        int goalObsIndex = 0;
        for(auto goalDelta : _searchDeltas){  
            _goalObs(goalObsIndex*3+0) = goalDelta(0)/10.0;
            _goalObs(goalObsIndex*3+1) = goalDelta(1)/10.0;
            _goalObs(goalObsIndex*3+2) = goalDelta(2)/10.0;
            goalObsIndex++;
        }
        //normalize check
        for(int x = 0; x < 5; x++){
          bool normalize = false;
          for(int entry = 0; entry < 3; entry++){
            if(_goalObs(x*3+entry)>1.0 || _goalObs(x*3+entry) < -1.0){
              normalize = true;
              break;
            }
          }
          if(normalize){
            Eigen::Vector3f vec = Eigen::Vector3f(_goalObs(x*3+0), _goalObs(x*3+1), _goalObs(x*3+2)).normalized();
            _goalObs(x*3+0) = vec(0);
            _goalObs(x*3+1) = vec(1);
            _goalObs(x*3+2) = vec(2);
          }
        }
      }


      int getClosestUnsearchedCluster(Eigen::Vector3f position){
        return _plannerManager->closestUnsearchedCluster(position, _searchedClusters);
      }

      void populateSearchTargets(std::vector<int> replaceIndex, std::shared_ptr<nanomap::map::Map> map, Eigen::Vector3f position){
        if(_searchClusterTargets.size() >= replaceIndex.size()){
           //Then we can populate search targets
           int targetIndex = 0;
            //std::cout << "stepping through targets? " << std::endl;
           for(auto it = _searchClusterTargets.begin(); it != std::next(_searchClusterTargets.begin(),replaceIndex.size()); ++it){

            //std::cout << "targetIndex = " << replaceIndex[targetIndex] << std::endl;
            //std::cout << "target point = " << (*it).second.x() << " / " << (*it).second.y() << " / "<< (*it).second.z() << std::endl;

            _searchTargets[replaceIndex[targetIndex]] = (*it).second;
            targetIndex++;
           } 
          }else{
            while(_searchClusterTargets.size() < replaceIndex.size()){
              _currentCluster = getClosestUnsearchedCluster(position);
            //Get closest neighbour that hasn't been searched
            //And add check those search cluster targets.
              _searchClusterTargets = _plannerManager->getSearchClusterTargetsByDistance(position, _currentCluster, map);
              if(_searchClusterTargets.size() < replaceIndex.size()){
                _searchedClusters[_currentCluster] = true;
              }
            }
            int targetIndex = 0;
           for(auto it = _searchClusterTargets.begin(); it != std::next(_searchClusterTargets.begin(),replaceIndex.size()); ++it){
            _searchTargets[replaceIndex[targetIndex]] = (*it).second;
            targetIndex++;
           } 
        }
        // std::cout << "targets = " << std::endl;
        // for(auto target : _searchTargets){
        //   std::cout << "[";
        //   for(int x = 0; x < 3; x++){
        //     std::cout << target(x);
        //     if(x != 2){
        //       std::cout << ", ";
        //     }
        //   }
        //   std::cout << "]" << std::endl;
        
        // }
      }

      
      void updateSearchTargets(nanomap::Pose pose, std::shared_ptr<nanomap::map::Map> map){
        _goalSearchCount = 0;
        //std::cout << "searchTargetsEmpty = " << _searchTargetsEmpty << std::endl;
        if(_searchTargetsEmpty){
          //std::cout << "are we even getting stuff?" << std::endl;
          //First we have to populate the search cluster targets
          
          _searchClusterTargets = _plannerManager->getSearchClusterTargetsByDistance(pose.position, _currentCluster, map);
          //Then We need to get 5 new search targets
          std::vector<int> replaceIndex = {0,1,2,3,4};
          populateSearchTargets(replaceIndex, map, pose.position);
          
          _searchTargetsEmpty = false;
        }else{
          //We check the old search targets, and if any are complete, we get a new one and increment the searchCounter
          //std::cout << "WHAT IS HAPPENING" << std::endl;
          std::vector<int> searchCompletion = _plannerManager->checkSearchTargets(_searchTargets, map);
          //std::cout << "searchCompletion = [";
          // for(int x = 0; x < searchCompletion.size(); x++){
          //   std::cout << searchCompletion[x] << ", ";
          // }
          // std::cout << "]" << std::endl;
          _goalSearchCount = searchCompletion.size();
          //std::cout << "searchCompletionSize = " << searchCompletion.size() << std::endl;
          if(searchCompletion.size()>0){
            //we have completed some of the search targets.
            if(searchCompletion.size()<=_searchClusterTargets.size()){
              _searchClusterTargets = _plannerManager->sortSearchClusterTargetsByDistance(pose.position, _searchClusterTargets, searchCompletion, _searchTargets);
            }
            populateSearchTargets(searchCompletion, map, pose.position);
          }
        }
      }

      bool isGoalReached(){
        
        if(std::abs(_firstTargetDeltaPose.position(0)) < 1.0 && 
            std::abs(_firstTargetDeltaPose.position(1)) < 1.0 &&
            std::abs(_firstTargetDeltaPose.position(2)) < 1.0){
          //GOAL IS REACHED! NOW WE CHECK TO SEE IF IT IS A TRAJECTORY GOAL
          
          // if(_goals[0].second == 1){
          //   //We have to check if orientation is reached
          //   float quatDiff = std::abs(_goals[0].first.orientation.dot(pose.orientation)); 
          //   if(quatDiff <= 1-0.05){
          //     //Trajectory OrientationDoesn't Match
          //     return false;
          //   }
          // }
          //Goals reached return true
          //std::cout << _firstTargetDeltaPose.position(0)/5.0 << " / " << _firstTargetDeltaPose.position(0)/5.0 << " / " << _firstTargetDeltaPose.position(0)/5.0 << std::endl; 
          return true;
        }else{
          return false;
        }
      }

      bool isGoalSearched(std::shared_ptr<nanomap::map::Map> map){
        return _plannerManager->isSearchGoalComplete(_goals[0].first.position, map);

          //GOAL IS REACHED! NOW WE CHECK TO SEE IF IT IS A TRAJECTORY GOAL
          
          // if(_goals[0].second == 1){
          //   //We have to check if orientation is reached
          //   float quatDiff = std::abs(_goals[0].first.orientation.dot(pose.orientation)); 
          //   if(quatDiff <= 1-0.05){
          //     //Trajectory OrientationDoesn't Match
          //     return false;
          //   }
          // }
          //Goals reached return true
          //std::cout << _firstTargetDeltaPose.position(0)/5.0 << " / " << _firstTargetDeltaPose.position(0)/5.0 << " / " << _firstTargetDeltaPose.position(0)/5.0 << std::endl; 
        //   return true;
        // }else{
        //   return false;
        // }
      }



 void updateSearchDeltas(nanomap::Pose pose){
        int searchIndex = 0;
        Eigen::Quaternionf inverseRotation = pose.orientation.normalized().inverse();
        EigenVec worldTargetDelta;
        EigenVec localTargetDelta;
        for(auto searchTarget : _searchTargets){
          worldTargetDelta = searchTarget - pose.position;       
          localTargetDelta = inverseRotation*worldTargetDelta;
          _searchDeltas[searchIndex] = localTargetDelta; 
          searchIndex++;
        }
      }

    EigenVec _transitDelta;

      void updateTransitDeltas(nanomap::Pose pose){
        //Deltas are in local UAV space, and so must be calculated according to the agent orientation
        //This means rotating the global space coordinate by the
        //Get closest point on preferred path
          Eigen::Quaternionf inverseRotation = pose.orientation.normalized().inverse();
        EigenVec worldTargetDelta = _transitGoal-pose.position;
        EigenVec localTargetDelta = inverseRotation*worldTargetDelta;
        _transitDelta = localTargetDelta;
        // EigenVec pointOnPath;
        // EigenVec path = _goals[0].first.position - _lastGoalLocation.position;
        // EigenVec pointInPathSpace = pose.position - _lastGoalLocation.position;
        // float pathLength = path.norm();
        // float t = pointInPathSpace.dot(path)/pathLength;
        // if(t<0){
        //   t = 0.0;
        // }else if(t>1){
        //   t = 1.0;
        // }
        // pointOnPath = _lastGoalLocation.position+t*path;

        // EigenVec firstWorldTargetDelta;
        // EigenVec secondWorldTargetDelta;
        // EigenVec firstLocalTargetDelta;
        // EigenVec secondLocalTargetDelta;
        // EigenVec worldPreferredDelta;
        // EigenVec localPreferredDelta;
        // Eigen::Quaternionf inverseRotation = pose.orientation.normalized().inverse();
        // //float yawTargetDelta = 0.0;
        // _targetRotationDelta = Eigen::Quaternionf(1,0,0,0);
        // //GET world space delta for target and preferred path 
        // firstWorldTargetDelta = _goals[0].first.position - pose.position;
        // secondWorldTargetDelta = _goals[1].first.position -pose.position;
        // // std::cout << "firstfirstWorldTargetDelta = " << firstWorldTargetDelta(0) << " / "
        // // << firstWorldTargetDelta(1) << " / "
        // // << firstWorldTargetDelta(2) << " / "
        // // << std::endl; 
        // //worldPreferredDelta = pointOnPath - pose.position;
        // //Then rotate world space delta by the inverse of the agent pose.
        // firstLocalTargetDelta = inverseRotation*firstWorldTargetDelta;
        // secondLocalTargetDelta = inverseRotation*secondWorldTargetDelta;
        // // std::cout << "localTargetDelta = " 
        // // << localTargetDelta(0) << " / "
        // // << localTargetDelta(1) << " / "
        // // << localTargetDelta(2) << " / "
        // // << std::endl; 
        // //localPreferredDelta = worldPreferredDelta.transpose()*inverseRotation;
        // _previousDeltaPose.position = _firstTargetDeltaPose.position;
        // _firstTargetDeltaPose.position = firstLocalTargetDelta;
        // _secondTargetDeltaPose.position = secondLocalTargetDelta;
        // //_preferredDeltaPose.position = localPreferredDelta;
        // //_deltaChange = _previousDeltaPose.position.norm() - _firstTargetDeltaPose.position.norm();
        // //This gives the delta in the agent space. 
        // //Then we need the delta for the target yaw but only if it exists
        // //if(_goals[0].second == 1){
        //   //Rotation diff = Final orientiation*currentorientation^-1
        // //  _targetRotationDelta = 
        // //            _goals[0].first.orientation*pose.orientation.inverse();
        // //  _targetRotationDelta.normalize();
        // //}
      }

      //std::shared_ptr<Eigen::ArrayXf> observationCloud(){return _observationCloud;}

      void clearObservationRays(){ _observationNorms.resize(0,0);
                                    _observationRays.resize(0,0);}
      Eigen::Matrix<float, 3, Eigen::Dynamic> observationRays(){return _observationRays;}
      Eigen::Matrix<float, 2, Eigen::Dynamic> observationNorms(){return _observationNorms;}
      // void resetAgent(){clearSensors();
      //                   clearObservationRays();}
      // Pose sensorPose(int index){return _sensorPoses[index];}

      // std::shared_ptr<Map> map(){return _map;}
      // std::vector<std::string> sensorNames() {return _sensorNames;}
      // int getId(){return _agentId;}
      // std::string getName(){return _agentName;}
      // bool spawnRandom(){return _spawnRandom;}
      bool _needsMapReset = false;
      Eigen::Matrix<float, 3, Eigen::Dynamic> _observationRays;
      Eigen::Matrix<float, 2, Eigen::Dynamic> _observationNorms;
      //goal obs are:
      // x, y, z delta from target position, and quaternion delta from target heading, flag for if yaw matters for reward
      // x, y, z, delta from closest position on target path
      // 3 + 4 + 1 +3
      Eigen::ArrayXf _goalObs;
      Eigen::ArrayXf _hazardObservations;
      Eigen::ArrayXf _unknownObservations;
      Eigen::ArrayXf _observationsNormalised;
      Eigen::ArrayXf _observationCloud;
      Eigen::ArrayXf _collisions;
      float _collisionDist;
      int _numObs;
      float _lenObs;
      float _gridRes;
      Eigen::Quaternionf _targetRotationDelta;
      Pose _firstTargetDeltaPose;
      Pose _secondTargetDeltaPose;
      Pose _previousDeltaPose;
      float _deltaChange;
      Pose _preferredDeltaPose;
      int _searchGoalIndex;
      //float _reward;
      //float _goalReachedReward;
      //float _approachingReward;
      //float _pathReward;
      bool _intermediateGoalReached = false;
      bool _finalGoalReached = false;
      //Eigen::ArrayXd<float> _goalObs;
      bool _goalSearched = false;

      bool _goalReached = false;
      bool _isTerminal;
      bool _isCollided;
      bool _isTooCloseToHazard;
      bool _searchTargetsEmpty = true;
      Pose _lastGoalLocation;
      std::vector<std::pair<Pose, int>> _goals;
      int _minPathSteps;
      int _voxelCount = 0;
      //int _currentCluster = 0;
      int _previousCluster = -1;
      std::vector<bool> _searchedClusters;
      std::vector<Eigen::Vector3f> _searchTargets;
      std::vector<Eigen::Vector3f> _searchDeltas;
      int _goalSearchCount = 0;
      std::map<float, Eigen::Vector3f> _searchClusterTargets;

      void setPlanner(std::shared_ptr<nanomap::manager::PlannerManager> planner){_plannerManager = planner;}
    protected:
      std::shared_ptr<nanomap::manager::PlannerManager> _plannerManager;

      


    };
  }
}
#endif
