// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Agent.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_AGENT_PLANNERAGENT_H_INCLUDED
#define NANOMAP_AGENT_PLANNERAGENT_H_INCLUDED
#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
#include <iomanip>
#include <chrono>
#include <iostream>
#include <string>
#include "nanomap/agent/AgentData.h"
#include "nanomap/sensor/Sensor.h"
#include "nanomap/map/Map.h"
#include "nanomap/map/PlannerMap.h"
#include "nanomap/nanomap.h"


/******************************************************************************
This class defines a basic agent. It is used for single body UAVs with one or
more FIXED sensors and doesn't currently contain more advanced robotics kinematics like
Joint and Link definitions. update the UAV pose, then use the class to update the
sensor poses and pass a map file to the sensors to update the map with the new
sensor views. This also uses a map file to generate observation distances for
deeprl. Rays for an agent are generally loaded from a file and are precomputed.
however, a spherical observation sphere of radius r is generated if file not provided.
*******************************************************************************/

namespace nanomap{
  namespace agent{

  class PlannerAgent : Agent{

    public:

      PlannerAgent(std::shared_ptr<nanomap::agent::AgentData> agentData, std::vector<std::shared_ptr<nanomap::sensor::Sensor>> sensors, std::shared_ptr<nanomap::map::Map> map, std::shared_ptr<nanomap::map::PlannerMap> plannerMap)
      :Agent(agentData,map)
      ,_plannerMap(_plannerMap)
      {
        // for(int x = 0; x < sensors.size(); x++){
        //   _sensors.push_back(sensors[x]);
        // }
      }

      // void updatePose(Pose pose){
      //   _agentData->pose() = pose;
      //   int index = 0;
      //   //Eigen::Matrix<float, 3, 3> defaultFrameTransform;
      //   //Currently not setup up correctly. Supposed to get relative transform of sensor from agent origin, and transform accordingly, as of now
      //   //only sets sensor pose to equal agentPose
      //   for(auto itr = _sensors.begin(); itr != _sensors.end(); itr++){
      //     (*itr)->sensorData()->updatePose(pose);
      //     (*itr)->sensorData()->rotateView();
      //   }
      // }

      // std::vector<std::shared_ptr<nanomap::sensor::Sensor>> sensors(){return _sensors;}
      // std::shared_ptr<nanomap::sensor::Sensor> sensor(int index){return _sensors[index];}
      // std::shared_ptr<nanomap::agent::AgentData> agentData(){return _agentData;}
      // std::shared_ptr<nanomap::map::Map> map(){return _map;      
      std::shared_ptr<nanomap::map::PlannerMap> plannerMap(){return _plannerMap;}
      
    protected:

      // //Agent Data, contains pose, and other lookup info. 
      // std::shared_ptr<nanomap::agent::AgentData> _agentData;

      // //The sensors this agent owns
      // std::vector<std::shared_ptr<nanomap::sensor::Sensor>> _sensors;      

      // //The agent's occupancy map
      // std::shared_ptr<nanomap::map::Map> _map;

      std::shared_ptr<nanomap::map::PlannerMap> _plannerMap;

    };
  }
}
#endif
