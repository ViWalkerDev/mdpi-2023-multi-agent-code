// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file AgentAllocator.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_ALLOCATOR_PLANNERALLOCATOR_H_INCLUDED
#define NANOMAP_ALLOCATOR_PLANNERALLOCATOR_H_INCLUDED
#include "nanomap/gpu/handlerAssert.h"
#include "cuda_fp16.h"
#include <nanovdb/NanoVDB.h>
#include "nanomap/gpu/PlannerBucket.h"
#include "nanomap/gpu/Cluster.h"
#include "nanomap/nanomap.h"
#include "nanomap/planner/GPUInfo.h"



namespace nanomap{
  namespace allocator{
    //using BufferT = nanovdb::CudaDeviceBuffer;
    using ValueT  = float;
    using EigenVec = Eigen::Matrix<ValueT, 3, 1>;
    class PlannerAllocator{

      public:
      
      PlannerAllocator(){}

      PlannerAllocator(std::shared_ptr<nanomap::planner::GPUInfo> plannerConfig)
      :_plannerBucket(std::make_shared<nanomap::gpu::PlannerBucket>(plannerConfig->gridRes, 
                                                                    plannerConfig->mappingRes, 
                                                                    plannerConfig->plannerRes, 
                                                                    plannerConfig->leafEdge))
      {}

      PlannerAllocator(float gridRes, float mappingRes, float plannerRes, int tileEdge)
      :_plannerBucket(std::make_shared<nanomap::gpu::PlannerBucket>(gridRes, mappingRes, plannerRes, tileEdge))
      {}
      
      // void createGPUClusters(std::vector<int>& clusterIDs, std::vector<std::vector<int>>& clustersSafe){
      //   for(int x = 0; x < clusterIDs.size() ; x++){
      //     _plannerClusters.push_back(std::make_shared<nanomap::gpu::Cluster>(*_plannerBucket->hostValidCount(), clustersSafe[x].size()));
      //     populateClusterIndex(x, clustersSafe);
      //   }
      //   return;
      // }

      void createGPUClusters(){
        for(int x = 0; x < _clusterIDs.size() ; x++){
          _plannerClusters.push_back(std::make_shared<nanomap::gpu::Cluster>(*_plannerBucket->hostValidCount(), _clustersSafe[x].size()));
          populateClusterIndex(x, _clustersSafe);
        }
        return;
      }


      void setClusterIDs(std::vector<int> clusterIDs){
        _clusterIDs = clusterIDs;
      }

      void setClustersSafe(std::vector<std::vector<int>> clustersSafe){
        _clustersSafe = clustersSafe;
      }

      void populateClusterIndex(int clusterIndex, std::vector<std::vector<int>>& clustersSafe){
        for(int x = 0; x < clustersSafe[clusterIndex].size(); x++){
          _plannerClusters[clusterIndex]->hostClusterIndex()[x] = clustersSafe[clusterIndex][x];
        }
        cudaCheck(cudaMemcpy(_plannerClusters[clusterIndex]->devClusterIndex(), _plannerClusters[clusterIndex]->hostClusterIndex(), (*(_plannerClusters[clusterIndex]->hostClusterCount()))*sizeof(int), cudaMemcpyHostToDevice));
      }


      void setHostGridIndex(int index, int x, int y, int z){
        *(_plannerBucket->hostGridIndex()+index) = nanovdb::Coord(x, y, z); 
      }

      void setHostSafeIndex(int index, int value){
        *(_plannerBucket->hostSafeIndex()+index) = value;
      }

      Eigen::Matrix<int, 3, 1> getGridIndexNode(int nodeIndex){
        //std::cout << nodeIndex << std::endl;
        Eigen::Matrix<int, 3, 1> node(_plannerBucket->hostGridIndex()[nodeIndex][0],
                                      _plannerBucket->hostGridIndex()[nodeIndex][1],
                                      _plannerBucket->hostGridIndex()[nodeIndex][2]);
        return node;
      }

      void copySafeAndGridIndexToDev(){
        cudaCheck(cudaMemcpy(_plannerBucket->devSafeIndex(), _plannerBucket->hostSafeIndex(), (*_plannerBucket->hostSafeCount())*sizeof(int), cudaMemcpyHostToDevice));
        cudaCheck(cudaMemcpy(_plannerBucket->devGridIndex(), _plannerBucket->hostGridIndex(), (*_plannerBucket->hostValidCount())*sizeof(nanovdb::Coord), cudaMemcpyHostToDevice));
      }
      void allocateValidAndSafe(int validCount, int safeCount){
        _plannerBucket->allocateValidAndSafe(validCount, safeCount);
      }

      
      std::shared_ptr<nanomap::gpu::PlannerBucket> plannerBucket(){return _plannerBucket;}
      std::shared_ptr<nanomap::gpu::Cluster> plannerCluster(int index){return _plannerClusters[index];}
      std::vector<int>& clusterIDs(){return _clusterIDs;}
      private:
        /******************************************************************************/
        std::shared_ptr<nanomap::gpu::PlannerBucket> _plannerBucket;
        std::vector<std::shared_ptr<nanomap::gpu::Cluster>> _plannerClusters;
        std::vector<std::vector<int>> _clustersSafe;
        std::vector<int> _clusterIDs;
    //  };

        



    };
  }
}
#endif
