// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file SensorAllocator.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_HANDLER_SENSORALLOCATOR_H_INCLUDED
#define NANOMAP_HANDLER_SENSORALLOCATOR_H_INCLUDED
#include "nanomap/gpu/handlerAssert.h"
#include "cuda_fp16.h"
#include <nanovdb/NanoVDB.h>
#include "nanomap/gpu/NodeWorker.h"
#include "nanomap/gpu/PointCloud.h"
#include "nanomap/gpu/Sensor.h"
#include "nanomap/gpu/GridData.h"
#include "nanomap/gpu/SensorBucket.h"
#include "nanomap/sensor/Sensor.h"
#include "nanomap/sensor/SensorData.h"
#include "nanomap/config/GPUInfo.h"
#include "nanomap/nanomap.h"



namespace nanomap{
  namespace allocator{
    //using BufferT = nanovdb::CudaDeviceBuffer;
    using ValueT  = float;
    using EigenVec = Eigen::Matrix<ValueT, 3, 1>;
    class SensorAllocator{

      public:

      SensorAllocator(std::shared_ptr<nanomap::sensor::GPUInfo> sensorConfig, std::shared_ptr<nanomap::config::GPUInfo> config)
      :_sb(std::make_shared<nanomap::gpu::SensorBucket>(sensorConfig->frustumPCLSize, sensorConfig->frustumLeafBufferSize))
      ,_sensorConfig(sensorConfig)
      ,_config(config)
      {
        _sb->setGridRes(_config->gridRes);
        _sb->setMappingRes(_config->mappingRes);
        _sb->setFilterType(_config->filterType);
        _sb->setProcessType(_config->processType);
        std::cout << "gridRes: " << _config->gridRes << std::endl;
        std::cout << "mappingRes: " << _config->mappingRes << std::endl;
        std::cout << "filterType: " << _config->filterType << std::endl;
        std::cout << "ProcessType: " << _config->processType << std::endl;
        //If using node optimisation for frustum cameras
        if(_config->processType!=1){ //|| _config->processType == 2){
          //Arrays used for sorting the active node information.
          cudaCheck(cudaMalloc((void**)&((*_sb)._activeLeafNodes), _sensorConfig->frustumLeafBufferSize*sizeof(int)));
          //std::cout << "1" << std::endl;
          cudaCheck(cudaMalloc((void**)&((*_sb)._activeFlags), _sensorConfig->frustumLeafBufferSize*sizeof(int)));
          //std::cout << "1" << std::endl;
          cudaCheck(cudaMalloc((void**)&((*_sb)._activeIndices), _sensorConfig->frustumLeafBufferSize*sizeof(int)));
          //Set Voxel allocation. This can be changed as needed, and will resize as necessary,
          //but resizing is costly, so it is a good number to reduce memory consumption
          //While also preventing a lot of resizing when using a frustum style sensor.
          //Default factor of 0.4 means that container size for voxel representation set to 2/5th of max observable area for a given sensor.
          _frustumVoxelAllocation = (_sensorConfig->frustumLeafBufferSize*(_config->leafVolume)*_sensorConfig->frustumAllocationFactor);
          //Frustum voxel worker contains the probablistic occupancy result of raycasting on GPU
          cudaCheck(cudaMalloc((void**)&((*_sb)._devFrustumVoxelWorker), _frustumVoxelAllocation*sizeof(float)));
          //Frustum leaf buffer contains the coordinates of active leafNodes.
          cudaCheck(cudaMalloc((void**)&((*_sb)._devFrustumLeafBuffer), _sensorConfig->frustumLeafBufferSize*3*sizeof(int)));
          cudaCheck(cudaMallocHost((void**)&((*_sb)._hostFrustumLeafBuffer), _sensorConfig->frustumLeafBufferSize*3*sizeof(int)));
          //Frustum Voxel buffer is used to transfer contents of the frustum voxel worker to CPU, uses int8_t type to reduce the size of the container,
          //And improve memcpy times as this step happens each loop.
          cudaCheck(cudaMalloc((void**)&((*_sb)._devFrustumVoxelBuffer), _frustumVoxelAllocation*sizeof(int8_t)));
          cudaCheck(cudaMallocHost((void**)&((*_sb)._hostFrustumVoxelBuffer), _frustumVoxelAllocation*sizeof(int8_t)));
        }
        if(_config->filterType == 0){
          //Do Nothing
        }else if(_config->filterType == 1 && (_config->processType == 0 || _config->processType == 2)){
            //VOXEL FILTER SETTING
            //ONLY USEFUL FOR FRUSTUM CAMERA
            //Filtering increases runtime but also increases memory usage.
            //This is usually only a problem for sensors with long range, and/or sensors with high grid resolution.
            //If you have the memory, the speed ups are
            //Generally worth the cost.
            //Once the grid resolution becomes too fine to meaningfully recude the input sensor cloud
            //the performance benefit is lost, and the overhead causes slowdown.
            // Four precision modes are provided

            if(_config->precisionType == 0){
              //Precision == 0, provides full xyz precision for discretising rays to a voxel but costs the most memory
              _sb->setPrecisionType(_config->precisionType);
              cudaCheck(cudaMalloc((void**)&((*_sb)._voxelFilterBuffer), _config->leafVolume*4*(_sensorConfig->frustumLeafBufferSize)*sizeof(float)));
            }else if(_config->precisionType == 1){
            //Precision == 1, provides (half2 type) xyz offset precision for discretising rays to a voxel. It costs half as much memory as precision 0
            //This is not supported on the Jetson Nano as the nano only supports Compute capability 5.4. This does work on the Xavier NX.
            //The jetson nano version of this code uses 16 bit integers to store an offset value that has been multiplied by 100.
            //This uses half the memory, which is good for a memory constrained platform, but loses some precision.
            //Uses 1/2 the memory of Precision  = 0;
              _sb->setPrecisionType(_config->precisionType);
              cudaCheck(cudaMalloc((void**)&((*_sb)._voxelFilterBufferHalf2), _config->leafVolume*2*(_sensorConfig->frustumLeafBufferSize)*sizeof(__half2)));
            }else if(_config->precisionType == 2){
              //Precision 2 doesn't even bother tracking ray offsets within a voxel, if a ray ends in a voxel, a counter is incremented for that voxel,
              //The resultant ray is always directed at the center of the voxel in question.
              //This is slightly less accurate, but uses significantly less memory. Great if you don't mind the loss of precision.
              //For smaller voxel sizes the loss of precision becomes smaller.
              //Uses 1/8th of the memory of Precision  = 0;
              //Uses 1/4th the memory of Precision = 1;
              _sb->setPrecisionType(_config->precisionType);
              cudaCheck(cudaMalloc((void**)&((*_sb)._voxelFilterBufferSimple), _config->leafVolume*(_sensorConfig->frustumLeafBufferSize)*sizeof(int)));
            }else if(_config->precisionType == 3){
              //Precision 3 tracks voxel count only, the same as Precision 2.
              //But it uses 1/4th the memory as Precision 2 by condensing 4 counts into a single 32 bit int,
              //for some resolutions this can cause bottlenecks for atomicAdd operations due to sharing single ints
              _sb->setPrecisionType(_config->precisionType);
              cudaCheck(cudaMalloc((void**)&((*_sb)._voxelFilterBufferSimpleQuad), _config->leafVolume*(std::ceil(_sensorConfig->frustumLeafBufferSize/4))*sizeof(int)));
            }
        }
        cudaDeviceSynchronize();
        _sb->hostGridData()->init(_config->mappingRes, _config->leafEdge, _sensorConfig->frustumLeafBufferSize);
      }

    //void update(int pcl_width, int pcl_height, int pcl_step, unsigned char* cloud,
    //             std::shared_ptr<nanomap::sensor::SensorData> sensorData, cudaStream_t s0){
    void update(std::shared_ptr<nanomap::sensor::Sensor> sensor, cudaStream_t s0){
     // _sb->hostSensor()->updateShared(sensor->sensorData()->sharedParameters());
        if(sensor->sensorData()->sharedParameters()._type == 0){
          _sb->hostSensor()->updateFrustum(sensor->sensorData()->sharedParameters());
        }
        else if(sensor->sensorData()->sharedParameters()._type == 1){
          _sb->hostSensor()->updateLaser(sensor->sensorData()->sharedParameters());
        }
        _sb->hostGridData()->update(sensor->sensorData()->sharedParameters()._voxelBounds,
                              sensor->sensorData()->sharedParameters()._leafBounds,
                              sensor->sensorData()->sharedParameters()._leafBufferSize);
        cudaCheck(cudaMemcpy(_sb->devSensor(), _sb->hostSensor(), sizeof(nanomap::gpu::Sensor<float>), cudaMemcpyHostToDevice));
        cudaCheck(cudaMemcpy(_sb->devGridData(), _sb->hostGridData(), sizeof(nanomap::gpu::GridData), cudaMemcpyHostToDevice));
        *(_sb->hostFrustumLeafCount()) = 0;
        cudaCheck(cudaMemcpy(_sb->devFrustumLeafCount(), _sb->hostFrustumLeafCount(), sizeof(int), cudaMemcpyHostToDevice));
        *(_sb->hostRayCount()) = 0;
        cudaCheck(cudaMemcpy(_sb->devRayCount(), _sb->hostRayCount(), sizeof(int), cudaMemcpyHostToDevice));
        _sb->pclHandle().updatePointCloudHandle(sensor->inputCloud()->height()*sensor->inputCloud()->width(), sensor->inputCloud()->step(), sensor->inputCloud()->cloudPtr());
        _sb->pclHandle().deviceUpload(s0);
        cudaDeviceSynchronize();

    }

    void update(std::shared_ptr<nanomap::sensor::SensorData> sensorData, cudaStream_t s0){
      //_sb->hostSensor()->updateShared(sensorData->sharedParameters());
      if(sensorData->sharedParameters()._type == 0){
        _sb->hostSensor()->updateFrustum(sensorData->sharedParameters());
      }else if(sensorData->sharedParameters()._type == 1){
        _sb->hostSensor()->updateLaser(sensorData->sharedParameters());
      }

      _sb->hostGridData()->update(sensorData->sharedParameters()._voxelBounds,
                            sensorData->sharedParameters()._leafBounds,
                            sensorData->sharedParameters()._leafBufferSize);
      cudaCheck(cudaMemcpy(_sb->devSensor(), _sb->hostSensor(), sizeof(nanomap::gpu::Sensor<float>), cudaMemcpyHostToDevice));
      cudaCheck(cudaMemcpy(_sb->devGridData(), _sb->hostGridData(), sizeof(nanomap::gpu::GridData), cudaMemcpyHostToDevice));
      *(_sb->hostFrustumLeafCount()) = 0;
      cudaCheck(cudaMemcpy(_sb->devFrustumLeafCount(), _sb->hostFrustumLeafCount(), sizeof(int), cudaMemcpyHostToDevice));
      *(_sb->hostRayCount()) = 0;
      cudaCheck(cudaMemcpy(_sb->devRayCount(), _sb->hostRayCount(), sizeof(int), cudaMemcpyHostToDevice));
    }

    void downloadCloudToSensor(std::shared_ptr<nanomap::sensor::Sensor> sensor, cudaStream_t s0){
        _sb->pclHandle().deviceDownload(s0);
        cudaDeviceSynchronize();
        int cloudSize = sensor->sensorData()->sharedParameters()._hRes*sensor->sensorData()->sharedParameters()._vRes;
        nanomap::gpu::PointCloud* pcl = _sb->pclHandle().pointCloud();
        for(int i = 0; i < cloudSize; i++){
          if((*(pcl))(i).norm >= 0.0){
            (sensor->publishCloud()).col(i)(0) = ((*(pcl))(i).x);
            (sensor->publishCloud()).col(i)(1) = ((*(pcl))(i).y);
            (sensor->publishCloud()).col(i)(2) = ((*(pcl))(i).z);
          }else{
              (sensor->publishCloud()).col(i)(0) = ((*(pcl))(i).x);
              (sensor->publishCloud()).col(i)(1) = ((*(pcl))(i).y);
              (sensor->publishCloud()).col(i)(2) = nanf("");
          }

        }
    }
        std::shared_ptr<nanomap::gpu::SensorBucket> sensorBucket(){return _sb;}
      private:
        /******************************************************************************/
        int _frustumVoxelAllocation = 0;
        std::shared_ptr<nanomap::sensor::GPUInfo> _sensorConfig;
        std::shared_ptr<nanomap::config::GPUInfo> _config;
        std::shared_ptr<nanomap::gpu::SensorBucket> _sb;
    //  };


    };
  }
}
#endif
