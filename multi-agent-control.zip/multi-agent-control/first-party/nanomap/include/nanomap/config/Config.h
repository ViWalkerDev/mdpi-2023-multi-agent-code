// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Config.h
///
/// @author Violet Walker
///

#ifndef NANOMAP_CONFIG_CONFIG_H_INCLUDED
#define NANOMAP_CONFIG_CONFIG_H_INCLUDED
#include <vector>
#include <memory>
#include <iomanip>
#include <chrono>
#include <iostream>
#include <string>
#include <fstream>
#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
#include "nanomap/nanomap.h"
#include "nanomap/config/GPUInfo.h"
//#include "nanomap/sensor/SensorData.h"
//#include "nanomap/sensor/FrustumData.h"
//#include "nanomap/sensor/LaserData.h"
//#include "nanomap/agent/Agent.h"
//#include "nanomap/config/Config.h"

//THIS CLASS IS JUST FOR MANAGING AND CONTAINING USER PROVIDED INFO.

#define M_PI 3.14159265358979323846
#define MAX_INT 32766
#define VOXEL_SIZE 1

namespace nanomap{
  namespace config{
//Config class. This contains all relevant user defined information for operation.
//Config information is loaded using config text files.
    class Config
  {
      public:
        //Empty Constructor
        //Config(){}
        //Constructor that takes main config file as input
        Config(std::string configFile);
        void setConfigFile(std::string configFile);
        void init();
        void getSensorConfigs(std::string configFile);
        void getAgentConfigs(std::string configFile);
        void loadMainConfig();
        //std::shared_ptr<nanomap::config::GPUInfo> configInfo(){return _configInfo;}
        std::shared_ptr<nanomap::config::GPUInfo> configInfo(){return _configInfo;}






    //Fetch Mode variables
          float& collisionPenalty(){return _collisionPenalty;}
          float& goalReachedReward(){return _goalReachedReward;}
          int& minimumSteps(){return _minimumSteps;}
          bool& generateSimGrid(){return _generateSimGrid;}
          std::string& mapGenConfig(){return _mapGenConfig;}

          int& filterType(){return _filterType;}
          int& updateType(){return _updateType;}
          int& exploreType(){return _exploreType;}
          int& processType(){return _processType;}
          int& precisionType(){return _precisionType;}
          int& simType(){return _simType;}
          int& publishSensor(){return _publishSensor;}
          float& gridRes(){return _gridRes;}
          float& mappingRes(){return _mappingRes;}
          float& plannerRes(){return _plannerRes;}
          int& leafEdge(){return _leafEdge;}
          int& leafVolume(){return _leafVolume;}
          float& frustumAllocationFactor(){return _frustumAllocationFactor;}
          //float& laserAllocationFactor(){return _laserAllocationFactor;}
          //int& maxPCLSize(){return _maxPCLSize;}
          //int& laserPCLSize(){return _laserPCLSize;}
          //int& laserVoxelBufferSize(){return _laserVoxelBufferSize;}
          //int& frustumPCLSize(){return _frustumPCLSize;}
          //int& frustumLeafBufferSize(){return _frustumLeafBufferSize;}
          bool& serialUpdate(){return _serialUpdate;}
          float& probHitThres(){return _probHitThres;}
          float& probMissThres(){return _probMissThres;}
          //int& maxObservationSize(){return _maxObservationSize;}


    /****************************************************************************/
    //Fetch _configFiles
          std::string mainConfig(){return _mainConfigFile;}
          std::vector<std::string> agentConfigs(){return _agentConfigFiles;}
          std::string agentConfig(int index){return _agentConfigFiles[index];}
          std::vector<std::string> sensorConfigs(){return _sensorConfigFiles;}
          std::string sensorConfig(int index){return _sensorConfigFiles[index];}
          std::string simGridFile(){return _simGridFile;}
          std::string plannerGridFile(){return _plannerGridFile;}
  /******************************************************************************/


  /****************************************************************************/

      private:
          bool _configCheck=false;
          bool _serialUpdate=false;

          bool _generateSimGrid;
          std::string _mapGenConfig;

          std::string _mainConfigFile;
          //This is used when an existing planning map is known
          std::string _plannerGridFile;
          //This is used when a sim grid is used. 
          std::string _simGridFile;
          std::vector<std::string> _agentConfigFiles;
          std::vector<std::string> _sensorConfigFiles;
          //Variables that define mode of operation.


          //Main Config Values
          float _gridRes;
          float _mappingRes;
          float _plannerRes;
          int _leafEdge;
          int _leafVolume;

          int _filterType;
          int _exploreType;
          int _updateType;
          int _processType;
          int _simType;
          int _precisionType;
          int _publishSensor;

          float _probHitThres;
          float _probMissThres;

          float _goalReachedReward;
          float _collisionPenalty;
          int _minimumSteps;

          float _frustumAllocationFactor;

          std::shared_ptr<nanomap::config::GPUInfo> _configInfo;

        };
  }
}




#endif
