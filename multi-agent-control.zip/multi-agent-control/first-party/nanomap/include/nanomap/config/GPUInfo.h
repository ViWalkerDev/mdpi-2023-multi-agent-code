#ifndef NANOMAP_CONFIG_GPUINFO_H_INCLUDED
#define NANOMAP_CONFIG_GPUINFO_H_INCLUDED


namespace nanomap{
    namespace config{
        struct GPUInfo
        {
            int leafEdge;
            int leafVolume;
            float gridRes;
            float mappingRes;
            float planningRes;
            int filterType;
            int processType;
            int precisionType;


            GPUInfo(){
                leafEdge = 8;
                leafVolume = 512;
                gridRes = 0.1;
                mappingRes = 0.1;
                planningRes = 0.8;
                filterType = 0;
                processType = 0;
                precisionType = 0;
            }
            GPUInfo(int _leafEdge, int _leafVolume, float _gridRes, float _mappingRes, float _planningRes, int _filterType, int _processType, int _precisionType){
                leafEdge = _leafEdge;
                leafVolume = _leafVolume;
                gridRes = _gridRes;
                mappingRes = _mappingRes;
                planningRes = _planningRes;
                filterType = _filterType;
                processType = _processType;
                precisionType = _precisionType;
            }
        };

    }
}
#endif