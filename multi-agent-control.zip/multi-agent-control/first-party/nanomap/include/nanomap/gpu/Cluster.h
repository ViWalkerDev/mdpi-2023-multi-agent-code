#ifndef NANOMAP_GPU_CLUSTER_H_INCLUDED
#define NANOMAP_GPU_CLUSTER_H_INCLUDED
//#include <openvdb/openvdb.h>
#include <nanovdb/util/CudaDeviceBuffer.h>
#include <nanovdb/util/GridHandle.h>
//#include "nanomap/sensor/SensorData.h"
#include "nanomap/nanomap.h"
#include <set>
#include <float.h>
#include "nanomap/gpu/handlerAssert.h"
#include "nanomap/gpu/Cluster.h"
#include "nanomap/gpu/PlannerBucket.h"

//
// #define cudaCheck(ans) \
//     { \
//         gpuAssert((ans), __FILE__, __LINE__); \
//     }
//
// extern static inline bool gpuAssert(cudaError_t code, const char* file, int line, bool abort = true)
// {
// #if defined(DEBUG) || defined(_DEBUG)
//     if (code != cudaSuccess) {
//         fprintf(stderr, "CUDA Runtime Error: %s %s %d\n", cudaGetErrorString(code), file, line);
//         if (abort)
//             exit(code);
//         return false;
//     }
// #endif
//     return true;
// }

namespace nanomap{
  namespace gpu{
    using BufferT = nanovdb::CudaDeviceBuffer;
    using ValueT  = float;

    class Cluster
    {

    public:

    Cluster(int validCount, int clusterNum)
    {
      cudaCheck(cudaMalloc((void**)&_devClusterCount, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostClusterCount, sizeof(int)));
      cudaCheck(cudaMalloc((void**)&_devVertexCount, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostVertexCount, sizeof(int)));
      cudaCheck(cudaMalloc((void**)&_devScoreSize, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostScoreSize, sizeof(int)));
      cudaCheck(cudaMalloc((void**)&_devClusterScoreSize, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostClusterScoreSize, sizeof(int)));
      cudaCheck(cudaMalloc((void**)&_devVertexSolution, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostVertexSolution, sizeof(int)));
      cudaCheck(cudaMalloc((void**)&_devLevel, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostLevel, sizeof(int)));
      cudaCheck(cudaMalloc((void**)&_devSolutionCounts, _levelDepth*sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostSolutionCounts, _levelDepth*sizeof(int)));
      //cudaCheck(cudaMemset(_hostSolutionCounts, 0, _levelDepth*sizeof(int)));
      *_hostClusterCount = clusterNum;
      *_hostClusterScoreSize = (*_hostClusterCount)*((*_hostClusterCount)-1)/2;
      *_hostVertexSolution = 0;
      *_hostVertexCount = 0;
      *_hostLevel = 1;
      cudaCheck(cudaMemcpy(_devVertexSolution, _hostVertexSolution, sizeof(int), cudaMemcpyHostToDevice));
      cudaCheck(cudaMemcpy(_devVertexCount, _hostVertexCount, sizeof(int), cudaMemcpyHostToDevice));
      cudaCheck(cudaMemcpy(_devLevel, _hostLevel, sizeof(int), cudaMemcpyHostToDevice));
      cudaCheck(cudaMemcpy(_devClusterCount, _hostClusterCount, sizeof(int), cudaMemcpyHostToDevice));
      cudaCheck(cudaMemcpy(_devClusterScoreSize, _hostClusterScoreSize, sizeof(int), cudaMemcpyHostToDevice));

      //The distances and visiblity between cluster nodes. If all nodes can see one another, then
      //a vertex based path-finding solution is not necessary.
      cudaCheck(cudaMalloc((void**)&_devClusterDistances, (*_hostClusterCount)*(*_hostClusterCount)*sizeof(float)));
      cudaCheck(cudaMallocHost((void**)&_hostClusterDistances, (*_hostClusterCount)*(*_hostClusterCount)*sizeof(float)));
      cudaCheck(cudaMalloc((void**)&_devClusterPairs, (*_hostClusterScoreSize)*2*sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostClusterPairs, (*_hostClusterScoreSize)*2*sizeof(int)));

      cudaCheck(cudaMalloc((void**)&_devClusterIndex, (*_hostClusterCount)*sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostClusterIndex, (*_hostClusterCount)*sizeof(int)));

      cudaCheck(cudaMalloc((void**)&_devVertexWorker, validCount*sizeof(uint8_t)));
      cudaCheck(cudaMalloc((void**)&_devEdgeWorker, validCount*sizeof(uint8_t)));
      cudaCheck(cudaMalloc((void**)&_devEdgeDirection, validCount*sizeof(uint8_t)));
      cudaCheck(cudaMalloc((void**)&_devEdgeScore, validCount*sizeof(uint8_t)));
      cudaCheck(cudaMalloc((void**)&_devVertexBuffer, validCount*sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostVertexBuffer, validCount*sizeof(int)));
      //populateClusterPairs();
    }

    ~Cluster(){
      freeMemory();
    }

    //void allocateSolutionArrays(){

    //}


      void allocateVertices(cudaStream_t s0){
        //cudaCheck(cudaMemcpy(_hostVertexCount, _devVertexCount, sizeof(int), cudaMemcpyDeviceToHost));
        if(*_hostVertexCount>_vertexAllocation){
          //Then required allocation isn't sufficient for vertex buffer.
          if(_verticesAllocated){
            //free buffer and paths for reallocation this is because paths size is tied to buffer size.
            //cudaFree(_devVertexPaths);
            cudaFree(_devVertexDistances);
            cudaFreeHost(_hostVertexDistances);
            cudaFree(_devNeighbourCounts);
            cudaFreeHost(_hostNeighbourCounts);
            cudaFree(_devGraphLevels);
            //cudaFreeHost(_hostGraphLevels);
            cudaFree(_devGraphScores);
            cudaFree(_devNewGraphScores);
            cudaFree(_devIndexPairs);
            cudaFreeHost(_hostIndexPairs);
            //cudaFree(_devNewGraphScores);
          }
          _vertexAllocation = *_hostVertexCount;
          _scoreAllocation = *_hostScoreSize;
          //printf("vertexAlloc = %d, scoreAlloc = %d \n", _vertexAllocation, _scoreAllocation);

          //cudaCheck(cudaMalloc((void**)&_devVertexDistances, _vertexAllocation*_vertexAllocation*sizeof(float)));
          //cudaCheck(cudaMallocHost((void**)&_hostVertexDistances, _vertexAllocation*_vertexAllocation*sizeof(float)));

          cudaCheck(cudaMalloc((void**)&_devNeighbourCounts, _vertexAllocation*sizeof(int)));
          cudaCheck(cudaMallocHost((void**)&_hostNeighbourCounts, _vertexAllocation*sizeof(int)));
          //cudaCheck(cudaMemsetAsync(_hostNeighbourCounts, 0, _vertexAllocation*sizeof(int), s0));

          cudaCheck(cudaMalloc((void**)&_devGraphLevels, _scoreAllocation*_levelDepth*sizeof(float)));
          //cudaCheck(cudaMallocHost((void**)&_hostGraphLevels, _scoreAllocation*_levelDepth*sizeof(int)));
          cudaCheck(cudaMalloc((void**)&_devGraphScores, _scoreAllocation*2*sizeof(float)));
          cudaCheck(cudaMallocHost((void**)&_hostGraphScores, _scoreAllocation*2*sizeof(float)));
          cudaCheck(cudaMalloc((void**)&_devNewGraphScores, _scoreAllocation*2*sizeof(float)));

          cudaCheck(cudaMalloc((void**)&_devIndexPairs, _scoreAllocation*2*sizeof(int)));
          cudaCheck(cudaMallocHost((void**)&_hostIndexPairs, _scoreAllocation*2*sizeof(int)));


          _verticesAllocated = true;
        }
        //populateIndex(stream);
      }

      void vertexDistancesFromClusters(cudaStream_t s0){
        for(int i = 0; i< *_hostScoreSize; i++){
        //for(int x = 0; x < *_hostVertexCount; x++){
        //for(int y = 0; y < *_hostVertexCount; y++){
            int x = _hostIndexPairs[i];
            int y = _hostIndexPairs[i+(*_hostScoreSize)];
            //int currentIndex =
            float dist = _hostClusterDistances[_hostVertexBuffer[x]*(*_hostClusterCount)+_hostVertexBuffer[y]];
            //_hostVertexDistances[x*(*_hostVertexCount)+y] = dist;
            //_hostVertexDistances[y*(*_hostVertexCount)+x] = dist;
            if(dist > 0){
              _clusterNeighbourTotal += 2;
              _hostNeighbourCounts[x] += 1;
              _hostNeighbourCounts[y] += 1;
              _hostGraphScores[i] = dist;
              _hostGraphScores[i+(*_hostScoreSize)] = 0.0;
              _hostGraphLevels[i] = dist;
            }else{
              _hostGraphScores[i] = FLT_MAX;
              _hostGraphScores[i+(*_hostScoreSize)] = FLT_MAX;
              _hostGraphLevels[i] = -1.0;
            }
          //}
        //}
        }
        cudaCheck(cudaMemcpyAsync(_devGraphScores, _hostGraphScores, _scoreAllocation*2*sizeof(int), cudaMemcpyHostToDevice,s0));
        cudaCheck(cudaMemcpyAsync(_devNewGraphScores, _hostGraphScores, _scoreAllocation*2*sizeof(float), cudaMemcpyHostToDevice,s0));
        cudaCheck(cudaMemcpyAsync(_devGraphLevels, _hostGraphLevels, _scoreAllocation*sizeof(int), cudaMemcpyHostToDevice,s0));
        cudaCheck(cudaMemcpyAsync(_devNeighbourCounts, _hostNeighbourCounts, _vertexAllocation*sizeof(int), cudaMemcpyHostToDevice, s0));
      }

      void populateIndex(cudaStream_t s0){
        cudaStreamSynchronize(s0);
        for(int x = 0; x< (*_hostVertexCount); x++){
          for(int y = 0; y< (*_hostVertexCount); y++){

            if(x<y){
                int  pairIndex = x*((*_hostVertexCount)-1)-(x*(x-1)/2) + (y-x-1);
                _hostIndexPairs[pairIndex] = x;
                _hostIndexPairs[pairIndex+(*_hostScoreSize)] = y;
            }
          }
        }
        cudaCheck(cudaMemcpyAsync(_devIndexPairs, _hostIndexPairs, (*_hostScoreSize)*2*sizeof(int), cudaMemcpyHostToDevice, s0));

      }

      void populateClusterPairs(cudaStream_t s0){
        //printf("host cluster count %d",*_hostClusterCount);
        //printf("hostclusterScoreSize %d", *_hostClusterScoreSize);
        for(int x = 0; x< (*_hostClusterCount); x++){
          for(int y = 0; y< (*_hostClusterCount); y++){

            if(x<y){
                int  pairIndex = x*((*_hostClusterCount)-1)-(x*(x-1)/2) + (y-x-1);
                _hostClusterPairs[pairIndex] = x;
                _hostClusterPairs[pairIndex+(*_hostClusterScoreSize)] = y;
            }
          }
        }
        cudaCheck(cudaMemcpyAsync(_devClusterPairs, _hostClusterPairs, (*_hostClusterScoreSize)*2*sizeof(int), cudaMemcpyHostToDevice, s0));

      }

      // void setVertexPathsForSingleVertex(){
        
      // }
          //
          //
          void allocateVertexPaths(cudaStream_t s0){
            cudaStreamSynchronize(s0);
            //void allocateVertexPaths(){
            int size = 0;
            if(_vertexAllocation>1){
              size = (*_hostScoreSize)*(*_hostLevel);
            }else{
              size = 1;
            }
            //cluster.allocateVertexPaths((*cluster.hostScoreSize())*level);
            //}
            if(size > _vertexPathAllocation){
              if(_vertexPathsAllocated){
                cudaFree(_devVertexPaths);
                cudaFreeHost(_hostVertexPaths);
              }
              _vertexPathAllocation = size;
              cudaCheck(cudaMalloc((void**)&_devVertexPaths, sizeof(int)*_vertexPathAllocation));
              cudaCheck(cudaMallocHost((void**)&_hostVertexPaths, sizeof(int)*_vertexPathAllocation));
              _vertexPathsAllocated = true;
            }
          }
          //
          void copyNeighbours(cudaStream_t s0){
            cudaStreamSynchronize(s0);
            cudaCheck(cudaMemcpyAsync(_hostSolutionCounts, _devSolutionCounts, _levelDepth*sizeof(int), cudaMemcpyDeviceToHost, s0));
            cudaCheck(cudaMemcpyAsync(_hostNeighbourCounts, _devNeighbourCounts, _vertexAllocation*sizeof(int), cudaMemcpyDeviceToHost, s0));
            cudaCheck(cudaMemcpyAsync(_hostVertexDistances, _devVertexDistances, _vertexAllocation*_vertexAllocation*sizeof(float), cudaMemcpyDeviceToHost, s0));
          }
          void allocateNeighbours(cudaStream_t s0){
            cudaStreamSynchronize(s0);
            //cudaDeviceSynchronize();
            // int count = 0;
            //("beforeupdate CNT \n neighbourAlloc %d \n vertexAlloc %d \n clusterNeighbourTotal %d \n",_neighbourAllocation, _vertexAllocation, _clusterNeighbourTotal);
            
            for(int x=0; x<_vertexAllocation; x++){
              _clusterNeighbourTotal += *(_hostNeighbourCounts+x);
            }
            _hostSolutionCounts[0] = _clusterNeighbourTotal;
            //printf("after update CNT \n neighbourAlloc %d \n vertexAlloc %d \n clusterNeighbourTotal %d \n",_neighbourAllocation, _vertexAllocation, _clusterNeighbourTotal);
            
            //std::cout << "clusterNeighbourTotal= " << _clusterNeighbourTotal << std::endl;
            //std::cout << "neighbourAllocation= " << _neighbourAllocation << std::endl;
            if(_clusterNeighbourTotal>_neighbourAllocation){
              //Then required allocation isn't sufficient for vertex buffer.
              if(_neighboursAllocated){
                //free buffer and paths for reallocation this is because paths size is tied to buffer size.
                cudaFree(_devNeighbourMap);
                cudaFreeHost(_hostNeighbourMap);
                cudaFree(_devNeighbourDistances);
                cudaFreeHost(_hostNeighbourDistances);
                cudaFree(_devNeighbourIndices);
                cudaFreeHost(_hostNeighbourIndices);
              }
              //std::cout << "an6" << std::endl;
              _neighbourAllocation = _clusterNeighbourTotal;
              cudaCheck(cudaMalloc((void**)&_devNeighbourMap, _neighbourAllocation*sizeof(int)));
              cudaCheck(cudaMallocHost((void**)&_hostNeighbourMap, _neighbourAllocation*sizeof(int)));
              cudaCheck(cudaMalloc((void**)&_devNeighbourDistances, _neighbourAllocation*sizeof(float)));
              cudaCheck(cudaMallocHost((void**)&_hostNeighbourDistances, _neighbourAllocation*sizeof(float)));
              cudaCheck(cudaMalloc((void**)&_devNeighbourIndices, _neighbourAllocation*sizeof(int)));
              cudaCheck(cudaMallocHost((void**)&_hostNeighbourIndices, _neighbourAllocation*sizeof(int)));
              _neighboursAllocated = true;
            }
          }



          void populateNeighbours(cudaStream_t s0){
            //allocateNeighbours();
            cudaStreamSynchronize(s0);
            int index = 0;
            //("populate neighbours \n neighbourAlloc %d \n vertexAlloc %d \n clusterNeighbourTotal %d \n",_neighbourAllocation, _vertexAllocation, _clusterNeighbourTotal);
            //std::cout << "neighbourAllocation= " << _neighbourAllocation << std::endl;
            //std::cout << "vertexAllocation = " << _vertexAllocation << std::endl;
            //std::cout << "clusterNeighbourTotal = " << _clusterNeighbourTotal << std::endl;
            if(_vertexAllocation>1){
              for(int x = 0; x<_vertexAllocation; x++){
                _hostNeighbourIndices[x] = index;
                int count = 0;
                for(int y = 0; y<_vertexAllocation; y++){

                  if(x!=y){
                  //   int pairIndex;
                  //   if(x<y){
                  //     pairIndex = x*(_vertexAllocation-1)-(x*(x-1)/2) + (y-x-1);
                  //   }else{
                  //     pairIndex = y*(_vertexAllocation-1)-(y*(y-1)/2) + (x-y-1);
                  //   }
                    //int graphIndex = x*_vertexAllocation+y;
                    int graphIndex = _hostVertexBuffer[x]*(*_hostClusterCount)+_hostVertexBuffer[y];
                    if(_hostClusterDistances[graphIndex]>0){
                      _hostNeighbourMap[index] = y;
                      _hostNeighbourDistances[index]= _hostClusterDistances[graphIndex];
                      index+=1;
                      count+=1;
                    }
                  }
                }
              }
            }
            //}
            cudaCheck(cudaMemcpyAsync(_devSolutionCounts, _hostSolutionCounts, _levelDepth*sizeof(int), cudaMemcpyHostToDevice,s0));
            cudaCheck(cudaMemcpyAsync(_devNeighbourMap, _hostNeighbourMap, _neighbourAllocation*sizeof(int), cudaMemcpyHostToDevice,s0));
            cudaCheck(cudaMemcpyAsync(_devNeighbourDistances, _hostNeighbourDistances, _neighbourAllocation*sizeof(float), cudaMemcpyHostToDevice,s0));
            cudaCheck(cudaMemcpyAsync(_devNeighbourIndices, _hostNeighbourIndices, _vertexAllocation*sizeof(int), cudaMemcpyHostToDevice,s0));
          }
          //
          void getClosestVertices(){
            //for all nodes in the cluster, get the vertex index of the closest vertex node.
            //Store it in a map. A result of -1 means that the node is a vertex.
          }

          void freeMemory(){

              cudaCheck(cudaFree(_devClusterCount));
              cudaCheck(cudaFreeHost(_hostClusterCount));

              cudaCheck(cudaFree(_devVertexCount));
              cudaCheck(cudaFreeHost(_hostVertexCount));

              cudaCheck(cudaFree(_devClusterPairs));
              cudaCheck(cudaFreeHost(_hostClusterPairs));

              cudaCheck(cudaFree(_devClusterIndex));
              cudaCheck(cudaFreeHost(_hostClusterIndex));

              cudaCheck(cudaFree(_devClusterDistances));
              cudaCheck(cudaFreeHost(_hostClusterDistances));

              cudaCheck(cudaFree(_devEdgeWorker));
              cudaCheck(cudaFree(_devEdgeDirection));
              cudaCheck(cudaFree(_devEdgeScore));

              cudaCheck(cudaFree(_devVertexWorker));

              cudaCheck(cudaFree(_devVertexBuffer));
              cudaCheck(cudaFreeHost(_hostVertexBuffer));

              cudaCheck(cudaFree(_devScoreSize));
              cudaCheck(cudaFreeHost(_hostScoreSize));

              cudaCheck(cudaFree(_devLevel));
              cudaCheck(cudaFreeHost(_hostLevel));

              cudaCheck(cudaFree(_devVertexSolution));
              cudaCheck(cudaFreeHost(_hostVertexSolution));

              cudaCheck(cudaFree(_devClusterScoreSize));
              cudaCheck(cudaFreeHost(_hostClusterScoreSize));


              cudaCheck(cudaFree(_devSolutionCounts));
              cudaCheck(cudaFreeHost(_hostSolutionCounts));

              if(_verticesAllocated){
                cudaCheck(cudaFree(_devVertexDistances));
                cudaCheck(cudaFreeHost(_hostVertexDistances));

                cudaCheck(cudaFree(_devNeighbourCounts));
                cudaCheck(cudaFreeHost(_hostNeighbourCounts));

                cudaCheck(cudaFree(_devGraphScores));
                cudaCheck(cudaFreeHost(_hostGraphScores));

                cudaCheck(cudaFree(_devNewGraphScores));

                cudaCheck(cudaFree(_devGraphLevels));
                //cudaFreeHost(_hostGraphLevels);

                cudaCheck(cudaFree(_devIndexPairs));
                cudaCheck(cudaFreeHost(_hostIndexPairs));
              }
              if(_neighboursAllocated){
                cudaCheck(cudaFree(_devNeighbourMap));
                cudaCheck(cudaFreeHost(_hostNeighbourMap));

                cudaCheck(cudaFree(_devNeighbourDistances));
                cudaCheck(cudaFreeHost(_hostNeighbourDistances));

                cudaCheck(cudaFree(_devNeighbourIndices));
                cudaCheck(cudaFreeHost(_hostNeighbourIndices));
              }
          }
          //void setVertexSolution(int value){_vertexSolution = value;}
          int* devVertexSolution(){return _devVertexSolution;}
          int* hostVertexSolution(){return _hostVertexSolution;}

          void setSolutionLevel(int level){_solutionLevel = level;}
          int solutionLevel(){return _solutionLevel;}

          int levelDepth(){return _levelDepth;}

          int* devLevel(){return _devLevel;}
          int* hostLevel(){return _hostLevel;}

          int* devClusterCount(){return _devClusterCount;}
          int* hostClusterCount(){return _hostClusterCount;}

          int* devClusterIndex(){return _devClusterIndex;}
          int* hostClusterIndex(){return _hostClusterIndex;}

          int* devVertexCount(){return _devVertexCount;}
          int* hostVertexCount(){return _hostVertexCount;}

          uint8_t* devEdgeWorker(){return _devEdgeWorker;}
          uint8_t* devEdgeDirection(){return _devEdgeDirection;}
          uint8_t* devEdgeScore(){return _devEdgeScore;}

          uint8_t* devVertexWorker(){return _devVertexWorker;} // max possible size equals number of safe cells in known grid. assuming every sigle cell is a vertex cell.
          //                                        This gets pared down to all grid cells that are valid vertices.
          //                                        It then checks for vertex cells that share at least two faces with other vertex cells
          //                                        these vertex cells aren't migrated to the final vertex buffer through the use of a flag array
          int* devVertexBuffer(){return _devVertexBuffer;}
          int* hostVertexBuffer(){return _hostVertexBuffer;}

          float* devVertexDistances(){return _devVertexDistances;} //Contains distance between all vertex Pairings. Calculated in parallel using ray tracing. Used for calculating devVertexPaths
          //                           //This contains the manhattan distance at each index between the target vertex, with -1 meaning the vertices cannot see each other.
          float* hostVertexDistances(){return _hostVertexDistances;} //Contains distance between all vertex Pairings. Calculated in parallel using ray tracing. Used for calculating devVertexPaths
          //This contains the manhattan distance at each index between the target vertex, with -1 meaning the vertices cannot see each other.

          float* devClusterDistances(){return _devClusterDistances;}
          float* hostClusterDistances(){return _hostClusterDistances;}

          int* devScoreSize(){return _devScoreSize;}
          int* hostScoreSize(){return _hostScoreSize;}
          int* devClusterScoreSize(){return _devClusterScoreSize;}
          int* hostClusterScoreSize(){return _hostClusterScoreSize;}


          float* devGraphScores(){return _devGraphScores;}// contains graph scores and the corresponding level to the solution.
          float* hostGraphScores(){return _hostGraphScores;}

          float* devNewGraphScores(){return _devNewGraphScores;} // stores new graph scores, then is copied into graph scores between iterations.

          float* devGraphLevels(){return _devGraphLevels;}
          float* hostGraphLevels(){return _hostGraphLevels;}

          int* devIndexPairs(){return _devIndexPairs;}
          int* hostIndexPairs(){return _hostIndexPairs;}

          int* devClusterPairs(){return _devClusterPairs;}
          int* hostClusterPairs(){return _hostClusterPairs;}

          //Used for checking whether solutions exist at last level of graph solver.
          int* devSolutionCounts(){return _devSolutionCounts;}
          int* hostSolutionCounts(){return _hostSolutionCounts;}

          int* hostVertexPaths(){return _hostVertexPaths;}
          int* devVertexPaths(){return _devVertexPaths;}

          int* devNeighbourCounts(){return _devNeighbourCounts;}
          int* hostNeighbourCounts(){return _hostNeighbourCounts;}
          int* devNeighbourMap(){return _devNeighbourMap;}
          int* hostNeighbourMap(){return _hostNeighbourMap;}
          float* devNeighbourDistances(){return _devNeighbourDistances;}
          float* hostNeighbourDistances(){return _hostNeighbourDistances;}
          int* devNeighbourIndices(){return _devNeighbourIndices;}
          int* hostNeighboutIndices(){return _hostNeighbourIndices;}

          int vertexAllocation(){return _vertexAllocation;}

    private:
      //int clusterIndex =
      int _clusterNeighbourTotal = 0;
      int _vertexSolution = 0;
      int _solutionLevel = 0;
      bool _verticesAllocated = false;
      int _vertexAllocation = 0;
      bool _neighboursAllocated = false;
      int _neighbourAllocation = 0;
      bool _vertexPathsAllocated = false;
      int _vertexPathAllocation = 0;
      int _scoreAllocation = 0;
      int _levelDepth = 8;

      int* _devLevel;
      int* _hostLevel;

      int* _devVertexSolution;
      int* _hostVertexSolution;

      int* _devClusterCount;
      int* _hostClusterCount;

      int* _devClusterScoreSize;
      int* _hostClusterScoreSize;

      int* _devClusterIndex;
      int* _hostClusterIndex;

      int* _devVertexCount;
      int* _hostVertexCount;


      uint8_t* _devEdgeWorker;
      uint8_t* _devEdgeDirection;
      uint8_t* _devEdgeScore;

      uint8_t* _devVertexWorker; // max possible size equals number of safe cells in known grid. assuming every sigle cell is a vertex cell.
      //                                        This gets pared down to all grid cells that are valid vertices.
      //                                        It then checks for vertex cells that share at least two faces with other vertex cells
      //                                        these vertex cells aren't migrated to the final vertex buffer through the use of a flag array
      int* _devVertexBuffer;
      int* _hostVertexBuffer;

      float* _devVertexDistances; //Contains distance between all vertex Pairings. Calculated in parallel using ray tracing. Used for calculating devVertexPaths
      //                           //This contains the manhattan distance at each index between the target vertex, with -1 meaning the vertices cannot see each other.
      float* _hostVertexDistances; //Contains distance between all vertex Pairings. Calculated in parallel using ray tracing. Used for calculating devVertexPaths
      //This contains the manhattan distance at each index between the target vertex, with -1 meaning the vertices cannot see each other.

      float* _devClusterDistances;
      float* _hostClusterDistances;


      int* _devScoreSize;
      int* _hostScoreSize;

      float* _devGraphScores;// contains graph scores and the corresponding level to the solution.
      float* _hostGraphScores;

      float* _devNewGraphScores; // stores new graph scores, then is copied into graph scores between iterations.

      float* _devGraphLevels;
      float* _hostGraphLevels;

      int* _devIndexPairs;
      int* _hostIndexPairs;

      int* _devClusterPairs;
      int* _hostClusterPairs;

      //Used for checking whether solutions exist at last level of graph solver.
      int* _devSolutionCounts;
      int* _hostSolutionCounts;

      //Visible neighbour information to save compute during graph solution.
      int* _devNeighbourMap;
      int* _hostNeighbourMap;
      //The manhattan distance between each vertex and it's visible neighbour verteces
      float* _devNeighbourDistances;
      float* _hostNeighbourDistances;
      //The amount of visible neighbours a vertex has within the vertex graph.
      int* _devNeighbourCounts;
      int* _hostNeighbourCounts;
      //
      int* _devNeighbourIndices;
      int* _hostNeighbourIndices;

      int* _hostVertexPaths;
      int* _devVertexPaths;     //Really a list of paths, each path mapping to a reduced pairwise matrix entry.
                                //Matrix is reduced because paths are unidirectional, meaning list size is (X*(X-1))/2 and max path size is X-2
                                //(start and end nodes are known at lookup and are also defined by list index)
                                //initialised to -1.
                                //For lookup for X vertices:
                                //Index = startIndex*(X-1)-(startIndex*(startIndex-1)/2) + (endIndex-startIndex-1);
                                //Array size = sizeof(int)*(x*(x-1)/2)*(length of longestPath-2)
                                //Where x = vertex count for known grid.
                                //Currently not implemented, but can be extracted from the graphLevels array.

    };



      //Calculating terminal distances is as follows
      //For an agent position A and Target B
      //Check if B is visible from A,
      //If visible, Vertex pathing not required.

      //Solve for closest leaf that views B from A
      //Using inverseLeaves and obsBy matrices.

      //else
      //Look up the closest vertices to A and B. These are the start and end vertices.
      //Then look up the shortest path between those vertices.
      //Starting with the next vertices in the path, check to see if any are visible to A or B.
      //If they are, then they become the new start or end vertex and the shortest path doesn't include the prior nodes.
      //Shortest path is calculated as manhattan distance from A->NewStartVertex->NewEndVertex->B.
      //Is the path end node in the inverse leaves grid, and is it a valid observer.
      //If yes: then you've found the node closest to A that can observe B.
      //Else:
      //First, loop over all vertex neighbours for the target, and check if any exist as valid observers.
      //If a vertex neighbour is a valid observer, then check the distance from that observer to NewStartVertex.
      //If it is shorter than the current distance, store it.
      //else if it is larger, store it if it is the smallest alternative.
      //If a value is shorter than the original path length, you've found the closest node to A that can observe B
      //else if the next best observer alternative is larger, find the shortest distance
      //between the original shortest path distance to the closest observer given by the observer matrix.
      //If there are no obstructions and the distance of the original path node + the step to the closest observer
      //is less than the distance to the alternative, then that is the shortest observer path, else the use the alternative.



      //OLD LOGIC
      //If not then find shortest path from A to B:
      //Look up the closest vertices to A and B. These are the start and end vertices.
      //Then look up the shortest path between those vertices.
      //Starting with the next vertices in the path, check to see if any are visible to A or B.
      //If they are, then they become the new start or end vertex and the shortest path doesn't include the prior nodes.
      //Shortest path is calculated as manhattan distance from A->NewStartVertex->NewEndVertex->ObservationNode->B.
      //From the new end vertex, known as the first visible vertex (FVV), find the closest node that can see B.

      //To solve the shortest path from the first visible vertex (FVV) and the target,
      //Convert the FVV to an inverse leaves offset (FVV-target).
      //Look up the target in the Observers matrix. Using the InverseLeavesGrid, input coord offset, to get index of FVV in Observers,
      //IF IT EXISTS. If it doesn't exist. Use the observers matrix and the inverse leaves index
      //, iterating over all valid observers to get the node
      //that has the minimum distance to FVV and is a valid observer.
  }
}
#endif
