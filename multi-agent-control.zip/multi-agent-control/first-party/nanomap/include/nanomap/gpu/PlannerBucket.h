#ifndef NANOMAP_GPU_PLANNERBUCKET_H_INCLUDED
#define NANOMAP_GPU_PLANNERBUCKET_H_INCLUDED
//#include <openvdb/openvdb.h>
#include <nanovdb/util/CudaDeviceBuffer.h>
#include <nanovdb/util/GridHandle.h>
//#include "nanomap/sensor/SensorData.h"
#include "nanomap/nanomap.h"
#include <set>
#include "nanomap/gpu/handlerAssert.h"
//#include "nanomap/gpu/Cluster.h"


//
// #define cudaCheck(ans) \
//     { \
//         gpuAssert((ans), __FILE__, __LINE__); \
//     }
//
// extern static inline bool gpuAssert(cudaError_t code, const char* file, int line, bool abort = true)
// {
// #if defined(DEBUG) || defined(_DEBUG)
//     if (code != cudaSuccess) {
//         fprintf(stderr, "CUDA Runtime Error: %s %s %d\n", cudaGetErrorString(code), file, line);
//         if (abort)
//             exit(code);
//         return false;
//     }
// #endif
//     return true;
// }

namespace nanomap{
  namespace gpu{
    using BufferT = nanovdb::CudaDeviceBuffer;
    using ValueT  = float;

    class PlannerBucket
    {

    public:

    PlannerBucket(){
      cudaCheck(cudaMalloc((void**)&_devVertexPatterns, sizeof(uint32_t)*11));
      cudaCheck(cudaMallocHost((void**)&_hostVertexPatterns, sizeof(uint32_t)*11));
      cudaCheck(cudaMalloc((void**)&_devGridRes, sizeof(float)));
      cudaCheck(cudaMallocHost((void**)&_hostGridRes, sizeof(float)));
      cudaCheck(cudaMalloc((void**)&_devMappingRes, sizeof(float)));
      cudaCheck(cudaMallocHost((void**)&_hostMappingRes, sizeof(float)));
      cudaCheck(cudaMalloc((void**)&_devPlannerRes, sizeof(float)));
      cudaCheck(cudaMallocHost((void**)&_hostPlannerRes, sizeof(float)));
      cudaCheck(cudaMalloc((void**)&_devTileEdge, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostTileEdge, sizeof(int)));
      cudaCheck(cudaMalloc((void**)&_devSafeCount, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostSafeCount, sizeof(int)));
      cudaCheck(cudaMalloc((void**)&_devValidCount, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostValidCount, sizeof(int)));

      cudaCheck(cudaMalloc((void**)&_devBoundaryCount, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostBoundaryCount, sizeof(int)));
      cudaCheck(cudaMalloc((void**)&_devBoundaryScoreSize, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostBoundaryScoreSize, sizeof(int)));

      cudaCheck(cudaMalloc((void**)&_devLevel, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostLevel, sizeof(int)));
      *_hostLevel = 0;
      cudaCheck(cudaMemcpy(_devLevel, _hostLevel, sizeof(int), cudaMemcpyHostToDevice));


      cudaCheck(cudaMalloc((void**)&_devSolutionCounts, _levelDepth*sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostSolutionCounts, _levelDepth*sizeof(int)));
      cudaCheck(cudaMemset(_devSolutionCounts, 0, _levelDepth*sizeof(int)));
      cudaCheck(cudaMemcpy(_hostSolutionCounts, _devSolutionCounts, _levelDepth*sizeof(int), cudaMemcpyDeviceToHost));
    }

    PlannerBucket(float gridRes, float mappingRes, float plannerRes, int tileEdge){
      cudaCheck(cudaMalloc((void**)&_devVertexPatterns, sizeof(uint32_t)*11));
      cudaCheck(cudaMallocHost((void**)&_hostVertexPatterns, sizeof(uint32_t)*11));

      cudaCheck(cudaMalloc((void**)&_devGridRes, sizeof(float)));
      cudaCheck(cudaMallocHost((void**)&_hostGridRes, sizeof(float)));
      cudaCheck(cudaMalloc((void**)&_devMappingRes, sizeof(float)));
      cudaCheck(cudaMallocHost((void**)&_hostMappingRes, sizeof(float)));
      cudaCheck(cudaMalloc((void**)&_devPlannerRes, sizeof(float)));
      cudaCheck(cudaMallocHost((void**)&_hostPlannerRes, sizeof(float)));
      cudaCheck(cudaMalloc((void**)&_devTileEdge, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostTileEdge, sizeof(int)));
      cudaCheck(cudaMalloc((void**)&_devSafeCount, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostSafeCount, sizeof(int)));
      cudaCheck(cudaMalloc((void**)&_devValidCount, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostValidCount, sizeof(int)));


      cudaCheck(cudaMalloc((void**)&_devBoundaryCount, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostBoundaryCount, sizeof(int)));
      cudaCheck(cudaMalloc((void**)&_devBoundaryScoreSize, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostBoundaryScoreSize, sizeof(int)));

      cudaCheck(cudaMalloc((void**)&_devLevel, sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostLevel, sizeof(int)));
      *_hostLevel = 0;
      cudaCheck(cudaMemcpy(_devLevel, _hostLevel, sizeof(int), cudaMemcpyHostToDevice));


      cudaCheck(cudaMalloc((void**)&_devSolutionCounts, _levelDepth*sizeof(int)));
      cudaCheck(cudaMallocHost((void**)&_hostSolutionCounts, _levelDepth*sizeof(int)));
      cudaCheck(cudaMemset(_devSolutionCounts, 0, _levelDepth*sizeof(int)));
      cudaCheck(cudaMemcpy(_hostSolutionCounts, _devSolutionCounts, _levelDepth*sizeof(int), cudaMemcpyDeviceToHost));

      init(gridRes, mappingRes, plannerRes, tileEdge);
    }

    ~PlannerBucket(){
      freeMemory();
    }

    void init(float gridRes, float mappingRes, float plannerRes, int tileEdge){
      printf("TILE EDGE DURING INIT %d \n", tileEdge);

      uint32_t patterns[11] =
      {
        0b000010000010101010000010000, //face check 0
        0b111111111000000000000000000, //-x side edge edges 1
        0b111000000111000000111000000, //-y 2
        0b100100100100100100100100100, //-z 3
        0b000000000000000000111111111, //x side edge edges 4
        0b000000111000000111000000111, //y 5
        0b001001001001001001001001001, // z 6
        0b000000000101000101000000000,
        0b000101000000000000000101000,
        0b010000010000000000010000010,
        0b101000101000000000101000101
      };
      for(int x = 0; x < 11; x++){
      *(_hostVertexPatterns+x) = patterns[x];
      }
      // for(int x = 0; x < 11; x++){
      //   printf("vertexPattern: %u,\n",_hostVertexPatterns[x]);
      // }

      cudaCheck(cudaMemcpy(_devVertexPatterns, _hostVertexPatterns, sizeof(uint32_t)*11, cudaMemcpyHostToDevice));
      //*_hostSafeOcclusionCount = 0;
      //cudaCheck(cudaMemcpy(_devSafeOcclusionCount, _hostSafeOcclusionCount, sizeof(int), cudaMemcpyHostToDevice));
      *_hostGridRes = gridRes;
      cudaCheck(cudaMemcpy(_devGridRes, _hostGridRes, sizeof(float), cudaMemcpyHostToDevice));
      *_hostMappingRes = mappingRes;
      cudaCheck(cudaMemcpy(_devMappingRes, _hostMappingRes, sizeof(float), cudaMemcpyHostToDevice));
      *_hostPlannerRes = plannerRes;
      cudaCheck(cudaMemcpy(_devPlannerRes, _hostPlannerRes, sizeof(float), cudaMemcpyHostToDevice));
      *_hostTileEdge = tileEdge;
      cudaCheck(cudaMemcpy(_devTileEdge, _hostTileEdge, sizeof(int), cudaMemcpyHostToDevice));
      //*_hostVertexCount = 0;
      //cudaCheck(cudaMemcpy(_devVertexCount, _hostVertexCount, sizeof(int), cudaMemcpyHostToDevice));
      *_hostSafeCount = 0;
      cudaCheck(cudaMemcpy(_devSafeCount, _hostSafeCount, sizeof(int), cudaMemcpyHostToDevice));
      *_hostValidCount = 0;
      cudaCheck(cudaMemcpy(_devValidCount, _hostValidCount, sizeof(int), cudaMemcpyHostToDevice));

      _initialised = true;

    }
/******************************************************************************/
    //void updateKnownGrid(cudaStream_t s0){
      //Used for handling map changes TODO
    //}
/******************************************************************************/
//This is the logic for updating the map from scratch.
      void allocateValidAndSafe(int validCount, int safeCount){
        //int newDistanceAllocation = (validCount*(validCount-1))/2;
        //int newValidAllocation = validCount;
        if(safeCount > _safeAllocation){
          _safeAllocation = safeCount;
          *_hostSafeCount = _safeAllocation;
          cudaCheck(cudaMemcpy(_devSafeCount, _hostSafeCount, sizeof(int), cudaMemcpyHostToDevice));
          cudaFree(_devSafeIndex);
          cudaFreeHost(_hostSafeIndex);
        }
        cudaCheck(cudaMalloc((void**)&_devSafeIndex, (*_hostSafeCount)*sizeof(int)));
        cudaCheck(cudaMallocHost((void**)&_hostSafeIndex, (*_hostSafeCount)*sizeof(int)));
        _safeAllocated = true;

        if(validCount > _validAllocation){
          if(_validAllocated){

            cudaFree(_devGridIndex);
            cudaFreeHost(_hostGridIndex);
            cudaFree(_devClusterMask);
            cudaFreeHost(_hostClusterMask);
            cudaFree(_devRepulsionVecs);
            cudaFreeHost(_hostRepulsionVecs);
            cudaFree(_devNextRepulsionVecs);
            cudaFree(_devClusterParents);
            cudaFree(_hostClusterParents);
            cudaFree(_devClusterWorker);
          }
          _validAllocation = validCount;
          *_hostValidCount = _validAllocation;
          cudaCheck(cudaMemcpy(_devValidCount, _hostValidCount, sizeof(int), cudaMemcpyHostToDevice));
          cudaCheck(cudaMalloc((void**)&_devGridIndex, _validAllocation*sizeof(nanovdb::Coord)));
          cudaCheck(cudaMallocHost((void**)&_hostGridIndex, _validAllocation*sizeof(nanovdb::Coord)));
          cudaCheck(cudaMalloc((void**)&_devClusterMask, _validAllocation*sizeof(uint8_t)));
          cudaCheck(cudaMallocHost((void**)&_hostClusterMask, _validAllocation*sizeof(uint8_t)));
          cudaCheck(cudaMalloc((void**)&_devRepulsionVecs, _validAllocation*sizeof(nanovdb::Vec3f)));
          cudaCheck(cudaMalloc((void**)&_devNextRepulsionVecs, _validAllocation*sizeof(nanovdb::Vec3f)));
          cudaCheck(cudaMallocHost((void**)&_hostRepulsionVecs, _validAllocation*sizeof(nanovdb::Vec3f)));
          cudaCheck(cudaMalloc((void**)&_devClusterParents, _validAllocation*sizeof(int)));
          cudaCheck(cudaMalloc((void**)&_devClusterWorker, _validAllocation*sizeof(int)));
          cudaCheck(cudaMallocHost((void**)&_hostClusterParents, _validAllocation*sizeof(int)));

          _validAllocated = true;
        }

      }

      void allocateBoundaryPaths(cudaStream_t s0){
        cudaStreamSynchronize(s0);
        //void allocateVertexPaths(){
        
        int size = (*_hostBoundaryScoreSize)*(*_hostLevel);
        //cluster.allocateVertexPaths((*cluster.hostScoreSize())*level);
        //}
        printf("boundaryPathAllocationSize = %d, hostlevel = %d \n", size, *_hostLevel);
        if(size > _boundaryPathsAllocation){
          if(_boundaryPathsAllocated){
            cudaFree(_devBoundaryPaths);
            cudaFreeHost(_hostBoundaryPaths);
          }
          _boundaryPathsAllocation = size;
          printf("_boundaryPathsAllocation = %d \n",_boundaryPathsAllocation);
          cudaCheck(cudaMalloc((void**)&_devBoundaryPaths, sizeof(int)*_boundaryPathsAllocation));
          cudaCheck(cudaMallocHost((void**)&_hostBoundaryPaths, sizeof(int)*_boundaryPathsAllocation));
          _boundaryPathsAllocated = true;
        }
      }

      void populateBoundaryPairs(){
        for(int x = 0; x< (*_hostBoundaryCount); x++){
          for(int y = 0; y< (*_hostBoundaryCount); y++){

            if(x<y){
                int  pairIndex = x*((*_hostBoundaryCount)-1)-(x*(x-1)/2) + (y-x-1);
                _hostBoundaryPairs[pairIndex] = x;
                _hostBoundaryPairs[pairIndex+(*_hostBoundaryScoreSize)] = y;
            }
          }
        }
      }

        void copyBoundaryContainers(cudaStream_t s0){
          cudaCheck(cudaMemcpyAsync(_devBoundaryCount, _hostBoundaryCount, sizeof(int), cudaMemcpyHostToDevice, s0));
          cudaCheck(cudaMemcpyAsync(_devBoundaryScoreSize, _hostBoundaryScoreSize, sizeof(int), cudaMemcpyHostToDevice, s0));
          cudaCheck(cudaMemcpyAsync(_devSolutionCounts, _hostSolutionCounts, _levelDepth*sizeof(int), cudaMemcpyHostToDevice, s0));
          cudaCheck(cudaMemcpyAsync(_devGraphLevels, _hostGraphLevels, (*_hostBoundaryScoreSize)*_levelDepth*sizeof(float), cudaMemcpyHostToDevice, s0));
          cudaCheck(cudaMemcpyAsync(_devGraphScores, _hostGraphScores, (*_hostBoundaryScoreSize)*2*sizeof(float), cudaMemcpyHostToDevice, s0));
          cudaDeviceSynchronize();
          cudaCheck(cudaMemcpyAsync(_devNewGraphScores, _hostGraphScores, (*_hostBoundaryScoreSize)*2*sizeof(float), cudaMemcpyHostToDevice, s0));
          cudaCheck(cudaMemcpyAsync(_devNeighbourMap, _hostNeighbourMap, _neighbourCount*sizeof(int), cudaMemcpyHostToDevice, s0));
          cudaCheck(cudaMemcpyAsync(_devNeighbourCounts, _hostNeighbourCounts, (*_hostBoundaryCount)*sizeof(int), cudaMemcpyHostToDevice, s0));
          cudaCheck(cudaMemcpyAsync(_devNeighbourDistances, _hostNeighbourDistances, _neighbourCount*sizeof(float), cudaMemcpyHostToDevice, s0));
          cudaCheck(cudaMemcpyAsync(_devNeighbourIndices, _hostNeighbourIndices, _neighbourCount*sizeof(int), cudaMemcpyHostToDevice, s0));
          cudaCheck(cudaMemcpyAsync(_devBoundaryPairs, _hostBoundaryPairs, (*_hostBoundaryScoreSize)*2*sizeof(int), cudaMemcpyHostToDevice, s0));
          cudaDeviceSynchronize();
      }

      void allocateBoundaryContainers(int boundaryCount, int scoreSize, int neighbourCount){
        *_hostBoundaryCount = boundaryCount;
        *_hostBoundaryScoreSize = scoreSize;
        _neighbourCount = neighbourCount;
        _boundaryContainersAllocated = true;
        printf("_neighbourCount = %d \n", _neighbourCount);
        printf("_scoreSize = %d \n", scoreSize);
        cudaCheck(cudaMalloc((void**)&_devNeighbourCounts, boundaryCount*sizeof(int)));
        cudaCheck(cudaMallocHost((void**)&_hostNeighbourCounts, boundaryCount*sizeof(int)));
        cudaCheck(cudaMemset(_devNeighbourCounts, 0, boundaryCount*sizeof(int)));
        cudaCheck(cudaMemcpy(_hostNeighbourCounts, _devNeighbourCounts, boundaryCount*sizeof(int), cudaMemcpyDeviceToHost));

        cudaCheck(cudaMalloc((void**)&_devGraphLevels, scoreSize*_levelDepth*sizeof(float)));
        cudaCheck(cudaMallocHost((void**)&_hostGraphLevels, scoreSize*_levelDepth*sizeof(float)));
        //cudaCheck(cudaMemset(_devGraphLevels, (int)-1.0, scoreSize*_levelDepth*sizeof(float)));
        // cudaCheck(cudaMemcpy(_hostGraphLevels, _devGraphLevels, scoreSize*_levelDepth*sizeof(float), cudaMemcpyDeviceToHost));

        cudaCheck(cudaMalloc((void**)&_devGraphScores, scoreSize*2*sizeof(float)));
        cudaCheck(cudaMallocHost((void**)&_hostGraphScores, scoreSize*2*sizeof(float)));
        cudaCheck(cudaMalloc((void**)&_devNewGraphScores, scoreSize*2*sizeof(float)));
        //cudaCheck(cudaMemset(_devGraphScores, (int)100000.0, scoreSize*2*sizeof(float)));
        //cudaCheck(cudaMemcpy(_hostGraphScores, _devGraphScores, scoreSize*2*sizeof(float), cudaMemcpyDeviceToHost));


        //cudaCheck(cudaMalloc((void**)&_devLevel, sizeof(int)));
        //cudaCheck(cudaMallocHost((void**)&_hostLevel, sizeof(int)));

        cudaCheck(cudaMalloc((void**)&_devBoundaryPairs, scoreSize*2*sizeof(int)));
        cudaCheck(cudaMallocHost((void**)&_hostBoundaryPairs, scoreSize*2*sizeof(int)));



        cudaCheck(cudaMalloc((void**)&_devNeighbourMap, _neighbourCount*sizeof(int)));
        cudaCheck(cudaMallocHost((void**)&_hostNeighbourMap, _neighbourCount*sizeof(int)));
        cudaCheck(cudaMalloc((void**)&_devNeighbourDistances, _neighbourCount*sizeof(float)));
        cudaCheck(cudaMallocHost((void**)&_hostNeighbourDistances, _neighbourCount*sizeof(float)));
        cudaCheck(cudaMalloc((void**)&_devNeighbourIndices, _neighbourCount*sizeof(int)));
        cudaCheck(cudaMallocHost((void**)&_hostNeighbourIndices, _neighbourCount*sizeof(int)));
        cudaDeviceSynchronize();
        //populateBoundaryPairs();
      }

      void increaseLevelDepth(cudaStream_t s0){
        _levelDepth = _levelDepth*2;
        //FREE THE MEMORY

        cudaCheck(cudaFree(_devSolutionCounts));
        cudaCheck(cudaFreeHost(_hostSolutionCounts));
        cudaCheck(cudaFree(_devGraphLevels));
        cudaCheck(cudaFreeHost(_hostGraphLevels));

        //Reallocate it
        cudaCheck(cudaMalloc((void**)&_devGraphLevels, (*_hostBoundaryScoreSize)*_levelDepth*sizeof(float)));
        cudaCheck(cudaMallocHost((void**)&_hostGraphLevels, (*_hostBoundaryScoreSize)*_levelDepth*sizeof(float)));
        cudaCheck(cudaMalloc((void**)&_devSolutionCounts, _levelDepth*sizeof(int)));
        cudaCheck(cudaMallocHost((void**)&_hostSolutionCounts, _levelDepth*sizeof(int)));
        
        cudaCheck(cudaMemset(_devSolutionCounts, 0, _levelDepth*sizeof(int)));
        
        // cudaCheck(cudaMemcpyAsync(_devSolutionCounts, _hostSolutionCounts, _levelDepth*sizeof(int), cudaMemcpyHostToDevice, s0));
        // cudaCheck(cudaMemcpyAsync(_devGraphLevels, _hostGraphLevels, (*_hostBoundaryScoreSize)*_levelDepth*sizeof(float), cudaMemcpyHostToDevice, s0));
          
      
      }

      void freeMemory(){

        cudaCheck(cudaFree(_devVertexPatterns));
        cudaCheck(cudaFreeHost(_hostVertexPatterns));
        cudaCheck(cudaFree(_devGridRes));
        cudaCheck(cudaFreeHost(_hostGridRes));
        cudaCheck(cudaFree(_devMappingRes));
        cudaCheck(cudaFreeHost(_hostMappingRes));
        cudaCheck(cudaFree(_devPlannerRes));
        cudaCheck(cudaFreeHost(_hostPlannerRes));
        cudaCheck(cudaFree(_devTileEdge));
        cudaCheck(cudaFreeHost(_hostTileEdge));

        cudaCheck(cudaFree(_devSafeCount));
        cudaCheck(cudaFreeHost(_hostSafeCount));
        cudaCheck(cudaFree(_devValidCount));
        cudaCheck(cudaFreeHost(_hostValidCount));

        cudaCheck(cudaFree(_devLevel));
        cudaCheck(cudaFreeHost(_hostLevel));

        cudaCheck(cudaFree(_devSolutionCounts));
        cudaCheck(cudaFreeHost(_hostSolutionCounts));
        

        cudaCheck(cudaFree(_devBoundaryCount));
        cudaCheck(cudaFreeHost(_hostBoundaryCount));

        cudaCheck(cudaFree(_devBoundaryScoreSize));
        cudaCheck(cudaFreeHost(_hostBoundaryScoreSize));
        

        if(_safeAllocated){
          cudaCheck(cudaFree(_devSafeIndex));
          cudaCheck(cudaFreeHost(_hostSafeIndex));
        }

        if(_validAllocated){
          //cudaFree(_devVertexNearest);
          cudaCheck(cudaFree(_devGridIndex));
          cudaCheck(cudaFreeHost(_hostGridIndex));
          //cudaCheck(cudaFree(_devGridIndex);
          //cudaCheck(cudaFreeHost(_hostGridIndex);
          cudaCheck(cudaFree(_devClusterMask));
          cudaCheck(cudaFreeHost(_hostClusterMask));
          cudaCheck(cudaFree(_devRepulsionVecs));
          cudaCheck(cudaFreeHost(_hostRepulsionVecs));
          cudaCheck(cudaFree(_devNextRepulsionVecs));
          cudaCheck(cudaFree(_devClusterParents));
          cudaCheck(cudaFreeHost(_hostClusterParents));
          cudaCheck(cudaFree(_devClusterWorker));
        }

        if(_boundaryContainersAllocated){
          cudaCheck(cudaFree(_devNeighbourCounts));
          cudaCheck(cudaFreeHost(_hostNeighbourCounts));

          cudaCheck(cudaFree(_devGraphLevels));
          cudaCheck(cudaFreeHost(_hostGraphLevels));

          cudaCheck(cudaFree(_devGraphScores));
          cudaCheck(cudaFreeHost(_hostGraphScores));
          cudaCheck(cudaFree(_devNewGraphScores));

          cudaCheck(cudaFree(_devBoundaryPairs));
          cudaCheck(cudaFreeHost(_hostBoundaryPairs));

          cudaCheck(cudaFree(_devNeighbourMap));
          cudaCheck(cudaFreeHost(_hostNeighbourMap));

          cudaCheck(cudaFree(_devNeighbourDistances));
          cudaCheck(cudaFreeHost(_hostNeighbourDistances));

          cudaCheck(cudaFree(_devNeighbourIndices));
          cudaCheck(cudaFreeHost(_hostNeighbourIndices));
        }

        if(_boundaryPathsAllocated){
            cudaCheck(cudaFree(_devBoundaryPaths));
            cudaCheck(cudaFreeHost(_hostBoundaryPaths));
        }
    }


/******************************************************************************/
        bool initialised(){return _initialised;}
        bool nearestAllocated(){return _validAllocated;}
        int nearestAllocation(){return _validAllocation;}
        bool distanceAllocated(){return _safeAllocated;}
        int distanceAllocation(){return _safeAllocation;}
        uint32_t* devVertexPatterns(){return _devVertexPatterns;}
        uint32_t* hostVertexPatterns(){return _hostVertexPatterns;}
        float* devGridRes(){return _devGridRes;}
        float* hostGridRes(){return _hostGridRes;}
        float* devMappingRes(){return _devMappingRes;}
        float* hostMappingRes(){return _hostMappingRes;}
        float* devPlannerRes(){return _devPlannerRes;}
        float* hostPlannerRes(){return _hostPlannerRes;}
        int* devTileEdge(){return _devTileEdge;}
        int* hostTileEdge(){return _hostTileEdge;}
        int* hostSafeCount(){return _hostSafeCount;}
        int* devSafeCount(){return _devSafeCount;}
        int* hostValidCount(){return _hostValidCount;}
        int* devValidCount(){return _devValidCount;}
        nanovdb::Coord* hostGridIndex(){return _hostGridIndex;}
        nanovdb::Coord* devGridIndex(){return _devGridIndex;}
        int*            devSafeIndex(){return _devSafeIndex;}
        int*            hostSafeIndex(){return _hostSafeIndex;}

        nanovdb::Vec3f* devRepulsionVecs(){return _devRepulsionVecs;}
        nanovdb::Vec3f* devNextRepulsionVecs(){return _devNextRepulsionVecs;}
        nanovdb::Vec3f* hostRepulsionVecs(){return _hostRepulsionVecs;}
        uint8_t* devClusterMask(){return _devClusterMask;}
        uint8_t* hostClusterMask(){return _hostClusterMask;}
        int*            devClusterParents(){return _devClusterParents;}
        int*            hostClusterParents(){return _hostClusterParents;}
        int*     devClusterWorker(){return _devClusterWorker;}


        int levelDepth(){return _levelDepth;}

        int* hostLevel(){return _hostLevel;}
        int* devLevel(){return _devLevel;}

        int* hostBoundaryCount(){return _hostBoundaryCount;}
        int* devBoundaryCount(){return _devBoundaryCount;}

        int* hostBoundaryScoreSize(){return _hostBoundaryScoreSize;}
        int* devBoundaryScoreSize(){return _devBoundaryScoreSize;}

        float* devGraphScores(){return _devGraphScores;}// contains graph scores and the corresponding level to the solution.
        float* hostGraphScores(){return _hostGraphScores;}

        float* devNewGraphScores(){return _devNewGraphScores;} // stores new graph scores, then is copied into graph scores between iterations.

        float* devGraphLevels(){return _devGraphLevels;}
        float* hostGraphLevels(){return _hostGraphLevels;}

        int* devBoundaryPairs(){return _devBoundaryPairs;}
        int* hostBoundaryPairs(){return _hostBoundaryPairs;}

        //Used for checking whether solutions exist at last level of graph solver.
        int* devSolutionCounts(){return _devSolutionCounts;}
        int* hostSolutionCounts(){return _hostSolutionCounts;}

        int* hostBoundaryPaths(){return _hostBoundaryPaths;}
        int* devBoundaryPaths(){return _devBoundaryPaths;}

        int* devNeighbourCounts(){return _devNeighbourCounts;}
        int* hostNeighbourCounts(){return _hostNeighbourCounts;}
        int* devNeighbourMap(){return _devNeighbourMap;}
        int* hostNeighbourMap(){return _hostNeighbourMap;}
        float* devNeighbourDistances(){return _devNeighbourDistances;}
        float* hostNeighbourDistances(){return _hostNeighbourDistances;}
        int* devNeighbourIndices(){return _devNeighbourIndices;}
        int* hostNeighbourIndices(){return _hostNeighbourIndices;}

      private:
        /******************************************************************************/
        bool _initialised = false;
        bool _useTileLogic = false;
        bool _validAllocated = false;
        int _validAllocation = 0;
        bool _safeAllocated = false;
        int _safeAllocation = 0;
        int _levelDepth = 50;
        int _neighbourCount = 0;
        bool _boundaryContainersAllocated = false;
        bool _boundaryPathsAllocated = false;
        int _boundaryPathsAllocation = 0;
        float* _devGridRes;
        float* _hostGridRes;
        float* _devMappingRes;
        float* _hostMappingRes;
        float* _devPlannerRes;
        float* _hostPlannerRes;
        int* _devTileEdge;
        int* _hostTileEdge;
        int* _devSafeCount;
        int* _hostSafeCount;
        int* _devValidCount;
        int* _hostValidCount;

        //This array contains all the patterns
        // for determining whether a cell is a vertex cell.
       //Each int32 in the array is a full pattern, with each bit in the int representing
       //the on/off state of a neighbour in -1 to 1 in ZYXorder (z being the fastest moving axis).
        uint32_t* _hostVertexPatterns;
        uint32_t* _devVertexPatterns;

        nanovdb::Coord* _hostGridIndex;
        nanovdb::Coord* _devGridIndex; //This is one half of a mapping from grid to index and back. By providing an index, the matching grid coordinate
                                        //is provided.
        int* _devSafeIndex;
        int* _hostSafeIndex;

        //DEV FOR POLYGON PROCESSING
        nanovdb::Vec3f* _devRepulsionVecs;
        nanovdb::Vec3f* _hostRepulsionVecs;
        nanovdb::Vec3f* _devNextRepulsionVecs;
        int* _devClusterParents;
        int* _hostClusterParents;
        int* _devClusterWorker;
        uint8_t* _devClusterMask;
        uint8_t* _hostClusterMask;


        int* _hostLevel;
        int* _devLevel;

        int* _devBoundaryCount;
        int* _hostBoundaryCount;

        int* _devBoundaryScoreSize;
        int* _hostBoundaryScoreSize;

        float* _devGraphScores;// contains graph scores and the corresponding level to the solution.
        float* _hostGraphScores;

        float* _devNewGraphScores; // stores new graph scores, then is copied into graph scores between iterations.

        float* _devGraphLevels;
        float* _hostGraphLevels;

        int* _devBoundaryPairs;
        int* _hostBoundaryPairs;

        //Used for checking whether solutions exist at last level of graph solver.
        int* _devSolutionCounts;
        int* _hostSolutionCounts;

        //Visible neighbour information to save compute during graph solution.
        int* _devNeighbourMap;
        int* _hostNeighbourMap;
        //The manhattan distance between each vertex and it's visible neighbour verteces
        float* _devNeighbourDistances;
        float* _hostNeighbourDistances;
        //The amount of visible neighbours a vertex has within the vertex graph.
        int* _devNeighbourCounts;
        int* _hostNeighbourCounts;
        //
        int* _devNeighbourIndices;
        int* _hostNeighbourIndices;

        int* _hostBoundaryPaths;
        int* _devBoundaryPaths;     //Really a list



      };



      //Calculating terminal distances is as follows
      //For an agent position A and Target B
      //Check if B is visible from A,
      //If visible, Vertex pathing not required.

      //Solve for closest leaf that views B from A
      //Using inverseLeaves and obsBy matrices.

      //else
      //Look up the closest vertices to A and B. These are the start and end vertices.
      //Then look up the shortest path between those vertices.
      //Starting with the next vertices in the path, check to see if any are visible to A or B.
      //If they are, then they become the new start or end vertex and the shortest path doesn't include the prior nodes.
      //Shortest path is calculated as manhattan distance from A->NewStartVertex->NewEndVertex->B.
      //Is the path end node in the inverse leaves grid, and is it a valid observer.
      //If yes: then you've found the node closest to A that can observe B.
      //Else:
      //First, loop over all vertex neighbours for the target, and check if any exist as valid observers.
      //If a vertex neighbour is a valid observer, then check the distance from that observer to NewStartVertex.
      //If it is shorter than the current distance, store it.
      //else if it is larger, store it if it is the smallest alternative.
      //If a value is shorter than the original path length, you've found the closest node to A that can observe B
      //else if the next best observer alternative is larger, find the shortest distance
      //between the original shortest path distance to the closest observer given by the observer matrix.
      //If there are no obstructions and the distance of the original path node + the step to the closest observer
      //is less than the distance to the alternative, then that is the shortest observer path, else the use the alternative.



      //OLD LOGIC
      //If not then find shortest path from A to B:
      //Look up the closest vertices to A and B. These are the start and end vertices.
      //Then look up the shortest path between those vertices.
      //Starting with the next vertices in the path, check to see if any are visible to A or B.
      //If they are, then they become the new start or end vertex and the shortest path doesn't include the prior nodes.
      //Shortest path is calculated as manhattan distance from A->NewStartVertex->NewEndVertex->ObservationNode->B.
      //From the new end vertex, known as the first visible vertex (FVV), find the closest node that can see B.

      //To solve the shortest path from the first visible vertex (FVV) and the target,
      //Convert the FVV to an inverse leaves offset (FVV-target).
      //Look up the target in the Observers matrix. Using the InverseLeavesGrid, input coord offset, to get index of FVV in Observers,
      //IF IT EXISTS. If it doesn't exist. Use the observers matrix and the inverse leaves index
      //, iterating over all valid observers to get the node
      //that has the minimum distance to FVV and is a valid observer.
  }
}
#endif
