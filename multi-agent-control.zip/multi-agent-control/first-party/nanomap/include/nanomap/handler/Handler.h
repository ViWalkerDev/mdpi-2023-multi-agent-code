// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Handler.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_HANDLER_HANDLER_H_INCLUDED
#define NANOMAP_HANDLER_HANDLER_H_INCLUDED
#include <iomanip>
#include <chrono>
#include <iostream>
#include <string>
#include <mutex>

#include <tbb/parallel_for.h>


#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>

#include <openvdb/Grid.h>
#include <openvdb/Types.h>

#include <nanovdb/util/CudaDeviceBuffer.h>
#include <nanovdb/util/OpenToNanoVDB.h>
#include <nanovdb/util/GridHandle.h>

#include "nanomap/sensor/Sensor.h"
#include "nanomap/sensor/GPUInfo.h"
#include "nanomap/config/GPUInfo.h"
#include "nanomap/gpu/SensorBucket.h"
#include "nanomap/allocator/SensorAllocator.h"


// The following functions are called by the host and launch the gpu kernels.

//This kernel filters the cloud. Filter functionality depends on user defined settings provided at runtime
extern "C" void filterCloud(nanomap::gpu::SensorBucket& _sensorBucket, cudaStream_t s0);

//This kernel raycasts the cloud over the area that is observable by the sensor in question
extern "C" void frustumCastCloud(nanomap::gpu::SensorBucket& _sensorBucket, cudaStream_t s0,  cudaStream_t s1);


namespace nanomap{
  namespace handler{

    class Handler{
      public:
        // Handler();
        Handler(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo, std::shared_ptr<nanomap::config::GPUInfo> config);
        // void init(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo);
        // void initSensorAllocator(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo);


        virtual void generateCloudFromSensor(std::shared_ptr<nanomap::sensor::Sensor> sensor, int publishSensor){}

        virtual void rayCastCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor);
        virtual void processSimGridUpdate(openvdb::FloatGrid::Ptr grid){}
        void closeHandler();
        void printUpdateTime(int count);

        int getFrustumLeafCount();
        int* getFrustumLeafBuffer();
        int8_t* getFrustumVoxelBuffer();

      protected:
        cudaStream_t                                                    _s0;
        cudaStream_t                                                    _s1;
        float _gpuTime;
        //std::shared_ptr<nanomap::map::PlannerMap>  _agentMap;
        //std::shared_ptr<nanomap::config::GymConfig> _config;
        //openvdb::FloatGrid::Ptr _simGrid;
        //nanomap::allocator::SimAllocators _simAllocators;
        //nanomap::allocator::SimHandles _simHandles;
        //nanomap::allocator::SensorAllocator _sensorAllocator;
        //nanovdb::GridHandle<nanovdb::CudaDeviceBuffer> _laserHandle;
        //nanovdb::GridHandle<nanovdb::CudaDeviceBuffer> _simGridHandle;
        nanomap::allocator::SensorAllocator _sensorAllocator;

      };


  }
}
#endif
