#ifndef NANOMAP_HANDLER_PLANNERHANDLER_H_INCLUDED
#define NANOMAP_HANDLER_PLANNERHANDLER_H_INCLUDED
#include <iomanip>
#include <chrono>
#include <iostream>
#include <string>
#include <mutex>

//#include <tbb/tbb_thread.h>
#include <tbb/parallel_for.h>
//#include <tbb/blocked_range.h>
//#include <tbb/task_arena.h>
//#include <tbb/task_group.h>

#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>

// #include <openvdb/Types.h>
// #include <openvdb/math/Coord.h>
// #include <openvdb/tree/Tree.h>
// #include <openvdb/Grid.h>

#include <nanovdb/util/CudaDeviceBuffer.h>
#include <nanovdb/util/GridHandle.h>
#include <nanovdb/util/OpenToNanoVDB.h>

#include "nanomap/map/PlannerMap.h"
#include "nanomap/nanomap.h"
#include "nanomap/allocator/PlannerAllocator.h"
#include "nanomap/gpu/PlannerBucket.h"
#include "nanomap/gpu/Cluster.h"
#include "nanomap/planner/GPUInfo.h"

//The purpose of this handler is to take a planning map and solve it. 

//That is all it does, it just does it quick.

extern "C" void getClusters(nanomap::gpu::PlannerBucket& plannerBucket, nanovdb::GridHandle<nanovdb::CudaDeviceBuffer>& gridHandle, cudaStream_t s);
extern "C" void mendClusters(nanomap::gpu::PlannerBucket& plannerBucket, nanovdb::GridHandle<nanovdb::CudaDeviceBuffer>& gridHandle, cudaStream_t s);
extern "C" void getClusterEdges(nanomap::gpu::PlannerBucket& plannerBucket, nanomap::gpu::Cluster& cluster, nanovdb::GridHandle<nanovdb::CudaDeviceBuffer>& gridHandle, cudaStream_t s);
extern "C" void getClusterDistances(nanomap::gpu::PlannerBucket& plannerBucket, nanomap::gpu::Cluster& cluster, nanovdb::GridHandle<nanovdb::CudaDeviceBuffer>& gridHandle, cudaStream_t s);
extern "C" void prepGraphSolutions(nanomap::gpu::PlannerBucket& plannerBucket, nanomap::gpu::Cluster& cluster, nanovdb::GridHandle<nanovdb::CudaDeviceBuffer>& gridHandle, cudaStream_t s);
extern "C" void getVertexDistances(nanomap::gpu::PlannerBucket& plannerBucket, nanomap::gpu::Cluster& cluster, nanovdb::GridHandle<nanovdb::CudaDeviceBuffer>& gridHandle, cudaStream_t s);
extern "C" void stepClusterGraphs(nanomap::gpu::PlannerBucket& plannerBucket, nanomap::gpu::Cluster& cluster, cudaStream_t s);
extern "C" void getClusterSolutions(nanomap::gpu::PlannerBucket& plannerBucket, nanomap::gpu::Cluster& cluster, cudaStream_t s);
extern "C" void prepBoundaryArrays(nanomap::gpu::PlannerBucket& plannerBucket, cudaStream_t s);
extern "C" void stepBoundaryGraph(nanomap::gpu::PlannerBucket& plannerBucket,  cudaStream_t s);
extern "C" void getBoundarySolutions(nanomap::gpu::PlannerBucket& plannerBucket, cudaStream_t s);

namespace nanomap{
  namespace handler{
    using BufferT = nanovdb::CudaDeviceBuffer;
    using ValueT  = float;
    using Vec3T   = nanovdb::Vec3<ValueT>;
    using EigenVec = Eigen::Matrix<ValueT, 3, 1>;
    using EigenMat = Eigen::Matrix<ValueT, 3, 3>;
    using Quaternion = Eigen::Quaternion<ValueT>;

    class PlannerHandler{
      public:
        PlannerHandler(std::shared_ptr<nanomap::planner::GPUInfo> plannerConfig);

        //void solvePlannerMap(std::shared_ptr<nanomap::map::PlannerMap> plannerMap, openvdb::FloatGrid::Ptr grid);
        void allocateValidAndSafe(int validCount, int SafeCount);
        void uploadPlannerGrid(openvdb::Int32Grid::Ptr grid);
        void setAllocatorClusterInfo(std::vector<int> clusterIDs, std::vector<std::vector<int>> clustersSafe);
        void createGPUClusters(std::vector<int>& clusterIDs, std::vector<std::vector<int>>& clustersSafe);
        void extractClusters();
        void solveClusters();
        void refineClusters();
        void prepareBoundaryArrays();
        void copyBoundaryContainers();
        void solveBoundaryGraph();
        void startBoundarySolve();
        void finishBoundarySolve();
        bool depthLevelSufficient();
        void increaseLevelDepth();
        std::shared_ptr<nanomap::allocator::PlannerAllocator> plannerAllocator(){return _plannerAllocator;}

        void freeBucketMemory();
        void closeHandler();
        void printUpdateTime(int count);

      private:
        cudaStream_t                                                    _s0;

        float _solveTime;
        
        std::shared_ptr<nanomap::allocator::PlannerAllocator> _plannerAllocator;
        nanovdb::GridHandle<nanovdb::CudaDeviceBuffer> _plannerHandle;
        



      };


  }
}
#endif
