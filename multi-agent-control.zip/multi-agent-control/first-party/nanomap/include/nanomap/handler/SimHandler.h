// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file SimHandler.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_HANDLER_SIMHANDLER_H_INCLUDED
#define NANOMAP_HANDLER_SIMHANDLER_H_INCLUDED
#include <iomanip>
#include <chrono>
#include <iostream>
#include <string>
#include <mutex>

#include <tbb/parallel_for.h>


#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>

#include <openvdb/Grid.h>
#include <openvdb/Types.h>

#include <nanovdb/util/CudaDeviceBuffer.h>
#include <nanovdb/util/GridHandle.h>
#include <nanovdb/util/OpenToNanoVDB.h>

#include "nanomap/handler/Handler.h"

#include "nanomap/sensor/Sensor.h"
#include "nanomap/sensor/GPUInfo.h"
#include "nanomap/config/GPUInfo.h"
#include "nanomap/gpu/SensorBucket.h"
#include "nanomap/allocator/SensorAllocator.h"


// The following functions are called by the host and launch the gpu kernels.

//This kernel generates a point cloud using a simulated sensor view and an existing map
extern "C" void generateCloud(nanomap::gpu::SensorBucket& _sensorBucket, nanovdb::GridHandle<nanovdb::CudaDeviceBuffer>& _simGridHandle, cudaStream_t s0);

//This kernel filters the cloud. Filter functionality depends on user defined settings provided at runtime
extern "C" void filterCloud(nanomap::gpu::SensorBucket& _sensorBucket, cudaStream_t s0);

//This kernel raycasts the cloud over the area that is observable by the sensor in question
extern "C" void frustumCastCloud(nanomap::gpu::SensorBucket& _sensorBucket, cudaStream_t s0,  cudaStream_t s1);


namespace nanomap{
  namespace handler{

    class SimHandler : public Handler{
      public:
        // SimHandler();
        SimHandler(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo, 
                    std::shared_ptr<nanomap::config::GPUInfo> config,
                    openvdb::FloatGrid::Ptr simGrid);
        // void init(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo);
        // void initSensorAllocator(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo);
        void generateCloudFromSensor(std::shared_ptr<nanomap::sensor::Sensor> sensor, int publishSensor);

        void rayCastCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor);
        void processSimGridUpdate(openvdb::FloatGrid::Ptr grid);
        //void rayCastCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor);
        //void closeSimHandler();
        //void printUpdateTime(int count);

        //int getFrustumLeafCount();
        //int* getFrustumLeafBuffer();
        //int8_t* getFrustumVoxelBuffer();

      protected:
        //cudaStream_t                                                    _s0;
        //cudaStream_t                                                    _s1;
        //float _gpuTime;
        //std::shared_ptr<nanomap::map::PlannerMap>  _agentMap;
        //std::shared_ptr<nanomap::config::GymConfig> _config;
        //openvdb::FloatGrid::Ptr _simGrid;
        //nanomap::allocator::SimAllocators _simAllocators;
        //nanomap::allocator::SimHandles _simHandles;
        //nanomap::allocator::SensorAllocator _sensorAllocator;
        //nanovdb::GridHandle<nanovdb::CudaDeviceBuffer> _laserHandle;
        nanovdb::GridHandle<nanovdb::CudaDeviceBuffer> _simGridHandle;
        //nanomap::allocator::SensorAllocator _sensorAllocator;


      };


  }
}
#endif
