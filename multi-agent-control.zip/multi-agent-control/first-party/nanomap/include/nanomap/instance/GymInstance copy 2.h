// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Manager.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_INSTANCE_GYMINSTANCE_H_INCLUDED
#define NANOMAP_INSTANCE_GYMINSTANCE_H_INCLUDED
#include "nanomap/instance/SimInstance.h"
#include "nanomap/instance/PlannerInstance.h"
#include "nanomap/manager/GymAgentManager.h"
#include "nanomap/manager/SensorManager.h"
#include "nanomap/manager/GymManager.h"
#include "nanomap/mapgen/procedural/MapGen.h"
#include "nanomap/config/Config.h"
#include "nanomap/nanomap.h"
#include <openvdb/math/Ray.h>
#include <openvdb/tools/Morphology.h>
#include <openvdb/math/DDA.h>

/******************************************************************************

*******************************************************************************/

namespace nanomap{
  namespace instance{
  


  class GymInstance : public SimInstance{
    public:
      GymInstance(std::string mainConfig);
      
      void createManager();
      void createAgentManager();

      void gymStep();

      void processAgentViews();

      void processAgentViews(int agentId);

      void processAgentViews(std::string agentName);

      //Planner Instance Specific Methods
      void initPlannerInstance();


      void resetAgentByIndex(int agentIndex);
      void resetAgents();
      void onAgentReset();
      void setObjectsOnPath(bool objectsOnPath){_objectsOnPath = objectsOnPath;}
      void setEnvironmentKnowledge(int environmentKnowledge, float environmentRadius){
        _environmentKnowledge = environmentKnowledge;
        _environmentRadius = environmentRadius;
      }
      Eigen::ArrayXf getObservationCloudByIndex(int agentIndex){return _agentManager->getObservationCloudByIndex(agentIndex);}
      void generateObjectsOnPath();
      void initialiseEnvironmentKnowledge();
      void processSimGridChanges();
      void revertSimGridChanges();
      std::shared_ptr<nanomap::instance::PlannerInstance> plannerInstance(){return _plannerInstance;}
      Eigen::ArrayXf getAgentStateByIndex(int agentIndex){return _agentManager->getStateByIndex(agentIndex);}
      Eigen::ArrayXf getObservationsByIndex(int agentIndex){return _agentManager->getObservationsByIndex(agentIndex);}
      Eigen::ArrayXf getGoalObservationsByIndex(int agentIndex){return _agentManager->getGoalObservationsByIndex(agentIndex);}

      //std::shared_ptr<nanomap::manager::GymManager> GymManager(){return _GymManager;}

    protected:

      //std::shared_ptr<nanomap::config::Config> _config;
      //std::shared_ptr<nanomap::manager::PlannerManager> _plannerManager;
      std::shared_ptr<nanomap::instance::PlannerInstance> _plannerInstance;

      //This openvdbGrid tracks changes made to the simGrid when generating obstacles
      //When the agent is reset, these changes in the grid are reverted.
      //This is so the grid doesn't become too cluttered over time. 
      openvdb::FloatGrid::Ptr _simGridChanges;
      
      //If environmentKnown = 0 - no prior knowledge
      //If environmentKnown = 1 - initial prior knowledge (a sphere of radius 2 metres is known to agent)
      //If environmentKnown = 2 - complete prior knowledge (agent map is the same as the sim grid) 
      int _environmentKnowledge = 0;
      float _environmentRadius = 1.0;
      //if objectsOnPath = false - there are no unknown objects on the random path generated for the agent.
      //else - unknown objects are spawned into the simgrid after planning that interfere with the path the agent desires
      bool _objectsOnPath = false;
      //std::shared_ptr<nanomap::manager::GymManager> _gymManager;
      //std::shared_ptr<nanomap::manager::GymAgentManager> _gymAgentManager;
      //std::shared_ptr<nanomap::manager::SensorManager> _sensorManager;
                  
      //openvdb::FloatGrid::Ptr _simGrid;
      //openvdb::FloatGrid::Ptr _plannerGrid;
    };
  }
}
#endif
