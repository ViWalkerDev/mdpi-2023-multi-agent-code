// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Manager.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_INSTANCE_GYMINSTANCE_H_INCLUDED
#define NANOMAP_INSTANCE_GYMINSTANCE_H_INCLUDED
#include "nanomap/manager/PlannerManager.h"
#include "nanomap/manager/GymAgentManager.h"
#include "nanomap/manager/SensorManager.h"
#include "nanomap/manager/GymManager.h"
#include "nanomap/config/Config.h"
#include "nanomap/nanomap.h"
/******************************************************************************

*******************************************************************************/

namespace nanomap{
  namespace instance{
  


  class GymInstance{
    public:
      GymInstance(std::string mainConfig);
      
      virtual void createManager();
      void createHandler();
      void loadSimGrid();
      void loadPlannerGrid(std::string gridFile);
      void setSimGrid(openvdb::FloatGrid::Ptr grid);
      void solveSimGrid();
      void solvePlannerGrid();
      std::shared_ptr<nanomap::manager::PlannerManager> plannerManager(){return _plannerManager;}
      std::shared_ptr<nanomap::manager::GymManager> GymManager(){return _GymManager;}

    protected:

      std::shared_ptr<nanomap::config::Config> _config;
      std::shared_ptr<nanomap::manager::PlannerManager> _plannerManager;
      std::shared_ptr<nanomap::manager::GymManager> _gymManager;
      std::shared_ptr<nanomap::manager::GymAgentManager> _agentManager;
      std::shared_ptr<nanomap::manager::SensorManager> _sensorManager;
                  
      openvdb::FloatGrid::Ptr _simGrid;
      openvdb::FloatGrid::Ptr _plannerGrid;
    };
  }
}
#endif
