// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Manager.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_INSTANCE_GYMINSTANCE_H_INCLUDED
#define NANOMAP_INSTANCE_GYMINSTANCE_H_INCLUDED
#include <cstdlib>
#include <ctime>
#include <iostream>
#include "nanomap/instance/SimInstance.h"
#include "nanomap/instance/PlannerInstance.h"
#include "nanomap/manager/GymAgentManager.h"
#include "nanomap/manager/SensorManager.h"
#include "nanomap/manager/GymManager.h"
#include "nanomap/mapgen/procedural/MapGen.h"
#include "nanomap/config/Config.h"
#include "nanomap/nanomap.h"
#include <openvdb/math/Ray.h>
#include <openvdb/tools/Morphology.h>
#include <openvdb/math/DDA.h>

/******************************************************************************

*******************************************************************************/

namespace nanomap{
  namespace instance{
  


  class GymInstance : public SimInstance{
    
    public:
      GymInstance(std::string mainConfig);
      GymInstance(std::string mainConfig, int seed);
      
      void createManager();
      void createAgentManager();

      void gymStep();

      void processAgentViews();

      void processAgentViews(int agentId);
      // openvdb::FloatGrid::Ptr generateObstaclesInSimGrid();
      void generateObstaclesInSimGrid(std::string saveFile, float obstacleOdds);
      void processAgentViews(std::string agentName);
      void setTargetPositions(std::vector<Eigen::Vector3f> targetPositions){
        _targetPositions = targetPositions;
        int numTargets = _targetPositions.size();
        int numAgents = _agentManager->getAgents().size();
        _targetObservedStatus.resize(numAgents);
        for(int x = 0; x < numAgents; x++){
          std::vector<bool> agentTargetFoundStatus;
          agentTargetFoundStatus.resize(numTargets, false);
          _targetObservedStatus[x] = agentTargetFoundStatus;
        }
      }

      void generateRandomTargetPositions(int numTargets){
        _targetPositions = _plannerInstance->plannerManager()->generateRandomTargetPositions(numTargets);
        int numAgents = _agentManager->getAgents().size();
        _targetObservedStatus.resize(numAgents);
        for(int x = 0; x < numAgents; x++){
          std::vector<bool> agentTargetFoundStatus;
          agentTargetFoundStatus.resize(numTargets, false);
          _targetObservedStatus[x] = agentTargetFoundStatus;
        }
      }
      bool isTargetLocalToAgentCluster(int agentIndex, int targetIndex){
        nanomap::Pose pose = _agentManager->getAgentByIndex(agentIndex)->agentData()->pose();
        int agentCluster = _plannerInstance->plannerManager()->getClusterFromPosition(pose.position);
        int targetCluster = _plannerInstance->plannerManager()->getClusterFromPosition(_targetPositions[targetIndex]);
        return agentCluster == targetCluster;
      }

      std::vector<Eigen::Vector3f> targetPositions(){return _targetPositions;}
      bool isAgentTransitComplete(int agentIndex, Eigen::Vector3f currentGoal){
        //TODO
        return true;
      }

      void simulateAgentSearch(int agentIndex, Eigen::Vector3f position){
        _manager->simulateAgentSearch(_agentManager->getAgentByIndex(agentIndex)->map(), _plannerInstance->plannerManager(), position);
      }

      void simulateAgentSearch(int agentIndex, int cluster){
        _manager->simulateAgentSearch(_agentManager->getAgentByIndex(agentIndex)->map(), _plannerInstance->plannerManager(), cluster);
      }

      int getTargetCluster(int targetIndex){
        return _plannerInstance->plannerManager()->getClusterFromPosition(_targetPositions[targetIndex]);
      }

      std::vector<Eigen::Vector3f> getLocalGoalsFromWorldGoals(int agentIndex, std::vector<Eigen::Vector3f> worldGoals){
        return _agentManager->getAgentByIndex(agentIndex)->getLocalGoalsFromWorldGoals(worldGoals);
      }

      bool isSearchGoalComplete(int agentIndex, Eigen::Vector3f goalPosition);
      //Planner Instance Specific Methods
      void initPlannerInstance();

      std::tuple<int, int, int, std::vector<Eigen::Vector3f>> getSearchGoalsForAgentByIndex(int index, int clusterIndex);
      std::tuple<int, int, int, std::vector<Eigen::Vector3f>> getTransitGoalsForClusterByIndex(int agentIndex, int clusterIndex); 
      std::vector<Eigen::Vector3f> getSearchGoalsVec(int index, int clusterIndex);
      std::vector<Eigen::Vector3f> getTransitGoalsVec(int agentIndex, int clusterIndex); 
      void resetAgentByIndex(int agentIndex);
      void resetAgents();
      void onAgentReset();
      void setObjectsOnPath(bool objectsOnPath){_objectsOnPath = objectsOnPath;}
      void setSearchGoal(bool searchGoal){_searchGoal = searchGoal;}
      void setEnvironmentKnowledge(int environmentKnowledge, float environmentRadius){
        _environmentKnowledge = environmentKnowledge;
        _environmentRadius = environmentRadius;
      }
      Eigen::ArrayXf getObservationCloudByIndex(int agentIndex){return _agentManager->getObservationCloudByIndex(agentIndex);}
      void generateObjectsOnPath();
      void initialiseEnvironmentKnowledge();
      void processSimGridChanges();
      void revertSimGridChanges();
      std::shared_ptr<nanomap::instance::PlannerInstance> plannerInstance(){return _plannerInstance;}
      Eigen::ArrayXf getAgentStateByIndex(int agentIndex){return _agentManager->getStateByIndex(agentIndex);}
      Eigen::ArrayXf getObservationsByIndex(int agentIndex){return _agentManager->getObservationsByIndex(agentIndex);}
      Eigen::ArrayXf getGoalObservationsByIndex(int agentIndex){return _agentManager->getGoalObservationsByIndex(agentIndex);}
      bool getSearchComplete(int index, Eigen::Vector3f position){
        return _plannerInstance->plannerManager()->isSearchGoalComplete(position, _agentManager->getAgentByIndex(index)->map());
      }
      //std::shared_ptr<nanomap::manager::GymManager> GymManager(){return _GymManager;}
      std::vector<bool> targetObservedStatus(int agentIndex){
        return _targetObservedStatus[agentIndex];
      }

    protected:

      //std::shared_ptr<nanomap::config::Config> _config;
      //std::shared_ptr<nanomap::manager::PlannerManager> _plannerManager;
      std::shared_ptr<nanomap::instance::PlannerInstance> _plannerInstance;

      //This openvdbGrid tracks changes made to the simGrid when generating obstacles
      //When the agent is reset, these changes in the grid are reverted.
      //This is so the grid doesn't become too cluttered over time. 
      openvdb::FloatGrid::Ptr _simGridChanges;
      openvdb::FloatGrid::Ptr _plannerGrid;
      //If environmentKnown = 0 - no prior knowledge
      //If environmentKnown = 1 - initial prior knowledge (a sphere of radius 2 metres is known to agent)
      //If environmentKnown = 2 - complete prior knowledge (agent map is the same as the sim grid) 
      int _environmentKnowledge = 0;
      float _environmentRadius = 1.0;
      //if objectsOnPath = false - there are no unknown objects on the random path generated for the agent.
      //else - unknown objects are spawned into the simgrid after planning that interfere with the path the agent desires
      bool _objectsOnPath = false;
      bool _searchGoal = false;
      bool _usePlannerGrid = false;
      std::vector<std::vector<bool>> _targetObservedStatus;
      std::vector<Eigen::Vector3f> _targetPositions;
      //std::shared_ptr<nanomap::manager::GymManager> _gymManager;
      //std::shared_ptr<nanomap::manager::GymAgentManager> _gymAgentManager;
      //std::shared_ptr<nanomap::manager::SensorManager> _sensorManager;
                  
      //openvdb::FloatGrid::Ptr _simGrid;
      //openvdb::FloatGrid::Ptr _plannerGrid;
    };
  }
}
#endif
