// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Manager.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_INSTANCE_INSTANCE_H_INCLUDED
#define NANOMAP_INSTANCE_INSTANCE_H_INCLUDED
#include "nanomap/manager/AgentManager.h"
#include "nanomap/manager/SensorManager.h"
#include "nanomap/manager/Manager.h"
#include "nanomap/config/Config.h"
#include "nanomap/nanomap.h"
/******************************************************************************

*******************************************************************************/

namespace nanomap{
  namespace instance{
  


  class Instance{
    public:
      Instance(std::string mainConfig);
      
      virtual void createManager();
      virtual void createAgentManager();

      void createHandler();
      
      std::shared_ptr<nanomap::manager::Manager> manager(){return _manager;}
      std::shared_ptr<nanomap::manager::AgentManager> agentManager(){return _agentManager;}
      virtual void updateAgentPose(int agentId, Pose pose);
      virtual void updateAgentPose(std::string agentName, Pose pose);
      virtual void updateAgentPoseFromFloat(int agentId, float x, float y, float z, float w, float qx, float qy, float qz);
      virtual void updateAgentPoseFromVelocities(int agentId, float timeStep, float xVel, float yVel, float zVel, float rollVel, float pitchVel, float yawVel);
      Eigen::Array<float,7,1> getAgentPoseAsFloat(int agentId);
      Eigen::Array<float,7,1> getAgentPoseAsFloat(std::string agentName);
      Eigen::Array<float,7,1> getAgentPoseAsFloatByIndex(int agentIndex);
      virtual void processAgentViews();
      virtual void processAgentViews(int agentId);
      virtual void processAgentViews(std::string agentName);
      virtual void updateSensorPointCloud(int agentId, int sensorId, int pclWidth, int pclHeight, int pclStep, unsigned char * cloudPtr);
      virtual void saveAgentGridToFile(int agentId, std::string fileName);

      virtual void saveGridToFile(openvdb::FloatGrid::Ptr grid, std::string fileName);

      virtual void resetAgent(int agentId);
      virtual void resetAgent(std::string agentName);
      virtual void resetAgentByIndex(int agentIndex);
      virtual void resetAgents();
      virtual void updateAgentObservations();
      virtual void updateAgentEnvironmentObservations();
      
    protected:

      std::shared_ptr<nanomap::config::Config> _config;
      std::shared_ptr<nanomap::manager::AgentManager> _agentManager;
      std::shared_ptr<nanomap::manager::Manager> _manager;
      std::shared_ptr<nanomap::manager::SensorManager> _sensorManager;

    };
  }
}
#endif
