// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Manager.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_INSTANCE_PLANNERINSTANCE_H_INCLUDED
#define NANOMAP_INSTANCE_PLANNERINSTANCE_H_INCLUDED
#include "nanomap/manager/PlannerManager.h"
#include "nanomap/config/Config.h"
#include "nanomap/nanomap.h"
/******************************************************************************

*******************************************************************************/

namespace nanomap{
  namespace instance{
  


  class PlannerInstance{
    public:
      PlannerInstance(std::string mainConfig);
      //PlannerInstance(std::string& mainConfig);
      
      virtual void createManager();
      void createHandler();
      void loadSimGrid();
      void setSimGrid(openvdb::FloatGrid::Ptr grid);
      void solveSimGrid();
      void loadPlannerGrid(std::string gridFile);
      void setPlannerGrid(openvdb::FloatGrid::Ptr grid);
      void processPlannerGrid();
      void solvePlannerGrid();
      openvdb::Vec3d getWorldVecFromPlannerCoord(openvdb::Coord voxel);
      std::shared_ptr<nanomap::manager::PlannerManager> plannerManager(){return _plannerManager;}

    protected:

      std::shared_ptr<nanomap::config::Config> _config;
      std::shared_ptr<nanomap::manager::PlannerManager> _plannerManager;
      openvdb::FloatGrid::Ptr _simGrid;
      openvdb::FloatGrid::Ptr _plannerGrid;
    };
  }
}
#endif
