// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Manager.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_INSTANCE_SIMINSTANCE_H_INCLUDED
#define NANOMAP_INSTANCE_SIMINSTANCE_H_INCLUDED
#include <openvdb/openvdb.h>
#include <openvdb/tree/Tree.h>
#include <openvdb/Grid.h>
#include "nanomap/instance/Instance.h"
#include "nanomap/manager/AgentManager.h"
#include "nanomap/manager/SensorManager.h"
#include "nanomap/manager/SimManager.h"
#include "nanomap/config/Config.h"
#include "nanomap/nanomap.h"
/******************************************************************************

*******************************************************************************/

namespace nanomap{
  namespace instance{
  


  class SimInstance : public Instance{
    public:
      SimInstance(std::string mainConfig);

      void createManager();
      void createAgentManager();
      openvdb::FloatGrid::Ptr loadSimGrid(std::string simGridFile);
      virtual void generateAgentViews(int agentId); 
      virtual void generateAgentViews();
      openvdb::FloatGrid::Ptr getSimGrid(){return _simGrid;}
      // void updateAgentPose(int agentId, Pose pose);
      // void updateAgentPose(std::string agentName, Pose pose);
      // void processAgentViews(int agentId);
      // void processAgentViews(std::string agentName);
      // void updateSensorPointCloud(int agentId, int sensorId, int pclWidth, int pclHeight, int pclStep, unsigned char * cloudPtr);
      // void saveAgentGridToFile(int agentId, std::string fileName);

      // void saveGridToFile(openvdb::FloatGrid::Ptr grid, std::string fileName);

    protected:
      openvdb::FloatGrid::Ptr _simGrid;

      // std::shared_ptr<nanomap::config::Config> _config;
      // std::shared_ptr<nanomap::manager::AgentManager> _agentManager;
      // std::shared_ptr<nanomap::manager::Manager> _manager;
      // std::shared_ptr<nanomap::manager::SensorManager> _sensorManager;

    };
  }
}
#endif
