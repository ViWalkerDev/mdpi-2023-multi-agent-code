
// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file AgentManager.h
///
/// @author Violet Walker
///
//This class is responsible for managing the agents used by nanomap. It reads the config files for the agents and creates the necessary agent objects

#ifndef NANOMAP_MANAGER_AGENTMANAGER_H_INCLUDED
#define NANOMAP_MANAGER_AGENTMANAGER_H_INCLUDED

#include "nanomap/config/Config.h"
#include "nanomap/sensor/SensorData.h"
#include "nanomap/sensor/Sensor.h"
#include "nanomap/agent/Agent.h"
#include "nanomap/agent/AgentData.h"
#include "nanomap/map/Map.h"


namespace nanomap{
    namespace manager{
      class AgentManager
      {
        public:
          // AgentManager(std::vector<std::string> agentConfigs, 
          //                           std::shared_ptr<nanomap::config::Config> config, 
          //                           std::vector<std::shared_ptr<nanomap::sensor::SensorData>> sensorData);
          AgentManager();

          virtual void loadAgents(std::vector<std::string> agentConfigs,
                          std::shared_ptr<nanomap::config::Config> config,
                          std::vector<std::shared_ptr<nanomap::sensor::SensorData>> sensorData);

          virtual std::shared_ptr<nanomap::agent::Agent> loadAgent(std::string agentConfig,
                                                            std::shared_ptr<nanomap::config::Config> config,
                                                            std::vector<std::shared_ptr<nanomap::sensor::SensorData>> sensorData);

          std::vector<std::shared_ptr<nanomap::agent::Agent>>& getAgents(){return _agents;}
          
          std::shared_ptr<nanomap::agent::Agent> getAgent(std::string agentName);

          std::shared_ptr<nanomap::agent::Agent> getAgent(int agentId);

          std::shared_ptr<nanomap::agent::Agent> getAgentByIndex(int agentIndex){return _agents[agentIndex];}

          void updateAgentPose(std::string agentName, Pose pose);

          void updateAgentPose(int agentId, Pose pose);

          void updateAgentPoseFromVelocities(int agentId, float timeStep, float xVel, float yVel, float zVel, float rollVel, float pitchVel, float yawVel);

          void updateSensorInputCloud(int agentId, int sensorId, int pclWidth, int pclHeight, int pclStep, unsigned char* );
          
          int getAgentIndex(std::string agentName);

          int getAgentIndex(int agentId);

          int getAgentId(std::string agentName);          

          virtual void resetAgent(int agentId);

          virtual void resetAgentByIndex(int agentIndex);

          virtual void resetAgent(std::string name);

          virtual void resetAgents();

          virtual bool isSearchGoalComplete(int agentIndex, Eigen::Vector3f position){}

          virtual std::tuple<int, int, int, std::vector<Eigen::Vector3f>> getSearchGoalsForAgentByIndex(int index, int clusterIndex){}
          virtual std::tuple<int, int, int, std::vector<Eigen::Vector3f>> getTransitGoalsForClusterByIndex(int agentIndex, int clusterIndex){}

          virtual std::vector<Eigen::Vector3f> getSearchGoalsVec(int index, int clusterIndex){}
          virtual std::vector<Eigen::Vector3f> getTransitGoalsVec(int agentIndex, int clusterIndex){}

          virtual std::vector<std::pair<Pose, int>> getTrajectoryGoalsByIndex(int index){}

          virtual Eigen::Array<float, 7, 1> getAgentPoseAsFloat(int agentIndex){
            return _agents[agentIndex]->getPoseAsFloat();
          }

          virtual void updateAgentObservations();
          virtual void updateAgentEnvironmentObservations();
          // virtual void updateAgentTransitObservations();
          virtual Eigen::ArrayXf getStateByIndex(int index){
            Eigen::Array<float,1,1> agentStates;
            return agentStates;
          }
          virtual Eigen::ArrayXf getObservationCloudByIndex(int index){return _agents[index]->getObservationCloud();}
          virtual Eigen::ArrayXf getObservationsByIndex(int index){return _agents[index]->getObservations();}
          virtual Eigen::ArrayXf getGoalObservationsByIndex(int index){return _agents[index]->getGoalObservations();} 

        protected:
          std::vector<std::shared_ptr<nanomap::agent::Agent>> _agents;

      };
    }//namespace manager
}//namespace nanomap
#endif