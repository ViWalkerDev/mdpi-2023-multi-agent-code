
// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file AgentManager.h
///
/// @author Violet Walker
///
//This class is responsible for managing the agents used by nanomap. It reads the config files for the agents and creates the necessary agent objects

#ifndef NANOMAP_MANAGER_GYMAGENTMANAGER_H_INCLUDED
#define NANOMAP_MANAGER_GYMAGENTMANAGER_H_INCLUDED



#include "nanomap/config/Config.h"
#include "nanomap/sensor/SensorData.h"
#include "nanomap/sensor/Sensor.h"
#include "nanomap/agent/GymAgent.h"
#include "nanomap/agent/AgentData.h"
#include "nanomap/agent/GymData.h"
#include "nanomap/map/Map.h"


namespace nanomap{
    namespace manager{
      class GymAgentManager : public AgentManager
      {
        public:
          GymAgentManager(std::vector<std::string> agentConfigs, 
                                    std::shared_ptr<nanomap::config::Config> config, 
                                    std::vector<std::shared_ptr<nanomap::sensor::SensorData>> sensorData);

          void loadAgents(std::vector<std::string> agentConfigs,
                          std::shared_ptr<nanomap::config::Config> config,
                          std::vector<std::shared_ptr<nanomap::sensor::SensorData>> sensorData);

          std::shared_ptr<nanomap::agent::Agent> loadAgent(std::string agentConfig,
                                                            std::shared_ptr<nanomap::config::Config> config,
                                                            std::vector<std::shared_ptr<nanomap::sensor::SensorData>> sensorData);

          std::shared_ptr<nanomap::agent::Agent> getAgent(std::string agentName);

          std::shared_ptr<nanomap::agent::Agent> getAgent(int agentId);

          void updateAgentPose(std::string agentName, Pose pose);

          void updateAgentPose(int agentId, Pose pose);

          void updateSensorInputCloud(int agentId, int sensorId, int pclWidth, int pclHeight, int pclStep, unsigned char* );

          int getAgentId(std::string agentName);          

          private:
              //std::vector<std::shared_ptr<nanomap::agent::GymAgent>> _agents;

      };
    }//namespace manager
}//namespace nanomap
#endif