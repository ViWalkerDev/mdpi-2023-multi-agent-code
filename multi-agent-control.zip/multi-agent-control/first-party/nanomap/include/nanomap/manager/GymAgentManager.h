
// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file AgentManager.h
///
/// @author Violet Walker
///
//This class is responsible for managing the agents used by nanomap. It reads the config files for the agents and creates the necessary agent objects

#ifndef NANOMAP_MANAGER_GYMAGENTMANAGER_H_INCLUDED
#define NANOMAP_MANAGER_GYMAGENTMANAGER_H_INCLUDED



#include <openvdb/Types.h>
#include <openvdb/Grid.h>
#include <openvdb/openvdb.h>
#include "nanomap/manager/AgentManager.h"
#include "nanomap/agent/GymAgent.h"
#include "nanomap/manager/PlannerManager.h"



namespace nanomap{
    namespace manager{
      class GymAgentManager : public AgentManager
      {
        public:
          GymAgentManager(std::shared_ptr<nanomap::manager::PlannerManager> plannerManager, openvdb::FloatGrid::Ptr simGrid);
          // GymAgentManager(std::vector<std::string> agentConfigs, 
          //                           std::shared_ptr<nanomap::config::Config> config, 
          //                           std::vector<std::shared_ptr<nanomap::sensor::SensorData>> sensorData);

          void loadAgents(std::vector<std::string> agentConfigs,
                          std::shared_ptr<nanomap::config::Config> config,
                          std::vector<std::shared_ptr<nanomap::sensor::SensorData>> sensorData);

          std::shared_ptr<nanomap::agent::Agent> loadAgent(std::string agentConfig,
                                                            std::shared_ptr<nanomap::config::Config> config,
                                                            std::vector<std::shared_ptr<nanomap::sensor::SensorData>> sensorData);

          Eigen::ArrayXf getStateByIndex(int agentIndex){
            Eigen::Array<float,4,1> agentStates;
            //IS TERMINAL
            if(_agents[agentIndex]->isTerminal()){
              agentStates(0) = 1;
            }else{
              agentStates(0) = 0;
            }
            //IS COLLIDED
            if(_agents[agentIndex]->isCollided()){
              agentStates(1) = 1;
            }else{
              agentStates(1) = 0;
            }
            //GOAL REACHED
            if(_agents[agentIndex]->isGoalReached()){
              agentStates(2) = 1;
              //std::cout << "Goal Reached?" << std::endl;
            }else{
              agentStates(2) = 0;
            }
            //agentStates(2) = float((_agents[agentIndex]->getGoalSearchCount()));

            //COUNT OF NEWLY EXPLORED VOXELS
            agentStates(3) = float((_agents[agentIndex]->voxelCount()));
            return agentStates;
          }

          virtual bool isSearchGoalComplete(int index, Eigen::Vector3f position){
            return _agents[index]->isSearchGoalComplete(position);
          }

          virtual std::tuple<int, int, int, std::vector<Eigen::Vector3f>> getSearchGoalsForAgentByIndex(int index, int clusterIndex){
            return _agents[index]->getSearchGoals(clusterIndex);
          }

          virtual std::tuple<int, int, int, std::vector<Eigen::Vector3f>> getTransitGoalsForClusterByIndex(int agentIndex, int clusterIndex){
            return _agents[agentIndex]->getTransitGoalsForCluster(clusterIndex); 
          }

          virtual  std::vector<Eigen::Vector3f> getSearchGoalsVec(int index, int clusterIndex){
            return _agents[index]->getSearchGoalsVec(clusterIndex);
          }

          virtual std::vector<Eigen::Vector3f> getTransitGoalsVec(int agentIndex, int clusterIndex){
            return _agents[agentIndex]->getTransitGoalsVec(clusterIndex); 
          }



          std::vector<std::pair<Pose, int>> getTrajectoryGoalsByIndex(int index){
            return _agents[index]->getTrajectoryGoals();
          }
          //void setObjectsOnPath(bool objectsOnPath){_objectsOnPath = objectsOnPath;}
          //void setEnvironmentKnowledge(int environmentKnowledge){_environmentKnowledge = environmentKnowledge;}
          // void resetAgentById(int agentId);
          
          // void resetAgentByName(std::string name);

          // void resetAgentByIndex(int index);
          
          // void resetAgents();

          // void updateAgentObservations();

          //std::shared_ptr<nanomap::agent::Agent> getAgent(std::string agentName);

          //std::shared_ptr<nanomap::agent::Agent> getAgent(int agentId);

          //void updateAgentPose(std::string agentName, Pose pose);

          //void updateAgentPose(int agentId, Pose pose);

          //void updateSensorInputCloud(int agentId, int sensorId, int pclWidth, int pclHeight, int pclStep, unsigned char* );

          //int getAgentId(std::string agentName);          


          private:
          std::shared_ptr<nanomap::manager::PlannerManager> _plannerManager;
          openvdb::FloatGrid::Ptr _simGrid;
          //bool _objectsOnPath = false;
          //int _environmentKnowledge = 0;
              //std::vector<std::shared_ptr<nanomap::agent::GymAgent>> _agents;

      };
    }//namespace manager
}//namespace nanomap
#endif