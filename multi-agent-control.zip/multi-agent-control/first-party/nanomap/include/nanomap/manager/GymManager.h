// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file GymManager.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_MANAGER_GYMMANAGER_H_INCLUDED
#define NANOMAP_MANAGER_GYMANAGER_H_INCLUDED
#include <iomanip>
#include <chrono>
#include <iostream>
#include <string>


#include <tbb/parallel_for.h>
#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>

#include <openvdb/Grid.h>
#include <openvdb/Types.h>
#include <openvdb/math/Ray.h>
#include <openvdb/tools/Morphology.h>
#include <openvdb/math/DDA.h>

#include "nanomap/sensor/Sensor.h"

#include "nanomap/manager/PlannerManager.h"
#include "nanomap/map/Map.h"

#include "nanomap/handler/SimHandler.h"
#include "nanomap/manager/SimManager.h"
#include "nanomap/nanomap.h"
#include "nanomap/sensor/GPUInfo.h"
//#include "nanomap/map/GPUInfo.h"
/******************************************************************************

*******************************************************************************/

namespace nanomap{
  namespace manager{
  


  class GymManager : public SimManager{
    using ValueT  = float;

    //using Vec3T   = nanovdb::Vec3<ValueT>;
    using EigenVec = Eigen::Matrix<ValueT, 3, 1>;
    using EigenMat = Eigen::Matrix<ValueT, 3, 3>;
    using Quaternion = Eigen::Quaternion<ValueT>;
    using LeafNodeT = openvdb::FloatGrid::TreeType::LeafNodeType;
    public:
      //GymManager();
      //GymManager(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo, std::shared_ptr<nanomap::gym::GPUInfo> gymInfo, std::shared_ptr<nanomap::config::GPUInfo> config, openvdb::FloatGrid::Ptr simGrid);
      //GymManager(std)
      GymManager(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo, std::shared_ptr<nanomap::config::GPUInfo> config, openvdb::FloatGrid::Ptr simGrid);
      
      void createHandler();
//Gym specific declarations
      // void insertPointCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor, 
      //                                       std::shared_ptr<nanomap::map::Map> map,
      //                                       bool serialUpdate,
      //                                       int updateType,
      //                                       int& voxelCount);
      // void voxelUpdateFromFrustumBuffer(std::shared_ptr<nanomap::map::Map> map, int& voxelCount, std::set<LeafNodeT*>& visitedLeafNodes);

      // void updateSearchGrid(std::shared_ptr<nanomap::map::Map> map, std::set<LeafNodeT*>& visitedLeafNodes);
      
      // void insertPointCloudCPU(std::shared_ptr<nanomap::sensor::Sensor> sensor,
      //                           std::shared_ptr<nanomap::map::Map> map,
      //                           int& voxelCount,
      //                           std::set<LeafNodeT*>& visitedLeafNodes);

      // void integrateTempGrid(openvdb::FloatGrid::Ptr tempGrid,
      //   std::shared_ptr<nanomap::map::Map> map,
      //   int& voxelCount,
      //   std::set<LeafNodeT*>& visitedLeafNodes);

      void insertPointCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor, 
                                            std::shared_ptr<nanomap::map::Map> map,
                                            bool serialUpdate,
                                            int updateType,
                                            int& voxelCount,
                                            std::vector<Eigen::Vector3f> targetPositions,
                                            std::vector<bool>& targetSeenStatus);
      void voxelUpdateFromFrustumBuffer(std::shared_ptr<nanomap::map::Map> map, 
                          int& voxelCount, std::set<LeafNodeT*>& visitedLeafNodes,
                                    std::vector<openvdb::Coord> targetCoords,
                                    std::vector<bool>& targetSeenStatus);

      void updateSearchGrid(std::shared_ptr<nanomap::map::Map> map, std::set<LeafNodeT*>& visitedLeafNodes);
      
      void insertPointCloudCPU(std::shared_ptr<nanomap::sensor::Sensor> sensor,
                                std::shared_ptr<nanomap::map::Map> map,
                                int& voxelCount,
                                std::set<LeafNodeT*>& visitedLeafNodes,
                                std::vector<openvdb::Coord> targetCoords,
                                std::vector<bool>& targetSeenStatus);

      void integrateTempGrid(openvdb::FloatGrid::Ptr tempGrid,
        std::shared_ptr<nanomap::map::Map> map,
        int& voxelCount,
        std::set<LeafNodeT*>& visitedLeafNodes,
          std::vector<openvdb::Coord> targetCoords,
           std::vector<bool>& targetSeenStatus);

      void simulateAgentSearch(std::shared_ptr<nanomap::map::Map> map, std::shared_ptr<nanomap::manager::PlannerManager> plannerManager, Eigen::Vector3f position);

      void simulateAgentSearch(std::shared_ptr<nanomap::map::Map> map, std::shared_ptr<nanomap::manager::PlannerManager> plannerManager, int cluster);
      

    protected:

      //std::unique_ptr<nanomap::handler::Handler> _handler;
      //openvdb::FloatGrid::Ptr _simGrid;
      //std::shared_ptr<nanomap::gym::GPUInfo> _gymInfo;
    };
  }
}
#endif
