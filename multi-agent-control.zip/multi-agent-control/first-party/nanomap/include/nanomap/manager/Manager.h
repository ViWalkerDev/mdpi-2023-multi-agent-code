// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Manager.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_MANAGER_MANAGER_H_INCLUDED
#define NANOMAP_MANAGER_MANAGER_H_INCLUDED
#include <iomanip>
#include <chrono>
#include <iostream>
#include <string>


#include <tbb/parallel_for.h>
#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>

#include <openvdb/Grid.h>
#include <openvdb/Types.h>
#include <openvdb/math/Ray.h>
#include <openvdb/tools/Morphology.h>
#include <openvdb/math/DDA.h>

#include "nanomap/sensor/Sensor.h"
#include "nanomap/manager/PlannerManager.h"
#include "nanomap/manager/BlockWorker.h"

#include "nanomap/handler/Handler.h"
#include "nanomap/nanomap.h"
#include "nanomap/sensor/GPUInfo.h"
#include "nanomap/map/GPUInfo.h"
/******************************************************************************

*******************************************************************************/

namespace nanomap{
  namespace manager{
  


  class Manager{
    using ValueT  = float;
    using LeafNodeT = openvdb::FloatGrid::TreeType::LeafNodeType;
    using Vec3T   = nanovdb::Vec3<ValueT>;
    using EigenVec = Eigen::Matrix<ValueT, 3, 1>;
    using EigenMat = Eigen::Matrix<ValueT, 3, 3>;
    using Quaternion = Eigen::Quaternion<ValueT>;

    public:
      //Manager();
      Manager(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo, std::shared_ptr<nanomap::config::GPUInfo> config);
      //void init(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo);


      virtual void createHandler();
      virtual void generateCloudFromSim(std::shared_ptr<nanomap::sensor::Sensor> sensor, int publishSensor){}
      //POINT CLOUD OPERATIONS
      virtual void insertPointCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor, 
                                            openvdb::FloatGrid::Ptr floatGrid, 
                                            std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
                                            std::shared_ptr<nanomap::map::GPUInfo> gridConfig,
                                            bool serialUpdate,
                                            int updateType);

      virtual void processSimGridUpdate(){}
      virtual void voxelUpdateFromFrustumBuffer(std::shared_ptr<openvdb::FloatGrid::Accessor> acc, std::shared_ptr<nanomap::map::GPUInfo> gridConfig);
      virtual void blockUpdateFromFrustumBuffer(bool serialUpdate, std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
                                          std::shared_ptr<nanomap::map::GPUInfo> gridConfig);

      
      
      
      virtual void insertPointCloudCPU(std::shared_ptr<nanomap::sensor::Sensor> sensor,
                                openvdb::FloatGrid::Ptr floatGrid, 
                                std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
                                std::shared_ptr<nanomap::map::GPUInfo> gridConfig);

      virtual void populateTempGrid(openvdb::FloatGrid::Accessor& tempAcc, 
                      std::shared_ptr<nanomap::sensor::Sensor> sensor,
                                        openvdb::FloatGrid::Ptr floatGrid, 
                      std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
                  std::shared_ptr<nanomap::map::GPUInfo> gridConfig);


      // void integrateTempGrid(openvdb::FloatGrid::Ptr tempGrid, std::shared_ptr<nanomap::map::Map> map);
      
      

      virtual void integrateTempGrid(openvdb::FloatGrid::Ptr tempGrid,
                              std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
                              std::shared_ptr<nanomap::map::GPUInfo> gridConfig);





//Gym specific declarations
      virtual void insertPointCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor, 
                                            openvdb::FloatGrid::Ptr floatGrid, 
                                            std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
                                            std::shared_ptr<nanomap::map::GPUInfo> gridConfig,
                                            bool serialUpdate,
                                            int updateType,
                                            int& voxelCount){}
      virtual void voxelUpdateFromFrustumBuffer(std::shared_ptr<openvdb::FloatGrid::Accessor> acc, 
                                                std::shared_ptr<nanomap::map::GPUInfo> gridConfig,
                                                int& voxelCount){}

      
      
      
      virtual void insertPointCloudCPU(std::shared_ptr<nanomap::sensor::Sensor> sensor,
                                openvdb::FloatGrid::Ptr floatGrid, 
                                std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
                                std::shared_ptr<nanomap::map::GPUInfo> gridConfig,
                                int& voxelCount){}

      virtual void integrateTempGrid(openvdb::FloatGrid::Ptr tempGrid,
        std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
        std::shared_ptr<nanomap::map::GPUInfo> gridConfig,
        int& voxelCount){}





      virtual void insertPointCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor, 
                                        std::shared_ptr<nanomap::map::Map> map,
                                            bool serialUpdate,
                                            int updateType,
                                            int& voxelCount){}

      virtual void voxelUpdateFromFrustumBuffer(std::shared_ptr<nanomap::map::Map> map,
                                                int& voxelCount,
                                  std::set<LeafNodeT*>& visitedLeafNodes){}

      
      
      
      virtual void insertPointCloudCPU(std::shared_ptr<nanomap::sensor::Sensor> sensor,
                                                std::shared_ptr<nanomap::map::Map> map,
                                                                      int& voxelCount,
                                    std::set<LeafNodeT*>& visitedLeafNodes){}

      virtual void integrateTempGrid(openvdb::FloatGrid::Ptr tempGrid,
                                std::shared_ptr<nanomap::map::Map> map,
                                                        int& voxelCount,
                                  std::set<LeafNodeT*>& visitedLeafNodes){}

      // virtual void simulateAgentSearch(std::shared_ptr<nanomap::map::Map> map, 
      //               std::shared_ptr<nanomap::manager::PlannerManager> plannerManager,
      //               Eigen::Vector3f position){}


      virtual void insertPointCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor, 
                                        std::shared_ptr<nanomap::map::Map> map,
                                            bool serialUpdate,
                                            int updateType,
                                            int& voxelCount,
                              std::vector<Eigen::Vector3f> targetPositions,
                                    std::vector<bool>& targetSeenStatus){}

      virtual void voxelUpdateFromFrustumBuffer(std::shared_ptr<nanomap::map::Map> map,
                                                int& voxelCount,
                                  std::set<LeafNodeT*>& visitedLeafNodes,
                                std::vector<openvdb::Coord> targetCoords,
                                    std::vector<bool>& targetSeenStatus){}

      //NEW GYM STUFF
      
      virtual void insertPointCloudCPU(std::shared_ptr<nanomap::sensor::Sensor> sensor,
                                                std::shared_ptr<nanomap::map::Map> map,
                                                                      int& voxelCount,
                                    std::set<LeafNodeT*>& visitedLeafNodes,
                                    std::vector<openvdb::Coord> targetCoords,
                                            std::vector<bool>& targetSeenStatus){}

      virtual void integrateTempGrid(openvdb::FloatGrid::Ptr tempGrid,
                                std::shared_ptr<nanomap::map::Map> map,
                                                        int& voxelCount,
                                  std::set<LeafNodeT*>& visitedLeafNodes,
                              std::vector<openvdb::Coord> targetCoords,
                                     std::vector<bool>& targetSeenStatus){}

      virtual void simulateAgentSearch(std::shared_ptr<nanomap::map::Map> map, 
                    std::shared_ptr<nanomap::manager::PlannerManager> plannerManager,
                    Eigen::Vector3f position){}


      virtual void simulateAgentSearch(std::shared_ptr<nanomap::map::Map> map, 
                    std::shared_ptr<nanomap::manager::PlannerManager> plannerManager,
                    int cluster){}








      void printUpdateTime(int count);

      void closeHandler();

    protected:

      std::unique_ptr<nanomap::handler::Handler> _handler;
      std::shared_ptr<nanomap::sensor::GPUInfo> _sensorInfo;
      std::shared_ptr<nanomap::config::GPUInfo> _config;

    };
  }
}
#endif
