#ifndef NANOMAP_MANAGER_PLANNERMANAGER_H_INCLUDED
#define NANOMAP_MANAGER_PLANNERMANAGER_H_INCLUDED
#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
#include <iomanip>
#include <chrono>
#include <iostream>
#include <string>
#include <float.h>

#include <openvdb/openvdb.h>
#include <openvdb/Types.h>
#include <openvdb/Grid.h>
#include <openvdb/tools/RayIntersector.h>
#include <openvdb/tools/Dense.h>

#include "nanomap/handler/PlannerHandler.h"
#include "nanomap/map/PlannerMap.h"
#include "nanomap/map/Map.h"
#include "nanomap/map/PlannerObjects.h"
#include "nanomap/nanomap.h"
#include "nanomap/config/Config.h"
#include "nanomap/planner/GPUInfo.h"


/******************************************************************************
This class defines a basic agent. It is used for single body UAVs with one or
more FIXED sensors and doesn't contain more advanced robotics kinematics like
Joint and Link definitions. update the UAV pose, then use the class to update the
sensor poses and pass a map file to the sensors to update the map with the new
sensor views. This also uses a map file to generate observation distances for
deeprl. Rays for an agent are generally loaded from a file and are precomputed.
however, a spherical observation sphere of radius r is generated if file not provided.
*******************************************************************************/

namespace nanomap{
    namespace manager{




  using GridType = openvdb::FloatGrid;
  using TreeT = GridType::TreeType;
  using RootType = TreeT::RootNodeType;   // level 3 RootNode
  using Int1Type = RootType::ChildNodeType;  // level 2 InternalNode
  using Int2Type = Int1Type::ChildNodeType;  // level 1 InternalNode
  using LeafType = TreeT::LeafNodeType;   // level 0 LeafNode
  using IterType = TreeT::ValueOnIter;
  using LeafT = TreeT::LeafNodeType;
  using AccessorT = openvdb::tree::ValueAccessor<TreeT>;
  using VecTreeT = openvdb::Vec3DGrid::TreeType;
  using VecAccessorT = openvdb::tree::ValueAccessor<VecTreeT>;
  using ValueT  = float;
  //using SensorData = nanomap::sensor::SensorData;
  using IterType = TreeT::ValueOnIter;
  //using Vec3T   = nanovdb::Vec3<ValueT>;

  //using SensorT = nanomap::sensor::Sensor<ValueT>;
  using EigenVec = Eigen::Matrix<ValueT, 3, 1>;
  using EigenMat = Eigen::Matrix<ValueT, 3, 3>;
  using Quaternion = Eigen::Quaternion<ValueT>;


  //nanovdb::CpuTimer<> timer;

  class PlannerManager{

    public:
      PlannerManager(std::shared_ptr<nanomap::config::Config> config);

      //std::pair<std::pair<int, int>, std::vector<Coord>> getRandomPairAndPath(float minPathDist);
      std::vector<std::pair<Pose, int>> getRandomPath(int minSteps);
      std::vector<std::pair<Pose, int>> getRandomPathWithStart(int minSteps, int startPlannerCoord);
      void createHandler();
      void solveMap(openvdb::FloatGrid::Ptr gridToSolve);
      openvdb::Int32Grid::Ptr getPlannerGrid(){return _plannerMap->plannerGrid();}
      void closeHandler();
    
    void calculateBoundaryLinesFromGraph();

    std::vector<int> getClusterNeighbours(int currentCluster);
    int getNearestClusterFromList(Eigen::Vector3f position, std::vector<int> clusterList);
    float getDistanceBetweenPositions(Eigen::Vector3f startPosition, Eigen::Vector3f endPosition);

    std::vector<Eigen::Vector3f> getEigenPathFromGlobalIndexPath(std::vector<int> indexPath);
    bool isCoordSafe(openvdb::Coord coord);
    //std::vector<int> sampleClusterForSearch(int clusterIndex);

    // std::vector<Eigen::Vector3f> EigenPathThroughSearchGoals(std::vector<int> globalSearchNodes);
    int getClusterFromPosition(Eigen::Vector3f position);

    int getGlobalIndexFromPosition(Eigen::Vector3f position);

    Eigen::Vector3f  getDestinationBoundaryPoint(int currentCluster, int targetCluster);

    std::vector<int> getUniformOccupancy();

    bool isSearchGoalComplete(Eigen::Vector3f goalPosition, std::shared_ptr<nanomap::map::Map> map);
    bool isClusterSearchComplete(int cluster, std::shared_ptr<nanomap::map::Map> map);
    std::vector<openvdb::Coord> getClusterSearchCoords(Eigen::Vector3f position);
    std::vector<openvdb::Coord> getClusterCoords(int cluster);

    std::vector<Eigen::Vector3f> generateRandomTargetPositions(int numTargets);

    std::vector<Eigen::Vector3f> getBoundaryLinesFromGraph();

    std::vector<Eigen::Vector3f> getClusterSearchNodesInWorld(int clusterIndex);

    std::vector<std::vector<Eigen::Vector3f>> getBoundaryPointsFromGraph(){return _plannerObjects->boundaryPoints;}

    std::vector<int> getShortestClusterPathBetweenBoundaries(int sourceCluster, int sourceBoundary, int destCluster);

    std::vector<Eigen::Vector3f> getWorldPathToClusterFromWorldPosition(int clusterIndex, Eigen::Vector3f position);

    std::vector<Eigen::Vector3f> getWorldSearchPathForClusterFromPosition(Eigen::Vector3f position);
    
    std::vector<Eigen::Vector3f> getWorldSearchGoalsFromPosition(Eigen::Vector3f position);
    std::vector<Eigen::Vector3f> getWorldSearchGoalsForCluster(int clusterIndex);

    std::vector<int> getGlobalPathFromClusterPath(int clusterIndex, std::vector<int> clusterPath);
    void calculateClusterSearchPaths(int clusterIndex);

    void calculateClusterBounds();

    std::vector<int> boundariesInClusterSpace(int clusterIndex);

    void sampleClustersForSearch();

    Eigen::Vector3f getPositionFromGlobalIndex(int globalIndex);

    Eigen::Vector3f getRandomPositionInCluster(int clusterIndex);

    void calculateBoundaryPointAverages();

    std::vector<Eigen::Vector3f> _boundaryPointAverages;

    int getRandomDestinationWithMinDistanceAndPosition(float minDist, EigenVec position);

    std::pair<int, int> getRandomPairWithMinDistance(float minDistance);

    std::vector<int> clusterPathBetweenGlobalIndexPair(int startIndex, int destIndex);

    void sampleClusterForSearch(int clusterIndex);

    EigenVec getClusterBoundaryAverage(int cluster);

    int closestUnsearchedCluster(Eigen::Vector3f position, std::vector<bool> searchedClusters);

    std::map<float, Eigen::Vector3f> getSearchClusterTargetsByDistance(Eigen::Vector3f position, 
                                                                                            int _currentCluster, 
                                                                        std::shared_ptr<nanomap::map::Map> map);

        std::map<float, Eigen::Vector3f> getSearchClusterTargetsByDistanceAndGoal(Eigen::Vector3f position, 
                                                                                            int _currentCluster,
                                                                                            Eigen::Vector3f _clusterGoal, 
                                                                        std::shared_ptr<nanomap::map::Map> map);
    
    std::vector<int> checkSearchTargets(std::vector<Eigen::Vector3f> searchTargets, std::shared_ptr<nanomap::map::Map> map);

    float getDistanceToClusterFromGlobalIndex(int clusterindex, int globalIndex);

    float getDistanceToClusterFromPosition(int clusterIndex, Eigen::Vector3f position);

    std::map<float, Eigen::Vector3f> sortSearchClusterTargetsByDistance(Eigen::Vector3f position,
                                          std::map<float, Eigen::Vector3f> searchTargetsMap,
                                                  std::vector<int> searchCompletion,
                                        std::vector<Eigen::Vector3f> searchTargets);

    std::vector<int> getClusterSearchPathFromBoundary(int clusterIndex, int clusterNodeStart);

    std::pair<int, int> getClusterBoundaryPairFromPos(Eigen::Vector3f position);
      //ClusterGraph is cluster entry -> list of neighbours entries (which map to actions)
    //Each entry is a pair, with the int representing the cluster index of the neighbour,
    //And the other half of the pair is a vector of pairs that represent each boundary the neighbours share and the cluster boundary index for those boundaries.  
   
      std::vector<std::vector<std::pair<int,std::vector<std::pair<int,int>>>>> returnClusterGraph();

    //Takes a cluster index, the source boundary within that cluster(in cluster reference space), and the destination cluster.
    //Returns pair, int = destination boundary in destination cluster space, and double  = distance between those two boundaries. 
      std::pair<int, double> getDestinationBoundaryAndCostFromClusterBoundary(int sourceCluster, int sourceBoundary, int destCluster);


      //Returns the shortest path and score between two nodes in global space. This is the function that is user-facing. 
      std::pair<float, std::vector<int>> getShortestPathAndScore(int sourceIndex, int destIndex);
      //Returns the shortest path between a global level node, and a target cluster. 
      std::vector<int> pathBetweenNodeAndCluster(int srcIndex, int destCluster);

      //gets shortest path as global indices when providing two global indices
      std::vector<int> getShortestPathAsIndex(int sourceIndex, int destIndex);
      //gets shortest path as global index when providing two openvdb coords as inputs
      std::vector<int> getShortestPathAsIndex(openvdb::Coord sourceNode, openvdb::Coord destNode);
      //gets the shortest path as coords when providing two global indices as input. 
      std::vector<openvdb::Coord> getShortestPathAsCoord(int sourceIndex, int destIndex);
      //gets the shortest path as coords when providing two coords as input
      std::vector<openvdb::Coord> getShortestPathAsCoord(openvdb::Coord sourceNode, openvdb::Coord destNode);

      //For a given world space vector (vec3d), return the corresponding planner space coord
      openvdb::Coord getPlannerCoordFromWorldVec(openvdb::Vec3d worldVec);
      openvdb::Vec3d getWorldVecFromPlannerCoord(openvdb::Coord voxel);
      //For a given planner space coord, retrieve the global node index
      int getGlobalIndexFromCoord(openvdb::Coord coord);
      int getClusterCount(){return _plannerObjects->clusterIDs.size();}
      //For a global node index, retrieve the coord within the planner map
      openvdb::Coord getCoordFromGlobalIndex(int index);

      int getSafeCountForCluster(int cluster){
        return _plannerObjects->clustersSafe[cluster].size();
      }
    protected:
      void createPlannerMapFromGrid(openvdb::FloatGrid::Ptr gridToSolve);

      void extractClustersFromPlannerMap();

      void solveClusters();

      void refineClusters();

      void createAndSolveBoundaryGraph();

      void createPlannerGrid(openvdb::FloatGrid::Ptr targetGrid);

      //populates the gpu and cpu grid indices according to the planner grid. 
      void populateGridIndexAndVoxels();

      //FUNCTIONS USED TO SOLVE THE MAP
      //CPU side cluster operations
      //This is called after extracting clusters
      //Uses information gathered and stored in _handler, to manipulate structures
      //in _plannerObjects
      void getClusterGraph();

      void resizeClusters();

      void resizeContainers();

      void combineClusters(int cluster1Index, int cluster2Index);

      void populateClusters();

      void mergeClusters();

      void getClusterBoundaries();
      //Primarily used to validate code and check things are functioning
      void populateFullClusters();
      //Primarily used to validate code and check things are functioning
      void populateValidClusters();

      void populateGlobalClusterMap();

      void populateEdges();

      void populateClusterEdges();

      void populateClusterEdgeCombos();

      //For each cluster, create a map that maps the clusterIndex of a node to the vertex index
      //of the closest vertex node
      void getClosestVertices();

      //For the boundary points of each cluster, get their global indices and map them
      void mapBoundaryPoints();

      //BOUNDARY LOGIC METHODS

      void setupBoundaryGraph();
      //USES GPU CLUSTER INFO
      //THIS GETS CALLED BEFORE SOLVING THE BOUNDARY GRAPH
      //This creates the boundary graph to be solved, using the cluster information
      //This calls both "getBoundaryPairs()" and "getClusterBoundaryPaths()"
      void getInitialBoundaryPaths();
      //?
      //USES GPU INFO
      void getBoundaryPairs();

      //?
      //USES GPU INFO
      void getClusterBoundaryPaths();

      //?
      //USES GPU INFO
      float getScoreOfClusterPath(int clusterID, std::vector<int> path);



      //Class the necessary function within _handler->_pa to allocate the necessary boundary objects
      void createBoundaryContainers();
      //USES GPU INFO
      //Populates the containers on the gpu so that the graph can be solved using cuda
      void populateBoundaryContainers();

      //Called by populateBoundaryContainers
      void populateNeighbours();
      //Called by popoulateBoundaryContainers
      void populateGraphScores();

      //maps the boundary points 
      //Gets initial Boundary paths
      //createsBoundaryContainers
      void processBoundaries();



      void getAverageNodePathScores();

      //Once the boundary graph has been solved on the GPU
      //This method calculates the shortest paths between all nodes in the boundary graph. 
      void getAllBoundaryPaths();

      void graphContinuityCheck();

      void removeDisconnectedClusters();

      void removeDisconnectedCluster(int clusterIndex);




      //Given a path between any two boundary points return
      //the same path but in global node space and not boundary space. 
      std::vector<int> getGlobalPathFromBoundaryPath(std::vector<int> path);

      //For two points (srcIndex and destIndex), that exist in separate clusters in the map
      //Return the shortest path between them (in global space?)
      std::vector<int> getShortestPathBetweenClusters(int srcCluster, int srcIndex,
                                                      int destCluster, int destIndex);

      //Return the shortest path and the score of that path between two points that exist within different clusters. 
      std::pair<float, std::vector<int>> getShortestPathAndScoreBetweenClusters(int srcCluster, int srcIndex,
                                                                                int destCluster, int destIndex);

      //For two indices within a cluster, find the shortest path. This is often a straight line, but
      //depending on the shape of the environment it isn't.
      std::vector<int> getShortestPathWithinCluster(int clusterID, int sourceIndex, int destIndex);

      //Converts a path in cluster space to global space
      std::vector<int> globalPathFromClusterPath(int clusterID, std::vector<int> clusterPath);

      //?
      std::vector<int> getVertexPath(int clusterID, int closestSourceVertex, int closestDestVertex);
      //std::vector<int> getVertexPath(int clusterID, int closestSourceVertex, int closestDestVertex);
      int getIntermediateToVertex(int clusterID, int sourceIndex);
      //?
      //VARIABLES
      void checkVertexValidity(int vertex);

      int startTime;

      std::shared_ptr<nanomap::map::PlannerMap> _plannerMap;

      std::shared_ptr<nanomap::map::PlannerObjects> _plannerObjects;

      std::unique_ptr<nanomap::handler::PlannerHandler> _handler;

      std::shared_ptr<nanomap::config::Config> _config;

      std::shared_ptr<nanomap::planner::GPUInfo> _plannerConfig;

      openvdb::FloatGrid::Ptr _simGrid;

      //std::map<int, std::set<openvdb::Coord>> _searchedTiles;
      std::set<std::pair<openvdb::Vec3d, openvdb::Vec3d>> _searchedTiles;
      std::map<int, int> _clusterMap;
    };
    }
}
#endif
