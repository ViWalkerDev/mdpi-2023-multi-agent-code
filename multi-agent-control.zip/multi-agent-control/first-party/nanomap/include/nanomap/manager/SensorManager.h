
#ifndef NANOMAP_MANAGER_SENSORMANAGER_H_INCLUDED
#define NANOMAP_MANAGER_SENSORMANAGER_H_INCLUDED

#include "nanomap/sensor/LaserData.h"
#include "nanomap/sensor/FrustumData.h"
#include "nanomap/sensor/SensorData.h"
#include "nanomap/sensor/GPUInfo.h"
#include "nanomap/config/Config.h"
//This object takes config files and creates sensor config and one sensor info object. 

namespace nanomap{
    namespace manager{

        class SensorManager{
            
            public:
            //SensorManager();
            SensorManager(std::vector<std::string> sensorConfigs, std::shared_ptr<nanomap::config::Config> config);
            //void init(std::vector<std::string> sensorConfigs);



            std::vector<std::shared_ptr<nanomap::sensor::SensorData>> sensorData(){return _sensorData;}
            std::shared_ptr<nanomap::sensor::SensorData> sensorData(int index){return _sensorData[index];}
            std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo(){return _sensorInfo;}

            void loadSensors(std::vector<std::string> sensorConfigs, std::shared_ptr<nanomap::config::Config> config);
            std::shared_ptr<nanomap::sensor::SensorData> loadSensorData(std::string sensorConfig, std::shared_ptr<nanomap::config::Config> config);

            private:
            //This contains the unique sensor configurations
            std::vector<std::shared_ptr<nanomap::sensor::SensorData>> _sensorData;

            //This contains the necessary information for allocating gpu sensor arrays
            std::shared_ptr<nanomap::sensor::GPUInfo> _sensorInfo;
        };
    }
}
#endif