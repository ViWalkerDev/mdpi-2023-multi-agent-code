// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file SimManager.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_MANAGER_SIMMANAGER_H_INCLUDED
#define NANOMAP_MANAGER_SIMMANAGER_H_INCLUDED
#include <iomanip>
#include <chrono>
#include <iostream>
#include <string>


#include <tbb/parallel_for.h>
#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>

#include <openvdb/Grid.h>
#include <openvdb/Types.h>
#include <openvdb/math/Ray.h>
#include <openvdb/tools/Morphology.h>
#include <openvdb/math/DDA.h>

#include "nanomap/sensor/Sensor.h"

#include "nanomap/manager/BlockWorker.h"
#include "nanomap/manager/Manager.h"

#include "nanomap/handler/SimHandler.h"
#include "nanomap/nanomap.h"
#include "nanomap/sensor/GPUInfo.h"
#include "nanomap/map/GPUInfo.h"
/******************************************************************************

*******************************************************************************/

namespace nanomap{
  namespace manager{
  


  class SimManager : public Manager{
    using ValueT  = float;

    //using Vec3T   = nanovdb::Vec3<ValueT>;
    using EigenVec = Eigen::Matrix<ValueT, 3, 1>;
    using EigenMat = Eigen::Matrix<ValueT, 3, 3>;
    using Quaternion = Eigen::Quaternion<ValueT>;

    public:
      //SimManager();
      SimManager(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo, std::shared_ptr<nanomap::config::GPUInfo> config, openvdb::FloatGrid::Ptr simGrid);
      //void init(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo);

      // void insertPointCloudFromSim(std::shared_ptr<nanomap::sensor::Sensor> sensor
      //                                            openvdb::FloatGrid::Ptr floatGrid, 
      //                             std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
      //                                 std::shared_ptr<nanomap::map::GPUInfo> gridConfig,
      //                                       bool serialUpdate,
      //                                       int updateType);

      void createHandler();
      void generateCloudFromSim(std::shared_ptr<nanomap::sensor::Sensor> sensor, int publishSensor);
      void processSimGridUpdate(){
        _handler->processSimGridUpdate(_simGrid);
      }


      // //POINT CLOUD OPERATIONS
      // void insertPointCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor, 
      //                                       openvdb::FloatGrid::Ptr floatGrid, 
      //                                       std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
      //                                       std::shared_ptr<nanomap::map::GPUInfo> gridConfig,
      //                                       bool serialUpdate,
      //                                       int updateType);

      // void voxelUpdateFromFrustumBuffer(std::shared_ptr<openvdb::FloatGrid::Accessor> acc, std::shared_ptr<nanomap::map::GPUInfo> gridConfig);
      // void blockUpdateFromFrustumBuffer(bool serialUpdate, std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
      //                                     std::shared_ptr<nanomap::map::GPUInfo> gridConfig);

      
      
      
      // void insertPointCloudCPU(std::shared_ptr<nanomap::sensor::Sensor> sensor,
      //                           openvdb::FloatGrid::Ptr floatGrid, 
      //                           std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
      //                           std::shared_ptr<nanomap::map::GPUInfo> gridConfig);

      // void populateTempGrid(openvdb::FloatGrid::Accessor& tempAcc, 
      //                 std::shared_ptr<nanomap::sensor::Sensor> sensor,
      //                                   openvdb::FloatGrid::Ptr floatGrid, 
      //                 std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
      //             std::shared_ptr<nanomap::map::GPUInfo> gridConfig);


      // // void integrateTempGrid(openvdb::FloatGrid::Ptr tempGrid, std::shared_ptr<nanomap::map::Map> map);
      
      

      // void integrateTempGrid(openvdb::FloatGrid::Ptr tempGrid,
      //                         std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
      //                         std::shared_ptr<nanomap::map::GPUInfo> gridConfig);





      //void printUpdateTime(int count);

      //void closeHandler();

    protected:

      //std::unique_ptr<nanomap::handler::Handler> _handler;
      openvdb::FloatGrid::Ptr _simGrid;
    };
  }
}
#endif
