planner solver method call sequence

//CREATE AND UPLOAD PLANNER GRID TO GPU
createPlannerMapFromGrid(){
- _manager->createPlannerGrid
- _handler->_plannerAllocator->allocateValidAndSafe(validCount, safeCount);
- _handler upload planner grid to GPU
}
//CREATE AND UPLOAD PLANNER GRID TO GPU


//EXTRACT CLUSTERS FROM PLANNER GRID ON GPU AND CREATE GPU CLUSTERS TO SOLVE
extractClustersFromPlannerMap(){
- extract clusters from map
- _handler->getClusters(plannerBucket, _plannerHandle));
WITH NEW CLUSTER INFO, CREATE PLANNER OBJECTS, MAKE A GRAPH FOR EACH CLUSTER, THEN POPULATE THE GPU CLUSTERS TO SOLVE
- manager->mergeClusters()
- manager->getClusterGraph()
- manager->populateGlobalClusterMap()
- manager->createGPUClusters()
}
//EXTRACT CLUSTERS FROM PLANNER GRID ON GPU AND CREATE GPU CLUSTERS TO SOLVE

solveClusters{
    _handler->solveClusters(){
        //THIS IS SOLVING ALL THE CLUSTERS WE HAVE CREATED AND IS DONE ON THE GPU IN THE HANDLER
        FOR EACH CLUSTER, WE CREATE A CUDA STREAM
                    std::vector<cudaStream_t> streams;
                    for(int x = 0; x < map->clusterIDs().size(); x++){
                    cudaStream_t stream;
                    streams.push_back(stream);
                    cudaCheck(cudaStreamCreate(&(streams[x])));
                    }
        AND ALSO CREATE EDGE EXTRACTION STREAMS
                    std::vector<cudaStream_t> edgeStreams;
                    for(int x = 0; x < map->clusterIDs().size(); x++){
                    cudaStream_t stream;
                    edgeStreams.push_back(stream);
                    cudaCheck(cudaStreamCreate(&(edgeStreams[x])));
                    }

        THEN IN PARALLEL
        WE Extract the edges of each cluster
                    for(int x = 0; x < map->clusterIDs().size(); x++){
                    getClusterEdges(*(map->plannerBucket()), *(map->plannerCluster(x)), _plannerHandle, edgeStreams[x]);
                    }

        While also populating clusters pairs, to begin solving
                    for(int x = 0; x < map->clusterIDs().size(); x++){
                    map->plannerCluster(x)->populateClusterPairs();
                    }
        Once we have populated cluster pairs for each cluster, we can get the distances between each cluster node
                    for(int x = 0; x < map->clusterIDs().size(); x++){
                    //cudaStream_t _stream;
                    //cudaCheck(cudaStreamCreate(&_stream));
                    //cudaDeviceSynchronize();
                    getClusterDistances(*(map->plannerBucket()), *(map->plannerCluster(x)), _plannerHandle, streams[x]);
                    //cudaDeviceSynchronize();
                    //std::cout << *(map->plannerCluster(x)->hostVertexSolution()) << std::endl;

                    //getClusterSolution(*(map->plannerBucket()),*(map->plannerCluster(x)), _plannerHandle, streams[x]);
                    }

        We can also continue the edge extraction, syncing the streams, and copying the necessary info to the host buffers
                    for(int x = 0; x < map->clusterIDs().size(); x++){
                    //cudaStreamSynchronize(streams[x]);
                    cudaStreamSynchronize(edgeStreams[x]);
                    cudaCheck(cudaMemcpyAsync(map->plannerCluster(x)->hostVertexCount(), map->plannerCluster(x)->devVertexCount(), sizeof(int),  cudaMemcpyDeviceToHost,edgeStreams[x]));
                    //cudaStreamSynchronize(streams[x]);
                    cudaStreamSynchronize(edgeStreams[x]);
                    *(map->plannerCluster(x)->hostScoreSize()) =(*(map->plannerCluster(x)->hostVertexCount()))*((*(map->plannerCluster(x)->hostVertexCount()))-1)/2;
                    cudaCheck(cudaMemcpyAsync(map->plannerCluster(x)->devScoreSize(), map->plannerCluster(x)->hostScoreSize(), sizeof(int), cudaMemcpyHostToDevice, edgeStreams[x]));
                    cudaCheck(cudaMemcpyAsync(map->plannerCluster(x)->hostVertexBuffer(), map->plannerCluster(x)->devVertexBuffer(), (*(map->plannerCluster(x)->hostVertexCount()))*sizeof(int),  cudaMemcpyDeviceToHost, edgeStreams[x]));
                    }

        Then, with the edge streams synced and copied.
        We allocate containers to for the vertex based operations
                    for(int x = 0; x < map->clusterIDs().size(); x++){
                    map->plannerCluster(x)->allocateVertices(edgeStreams[x]);
                    }
        Then we populate the necessary index objects
                    for(int x = 0; x < map->clusterIDs().size(); x++){
                    map->plannerCluster(x)->populateIndex(edgeStreams[x]);
                    //map->plannerCluster(x)->vertexDistancesFromClusters(streams[x]);
                    }
        Finally we sync the edge streams, and prep the clusters for graph solutions
        for(int x = 0; x < map->clusterIDs().size(); x++){
            cudaStreamSynchronize(edgeStreams[x]);
            prepGraphSolutions(*(map->plannerBucket()), *(map->plannerCluster(x)), _plannerHandle, streams[x]);
        }
        for(int x = 0 ; x < map->clusterIDs().size(); x++){
            map->plannerCluster(x)->copyNeighbours(streams[x]);
        }
        //std::cout << "6" << std::endl;
        // for(int x = 0; x < map->clusterIDs().size(); x++){
        //   map->plannerCluster(x)->vertexDistancesFromClusters(streams[x]);
        // }
        for(int x = 0 ; x < map->clusterIDs().size(); x++){
            map->plannerCluster(x)->allocateNeighbours(streams[x]);
        }
        //std::cout << "7" << std::endl;
        for(int x = 0 ; x < map->clusterIDs().size(); x++){
            map->plannerCluster(x)->populateNeighbours(streams[x]);
        }
        //std::cout << "8" << std::endl;
        Finally we 'step the clusters' this is the term used for the graph solving algorithm developed, solving each vertex graph for each cluster. 
        for(int x = 0; x < map->clusterIDs().size(); x++){
            stepClusterGraphs(*(map->plannerBucket()), *(map->plannerCluster(x)), streams[x]);
        }

        We sync the streams, and copy the necessary information to the host
        for(int x = 0; x < map->clusterIDs().size(); x++){
            cudaStreamSynchronize(streams[x]);
            cudaCheck(cudaMemcpyAsync(map->plannerCluster(x)->hostLevel(), map->plannerCluster(x)->devLevel(), sizeof(int), cudaMemcpyDeviceToHost,streams[x]));
            cudaStreamSynchronize(streams[x]);
            cudaCheck(cudaMemcpyAsync(map->plannerCluster(x)->hostSolutionCounts(), map->plannerCluster(x)->devSolutionCounts(), (*(map->plannerCluster(x)->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost,streams[x]));
        }

        Using this informaiton we can allocate the objects necessary to store the paths between the vertices of each cluster
                    for(int x = 0; x < map->clusterIDs().size(); x++){
                    map->plannerCluster(x)->allocateVertexPaths(streams[x]);
                    }
                    //std::cout << "11" << std::endl;
        And then extract these paths from the existing device side data structures we populated during the stepClusterGraphs() stage
                    for(int x =  0; x <  map->clusterIDs().size(); x++){
                    //cudaDeviceSynchronize();
                    //std::cout << "CLUSTER ID = " << x << std::endl;
                    getClusterSolutions(*(map->plannerBucket()), *(map->plannerCluster(x)), streams[x]);
                    }
        These paths are then copied to host data structures where they can be used!
                    //std::cout << "12" << std::endl;
                    for(int x = 0;  x < map->clusterIDs().size(); x++){
                    cudaStreamSynchronize(streams[x]);
                    cudaCheck(cudaMemcpyAsync(map->plannerCluster(x)->hostVertexPaths(), map->plannerCluster(x)->devVertexPaths(), *(map->plannerCluster(x)->hostScoreSize())*(*(map->plannerCluster(x)->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost,streams[x]));
                    }
    }
}
//THIS IS SOLVING THE CLUSTERS THAT WE HAVE CREATED AND CAN ALL BE DONE ON THE GPU

//WE DO THE REST FROM THE MANANGER SIDE OF THINGS

createAndSolveBoundaryGraph(){
    Now that we have a bunch of separate clusters, each with their own vertex graph solutions.
    We can start solving the graph that connects all these clusters. 
    First we determine which nodes are exist on the boundaries between clusters
    SOME OF THESE METHODS MAY BE POSSIBLE TO RUN WHILE THE PREVIOUS CLUSTER GPU CALCS ARE BEING PERFORMED NOT SURE IF 
    THERE IS LIKELY ROOM FOR SPEED UP HERE, BUT AGAIN, NOT SURE IF WORTH
    map->getClusterBoundaries();
    map->getClosestVertices();
    map->populateFullClusters(); ????? THIS MAY NOT BE NECESSARY
    map->processBoundaries();
        PROCESSBOUNDARIES does a lot of work:
            IT MAPS THE BOUNDARY POINTS (mapBoundaryPoints())
            GETS THE PATHS BETWEEN BOUNDARY POINTS WITHIN EACH CLUSTER (getInitialBoundaryPaths())
            AND PERFORMS THE NECESSARY GPU SETUP TO SOLVE THE BOUNDARY GRAPH (setupBoundaryGraph())
    With the CPU prep mostly done, we can
    prepBoundaryArrays(*(map->plannerBucket()), _s0)
    then we 
    populateBoundaryContainers()
    and then use
    plannerBucket()->copyBoundaryContainers()
    to copy the host side boundary container info to the gpu
    FINALLY WE CAN SOLVE THE BOUNDARY GRAPH
    stepBoundaryGraph(plannerBucket(), s0)
    We synchronize the device, copy the necessary info from the boundary graph solution
    cudaStreamSynchronize(_s0);
    cudaCheck(cudaMemcpyAsync(map->plannerBucket()->hostLevel(), map->plannerBucket()->devLevel(), sizeof(int), cudaMemcpyDeviceToHost, _s0));
    cudaStreamSynchronize(_s0);
    cudaCheck(cudaMemcpyAsync(map->plannerBucket()->hostSolutionCounts(), map->plannerBucket()->devSolutionCounts(), (*(map->plannerBucket()->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost, _s0));
    THEN WE CAN USE THAT TO CORRECTLY ALLOCATE ROOM FOR THE BOUNDARY PATH SOLUTIONS WE HAVE CALCULATED
    map->plannerBucket()->allocateBoundaryPaths(_s0)
    THEN WITH THE CORRECT ALLOCATIONS, WE CAN GET THE PATHS FROM THE SOLUTION WITH
    getBoundarySolutions(*(map->plannerBkucet()),_s0)
    WE SYNC THE STREAM AGAIN, THEN COPY THE BOUNDARY PATHS TO THE HOST
    cudaStreamSynchronize(_s0);
    cudaCheck(cudaMemcpyAsync(map->plannerBucket()->hostBoundaryPaths(), map->plannerBucket()->devBoundaryPaths(), (*(map->plannerBucket()->hostBoundaryScoreSize()))*(*(map->plannerBucket()->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost,_s0));
    cudaStreamSynchronize(_s0);

    Then we call 
    map->getAllBoundaryPaths()
    THIS EXTRACTS THE BOUNDARY PATH SOLUTIONS THAT WE JUST CALCULATED INTO USABLE SEARCHABLE OBJECTS

    With the calculated info, looking up paths between any two points is very fast now
}





PlannerManager::createPlannerMapFromGrid(openvdb::FloatGrid::Ptr grid){
    createPlannerGrid(grid);
    _handler->allocateValidAndSafe(validCount, safeCount); 
    _handler->uploadPlannerGrid(_plannerMap->plannerGrid());
}
PlannerHandler::allocateValidAndSafe(int validCount, int safeCount){
    _plannerAllocator->allocateValidAndSafe(validCount, safeCount);
}
PlannerHandler::uploadPlannerGrid(openvdb::Int32Grid::Ptr grid){
    _plannerHandle = nanomap::openvdbToNanoVDB<nanomap::CudaDeviceBuffer>(*(map->plannerGrid()));
    _plannerHandle.deviceUpload();
}

PlannerManager::extractClustersFromPlannerMap(){
    _handler->getClusters();
    mergeClusters();
    getClusterGraph();
    populateGlobalClusterMap();
    createGPUClusters();
}

PlannerManager::solveClusters(){
    //This does double duty, it extracts the vertex nodes for each cluster and then solves them
   _handler->solveClusters();
}

PlannerManager::createAndSolveBoundaryGraph(){
    //Calculate boundary nodes between clusters before creating the necessary GPU containers
    getClusterBoundaries();
    getClosestVertices();
    processBoundaries();
    _handler->prepareBoundaryArrays();
    populateBoundaryContainers();
    _handler->copyBoundaryContainers();
    plannerBucket()->copyBoundaryContainers();
    //FINALLY WE CAN SOLVE THE BOUNDARY GRAPH
    _handler->solveBoundaryGraph();
    //WE THE BOUNDARY PATH SOLUTIONS THAT WE JUST CALCULATED INTO USABLE SEARCHABLE OBJECTS
    getAllBoundaryPaths()
}


PlannerHandler::prepareBoundaryArrays(){
    prepBoundaryArrays(*(_plannerAllocator->plannerBucket()), _s0);
}

PlannerHandler::copyBoundaryContainers(){
    _plannerAllocator->plannerBucket()->copyBoundaryContainers();
}

PlannerHandler::solveBoundaryGraph(){
    stepBoundaryGraph(*(_plannerAllocator->plannerBucket()), s0);
    cudaStreamSynchronize(_s0);
    cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerBucket()->hostLevel(), _plannerAllocator->plannerBucket()->devLevel(), sizeof(int), cudaMemcpyDeviceToHost, _s0));
    cudaStreamSynchronize(_s0);
    cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerBucket()->hostSolutionCounts(), _plannerAllocator->plannerBucket()->devSolutionCounts(), (*(_plannerAllocator->plannerBucket()->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost, _s0));
    _plannerAllocator->plannerBucket()->allocateBoundaryPaths(_s0)
    getBoundarySolutions(*(_plannerAllocator->plannerBucket()),_s0)
    cudaStreamSynchronize(_s0);
    cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerBucket()->hostBoundaryPaths(), _plannerAllocator->plannerBucket()->devBoundaryPaths(), (*(_plannerAllocator->plannerBucket()->hostBoundaryScoreSize()))*(*(_plannerAllocator->plannerBucket()->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost,_s0));
    cudaStreamSynchronize(_s0);
}



 PlannerHandler::solveClusters(){
    //FOR EACH CLUSTER, WE CREATE A CUDA STREAM
    std::vector<cudaStream_t> streams;
    for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
        cudaStream_t stream;
        streams.push_back(stream);
        cudaCheck(cudaStreamCreate(&(streams[x])));
    }
    // AND ALSO CREATE EDGE EXTRACTION STREAMS
    std::vector<cudaStream_t> edgeStreams;
    for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
        cudaStream_t stream;
        edgeStreams.push_back(stream);
        cudaCheck(cudaStreamCreate(&(edgeStreams[x])));
    }
    //Then we extract the edges of each cluster
    for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
        getClusterEdges(*(_plannerAllocator->plannerBucket()), *(_plannerAllocator->plannerCluster(x)), _plannerHandle, edgeStreams[x]);
    }
    // While also populating clusters pairs, to begin solving
    for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
        _plannerAllocator->plannerCluster(x)->populateClusterPairs();
    }
    //Once we have populated cluster pairs for each cluster, we can get the distances between each cluster node
    for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
        getClusterDistances(*(_plannerAllocator->plannerBucket()), *(_plannerAllocator->plannerCluster(x)), _plannerHandle, streams[x]);
    }

    //We can also continue the edge extraction, syncing the streams, and copying the necessary info to the host buffers
    for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
        cudaStreamSynchronize(edgeStreams[x]);
        cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerCluster(x)->hostVertexCount(), _plannerAllocator->plannerCluster(x)->devVertexCount(), sizeof(int),  cudaMemcpyDeviceToHost,edgeStreams[x]));
        cudaStreamSynchronize(edgeStreams[x]);
        *(_plannerAllocator->plannerCluster(x)->hostScoreSize()) =(*(_plannerAllocator->plannerCluster(x)->hostVertexCount()))*((*(_plannerAllocator->plannerCluster(x)->hostVertexCount()))-1)/2;
        cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerCluster(x)->devScoreSize(), _plannerAllocator->plannerCluster(x)->hostScoreSize(), sizeof(int), cudaMemcpyHostToDevice, edgeStreams[x]));
        cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerCluster(x)->hostVertexBuffer(), _plannerAllocator->plannerCluster(x)->devVertexBuffer(), (*(_plannerAllocator->plannerCluster(x)->hostVertexCount()))*sizeof(int),  cudaMemcpyDeviceToHost, edgeStreams[x]));
    }
    //Then, with the edge streams synced and copied.
    //We allocate containers to for the vertex based operations
    for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
        _plannerAllocator->plannerCluster(x)->allocateVertices(edgeStreams[x]);
    }
    //Then we populate the necessary index objects
    for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
        _plannerAllocator->plannerCluster(x)->populateIndex(edgeStreams[x]);
    }
    //Finally we sync the edge streams, and prep the clusters for graph solutions
    for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
        cudaStreamSynchronize(edgeStreams[x]);
        prepGraphSolutions(*(_plannerAllocator->plannerBucket()), *(_plannerAllocator->plannerCluster(x)), _plannerHandle, streams[x]);
    }
    for(int x = 0 ; x < _plannerAllocator->clusterIDs().size(); x++){
        _plannerAllocator->plannerCluster(x)->copyNeighbours(streams[x]);
    }
    for(int x = 0 ; x < _plannerAllocator->clusterIDs().size(); x++){
        _plannerAllocator->plannerCluster(x)->allocateNeighbours(streams[x]);
    }
    for(int x = 0 ; x < _plannerAllocator->clusterIDs().size(); x++){
        _plannerAllocator->plannerCluster(x)->populateNeighbours(streams[x]);
    }

    //Finally we 'step the clusters' this is the term used for the graph solving algorithm developed, solving each vertex graph for each cluster. 
    for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
        stepClusterGraphs(*(_plannerAllocator->plannerBucket()), *(_plannerAllocator->plannerCluster(x)), streams[x]);
    }
    //We sync the streams, and copy the necessary information to the host
    for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
        cudaStreamSynchronize(streams[x]);
        cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerCluster(x)->hostLevel(), _plannerAllocator->plannerCluster(x)->devLevel(), sizeof(int), cudaMemcpyDeviceToHost,streams[x]));
        cudaStreamSynchronize(streams[x]);
        cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerCluster(x)->hostSolutionCounts(), _plannerAllocator->plannerCluster(x)->devSolutionCounts(), (*(_plannerAllocator->plannerCluster(x)->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost,streams[x]));
    }
    //Using this informaiton we can allocate the objects necessary to store the paths between the vertices of each cluster
    for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
        _plannerAllocator->plannerCluster(x)->allocateVertexPaths(streams[x]);
    }
    //And then extract these paths from the existing device side data structures we populated during the stepClusterGraphs() stage
    for(int x =  0; x <  _plannerAllocator->clusterIDs().size(); x++){
        getClusterSolutions(*(_plannerAllocator->plannerBucket()), *(_plannerAllocator->plannerCluster(x)), streams[x]);
    }
    //These paths are then copied to host data structures where they can be used!
    for(int x = 0;  x < _plannerAllocator->clusterIDs().size(); x++){
        cudaStreamSynchronize(streams[x]);
        cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerCluster(x)->hostVertexPaths(), _plannerAllocator->plannerCluster(x)->devVertexPaths(), *(_plannerAllocator->plannerCluster(x)->hostScoreSize())*(*(_plannerAllocator->plannerCluster(x)->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost,streams[x]));
    }
}