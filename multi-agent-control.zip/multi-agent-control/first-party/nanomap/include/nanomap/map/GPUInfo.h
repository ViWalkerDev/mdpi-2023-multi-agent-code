
#ifndef NANOMAP_MAP_GPUINFO_H_INCLUDED
#define NANOMAP_MAP_GPUINFO_H_INCLUDED


namespace nanomap{
    namespace map{
        struct GPUInfo
        {
        float gridRes; 
        float logOddsMissThreshold; 
        float logOddsHitThreshold;
        float occupiedClampingThreshold;
        float emptyClampingThreshold;
        int leafEdge = 8;

        GPUInfo(){
            gridRes = 0.1;
            logOddsMissThreshold = 0.0;
            logOddsHitThreshold = 0.0;
            occupiedClampingThreshold = 0.0;
            emptyClampingThreshold = 0.0;;
            }
        GPUInfo(float _gridRes, 
                float _logOddsMissThreshold, 
                float _logOddsHitThreshold, 
                float _occupiedClampingThreshold,
                float _emptyClampingThreshold){
                gridRes = _gridRes;
                logOddsMissThreshold = _logOddsMissThreshold; 
                logOddsHitThreshold = _logOddsHitThreshold;
                occupiedClampingThreshold = _occupiedClampingThreshold;
                emptyClampingThreshold = _emptyClampingThreshold;
            }
        };

    }
}
#endif