// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file OccupancyMap.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_MAP_MAP_H_INCLUDED
#define NANOMAP_MAP_MAP_H_INCLUDED
#include <memory>
#include <openvdb/Types.h>
#include <openvdb/Grid.h>
#include <openvdb/openvdb.h>
#include <openvdb/tree/Tree.h>
#include <openvdb/tools/ValueTransformer.h>
#include "nanomap/map/GPUInfo.h"
//#include <nanovdb/util/GridHandle.h>
namespace nanomap{
  namespace map{


    //Base Map Class, contains a single float grid.
    class Map{
      using FloatGrid = openvdb::FloatGrid;
      using FloatTreeT = openvdb::FloatGrid::TreeType;
      using FloatLeafT = FloatTreeT::LeafNodeType;
      using FloatAccessorT = openvdb::tree::ValueAccessor<FloatTreeT>;

      // using IntGrid = openvdb::Int32Grid;
      // using IntTreeT = IntGrid::TreeType;
      // using IntLeafT = IntTreeT::LeafNodeType;
      // using IntAccessorT = openvdb::tree::ValueAccessor<IntTreeT>;
      public:
        Map(){}

        Map(float gridRes, float probThresHit, float probThresMiss){
            //Define GridRes
            _gridRes = 0.1;
            //DO NOT DEFINE RESOLTIONS WITH FLOAT MULTIPLICATION (ie gridRes_*8), THE SOFTWARE LOSES ITS MIND BECAUSE OF MINUTE ROUNDING ERRORS
            _searchRes = 0.8;
            //Define Mapping Variables
            _logOddsMissThreshold = log(probThresMiss)-log(1-probThresMiss);
            _logOddsHitThreshold = log(probThresHit)-log(1-probThresHit);
            _occupiedClampingThreshold = log(0.97)-log(1-0.97);
            _emptyClampingThreshold = (log(0.12)-log(1-0.12));
            //Create Grids
            _knownGrid = openvdb::FloatGrid::create(0.0);
            _searchGrid = openvdb::FloatGrid::create(0.0);
            _occupiedGrid = openvdb::FloatGrid::create(0.0);
            // Create Linear Transforms for World to GridRes transform.
            _searchGrid->setTransform(openvdb::math::Transform::createLinearTransform(_searchRes));
            _occupiedGrid->setTransform(openvdb::math::Transform::createLinearTransform(_gridRes));
            _knownGrid->setTransform(openvdb::math::Transform::createLinearTransform(_gridRes));
            // Identify the grids as level set
            _searchGrid->setGridClass(openvdb::GRID_LEVEL_SET);
            _searchGrid->setName("SearchGrid");
            _occupiedGrid->setGridClass(openvdb::GRID_LEVEL_SET);
            _occupiedGrid->setName("OccupiedGrid");
            _knownGrid->setGridClass(openvdb::GRID_LEVEL_SET);
            _knownGrid->setName("KnownGrid");
            //create accessor ptr
            _knownAccessor = std::make_shared<FloatAccessorT>(_knownGrid->getAccessor());
            _searchAccessor = std::make_shared<FloatAccessorT>(_searchGrid->getAccessor());
            _occAccessor = std::make_shared<FloatAccessorT>(_occupiedGrid->getAccessor());
            _gridConfig = std::make_shared<nanomap::map::GPUInfo>(_gridRes, 
                                                                  _logOddsMissThreshold, 
                                                                  _logOddsHitThreshold, 
                                                                  _occupiedClampingThreshold,
                                                                  _emptyClampingThreshold);
          }

        virtual void clearMap(){
          _knownGrid->clear();
          _occupiedGrid->clear();
          _searchGrid->clear();
        }

        virtual openvdb::FloatGrid::Ptr searchGrid(){return _searchGrid;}
        virtual openvdb::FloatGrid::Ptr knownGrid(){return _knownGrid;}
        virtual openvdb::FloatGrid::Ptr occupiedGrid(){return _occupiedGrid;}

        virtual float occupiedClampingThreshold() {return _occupiedClampingThreshold;}
        virtual float emptyClampingThreshold() {return _emptyClampingThreshold;}
        virtual float logOddsHitThreshold() {return _logOddsHitThreshold;}
        virtual float logOddsMissThreshold() {return _logOddsMissThreshold;}

        virtual std::shared_ptr<FloatAccessorT> searchAccessor(){return _searchAccessor;}
        virtual std::shared_ptr<FloatAccessorT> knownAccessor(){return _knownAccessor;}        
        virtual std::shared_ptr<FloatAccessorT> occAccessor(){return _occAccessor;}
        float gridRes(){return _gridRes;}
        float searchRes(){return _searchRes;}
        std::shared_ptr<nanomap::map::GPUInfo> gridConfig(){return _gridConfig;}
      private:
        std::shared_ptr<nanomap::map::GPUInfo> _gridConfig;
        double _gridRes;
        double _searchRes;
        float _logOddsMissThreshold;
        float _logOddsHitThreshold;
        float _occupiedClampingThreshold;
        float _emptyClampingThreshold;
        FloatGrid::Ptr _occupiedGrid;
        FloatGrid::Ptr _searchGrid;
        FloatGrid::Ptr _knownGrid;
        std::shared_ptr<FloatAccessorT> _knownAccessor;
        std::shared_ptr<FloatAccessorT> _searchAccessor;
        std::shared_ptr<FloatAccessorT> _occAccessor;


    };
  }//namespace map
}//namespace nanomap
#endif
