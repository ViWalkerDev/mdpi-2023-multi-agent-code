#ifndef NANOMAP_MAP_PLANNERMAP_H_INCLUDED
#define NANOMAP_MAP_PLANNERMAP_H_INCLUDED

//#include <nanovdb/NanoVDB.h>
//#include "nanomap/map/OccupancyMap.h"


#include <map>
#include <algorithm>
#include <set>

#include <openvdb/Types.h>
#include <openvdb/Grid.h>
#include <openvdb/openvdb.h>
#include <openvdb/tree/Tree.h>
//#include <openvdb/tools/ValueTransformer.h>
// #include <nanovdb/util/GridHandle.h>
// #include <nanovdb/util/Ray.h> // for nanovdb::Ray



namespace nanomap{
  namespace map{


    //Base Map Class, contains a single grid.
    class PlannerMap{
      using IntGrid = openvdb::Int32Grid;
      using IntTreeT = IntGrid::TreeType;
      using IntLeafT = IntTreeT::LeafNodeType;
      using IntAccessorT = openvdb::tree::ValueAccessor<IntTreeT>;

      public:
        PlannerMap(float plannerRes);




        IntGrid::Ptr plannerGrid();
        std::shared_ptr<IntAccessorT> plannerAccessor();

      private:

        float _plannerRes;
        IntGrid::Ptr _plannerGrid;
        std::shared_ptr<IntAccessorT> _plannerAccessor;
    };
  }//namespace map
}//namespace nanomap
#endif
