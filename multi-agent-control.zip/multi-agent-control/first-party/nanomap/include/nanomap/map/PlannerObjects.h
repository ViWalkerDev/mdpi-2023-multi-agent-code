
#ifndef NANOMAP_MAP_PLANNEROBJECTS_H_INCLUDED
#define NANOMAP_MAP_PLANNEROBJECTS_H_INCLUDED
#include <map>
#include <vector>
#include <set>
//This struct contains all the CPU side planner objects required for solving the environment graph map. 
namespace nanomap{
    namespace map{
        struct PlannerObjects
        {
         
            

        std::vector<std::vector<std::set<int>>> clusterBoundarySets;
        std::vector<std::set<int>> clusterNeighbours;
        std::map<int,int> clusterIndices;

        std::map<int, int> globalClusterNodeMap;
        //Maps what global indices belong to which clusters.
        std::map<int, int> globalClusterMap;
        std::map<std::pair<int, int>, std::pair<float, std::vector<int>>> boundaryPaths;
        //Maps Cluster and Boundarypoint index to a boundary index;
        std::map<int, std::pair<int, int>> boundaryToGlobalMap;
        std::map<int, int> globalToBoundaryMap;
        std::vector<std::vector<float>> meanNodePathScores;
        std::vector<std::vector<int>> nodePathCounts;
        std::vector<int> clusterIDs;
        std::vector<std::vector<int>>  clustersSafe;
        std::vector<std::vector<int>> clustersFull;
        std::vector<std::vector<int>> clustersValid;
        std::vector<std::vector<int>> clusterParents;
        std::vector<std::vector<int>> clusterBoundaryPoints;
        //std::shared_ptr<nanovdb::GridHandle<nanovdb::CudaDeviceBuffer>> _plannerHandle;
        //contains the global indexes for all vertex edges belonging to each cluster
        std::vector<std::vector<int>> clusterEdges;
        std::vector<std::vector<int>> clusterEdgeCombos;
        
        std::vector<std::set<int>> clusterBoundaryNodes;
        //For each cluster, sets of nodes that make up each contiguous boundary
        //std::vector<std::vector<std::set<int>>> _clusterBoundarySets;
        
        //For each cluster, the nodes that are the closest to the centre of each boundary.

        std::vector<std::map<int, int>> clusterVertexNodeMap;

        std::vector<std::vector<std::pair<int,std::vector<std::pair<int,int>>>>> clusterGraph;
        std::vector<Eigen::Vector3f> boundaryLines;
        std::vector<std::vector<Eigen::Vector3f>> boundaryPoints;

        //Maps global index to cluster node index within a cluster

        //This contains the shortest paths for all cluster pairs.
        std::vector<std::vector<int>> clusterShortestPaths;
        //radius of each cluster search association. to be completed, must observe all nodes within radius distance. 
        int clusterSearchRadius = 5;
        //Cluster Search Target Density = the minimum distace that search targets can be separated by. 
        int clusterSearchDensity = 3;
        //one entry per cluster, per cluster, a list of search targets. Each target is a node that is associated with a list of cluster local nodes. 
        std::vector<std::vector<int>> clusterSearchNodes;
        std::map<int, std::map<int, std::vector<int>>> clusterSearchInfo;
        
        //Bounding box for each cluster, used for assisting with sampling search targets. 
        std::vector<openvdb::CoordBBox> clusterBounds;

        //Contains the calculated search paths from <starting boundary, ending boundary> passing through the search targets
        //Calculation of this may be accelerated by the GPU but time did not permit. 
        std::vector<std::map<std::pair<int, int>, std::vector<int>>> clusterSearchPaths;

        int boundaryCount = 0;
        int boundaryScoreSize = 0;
        int boundaryNeighbourCount = 0;
        int safeCount = 0;
        int validCount = 0;
        float maxMovePenalty = 0.0;
        PlannerObjects(){}
        };

    }
}
#endif