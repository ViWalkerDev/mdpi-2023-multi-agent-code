// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

///
/// @author Violet Walker
///
#ifndef NANOMAP_MAPGEN_MAPGEN_H_INCLUDED
#define NANOMAP_MAPGEN_MAPGEN_H_INCLUDED

#include "nanomap/mapgen/procedural/CaveGen.h"

namespace nanomap{
    namespace mapgen{
        class MapGen{
            public:
                MapGen(){}

                openvdb::FloatGrid::Ptr generateAndReturnMap(std::string& mapGenConfig){
                    nanomap::mapgen::CaveGen generator(mapGenConfig);
                    generator.populateMap2D();
                    generator.smoothMapXY();
                    generator.getRegions();
                    generator.keepLargestRegion();
                    return generator.invertAndReturn();
                }
        };
    }
}

#endif