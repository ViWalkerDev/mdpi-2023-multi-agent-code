// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file nanomap.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_H_INCLUDED
#define NANOMAP_H_INCLUDED
#include <vector>
#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>

#define M_PI 3.14159265358979323846
#define MAX_INT 32766
#define VOXEL_SIZE 1
//GRIDRENDER IS A DEFINE FOR DEBUGGING MAP GENERATION IT IS USED BY THE PLANNER 
//MANAGER FOR SAVING IN BETWEEN PROCESSSING STEPS AND ISN'T NEEDED FOR OPERATION
#define GRIDRENDER 0
namespace nanomap{
//Basic pose structure for managing agent Poses
  struct Pose
  {
      Eigen::Vector3f position;
      Eigen::Quaternionf orientation;
      Pose(Eigen::Vector3f newPosition, Eigen::Quaternionf newOrientation){
        position = newPosition;
        orientation = newOrientation;
      }
      Pose(){
        position = Eigen::Vector3f(0.0f,0.0f,0.0f);
        orientation = Eigen::Quaternionf(0.0f,0.0f,0.0f,1.0f);
      }
      // std::vector<float> getPositionAsFloat(){
      //   std::vector<float> vecPosition{position(0), position(1), position(2)};
      //   return vecPosition;
      // }
      std::vector<float> getPositionAsFloat(){return std::vector<float>{position(0), position(1), position(2)};}
      std::vector<float> getOrientationAsFloat(){return std::vector<float>{orientation.w(), orientation.x(), orientation.y(), orientation.z()};}
      void setPositionFromFloat(float x, float y, float z){
        position = Eigen::Vector3f(x,y,z);
      }
      void setOrientationFromFloat(float w, float x, float y, float z){
        orientation = Eigen::Quaternionf(w,x,y,z);
      }
  };

}




#endif
