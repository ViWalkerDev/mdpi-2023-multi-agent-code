
#ifndef NANOMAP_PLANNER_GPUINFO_H_INCLUDED
#define NANOMAP_PLANNER_GPUINFO_H_INCLUDED


namespace nanomap{
    namespace planner{
        struct GPUInfo
        {
        float gridRes; 
        float mappingRes;
        float plannerRes;
        int leafEdge = 8;
        bool useTileLogic = false;

        GPUInfo(){
            gridRes = 0.1;
            mappingRes = 0.1;
            plannerRes = 0.8;
            leafEdge = 8;
            useTileLogic = false;
            }
        GPUInfo(float _gridRes, 
                float _mappingRes,
                float _plannerRes, 
                float _leafEdge){
                gridRes = _gridRes; 
                mappingRes = _mappingRes;
                plannerRes = _plannerRes;
                leafEdge = _leafEdge;
                useTileLogic = false;
            }
        };

    }
}
#endif