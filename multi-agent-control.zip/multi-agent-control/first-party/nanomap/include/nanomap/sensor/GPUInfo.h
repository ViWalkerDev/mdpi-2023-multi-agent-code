
#ifndef NANOMAP_SENSOR_GPUINFO_H_INCLUDED
#define NANOMAP_SENSOR_GPUINFO_H_INCLUDED


namespace nanomap{
    namespace sensor{
        struct GPUInfo
        {
          int frustumPCLSize;
          float frustumAllocationFactor;
          int frustumLeafBufferSize;

        GPUInfo(){
                frustumPCLSize = 0;
                frustumAllocationFactor = 0.4;
                frustumLeafBufferSize = 0;
            }
        GPUInfo(int pclSize, float allocationFactor, int leafBufferSize){
            frustumPCLSize = pclSize;
            frustumAllocationFactor = allocationFactor;
            frustumLeafBufferSize = leafBufferSize;
            }
        };

    }
}
#endif