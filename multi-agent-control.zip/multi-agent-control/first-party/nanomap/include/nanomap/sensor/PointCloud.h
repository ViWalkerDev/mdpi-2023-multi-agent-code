



namespace nanomap{
    namespace sensor{
        class PointCloud{
            public:
                PointCloud()
                :_width(0)
                ,_height(0)
                ,_step(0)
                ,_cloudPtr(NULL)
                {}

                PointCloud(int width, int height, int step)
                :_width(width)
                ,_height(height)
                ,_step(step)
                ,_cloudPtr(NULL)
                {}

                void updateCloud(int width, int height, int step, unsigned char * cloudPtr){
                    _width = width;
                    _height = height;
                    _step = step;
                    _cloudPtr = cloudPtr;
                }

                void updateCloudPtr(unsigned char * cloudPtr){
                    _cloudPtr = cloudPtr;
                }

                void setWidth(int width){_width = width;}
                void setHeight(int height){_height = height;}
                void setStep(int step){_step = step;}

                int width(){return _width;}
                int height(){return _height;}
                int step(){return _step;}
                unsigned char* cloudPtr(){return _cloudPtr;}
            private:
                int _width;
                int _height;
                int _step;
                unsigned char* _cloudPtr;


        };
    }
}