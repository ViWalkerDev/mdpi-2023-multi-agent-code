// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file SensorData.h
///
/// @author Violet Walker
///
#ifndef NANOMAP_SENSOR_SENSOR_H_HAS_BEEN_INCLUDED
#define NANOMAP_SENSOR_SENSOR_H_HAS_BEEN_INCLUDED
#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
#include <iomanip>
#include <chrono>
#include <iostream>
#include <string>
//#include <nanovdb/NanoVDB.h>
//#include "nanomap/nanomap.h"
#include "nanomap/sensor/SensorConfig.h"
#include "nanomap/sensor/SensorData.h"
#include "nanomap/sensor/PointCloud.h"
#include "nanomap/nanomap.h"
// #include <openvdb/Types.h>
// #include <openvdb/Grid.h>
// #include <openvdb/openvdb.h>
// #include <openvdb/tree/Tree.h>
// #include <openvdb/math/Coord.h>
// #include <openvdb/math/Ray.h>
// #include <openvdb/math/DDA.h>
//#include "nanomap/sensor/SharedParameters.h"
#include <cfenv>
#include <cmath>
namespace nanomap{
  namespace sensor{
    class Sensor{

      public:
        //Sensor();
        Sensor(std::shared_ptr<nanomap::sensor::SensorData> sensorData)
        :_sensorData(sensorData){
          //Initialise publishCloud and inputCloud structures
          _publishCloud.resize(3, _sensorData->sharedParameters()._pclSize);
        }
        
        Sensor(nanomap::sensor::SensorData sensorData)
        :_sensorData(std::make_shared<nanomap::sensor::SensorData>(sensorData)){
          //Initialise publishCloud and inputCloud structures
          _publishCloud.resize(3, _sensorData->sharedParameters()._pclSize);
        }

        // void init(std::shared_ptr<nanomap::sensor::SensorData> sensorData){

        // }

        //std::shared_ptr<nanomap::sensor::SensorConfig> sensorConfig(){return _sensorConfig;}
        std::shared_ptr<nanomap::sensor::SensorData> sensorData(){return _sensorData;}
        std::shared_ptr<nanomap::sensor::PointCloud> inputCloud(){return _inputCloud;}
        Eigen::Matrix<ValueT, 3, Eigen::Dynamic, Eigen::RowMajor>& publishCloud(){return _publishCloud;}
        void setPublishCloudAsInputCloud(){
          _inputCloud->setWidth(_sensorData->sharedParameters()._hRes);
          _inputCloud->setHeight(_sensorData->sharedParameters()._vRes);
          _inputCloud->setStep(12);
          _inputCloud->updateCloudPtr(reinterpret_cast<unsigned char*>(_publishCloud.data()));
        };


      protected:
        // //configuration data for this sensor configuration. This object can be shared by many sensors and is managed
        // //by the sensor manager
        // std::shared_ptr<nanomap::sensor::SensorConfig> _sensorConfig;

        //Sensor data contains the important infomation about this sensor entity
        std::shared_ptr<nanomap::sensor::SensorData> _sensorData;

        //The input point cloud object for this sensor object
        std::shared_ptr<nanomap::sensor::PointCloud> _inputCloud; 

        //The output pint cloud object for this sensor object, only used if _sensorConfig.publishSensor = true;
        Eigen::Matrix<ValueT, 3, Eigen::Dynamic, Eigen::RowMajor> _publishCloud;

      };
  }
}
#endif
