// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file Config.cpp
///
/// @author Violet Walker
///

#include "nanomap/config/Config.h"

#define M_PI 3.14159265358979323846
#define MAX_INT 32766
#define VOXEL_SIZE 1

namespace nanomap{
  namespace config{
    //Large Config Class Definitions
    Config::Config(std::string configFile)
    {
      setConfigFile(configFile);
      init();
    }
    void Config::setConfigFile(std::string configFile){
      _mainConfigFile = configFile;
      _configCheck = true;
    }

    void Config::init()
    {
      if(_configCheck){
        loadMainConfig();
        getAgentConfigs(_mainConfigFile);
        getSensorConfigs(_mainConfigFile);
      }
    }
    void Config::loadMainConfig(){
      std::cout <<"reading in config file: " << _mainConfigFile << std::endl;
      std::ifstream *input = new std::ifstream(_mainConfigFile.c_str(), std::ios::in | std::ios::binary);
      //bool end = false;
      std::string file, line;
      float goalReachedReward, collisionPenalty, gridRes, plannerRes, mappingRes, frustumAllocationFactor, laserAllocationFactor, probHitThres, probMissThres;
      int leafEdge, filterType, processType, updateType, exploreType, precisionType, simType, publishSensor, minimumSteps;
      int serialUpdate, generateSimGrid;
      std::string mapGenConfig;
      *input >> line;
      //std::cout << line << std::endl;
      float res;
      if(line.compare("#config") != 0){
        std::cout << "Error: first line reads [" << line << "] instead of [#config]" << std::endl;
        delete input;
        return;
      }
      while(input->good()) {
        *input >> line;
        if (line.compare("MappingRes:") == 0){
          *input >> mappingRes;
          _mappingRes = mappingRes;
        }else if (line.compare("ProbHitThres:") == 0){
          *input >> probHitThres;
          _probHitThres = probHitThres;
        }else if (line.compare("ProbMissThres:") == 0){
          *input >> probMissThres;
          _probMissThres = probMissThres;
        }else if (line.compare("GridRes:") == 0){
          *input >> gridRes;
          _gridRes = gridRes;
        }else if (line.compare("PlannerRes:") == 0){
          *input >> plannerRes;
          _plannerRes = plannerRes;
        }else if (line.compare("NodeEdge:") == 0){
          *input >> leafEdge;
          _leafEdge = leafEdge;
        }else if (line.compare("FrustumAllocationFactor:") == 0){
          *input >> frustumAllocationFactor;
          _frustumAllocationFactor = frustumAllocationFactor;
        }else if (line.compare("FilterType:") == 0){
          *input >> filterType;
          _filterType = filterType;
        }else if(line.compare("UpdateType:")==0){
          *input >> updateType;
          _updateType = updateType;
        }else if (line.compare("PrecisionType:") == 0){
          *input >> precisionType;
          _precisionType = precisionType;
        }else if (line.compare("ProcessType:") == 0){
          *input >> processType;
          _processType = processType;
        }else if (line.compare("PublishSensor:") == 0){
          *input >> publishSensor;
          _publishSensor = publishSensor;
        }else if (line.compare("GoalReachedReward:") == 0){
          *input >> goalReachedReward;
          _goalReachedReward = goalReachedReward;
        }else if (line.compare("CollisionPenalty:") == 0){
          *input >> collisionPenalty;
          _collisionPenalty = collisionPenalty;
        }else if (line.compare("MinimumSteps:") == 0){
          *input >> minimumSteps;
          _minimumSteps = minimumSteps;
        }else if (line.compare("GenerateSimGrid:") == 0){
        *input >> generateSimGrid;
          if(generateSimGrid==1){
            _generateSimGrid = true;
          }else{
            _generateSimGrid = false;
          }
        }else if (line.compare("MapGenConfig:") == 0){
        *input >> mapGenConfig;
        _mapGenConfig = mapGenConfig;
        }else if (line.compare("SimGrid:") == 0){
          *input >> file;
          _simGridFile = file;
        }else if (line.compare("PlannerGrid:") == 0){
          *input >> file;
          _plannerGridFile = file;
        }else if (line.compare("#endconfig")==0){
          break;
        }
      }
        input->close();
        _leafVolume = _leafEdge*_leafEdge*_leafEdge;
        _configInfo = std::make_shared<nanomap::config::GPUInfo>(_leafEdge, 
                                                                 _leafVolume,
                                                                 _gridRes,
                                                                 _mappingRes,
                                                                 _plannerRes,
                                                                 _filterType,
                                                                 _processType,
                                                                 _precisionType
                                                                 );
    }
    //This just loops over main config file and fetches the agent config file locations,
    // and stores them in a vector to be used by the agent manager
    void Config::getAgentConfigs(std::string config){
      std::cout <<"reading in config file for Agents: " << config << std::endl;
      std::ifstream *input = new std::ifstream(config.c_str(), std::ios::in | std::ios::binary);
      //bool end = false;
      std::string file, line;
      *input >> line;
      //std::cout << line << std::endl;
      float res;
      _agentConfigFiles.clear();
      if(line.compare("#config") != 0){
        std::cout << "Error: first line reads [" << line << "] instead of [#config]" << std::endl;
        delete input;
        return;
      }
      while(input->good()) {
        *input >> line;
        if (line.compare("Agent:") == 0){
          *input >> file;
          std::cout << "Found Agent File: " << file << std::endl;
          _agentConfigFiles.push_back(file);
        }
      }
        input->close();
    }

        //This just loops over main config file and fetches the sensor config file locations,
    // and stores them in a vector to be used by the sensor manager
    void Config::getSensorConfigs(std::string config){
      std::cout <<"reading in config file for Sensors: " << config << std::endl;
      std::ifstream *input = new std::ifstream(config.c_str(), std::ios::in | std::ios::binary);
      //bool end = false;
      std::string file, line;
      *input >> line;
      //std::cout << line << std::endl;
      float res;
      _sensorConfigFiles.clear();
      if(line.compare("#config") != 0){
        std::cout << "Error: first line reads [" << line << "] instead of [#config]" << std::endl;
        delete input;
        return;
      }
      while(input->good()) {
        *input >> line;
        if (line.compare("Sensor:") == 0){
          *input >> file;
          std::cout << "Found Sensor File: " << file << std::endl;
          _sensorConfigFiles.push_back(file);
        }
      }
        input->close();
    }
    
  }//namespace config
}//namespace nanomap
