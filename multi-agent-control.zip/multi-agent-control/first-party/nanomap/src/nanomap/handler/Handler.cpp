// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file SimHandler.cpp
///
/// @author Violet Walker
///


//THE MOST BASIC HANDLER CLASS. TAKES A SENSOR, RAY CASTS THE CLOUD.
//OCCUPANCY MAP EXTRACTED AT THE MANAGER LEVEL
#include "nanomap/handler/Handler.h"

namespace nanomap{
    namespace handler{

        // Handler::Handler(){
        //     _gpuTime = 0.0;
        //     cudaCheck(cudaStreamCreate(&_s0));
        //     cudaCheck(cudaStreamCreate(&_s1));
        // }

        Handler::Handler(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo, std::shared_ptr<nanomap::config::GPUInfo> config)
        :_sensorAllocator(sensorInfo, config){
          _gpuTime = 0.0;
          cudaCheck(cudaStreamCreate(&_s0));
          cudaCheck(cudaStreamCreate(&_s1));
        }

        // void Handler::init(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo, std::shared_ptr<nanomap::config::GPUInfo> config){
        //     initSensorAllocator(sensorInfo, config);
        // }

        // void Handler::initSensorAllocator(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo, std::shared_ptr<nanomap::config::GPUInfo> config){
        //     _sensorAllocator = nanomap::allocator::SensorAllocator(sensorInfo, config);
        // }

        void Handler::rayCastCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor){
            std::chrono::duration<double, std::milli> delay;
            //std::cout << calling base castCloud" << std::endl;
            auto gpu_start = std::chrono::high_resolution_clock::now();

            _sensorAllocator.update(sensor, _s0);
            //_sensorAllocator.update(sensor->sensorData(), _s0);
            //generateCloud(*(_sensorAllocator.sensorBucket()), _simGridHandle, _s0);
            cudaDeviceSynchronize();
            auto start = std::chrono::high_resolution_clock::now();
            // if(sensorData->sharedParameters()._type == 1){
            //     _sensorAllocator.downloadCloudToSensor(sensorData, _s0);
            //     start  = std::chrono::high_resolution_clock::now();
            //     processPointCloudCPU(sensorIndex, agentMap);
            // }else if(publishSensor == 1){
            //     _sensorAllocator.downloadCloudToSensor(sensorData, _s0);
            // }
            filterCloud(*(_sensorAllocator.sensorBucket()), _s0);

            cudaDeviceSynchronize();
            
            frustumCastCloud(*(_sensorAllocator.sensorBucket()), _s0, _s1);
            
            cudaCheck(cudaMemcpyAsync(_sensorAllocator.sensorBucket()->hostFrustumLeafBuffer(), _sensorAllocator.sensorBucket()->devFrustumLeafBuffer(), (*_sensorAllocator.sensorBucket()->hostFrustumLeafCount())*3*sizeof(int), cudaMemcpyDeviceToHost, _s0));
            cudaCheck(cudaMemcpyAsync(_sensorAllocator.sensorBucket()->hostFrustumVoxelBuffer(), _sensorAllocator.sensorBucket()->devFrustumVoxelBuffer(), (*_sensorAllocator.sensorBucket()->hostFrustumLeafCount())*512*sizeof(int8_t), cudaMemcpyDeviceToHost,_s1));
            
            cudaStreamSynchronize(_s0);
            cudaStreamSynchronize(_s1);

            auto gpu_end = std::chrono::high_resolution_clock::now();
            delay = gpu_end-gpu_start;
            _gpuTime+=delay.count();
            start = std::chrono::high_resolution_clock::now();

            // if(_sensorAllocator.sensorBucket()->hostSensor()->type()==0){
            //     if(updateType == 0){
            //         voxelUpdateFromFrustumBuffer(sensorData->sharedParameters()._leafEdge);
            //     }else if(updateType == 1){
            //         blockUpdateFromFrustumBuffer();
            //         }
            //     }
            // }
            auto end = std::chrono::high_resolution_clock::now();
            //delay = end-start;
            //_mapUpdateTime+=delay.count();
        }
        void Handler::closeHandler(){
            cudaCheck(cudaStreamDestroy(_s0));
            cudaCheck(cudaStreamDestroy(_s1));
        }

        void Handler::printUpdateTime(int count){
          std::cout << "gpu update time per loop:" << _gpuTime / count << std::endl;
          //std::cout << "map update time per loop:" << _mapUpdateTime / count << std::endl;

        }

        int Handler::getFrustumLeafCount(){return *(_sensorAllocator.sensorBucket()->hostFrustumLeafCount());}
        
        int* Handler::getFrustumLeafBuffer(){return _sensorAllocator.sensorBucket()->hostFrustumLeafBuffer();}

        int8_t* Handler::getFrustumVoxelBuffer(){return _sensorAllocator.sensorBucket()->hostFrustumVoxelBuffer();}

    }
}
