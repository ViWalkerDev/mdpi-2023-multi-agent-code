#include "nanomap/handler/PlannerHandler.h"
// The following functions are called by the host and launch the gpu kernels.
namespace nanomap{
  namespace handler{
        PlannerHandler::PlannerHandler(std::shared_ptr<nanomap::config::Config> config, openvdb::FloatGrid::Ptr simGrid)
        :_config(config)
        ,_simGrid(simGrid)
        ,_sensorAllocator(config)
        {
          _gpuTime = 0.0;
          _mapUpdateTime = 0.0;
          //_sensorData = sensorData;
          //_simGridHandle = nanovdb::openToNanoVDB<nanovdb::CudaDeviceBuffer>(*_simGrid);
          //_simGridHandle.deviceUpload();
          cudaCheck(cudaStreamCreate(&_s0));
          //cudaCheck(cudaStreamCreate(&_s1));
        }

        void PlannerHandler::updateMap(std::shared_ptr<nanomap::map::PlannerMap> map,
                        openvdb::FloatGrid::Ptr grid){

            map->updatePlannerGrid(grid);

            _plannerHandle = nanovdb::openToNanoVDB<nanovdb::CudaDeviceBuffer>(*(map->plannerGrid()));

            _plannerHandle.deviceUpload();
            auto clusterStart = std::chrono::high_resolution_clock::now();
            auto clusterEnd = std::chrono::high_resolution_clock::now();
            std::chrono::duration<double, std::milli> clusterDelay;
            clusterStart = std::chrono::high_resolution_clock::now();
            getClusters(*(map->plannerBucket()), _plannerHandle, _s0);
            map->mergeClusters();
            map->getClusterGraph();
            map->populateGlobalClusterMap();
            map->createGPUClusters();
            std::vector<cudaStream_t> streams;
            for(int x = 0; x < map->clusterIDs().size(); x++){
              cudaStream_t stream;
              streams.push_back(stream);
              cudaCheck(cudaStreamCreate(&(streams[x])));
            }
            std::vector<cudaStream_t> edgeStreams;
            for(int x = 0; x < map->clusterIDs().size(); x++){
              cudaStream_t stream;
              edgeStreams.push_back(stream);
              cudaCheck(cudaStreamCreate(&(edgeStreams[x])));
            }
            cudaDeviceSynchronize();
            for(int x = 0; x < map->clusterIDs().size(); x++){
              getClusterEdges(*(map->plannerBucket()), *(map->plannerCluster(x)), _plannerHandle, edgeStreams[x]);
            }
            for(int x = 0; x < map->clusterIDs().size(); x++){
              map->plannerCluster(x)->populateClusterPairs();
            }
            for(int x = 0; x < map->clusterIDs().size(); x++){
              //cudaStream_t _stream;
              //cudaCheck(cudaStreamCreate(&_stream));
              //cudaDeviceSynchronize();
              getClusterDistances(*(map->plannerBucket()), *(map->plannerCluster(x)), _plannerHandle, streams[x]);
              //cudaDeviceSynchronize();
              //std::cout << *(map->plannerCluster(x)->hostVertexSolution()) << std::endl;

              //getClusterSolution(*(map->plannerBucket()),*(map->plannerCluster(x)), _plannerHandle, streams[x]);
            }
            //std::cout << "1 " << std::endl;
            for(int x = 0; x < map->clusterIDs().size(); x++){
              //cudaStreamSynchronize(streams[x]);
              cudaStreamSynchronize(edgeStreams[x]);
              cudaCheck(cudaMemcpyAsync(map->plannerCluster(x)->hostVertexCount(), map->plannerCluster(x)->devVertexCount(), sizeof(int),  cudaMemcpyDeviceToHost,edgeStreams[x]));
              //cudaStreamSynchronize(streams[x]);
              cudaStreamSynchronize(edgeStreams[x]);
              *(map->plannerCluster(x)->hostScoreSize()) =(*(map->plannerCluster(x)->hostVertexCount()))*((*(map->plannerCluster(x)->hostVertexCount()))-1)/2;
              cudaCheck(cudaMemcpyAsync(map->plannerCluster(x)->devScoreSize(), map->plannerCluster(x)->hostScoreSize(), sizeof(int), cudaMemcpyHostToDevice, edgeStreams[x]));
              cudaCheck(cudaMemcpyAsync(map->plannerCluster(x)->hostVertexBuffer(), map->plannerCluster(x)->devVertexBuffer(), (*(map->plannerCluster(x)->hostVertexCount()))*sizeof(int),  cudaMemcpyDeviceToHost, edgeStreams[x]));
            }
            //std::cout << "2 " << std::endl;

            for(int x = 0; x < map->clusterIDs().size(); x++){
              map->plannerCluster(x)->allocateVertices(edgeStreams[x]);
            }
            //std::cout << "3" << std::endl;
            for(int x = 0; x < map->clusterIDs().size(); x++){
              map->plannerCluster(x)->populateIndex(edgeStreams[x]);
              //map->plannerCluster(x)->vertexDistancesFromClusters(streams[x]);
            }
            //std::cout << "4 " << std::endl;
            for(int x = 0; x < map->clusterIDs().size(); x++){
              cudaStreamSynchronize(edgeStreams[x]);
              prepGraphSolutions(*(map->plannerBucket()), *(map->plannerCluster(x)), _plannerHandle, streams[x]);
            }
            //
            //
            //std::cout << "5" << std::endl;
            // cudaStreamSynchronize(s0);
            // (*cluster.hostScoreSize()) =(*cluster.hostVertexCount())*((*cluster.hostVertexCount())-1)/2;
            // cudaCheck(cudaMemcpyAsync(cluster.devScoreSize(), cluster.hostScoreSize(), sizeof(int), cudaMemcpyHostToDevice,s0));
            // cudaStreamSynchronize(s0);
            // cluster.allocatePaths();
            // cudaStreamSynchronize(s0);
            // cluster.populateIndex(s0);
            //cudaStreamSynchronize(s0);
            //printf("ADASDASDASD\n");
                // for(int x = 0; x < map->clusterIDs().size(); x++){
                //   getVertexDistances(*(map->plannerBucket()), *(map->plannerCluster(x)), _plannerHandle, streams[x]);
                // }

            for(int x = 0 ; x < map->clusterIDs().size(); x++){
              map->plannerCluster(x)->copyNeighbours(streams[x]);
            }
            //std::cout << "6" << std::endl;
            // for(int x = 0; x < map->clusterIDs().size(); x++){
            //   map->plannerCluster(x)->vertexDistancesFromClusters(streams[x]);
            // }
            for(int x = 0 ; x < map->clusterIDs().size(); x++){
              map->plannerCluster(x)->allocateNeighbours(streams[x]);
            }
            //std::cout << "7" << std::endl;
            for(int x = 0 ; x < map->clusterIDs().size(); x++){
              map->plannerCluster(x)->populateNeighbours(streams[x]);
            }
            //std::cout << "8" << std::endl;

            for(int x = 0; x < map->clusterIDs().size(); x++){
              stepClusterGraphs(*(map->plannerBucket()), *(map->plannerCluster(x)), streams[x]);
            }
            //std::cout << "9" << std::endl;
            for(int x = 0; x < map->clusterIDs().size(); x++){
              cudaStreamSynchronize(streams[x]);
              cudaCheck(cudaMemcpyAsync(map->plannerCluster(x)->hostLevel(), map->plannerCluster(x)->devLevel(), sizeof(int), cudaMemcpyDeviceToHost,streams[x]));
              cudaStreamSynchronize(streams[x]);
              cudaCheck(cudaMemcpyAsync(map->plannerCluster(x)->hostSolutionCounts(), map->plannerCluster(x)->devSolutionCounts(), (*(map->plannerCluster(x)->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost,streams[x]));
            }
            //std::cout << "10" << std::endl;
            for(int x = 0; x < map->clusterIDs().size(); x++){
              map->plannerCluster(x)->allocateVertexPaths(streams[x]);
            }
            //std::cout << "11" << std::endl;
            for(int x =  0; x <  map->clusterIDs().size(); x++){
              //cudaDeviceSynchronize();
              //std::cout << "CLUSTER ID = " << x << std::endl;
              getClusterSolutions(*(map->plannerBucket()), *(map->plannerCluster(x)), streams[x]);
            }
            //std::cout << "12" << std::endl;
            for(int x = 0;  x < map->clusterIDs().size(); x++){
              cudaStreamSynchronize(streams[x]);
              cudaCheck(cudaMemcpyAsync(map->plannerCluster(x)->hostVertexPaths(), map->plannerCluster(x)->devVertexPaths(), *(map->plannerCluster(x)->hostScoreSize())*(*(map->plannerCluster(x)->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost,streams[x]));
            }
            //std::cout << "13" << std::endl;
            cudaDeviceSynchronize();
            clusterEnd = std::chrono::high_resolution_clock::now();
            clusterDelay = clusterEnd-clusterStart;
            std::cout << "clusterSolveTime = " << clusterDelay.count() <<std::endl;
            auto boundaryStart = std::chrono::high_resolution_clock::now();
            auto boundaryEnd = std::chrono::high_resolution_clock::now();
            std::chrono::duration<double, std::milli> boundaryDelay;
            boundaryStart = std::chrono::high_resolution_clock::now();
            map->getClusterBoundaries();
            map->getClosestVertices();
            // for(int x = 0; x < map->clusterIDs().size(); x++){
            //   map->getClosestVertices();
            // }
            map->populateFullClusters();
            //map->getBoundaryPairs();
            map->processBoundaries();
            prepBoundaryArrays(*(map->plannerBucket()), _s0);
            cudaDeviceSynchronize();
            map->populateBoundaryContainers();

            map->plannerBucket()->copyBoundaryContainers(_s0);
            cudaDeviceSynchronize();
            stepBoundaryGraph(*(map->plannerBucket()), _s0);

            //for(int x = 0; x < map->clusterIDs().size(); x++){
            cudaStreamSynchronize(_s0);
             cudaCheck(cudaMemcpyAsync(map->plannerBucket()->hostLevel(), map->plannerBucket()->devLevel(), sizeof(int), cudaMemcpyDeviceToHost, _s0));
             cudaStreamSynchronize(_s0);
             cudaCheck(cudaMemcpyAsync(map->plannerBucket()->hostSolutionCounts(), map->plannerBucket()->devSolutionCounts(), (*(map->plannerBucket()->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost, _s0));
            // //}
            // //std::cout << "10" << std::endl;
            // //for(int x = 0; x < map->clusterIDs().size(); x++){
             map->plannerBucket()->allocateBoundaryPaths(_s0);
            // //}
            //
            //std::cout << "DEVLEVEL " << *map->plannerBucket()->hostLevel() << std::endl;
             getBoundarySolutions(*(map->plannerBucket()), _s0);
             cudaStreamSynchronize(_s0);
             cudaCheck(cudaMemcpyAsync(map->plannerBucket()->hostBoundaryPaths(), map->plannerBucket()->devBoundaryPaths(), (*(map->plannerBucket()->hostBoundaryScoreSize()))*(*(map->plannerBucket()->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost,_s0));
            //
             cudaStreamSynchronize(_s0);
             map->getAllBoundaryPaths();

             boundaryEnd = std::chrono::high_resolution_clock::now();
             boundaryDelay = boundaryEnd-boundaryStart;
             std::cout << "boundarySolveTime = " << boundaryDelay.count() <<std::endl;
             map->getAverageNodePathScores();

            //map->populateEdges();
            bool timePathLookup = false;
            if(timePathLookup){
              srand (time(NULL));
              std::vector<std::pair<int,int>> internalPaths;
              std::vector<std::pair<int, int>> globalPaths;
              int internalCount = 0;
              while(internalCount < 100){
                int startIndex = rand()%(*map->plannerBucket()->hostSafeCount());
                int endIndex = rand()%(*map->plannerBucket()->hostSafeCount());
                int xIndex = map->plannerBucket()->hostSafeIndex()[startIndex];
                int yIndex = map->plannerBucket()->hostSafeIndex()[endIndex];
                int xCluster = map->_globalClusterMap[xIndex];
                int yCluster = map->_globalClusterMap[yIndex];
                if(xCluster == yCluster){
                  std::pair<int, int> indexPair = std::pair<int, int>(xIndex, yIndex);
                  internalPaths.push_back(indexPair);
                  internalCount++;
                }
              }

              int globalCount = 0;
              while(globalCount < 100){
                //for(int x = 0; x < 100; x++){
                int startIndex = rand()%(*map->plannerBucket()->hostSafeCount());
                int endIndex = rand()%(*map->plannerBucket()->hostSafeCount());
                int xIndex = map->plannerBucket()->hostSafeIndex()[startIndex];
                int yIndex = map->plannerBucket()->hostSafeIndex()[endIndex];
                int xCluster = map->_globalClusterMap[xIndex];
                int yCluster = map->_globalClusterMap[yIndex];
                if(xCluster != yCluster){
                  std::pair<int, int> indexPair = std::pair<int, int>(xIndex, yIndex);
                  globalPaths.push_back(indexPair);
                  globalCount++;
                }
              }

              auto internalStart = std::chrono::high_resolution_clock::now();
              auto internalEnd = std::chrono::high_resolution_clock::now();
              std::chrono::duration<double, std::milli> internalDelay;
              internalStart = std::chrono::high_resolution_clock::now();
              for(int x = 0; x < 100; x++){
                //int startIndex = rand()%(*map->plannerBucket()->hostSafeCount());
                //int endIndex = rand()%(*map->plannerBucket()->hostSafeCount());
                int xIndex = internalPaths[x].first;
                int yIndex = internalPaths[x].second;
                std::vector<int> boundaryPathVec = map->getShortestPathAsIndex(xIndex, yIndex);
              }
              internalEnd = std::chrono::high_resolution_clock::now();
              internalDelay = internalEnd-internalStart;
              std::cout << "average time to get path between two internal nodes = "<< internalDelay.count()/100 << std::endl;
              //5912 x / 424 y
              //998 x / 4882 y
              //6203 x / 9924 y
              //3865 x / 9526 y
              //6251 x / 10740 y
              // globalPaths.push_back(std::pair<int, int>(5912, 424));
              // globalPaths.push_back(std::pair<int, int>(998, 4882));
              // globalPaths.push_back(std::pair<int, int>(6203, 9924));
              // globalPaths.push_back(std::pair<int, int>(3865, 9526));
              // globalPaths.push_back(std::pair<int, int>(6251, 10740));
              auto globalStart = std::chrono::high_resolution_clock::now();
              auto globalEnd = std::chrono::high_resolution_clock::now();
              std::chrono::duration<double, std::milli> globalDelay;
              globalStart = std::chrono::high_resolution_clock::now();
              for(int x = 0; x < globalPaths.size(); x++){
                //std::cout << "global x " << x << std::endl;
                //int startIndex = rand()%(*map->plannerBucket()->hostSafeCount());
                //int endIndex = rand()%(*map->plannerBucket()->hostSafeCount());
                int xIndex = globalPaths[x].first;
                int yIndex = globalPaths[x].second;
                //std::cout << "xIndex = " << xIndex << std::endl;
                //std::cout << "yIndex = " << yIndex << std::endl;
                std::vector<int> boundaryPathVec = map->getShortestPathAsIndex(xIndex, yIndex);
              }
              globalEnd = std::chrono::high_resolution_clock::now();
              globalDelay = globalEnd-globalStart;
              std::cout << "average time to get path between two global nodes = "<< globalDelay.count()/100 << std::endl;
            }

            bool renderClusterParents = true;
            bool renderBoundaryPoints = false;
            //bool printPaths = true;
            bool printPaths = false;
            bool printBoundaryPath = false;
            bool printGlobalPath = false;



            if(printBoundaryPath){
              openvdb::GridPtrVec bpGrids;
              openvdb::FloatGrid::Ptr boundaryPoints;
              boundaryPoints = openvdb::FloatGrid::create(0.0);
              auto bpacc = boundaryPoints->getAccessor();
              boundaryPoints->setGridClass(openvdb::GRID_LEVEL_SET);
              boundaryPoints->setName("boundarypoints");
              boundaryPoints->setTransform(openvdb::math::Transform::createLinearTransform(0.8));

              int x = 1;
              int y = 20;
              int xIndex = map->_boundaryToGlobalMap[x].second;
              int yIndex = map->_boundaryToGlobalMap[y].second;
              bpacc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[xIndex][0],
                                                map->plannerBucket()->hostGridIndex()[xIndex][1],
                                                map->plannerBucket()->hostGridIndex()[xIndex][2]));
              bpacc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[yIndex][0],
                                                map->plannerBucket()->hostGridIndex()[yIndex][1],
                                                map->plannerBucket()->hostGridIndex()[yIndex][2]));

              bpGrids.push_back(boundaryPoints);
              openvdb::FloatGrid::Ptr boundaryPath;
              boundaryPath = openvdb::FloatGrid::create(0.0);
              auto bpathacc = boundaryPath->getAccessor();
              boundaryPath->setGridClass(openvdb::GRID_LEVEL_SET);
              boundaryPath->setName("boundarypoints");
              boundaryPath->setTransform(openvdb::math::Transform::createLinearTransform(0.8));
              std::pair<int, int> pair = std::pair<int, int>(x,y);
              std::vector<int> boundaryPathVec = map->_boundaryPaths[pair].second;
              for(int x = 0; x < boundaryPathVec.size(); x++){
                  //for(int y = 0; y < map->clusterBoundaryPoints()[x].size(); y++){
                  int index = boundaryPathVec[x];
                  //if(clusterIndex >= 0 && clusterIndex < *(map->plannerBucket()->hostValidCount())){
                  //std::cout << clusterIndex << std::endl;
                  // acc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[clusterIndex][0],
                  //                                   map->plannerBucket()->hostGridIndex()[clusterIndex][1],
                  //                                   map->plannerBucket()->hostGridIndex()[clusterIndex][2]));
                  bpathacc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[index][0],
                                                    map->plannerBucket()->hostGridIndex()[index][1],
                                                    map->plannerBucket()->hostGridIndex()[index][2]));
                  //}
                }
                bpGrids.push_back(boundaryPath);
                openvdb::io::File savefile("boundaryPathGrid.vdb");
                savefile.write(bpGrids);
                savefile.close();
            }

            if(printGlobalPath){
              openvdb::GridPtrVec bpGrids;
              openvdb::FloatGrid::Ptr boundaryPoints;
              boundaryPoints = openvdb::FloatGrid::create(0.0);
              auto bpacc = boundaryPoints->getAccessor();
              boundaryPoints->setGridClass(openvdb::GRID_LEVEL_SET);
              boundaryPoints->setName("boundarypoints");
              boundaryPoints->setTransform(openvdb::math::Transform::createLinearTransform(0.8));
              srand (time(NULL));
              int startIndex = rand()%(*map->plannerBucket()->hostSafeCount());
              int endIndex = rand()%(*map->plannerBucket()->hostSafeCount());
              std::cout << startIndex << std::endl;
              std::cout << endIndex << std::endl;
              int xIndex = map->plannerBucket()->hostSafeIndex()[startIndex];
              int yIndex = map->plannerBucket()->hostSafeIndex()[endIndex];
              bpacc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[xIndex][0],
                                                map->plannerBucket()->hostGridIndex()[xIndex][1],
                                                map->plannerBucket()->hostGridIndex()[xIndex][2]));
              bpacc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[yIndex][0],
                                                map->plannerBucket()->hostGridIndex()[yIndex][1],
                                                map->plannerBucket()->hostGridIndex()[yIndex][2]));

              bpGrids.push_back(boundaryPoints);
              openvdb::FloatGrid::Ptr boundaryPath;
              boundaryPath = openvdb::FloatGrid::create(0.0);
              auto bpathacc = boundaryPath->getAccessor();
              boundaryPath->setGridClass(openvdb::GRID_LEVEL_SET);
              boundaryPath->setName("boundarypoints");
              boundaryPath->setTransform(openvdb::math::Transform::createLinearTransform(0.8));
              //std::pair<int, int> pair = std::pair<int, int>(x,y);
              std::vector<int> boundaryPathVec = map->getShortestPathAsIndex(xIndex, yIndex);
              for(int x = 0; x < boundaryPathVec.size(); x++){
                  //for(int y = 0; y < map->clusterBoundaryPoints()[x].size(); y++){
                  int index = boundaryPathVec[x];
                  //if(clusterIndex >= 0 && clusterIndex < *(map->plannerBucket()->hostValidCount())){
                  //std::cout << clusterIndex << std::endl;
                  // acc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[clusterIndex][0],
                  //                                   map->plannerBucket()->hostGridIndex()[clusterIndex][1],
                  //                                   map->plannerBucket()->hostGridIndex()[clusterIndex][2]));
                  bpathacc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[index][0],
                                                    map->plannerBucket()->hostGridIndex()[index][1],
                                                    map->plannerBucket()->hostGridIndex()[index][2]));
                  //}
                }
                bpGrids.push_back(boundaryPath);



                openvdb::FloatGrid::Ptr safeFull;
                safeFull = openvdb::FloatGrid::create(0.0);
                auto sacc = safeFull->getAccessor();
                safeFull->setGridClass(openvdb::GRID_LEVEL_SET);
                safeFull->setName("safefull");
                safeFull->setTransform(openvdb::math::Transform::createLinearTransform(0.8));

                for(int x = 0; x < *(map->plannerBucket()->hostSafeCount()); x++){

                  int safeIndex = map->plannerBucket()->hostSafeIndex()[x];
                  //if(clusterIndex >= 0 && clusterIndex < *(map->plannerBucket()->hostValidCount())){
                  //std::cout << clusterIndex << std::endl;
                  // acc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[clusterIndex][0],
                  //                                   map->plannerBucket()->hostGridIndex()[clusterIndex][1],
                  //                                   map->plannerBucket()->hostGridIndex()[clusterIndex][2]));
                  sacc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[safeIndex][0],
                                                    map->plannerBucket()->hostGridIndex()[safeIndex][1],
                                                    map->plannerBucket()->hostGridIndex()[safeIndex][2]));
                  }

                bpGrids.push_back(safeFull);

                openvdb::io::File savefile("boundaryPathGrid.vdb");
                savefile.write(bpGrids);
                savefile.close();
            }

            if(renderBoundaryPoints){
              openvdb::GridPtrVec bGrids;
              openvdb::FloatGrid::Ptr boundaryFull;
              boundaryFull = openvdb::FloatGrid::create(0.0);
              auto bfacc = boundaryFull->getAccessor();
              boundaryFull->setGridClass(openvdb::GRID_LEVEL_SET);
              boundaryFull->setName("boundaryfull");
              boundaryFull->setTransform(openvdb::math::Transform::createLinearTransform(0.8));

              for(int x = 0; x < map->clusterIDs().size(); x++){
                  for(int y = 0; y < map->clusterBoundaryPoints()[x].size(); y++){
                  int index = map->clusterBoundaryPoints()[x][y];
                  //if(clusterIndex >= 0 && clusterIndex < *(map->plannerBucket()->hostValidCount())){
                  //std::cout << clusterIndex << std::endl;
                  // acc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[clusterIndex][0],
                  //                                   map->plannerBucket()->hostGridIndex()[clusterIndex][1],
                  //                                   map->plannerBucket()->hostGridIndex()[clusterIndex][2]));
                  bfacc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[index][0],
                                                    map->plannerBucket()->hostGridIndex()[index][1],
                                                    map->plannerBucket()->hostGridIndex()[index][2]));
                  }
                }
                bGrids.push_back(boundaryFull);
                openvdb::io::File savefile("boundaryGrid.vdb");
                savefile.write(bGrids);
                savefile.close();
            }

            if(renderClusterParents){
              int clustCount = 0;
              openvdb::GridPtrVec Grids;
              //openvdb::FloatGrid::Ptr safeFull;
              //safeFull = openvdb::FloatGrid::create(0.0);
              //auto sacc = safeFull->getAccessor();
              //safeFull->setGridClass(openvdb::GRID_LEVEL_SET);
              //safeFull->setName("safefull");
              //safeFull->setTransform(openvdb::math::Transform::createLinearTransform(0.8));

              // for(int x = 0; x < *(map->plannerBucket()->hostSafeCount()); x++){
              //
              //   int safeIndex = map->plannerBucket()->hostSafeIndex()[x];
              //   //if(clusterIndex >= 0 && clusterIndex < *(map->plannerBucket()->hostValidCount())){
              //   //std::cout << clusterIndex << std::endl;
              //   // acc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[clusterIndex][0],
              //   //                                   map->plannerBucket()->hostGridIndex()[clusterIndex][1],
              //   //                                   map->plannerBucket()->hostGridIndex()[clusterIndex][2]));
              //   sacc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[safeIndex][0],
              //                                     map->plannerBucket()->hostGridIndex()[safeIndex][1],
              //                                     map->plannerBucket()->hostGridIndex()[safeIndex][2]));
              //   }





              for(int x = 0; x < map->clusterIDs().size(); x++){
                openvdb::FloatGrid::Ptr clusterFull;
                clusterFull = openvdb::FloatGrid::create(0.0);
                auto acc = clusterFull->getAccessor();
                clusterFull->setGridClass(openvdb::GRID_LEVEL_SET);
                clusterFull->setName("cluster " + std::to_string(x));
                clusterFull->setTransform(openvdb::math::Transform::createLinearTransform(0.8));

              //   if(c++>0){
              //std::cout <<  *(map->plannerBucket()->hostSafeCount()) << std::endl;
              // for(int x = 0; x < map->clusterIDs().size(); x++){
              //
              //   int clusterIndex = (map->clusterIDs())[x];
              //   //if(clusterIndex >= 0 && clusterIndex < *(map->plannerBucket()->hostValidCount())){
              //   //std::cout << "x = "<< x <<" cIndex = " << clusterIndex << std::endl;
              //   // acc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[clusterIndex][0],
              //   //                                   map->plannerBucket()->hostGridIndex()[clusterIndex][1],
              //   //                                   map->plannerBucket()->hostGridIndex()[clusterIndex][2]));
              //   if(clusterIndex >= 0 && clusterIndex < *(map->plannerBucket()->hostValidCount())){
              //     acc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[clusterIndex][0],
              //                                     map->plannerBucket()->hostGridIndex()[clusterIndex][1],
              //                                     map->plannerBucket()->hostGridIndex()[clusterIndex][2]));
              //   }
              // }

                for(int y = 0; y < map->_clustersFull[x].size(); y++){
                    int clusterIndex = map->_clustersFull[x][y];
                      acc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[clusterIndex][0],
                                                      map->plannerBucket()->hostGridIndex()[clusterIndex][1],
                                                      map->plannerBucket()->hostGridIndex()[clusterIndex][2]));
                }
                Grids.push_back(clusterFull);
              }
              //Grids.push_back(safeFull);
              //Grids.push_back(clusterFull);
              //int count = 0;
              // for(int x = 0; x < map->clusterIDs().size(); x++){
              //   //std::cout << "clusterActiveMask = %d" << (int)map->plannerBucket()->hostClusterActiveMask()[x] << std::endl;
              //   //if(map->plannerBucket()->hostClusterActiveMask()[x]==1){
              //   if(map->clusterIDs()[x]!=-1){
              //     openvdb::FloatGrid::Ptr clusterGrid;
              //     clusterGrid = openvdb::FloatGrid::create(0.0);
              //     auto cacc = clusterGrid->getAccessor();
              //           // Identify the grids as level set
              //     clusterGrid->setGridClass(openvdb::GRID_LEVEL_SET);
              //     clusterGrid->setName(std::to_string(x)+"clusterNodes");
              //     int clusterID = (map->clusterIDs())[x];
              //     //std::cout<< "clust" << std::endl;
              //     //std::cout <<"clusterID " << x << " = " << (map->clusterIDs())[x] << std::endl;
              //     int count = 0;
              //     for(int i = 0; i<*(map->plannerBucket()->hostSafeCount()); i++){
              //       //std::cout << i << std::endl;
              //       //if((map->plannerBucket()->hostClusterIndex()[x]==1)){
              //         //std::cout << map->plannerBucket()->hostClusterCentroids()[x] << std::endl;
              //         int index = (map->plannerBucket()->hostClusterParents())[map->plannerBucket()->hostSafeIndex()[i]];
              //         if(index == clusterID){
              //           count++;
              //           int globalIndex = map->plannerBucket()->hostSafeIndex()[i];
              //           cacc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[globalIndex][0],
              //                                         map->plannerBucket()->hostGridIndex()[globalIndex][1],
              //                                         map->plannerBucket()->hostGridIndex()[globalIndex][2]));
              //         }
              //       }
              //     clusterGrid->setTransform(openvdb::math::Transform::createLinearTransform(0.8));
              //     Grids.push_back(clusterGrid);
              //
              //
              //     openvdb::FloatGrid::Ptr clusterEdgeCombos;
              //     clusterEdgeCombos = openvdb::FloatGrid::create(0.0);
              //     auto cecacc = clusterEdgeCombos->getAccessor();
              //           // Identify the grids as level set
              //     clusterEdgeCombos->setGridClass(openvdb::GRID_LEVEL_SET);
              //     clusterEdgeCombos->setName(std::to_string(x)+"clusterEdgeCombos");
              //     //int clusterID = (map->clusterIDs())[x];
              //     //std::cout<< "clust" << std::endl;
              //     //std::cout <<"clusterID " << x << " = " << (map->clusterIDs())[x] << std::endl;
              //     //int count = 0;
              //     //std::cout << "clusterEdgeCombos"
              //     //std::cout << map->clusterEdgeCombos()[x].size() << std::endl;
              //     for(int i = 0; i<(map->clusterEdgeCombos()[x].size()); i++){
              //       //std::cout << i << std::endl;
              //       //if((map->plannerBucket()->hostClusterIndex()[x]==1)){
              //         //std::cout << map->plannerBucket()->hostClusterCentroids()[x] << std::endl;
              //         //int index = (map->plannerBucket()->hostClusterParents())[map->plannerBucket()->hostSafeIndex()[i]];
              //         //if(index == clusterID){
              //         //  count++;
              //           int globalIndex = map->clusterEdgeCombos()[x][i];
              //           cecacc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[globalIndex][0],
              //                                         map->plannerBucket()->hostGridIndex()[globalIndex][1],
              //                                         map->plannerBucket()->hostGridIndex()[globalIndex][2]));
              //         //}
              //       }
              //     clusterEdgeCombos->setTransform(openvdb::math::Transform::createLinearTransform(0.8));
              //     Grids.push_back(clusterEdgeCombos);
              //
              //
              //     openvdb::FloatGrid::Ptr boundaryPointGrid;
              //     boundaryPointGrid = openvdb::FloatGrid::create(0.0);
              //     auto bpacc = boundaryPointGrid->getAccessor();                                              // Identify the grids as level set
              //     boundaryPointGrid->setGridClass(openvdb::GRID_LEVEL_SET);
              //     for(int i = 0; i < map->clusterBoundaryPoints()[x].size(); i++){
              //       bpacc.setValueOn(openvdb::Coord(map->plannerBucket()->hostGridIndex()[map->clusterBoundaryPoints()[x][i]][0],
              //                                       map->plannerBucket()->hostGridIndex()[map->clusterBoundaryPoints()[x][i]][1],
              //                                       map->plannerBucket()->hostGridIndex()[map->clusterBoundaryPoints()[x][i]][2]));
              //     }
              //     boundaryPointGrid->setName(std::to_string(x)+"boundaryPoints");
              //     boundaryPointGrid->setTransform(openvdb::math::Transform::createLinearTransform(0.8));
              //     Grids.push_back(boundaryPointGrid);
              //     count++;
              //   }
              // }

                // Write out the contents of the container.

              openvdb::io::File savefile("clusterGrid.vdb");
              savefile.write(Grids);
              savefile.close();
            }
            if(printPaths){
              for(int x = 0; x < map->clusterIDs().size(); x++){
                std::cout << "CLUSTER " << x << " PATHS:" << std::endl;
                for(int solutionIndex = 0; solutionIndex < *(map->plannerCluster(x)->hostScoreSize()); solutionIndex++){
                  int startNode = map->plannerCluster(x)->hostIndexPairs()[solutionIndex];
                  int endNode = map->plannerCluster(x)->hostIndexPairs()[solutionIndex+*(map->plannerCluster(x)->hostScoreSize())];
                  //if(map->plannerBucket()->hostVertexPaths()[solutionIndex*map->plannerBucket()->solutionLevel()] == -1){
                    std::cout << "Path from " << map->plannerCluster(x)->hostVertexBuffer()[startNode] << " to " << map->plannerCluster(x)->hostVertexBuffer()[endNode] << ": " << map->plannerCluster(x)->hostVertexBuffer()[startNode];
                  //}
                                    //<< "(" <<((map->plannerBucket()->hostGridIndex())[((map->plannerBucket()->hostVertexBuffer())[startNode])])[0]
                                    //<< "," <<((map->plannerBucket()->hostGridIndex())[((map->plannerBucket()->hostVertexBuffer())[startNode])])[1]
                                    //<< "," <<((map->plannerBucket()->hostGridIndex())[((map->plannerBucket()->hostVertexBuffer())[startNode])])[2] << ")";
                  int stepIndex = 0;
                  // //std::cout << *(map->plannerBucket()->hostVertexPaths()+solutionIndex*(map->plannerBucket()->solutionLevel())+stepIndex);
                   while((map->plannerCluster(x)->hostVertexPaths())[solutionIndex*(*(map->plannerCluster(x)->hostLevel()))+stepIndex]!=-1 &&
                          (map->plannerCluster(x)->hostVertexPaths())[solutionIndex*(*(map->plannerCluster(x)->hostLevel()))+stepIndex]!= endNode ){
                       std::cout << "->" <<
                       map->plannerCluster(x)->hostVertexBuffer()[
                                  (map->plannerCluster(x)->hostVertexPaths())[solutionIndex*(*(map->plannerCluster(x)->hostLevel()))+stepIndex]];
                  //                   //<< "(" << (map->plannerBucket()->hostGridIndex()[map->plannerBucket()->hostVertexBuffer()[(map->plannerBucket()->hostVertexPaths())[solutionIndex*(map->plannerBucket()->solutionLevel())+stepIndex]]])[0]
                  //                   //<< "," << (map->plannerBucket()->hostGridIndex()[map->plannerBucket()->hostVertexBuffer()[(map->plannerBucket()->hostVertexPaths())[solutionIndex*(map->plannerBucket()->solutionLevel())+stepIndex]]])[1]
                  //                   //<< "," << (map->plannerBucket()->hostGridIndex()[map->plannerBucket()->hostVertexBuffer()[(map->plannerBucket()->hostVertexPaths())[solutionIndex*(map->plannerBucket()->solutionLevel())+stepIndex]]])[2] << ")";
                       stepIndex++;
                   }
                   if(stepIndex == 0 && (map->plannerCluster(x)->hostVertexPaths())[solutionIndex*(*(map->plannerCluster(x)->hostLevel()))+stepIndex]==-1){
                     std::cout << "ERROR" << std::endl;
                   }else{
                     std::cout << "->" << map->plannerCluster(x)->hostVertexBuffer()[endNode] << std::endl;
                  }// //<< "(" <<((map->plannerBucket()->hostGridIndex())[((map->plannerBucket()->hostVertexBuffer())[endNode])])[0]
                  //<< "," <<((map->plannerBucket()->hostGridIndex())[((map->plannerBucket()->hostVertexBuffer())[endNode])])[1]
                  //<< "," <<((map->plannerBucket()->hostGridIndex())[((map->plannerBucket()->hostVertexBuffer())[endNode])])[2] << ")" << std::endl;;
                }
              }
          }
        }

        void PlannerHandler::closeHandler(){
          //_sensorBucket.freeMemory();
          //_agentMap->freeBucketMemory();
          cudaCheck(cudaStreamDestroy(_s0));
          //cudaCheck(cudaStreamDestroy(_s1));
          }


          void PlannerHandler::printUpdateTime(int count){
            std::cout << "gpu update time per loop:" << _gpuTime / count << std::endl;
            std::cout << "map update time per loop:" << _mapUpdateTime / count << std::endl;

          }
  }
}
