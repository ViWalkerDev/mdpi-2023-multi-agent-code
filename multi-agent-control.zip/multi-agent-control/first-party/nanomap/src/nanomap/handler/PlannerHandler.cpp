#include "nanomap/handler/PlannerHandler.h"
// The following functions are called by the host and launch the gpu kernels.
namespace nanomap{
  namespace handler{
        PlannerHandler::PlannerHandler(std::shared_ptr<nanomap::planner::GPUInfo> plannerConfig)
        :_plannerAllocator(std::make_shared<nanomap::allocator::PlannerAllocator>(plannerConfig))
        {
          _solveTime = 0.0;
          //_mapUpdateTime = 0.0;
          cudaCheck(cudaStreamCreate(&_s0));
        }    

        void PlannerHandler::allocateValidAndSafe(int validCount, int safeCount){
            _plannerAllocator->allocateValidAndSafe(validCount, safeCount);
        }
        void PlannerHandler::uploadPlannerGrid(openvdb::Int32Grid::Ptr grid){
            _plannerHandle = nanovdb::openToNanoVDB<nanovdb::CudaDeviceBuffer>(*(grid));
            _plannerHandle.deviceUpload();
        }

        void PlannerHandler::createGPUClusters(std::vector<int>& clusterIDs, std::vector<std::vector<int>>& clustersSafe){
          _plannerAllocator->createGPUClusters();
        }
        void PlannerHandler::extractClusters(){
          getClusters(*(_plannerAllocator->plannerBucket()), _plannerHandle, _s0);
        }

        void PlannerHandler::refineClusters(){
          mendClusters(*(_plannerAllocator->plannerBucket()), _plannerHandle, _s0);
        }
        

        void PlannerHandler::setAllocatorClusterInfo(std::vector<int> clusterIDs, std::vector<std::vector<int>> clustersSafe){
            _plannerAllocator->setClusterIDs(clusterIDs);
            _plannerAllocator->setClustersSafe(clustersSafe);
        }

        void PlannerHandler::solveClusters(){
            //FOR EACH CLUSTER, WE CREATE A CUDA STREAM
            std::vector<cudaStream_t> streams;
            //std::cout << _plannerAllocator->clusterIDs().size() << std::endl;
            for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
                cudaStream_t stream;
                streams.push_back(stream);
                cudaCheck(cudaStreamCreate(&(streams[x])));
            }
            //DEBUG SYNC
            //                cudaDeviceSynchronize();
            
            //std::cout << " 1 " << std::endl;
            // AND ALSO CREATE EDGE EXTRACTION STREAMS
            std::vector<cudaStream_t> edgeStreams;
            for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
                cudaStream_t stream;
                edgeStreams.push_back(stream);
                cudaCheck(cudaStreamCreate(&(edgeStreams[x])));
            }
            //DEBUG SYNC
            //                cudaDeviceSynchronize();
            //std::cout << " 2 " << std::endl;
            //Then we extract the edges of each cluster
            for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
                //cudaDeviceSynchronize();
                //std::cout << "get cluster edges for cluster x = " << x << std::endl;
                getClusterEdges(*(_plannerAllocator->plannerBucket()), *(_plannerAllocator->plannerCluster(x)), _plannerHandle, edgeStreams[x]);
            }
            //DEBUG SYNC
            //                cudaDeviceSynchronize();
            
            //std::cout << " 3 " << std::endl;
            // While also populating clusters pairs, to begin solving
            for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
                //std::cout << "populating cluster pairs for cluster " << x << std::endl;
                _plannerAllocator->plannerCluster(x)->populateClusterPairs(streams[x]);
            }
            //DEBUG SYNC
            //                cudaDeviceSynchronize();
            
            //std::cout << " 4 " << std::endl;
            //Once we have populated cluster pairs for each cluster, we can get the distances between each cluster node
            for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
                getClusterDistances(*(_plannerAllocator->plannerBucket()), *(_plannerAllocator->plannerCluster(x)), _plannerHandle, streams[x]);
            }
            //DEBUG SYNC
            //                cudaDeviceSynchronize();
            
            //std::cout << " 5 " << std::endl;
            //We can also continue the edge extraction, syncing the streams, and copying the necessary info to the host buffers
            for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
                cudaStreamSynchronize(edgeStreams[x]);
                cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerCluster(x)->hostVertexCount(), _plannerAllocator->plannerCluster(x)->devVertexCount(), sizeof(int),  cudaMemcpyDeviceToHost,edgeStreams[x]));
                cudaStreamSynchronize(edgeStreams[x]);
                *(_plannerAllocator->plannerCluster(x)->hostScoreSize()) =(*(_plannerAllocator->plannerCluster(x)->hostVertexCount()))*((*(_plannerAllocator->plannerCluster(x)->hostVertexCount()))-1)/2;
                cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerCluster(x)->devScoreSize(), _plannerAllocator->plannerCluster(x)->hostScoreSize(), sizeof(int), cudaMemcpyHostToDevice, edgeStreams[x]));
                cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerCluster(x)->hostVertexBuffer(), _plannerAllocator->plannerCluster(x)->devVertexBuffer(), (*(_plannerAllocator->plannerCluster(x)->hostVertexCount()))*sizeof(int),  cudaMemcpyDeviceToHost, edgeStreams[x]));
            }
            //std::cout << " 6 " << std::endl;
            //Then, with the edge streams synced and copied.
            //We allocate containers to for the vertex based operations
            for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
                _plannerAllocator->plannerCluster(x)->allocateVertices(edgeStreams[x]);
            }
            //std::cout << " 7 " << std::endl;
            //Then we populate the necessary index objects
            for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
                _plannerAllocator->plannerCluster(x)->populateIndex(edgeStreams[x]);
            }
            //std::cout << " 8 " << std::endl;
            //Finally we sync the edge streams, and prep the clusters for graph solutions
            for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
                cudaStreamSynchronize(edgeStreams[x]);
                prepGraphSolutions(*(_plannerAllocator->plannerBucket()), *(_plannerAllocator->plannerCluster(x)), _plannerHandle, streams[x]);
            }
            //std::cout << " 9 " << std::endl;
            for(int x = 0 ; x < _plannerAllocator->clusterIDs().size(); x++){
                _plannerAllocator->plannerCluster(x)->copyNeighbours(streams[x]);
            }
            //std::cout << " 10 " << std::endl;
            for(int x = 0 ; x < _plannerAllocator->clusterIDs().size(); x++){
                _plannerAllocator->plannerCluster(x)->allocateNeighbours(streams[x]);
            }
            //std::cout << " 11" << std::endl;
            for(int x = 0 ; x < _plannerAllocator->clusterIDs().size(); x++){
                _plannerAllocator->plannerCluster(x)->populateNeighbours(streams[x]);
            }
            //std::cout << " 12 " << std::endl;
            //Finally we 'step the clusters' this is the term used for the graph solving algorithm developed, solving each vertex graph for each cluster. 
            for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
                if(_plannerAllocator->plannerCluster(x)->vertexAllocation()>1){
                    stepClusterGraphs(*(_plannerAllocator->plannerBucket()), *(_plannerAllocator->plannerCluster(x)), streams[x]);
                }
            }
            //std::cout << " 13 " << std::endl;
            //We sync the streams, and copy the necessary information to the host
            for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
                cudaStreamSynchronize(streams[x]);
                cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerCluster(x)->hostLevel(), _plannerAllocator->plannerCluster(x)->devLevel(), sizeof(int), cudaMemcpyDeviceToHost,streams[x]));
                cudaStreamSynchronize(streams[x]);
                cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerCluster(x)->hostSolutionCounts(), _plannerAllocator->plannerCluster(x)->devSolutionCounts(), (*(_plannerAllocator->plannerCluster(x)->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost,streams[x]));
            }
            //Using this informaiton we can allocate the objects necessary to store the paths between the vertices of each cluster
            //std::cout << " 14 " << std::endl;
            for(int x = 0; x < _plannerAllocator->clusterIDs().size(); x++){
                _plannerAllocator->plannerCluster(x)->allocateVertexPaths(streams[x]);
            }
            //And then extract these paths from the existing device side data structures we populated during the stepClusterGraphs() stage
            //std::cout << " 15 " << std::endl;
            for(int x =  0; x <  _plannerAllocator->clusterIDs().size(); x++){
                if(_plannerAllocator->plannerCluster(x)->vertexAllocation()>1){
                    getClusterSolutions(*(_plannerAllocator->plannerBucket()), *(_plannerAllocator->plannerCluster(x)), streams[x]);
                }
            }
            //These paths are then copied to host data structures where they can be used!
            //std::cout << " 16 " << std::endl;
            for(int x = 0;  x < _plannerAllocator->clusterIDs().size(); x++){
                cudaStreamSynchronize(streams[x]);
                if(_plannerAllocator->plannerCluster(x)->vertexAllocation()>1){
                    cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerCluster(x)->hostVertexPaths(), _plannerAllocator->plannerCluster(x)->devVertexPaths(), *(_plannerAllocator->plannerCluster(x)->hostScoreSize())*(*(_plannerAllocator->plannerCluster(x)->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost,streams[x]));
                }
                // }else{
                //     _plannerAllocator->plannerCluster(x)->setPathsForSingleVertex();
                // }
            }
        }


        void PlannerHandler::prepareBoundaryArrays(){
          prepBoundaryArrays(*(_plannerAllocator->plannerBucket()), _s0);
        }

        void PlannerHandler::copyBoundaryContainers(){
            _plannerAllocator->plannerBucket()->copyBoundaryContainers(_s0);
        }

        void PlannerHandler::increaseLevelDepth(){
            _plannerAllocator->plannerBucket()->increaseLevelDepth(_s0);
        }

        void PlannerHandler::startBoundarySolve(){
          stepBoundaryGraph(*(_plannerAllocator->plannerBucket()), _s0);
          cudaStreamSynchronize(_s0);
          cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerBucket()->hostLevel(), _plannerAllocator->plannerBucket()->devLevel(), sizeof(int), cudaMemcpyDeviceToHost, _s0));
          cudaStreamSynchronize(_s0);
          printf("hostLevelduring solve = %d \n", *(_plannerAllocator->plannerBucket()->hostLevel()));
        }
        
        bool PlannerHandler::depthLevelSufficient(){
            if((*(_plannerAllocator->plannerBucket()->hostLevel()))>=_plannerAllocator->plannerBucket()->levelDepth()-1){
                return false;
            }else{
                return true;
            }
        }

        void PlannerHandler::finishBoundarySolve(){
          cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerBucket()->hostSolutionCounts(), _plannerAllocator->plannerBucket()->devSolutionCounts(), (*(_plannerAllocator->plannerBucket()->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost, _s0));
          _plannerAllocator->plannerBucket()->allocateBoundaryPaths(_s0);
          getBoundarySolutions(*(_plannerAllocator->plannerBucket()),_s0);
          cudaStreamSynchronize(_s0);
          cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerBucket()->hostBoundaryPaths(), _plannerAllocator->plannerBucket()->devBoundaryPaths(), (*(_plannerAllocator->plannerBucket()->hostBoundaryScoreSize()))*(*(_plannerAllocator->plannerBucket()->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost,_s0));
          cudaStreamSynchronize(_s0);
        }


        void PlannerHandler::solveBoundaryGraph(){
          stepBoundaryGraph(*(_plannerAllocator->plannerBucket()), _s0);
          cudaStreamSynchronize(_s0);
          cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerBucket()->hostLevel(), _plannerAllocator->plannerBucket()->devLevel(), sizeof(int), cudaMemcpyDeviceToHost, _s0));
          cudaStreamSynchronize(_s0);
          printf("hostLevelduring solve = %d \n", *(_plannerAllocator->plannerBucket()->hostLevel()));
          cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerBucket()->hostSolutionCounts(), _plannerAllocator->plannerBucket()->devSolutionCounts(), (*(_plannerAllocator->plannerBucket()->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost, _s0));
          _plannerAllocator->plannerBucket()->allocateBoundaryPaths(_s0);
          getBoundarySolutions(*(_plannerAllocator->plannerBucket()),_s0);
          cudaStreamSynchronize(_s0);
          cudaCheck(cudaMemcpyAsync(_plannerAllocator->plannerBucket()->hostBoundaryPaths(), _plannerAllocator->plannerBucket()->devBoundaryPaths(), (*(_plannerAllocator->plannerBucket()->hostBoundaryScoreSize()))*(*(_plannerAllocator->plannerBucket()->hostLevel()))*sizeof(int), cudaMemcpyDeviceToHost,_s0));
          cudaStreamSynchronize(_s0);
        }

        void PlannerHandler::freeBucketMemory(){
          _plannerAllocator->plannerBucket()->freeMemory();
        }
        


        void PlannerHandler::closeHandler(){
          cudaCheck(cudaStreamDestroy(_s0));
        }


          void PlannerHandler::printUpdateTime(int count){
            std::cout << "gpu update time per loop:" << _solveTime / count << std::endl;
            //std::cout << "map update time per loop:" << _mapUpdateTime / count << std::endl;

          }
  }
}
