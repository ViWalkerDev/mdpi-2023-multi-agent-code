// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file SimSimHandler.cpp
///
/// @author Violet Walker
///


//THE MOST BASIC HANDLER CLASS. TAKES A SENSOR, RAY CASTS THE CLOUD.
//OCCUPANCY MAP EXTRACTED AT THE MANAGER LEVEL
#include "nanomap/handler/SimHandler.h"

namespace nanomap{
    namespace handler{

        // SimHandler::SimHandler(){
        //     _gpuTime = 0.0;
        //     cudaCheck(cudaStreamCreate(&_s0));
        //     cudaCheck(cudaStreamCreate(&_s1));
        // }

        SimHandler::SimHandler(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo, std::shared_ptr<nanomap::config::GPUInfo> config, openvdb::FloatGrid::Ptr simGrid)
        :Handler(sensorInfo, config){
          //_gpuTime = 0.0;
          //cudaCheck(cudaStreamCreate(&_s0));
          //cudaCheck(cudaStreamCreate(&_s1));
          _simGridHandle = nanovdb::openToNanoVDB<nanovdb::CudaDeviceBuffer>(*(simGrid));
          _simGridHandle.deviceUpload();
        }

        void SimHandler::processSimGridUpdate(openvdb::FloatGrid::Ptr simGrid){
          _simGridHandle = nanovdb::openToNanoVDB<nanovdb::CudaDeviceBuffer>(*(simGrid));
          _simGridHandle.deviceUpload();
        }

        void SimHandler::generateCloudFromSensor(std::shared_ptr<nanomap::sensor::Sensor> sensor, int publishSensor){
          _sensorAllocator.update(sensor->sensorData(), _s0);
          generateCloud(*(_sensorAllocator.sensorBucket()), _simGridHandle, _s0);
          cudaDeviceSynchronize();
          //auto start = std::chrono::high_resolution_clock::now();
          if(sensor->sensorData()->sharedParameters()._type == 1){
            _sensorAllocator.downloadCloudToSensor(sensor, _s0);
            sensor->setPublishCloudAsInputCloud();
            //start  = std::chrono::high_resolution_clock::now();
            //processPointCloudCPU(sensorIndex,agentMap);
          }else if(publishSensor == 1){
            //std::cout << downloading cloud from GPU to sensor" << std::endl;
            _sensorAllocator.downloadCloudToSensor(sensor, _s0);
          }
          
          cudaDeviceSynchronize();
        }

      

        // void SimHandler::init(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo, std::shared_ptr<nanomap::config::GPUInfo> config){
        //     initSensorAllocator(sensorInfo, config);
        // }

        // void SimHandler::initSensorAllocator(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo, std::shared_ptr<nanomap::config::GPUInfo> config){
        //     _sensorAllocator = nanomap::allocator::SensorAllocator(sensorInfo, config);
        // }

        void SimHandler::rayCastCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor){
            std::chrono::duration<double, std::milli> delay;
            //std::cout << calling SimCastACloud " << std::endl;
            auto gpu_start = std::chrono::high_resolution_clock::now();
            //std::cout << "sensorName = " << sensor->sensorData()->sensorName() << std::endl;
            _sensorAllocator.update(sensor->sensorData(), _s0);
            //_sensorAllocator.update(sensor->sensorData(), _s0);
            //generateCloud(*(_sensorAllocator.sensorBucket()), _simGridHandle, _s0);
            cudaDeviceSynchronize();
            auto start = std::chrono::high_resolution_clock::now();
            // if(sensorData->sharedParameters()._type == 1){
            //     _sensorAllocator.downloadCloudToSensor(sensorData, _s0);
            //     start  = std::chrono::high_resolution_clock::now();
            //     processPointCloudCPU(sensorIndex, agentMap);
            // }else if(publishSensor == 1){
            //     _sensorAllocator.downloadCloudToSensor(sensorData, _s0);
            // }
            filterCloud(*(_sensorAllocator.sensorBucket()), _s0);

            cudaDeviceSynchronize();
            
            frustumCastCloud(*(_sensorAllocator.sensorBucket()), _s0, _s1);
            
            cudaCheck(cudaMemcpyAsync(_sensorAllocator.sensorBucket()->hostFrustumLeafBuffer(), _sensorAllocator.sensorBucket()->devFrustumLeafBuffer(), (*_sensorAllocator.sensorBucket()->hostFrustumLeafCount())*3*sizeof(int), cudaMemcpyDeviceToHost, _s0));
            cudaCheck(cudaMemcpyAsync(_sensorAllocator.sensorBucket()->hostFrustumVoxelBuffer(), _sensorAllocator.sensorBucket()->devFrustumVoxelBuffer(), (*_sensorAllocator.sensorBucket()->hostFrustumLeafCount())*512*sizeof(int8_t), cudaMemcpyDeviceToHost,_s1));
            
            cudaStreamSynchronize(_s0);
            cudaStreamSynchronize(_s1);

            auto gpu_end = std::chrono::high_resolution_clock::now();
            delay = gpu_end-gpu_start;
            _gpuTime+=delay.count();
            start = std::chrono::high_resolution_clock::now();

            // if(_sensorAllocator.sensorBucket()->hostSensor()->type()==0){
            //     if(updateType == 0){
            //         voxelUpdateFromFrustumBuffer(sensorData->sharedParameters()._leafEdge);
            //     }else if(updateType == 1){
            //         blockUpdateFromFrustumBuffer();
            //         }
            //     }
            
            // }
            //std::cout << "frustum leaf count in handler: " << *(_sensorAllocator.sensorBucket()->hostFrustumLeafCount()) << std::endl;
            auto end = std::chrono::high_resolution_clock::now();
            //delay = end-start;
            //_mapUpdateTime+=delay.count();
        }
        // void SimHandler::closeSimHandler(){
        //     cudaCheck(cudaStreamDestroy(_s0));
        //     cudaCheck(cudaStreamDestroy(_s1));
        // }

        // void SimHandler::printUpdateTime(int count){
        //   //std::cout << gpu update time per loop:" << _gpuTime / count << std::endl;
        //   //std::cout << "map update time per loop:" << _mapUpdateTime / count << std::endl;

        // }

        // int SimHandler::getFrustumLeafCount(){return *(_sensorAllocator.sensorBucket()->hostFrustumLeafCount());}
        
        // int* SimHandler::getFrustumLeafBuffer(){return _sensorAllocator.sensorBucket()->hostFrustumLeafBuffer();}

        // int8_t* SimHandler::getFrustumVoxelBuffer(){return _sensorAllocator.sensorBucket()->hostFrustumVoxelBuffer();}

    }
}
