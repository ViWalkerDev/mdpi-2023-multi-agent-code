#include <random>
#include "nanomap/instance/GymInstance.h"
namespace nanomap{
    namespace instance{
        GymInstance::GymInstance(std::string mainConfig):SimInstance(mainConfig), 
        _plannerInstance(std::make_shared<nanomap::instance::PlannerInstance>(nanomap::instance::PlannerInstance(mainConfig))){
        //_config = std::make_shared<nanomap::config::Config>(mainConfig);
      }

        GymInstance::GymInstance(std::string mainConfig, int seed):SimInstance(mainConfig), 
        _plannerInstance(std::make_shared<nanomap::instance::PlannerInstance>(nanomap::instance::PlannerInstance(mainConfig))){
        std::srand(seed);
        //_config = std::make_shared<nanomap::config::Config>(mainConfig);
      }


      void GymInstance::createManager(){
        std::cout << "Starting Gym Instance" << std::endl;
        std::cout << "Loading Sim Grid File: " << _config->simGridFile() << std::endl;
        if(_config->generateSimGrid() == 1){
          nanomap::mapgen::MapGen generator;
          _simGrid = generator.generateAndReturnMap(_config->mapGenConfig());
        }else{
          if(_config->simGridFile().compare(_config->plannerGridFile()) == 0){
            _simGrid = loadSimGrid(_config->simGridFile());
            //no diff between sim and planner grid, only use sim grid
          }else{
            _simGrid = loadSimGrid(_config->simGridFile());
            _plannerGrid = loadSimGrid(_config->plannerGridFile());
            _usePlannerGrid = true;
          }
        }
        _simGridChanges = _simGrid->deepCopy();
        _simGridChanges->clear();
        _manager = std::make_shared<nanomap::manager::GymManager>(_sensorManager->sensorInfo(), _config->configInfo(), _simGrid);
        //_plannerInstance = std::make_shared<nanomap::instance::PlannerInstance>(nanomap::instance::PlannerInstance(_config));
        initPlannerInstance();
        createAgentManager();
      }

      void GymInstance::createAgentManager(){
        _agentManager = std::make_shared<nanomap::manager::GymAgentManager>(nanomap::manager::GymAgentManager(_plannerInstance->plannerManager(), _simGrid));
        _agentManager->loadAgents(_config->agentConfigs(), _config, _sensorManager->sensorData());
      }


      void GymInstance::initPlannerInstance(){
        std::cout << "Initialising Planner Instance" << std::endl;
        std::cout << "Creating Planner Manager" << std::endl;
        _plannerInstance->createManager();
        std::cout << "Creating Planner Handler" << std::endl;
        _plannerInstance->createHandler();
        std::cout << "Setting Planner Sim Grid" << std::endl;
        if(_usePlannerGrid){
          _plannerInstance->setPlannerGrid(_plannerGrid);
        }else{
          _plannerInstance->setPlannerGrid(_simGrid);
        }
        std::cout << "Processing Sim Grid" << std::endl;
        _plannerInstance->processPlannerGrid();
        std::cout << "solving planner grid" << std::endl;
        _plannerInstance->solvePlannerGrid();
        std::cout << "grid solved" << std::endl;
      }


      std::tuple<int, int, int, std::vector<Eigen::Vector3f>> GymInstance::getSearchGoalsForAgentByIndex(int index, int clusterIndex){
        return _agentManager->getSearchGoalsForAgentByIndex(index, clusterIndex);
      }
      
      std::tuple<int, int, int, std::vector<Eigen::Vector3f>> GymInstance::getTransitGoalsForClusterByIndex(int agentIndex, int clusterIndex){
        return _agentManager->getTransitGoalsForClusterByIndex(agentIndex, clusterIndex);
      }



      std::vector<Eigen::Vector3f> GymInstance::getSearchGoalsVec(int index, int clusterIndex){
        return _agentManager->getSearchGoalsVec(index, clusterIndex);
      }
      
      std::vector<Eigen::Vector3f> GymInstance::getTransitGoalsVec(int agentIndex, int clusterIndex){
        return _agentManager->getTransitGoalsVec(agentIndex, clusterIndex);
      }



      void GymInstance::resetAgentByIndex(int agentIndex){
        //reset the agent as usual
        _agentManager->resetAgentByIndex(agentIndex);
      }

      void GymInstance::resetAgents(){
        for(int x = 0; x < _agentManager->getAgents().size(); x++){
          _agentManager->resetAgentByIndex(x);
        }
        onAgentReset();
      }
      
      //Perform this on gym reset
      void GymInstance::onAgentReset(){
        //std::cout << "starting onAgentReset" << std::endl;
        processSimGridChanges();
        //std::cout << "initialising environmnet knowledge" << std::endl;
        initialiseEnvironmentKnowledge();
        //std::cout << "finishing onAgentReset" << std::endl;
      }

      void GymInstance::processSimGridChanges(){
              //if _simGridChanges is not empty, changes were made to the sim grid in a prior episode
        //So we need to revert them
        if(!_simGridChanges->empty()){
          //std::cout << "simGrdchanges not empty, clearing simgrid changes" << std::endl;
          revertSimGridChanges();
          //then if there we are not spawning more objects, we can update the sim grid on the GPU
          if(!_objectsOnPath){
            _manager->processSimGridUpdate();
          }
        }
        //But if we do want to generate obstacles on the new path
        if(_objectsOnPath){
          //std::cout << "generating objects on path" << std::endl;
          //We generate obstacles on the path
          generateObjectsOnPath();
          //Then we update simgrid on GPU
          //std::cout << "processing simGridUpdate" << std::endl;
          _manager->processSimGridUpdate();
          //std::cout << "simgridhandle updated" << std::endl;
        }
      }

      void GymInstance::revertSimGridChanges(){
        auto simAcc = _simGrid->getAccessor();
        for (openvdb::FloatGrid::ValueOnIter iter = _simGridChanges->beginValueOn(); iter; ++iter) {
          simAcc.setValueOff(iter.getCoord(),0.0);
        }
        _simGridChanges->clear();
      }

      void GymInstance::initialiseEnvironmentKnowledge(){
        //For each agent, we need to set prior knowledge according to desired knowledge
        if(_environmentKnowledge == 0){
          //we currently do nothing
          return;
        }else{
          //agents have some prior knowledge
          for(int x = 0; x < _agentManager->getAgents().size();x++){
            if(_environmentKnowledge == 2){
              //If setPriorKnowledge <= 0.0 then complete map knowledge is assumed. 
              _agentManager->getAgents()[x]->setPriorKnowledge(0.0, _simGrid);
            }else{
              //std::cout << "initialising environment knowledge with radius " << _environmentRadius << std::endl;
              _agentManager->getAgents()[x]->setPriorKnowledge(_environmentRadius, _simGrid);
            }
          }
        }
      }
    

      void GymInstance::generateObstaclesInSimGrid(std::string saveString, float obstacleOdds){
        using LeafNodeT = openvdb::FloatGrid::TreeType::LeafNodeType;
        //This is slow. do not do this all the time obviously
        openvdb::FloatGrid::Ptr obstacleGrid = _simGrid->deepCopy();
        openvdb::Int32Grid::Ptr plannerGrid = _plannerInstance->plannerManager()->getPlannerGrid()->deepCopy();
        std::array<std::array<openvdb::Coord, 2>, 3> coordChecks;
        openvdb::Int32Grid::Ptr tempGrid = openvdb::Int32Grid::create(0);
        openvdb::Int32Grid::Accessor tempAcc = tempGrid->getAccessor();
        std::vector<openvdb::Coord> otherObstaclesChecker;
        for(int x = -2; x < 3; x++){
          for(int y = -2; y < 3; y++){
            for(int z = -2; z < 3; z++){
              if(x != 0 && y != 0 && z != 0){
                otherObstaclesChecker.push_back(openvdb::Coord(x, y, z));
              }
            }
          }
        }
        coordChecks[0][0] = openvdb::Coord(-1, 0, 0);
        coordChecks[0][1] = openvdb::Coord(1, 0, 0);
        coordChecks[1][0] = openvdb::Coord(0, -1, 0);
        coordChecks[1][1] = openvdb::Coord(0, 1, 0);
        coordChecks[2][0] = openvdb::Coord(0, 0, -1);
        coordChecks[2][1] = openvdb::Coord(0, 0, 1);
        auto plannerAcc = plannerGrid->getAccessor();
        auto obstacleAcc = obstacleGrid->getAccessor();
        std::random_device device;
        std::mt19937 gen(device());
        std::bernoulli_distribution obstacleChance(obstacleOdds);
        for (openvdb::Int32Grid::ValueOnIter iter = plannerGrid->beginValueOn(); iter.test(); ++iter) {
              int value = *iter;
              openvdb::Coord valueCoord = iter.getCoord();
              if(value > 0){
                std::cout << value << std::endl;
                //node is considered safe.
                //Let's check if it is a candidate for an obstacle.
                bool candidate = true;
                for(auto coordPair : coordChecks){
                  openvdb::Coord offsetCoord1 = valueCoord + coordPair[0];
                  openvdb::Coord offsetCoord2 = valueCoord + coordPair[1];
                  if(plannerAcc.getValue(offsetCoord1) < 0 && plannerAcc.getValue(offsetCoord2) < 0 ){
                    candidate = false;
                    break;
                  }
                }
                bool finalCheck = true;
                for(int x = 0; x < otherObstaclesChecker.size(); x++){
                  if(tempAcc.isValueOn(valueCoord+otherObstaclesChecker[x])){
                    finalCheck = false;
                    break;
                  }
                }
                if(candidate && finalCheck){
                  if(obstacleChance(gen)){

                    //LeafNodeT leafNode;
                    //leafNode.fill(1.0, true);
                    //leafNode.setOrigin(openvdb::Coord(valueCoord.x()*8, valueCoord.y()*8, valueCoord.z()*8));
                    //obstacleAcc.addLeaf(&leafNode);
                      tempAcc.setValueOn(valueCoord);
                      openvdb::Coord gridCoord = openvdb::Coord(valueCoord.x()*8, valueCoord.y()*8, valueCoord.z()*8);
                      openvdb::Coord gridCoordUpper = openvdb::Coord(gridCoord.x()+7, gridCoord.y()+7, gridCoord.z()+7);
                      openvdb::CoordBBox bbox(gridCoord, gridCoordUpper);
                    //          std::cout << "14" << std::endl;
                      for(auto iter = bbox.begin(); iter!= bbox.end(); ++iter){
                        obstacleAcc.setValue(*iter, 1);
                      }
                      iter.setValue(-1*value);
                  }
                }
              }
        }
    std::cout << "saving obstacle grid " << std::endl;
    openvdb::GridPtrVec Grids;
    Grids.push_back(obstacleGrid);
    // Write out the contents of the container
    openvdb::io::File savefile(saveString);
    savefile.write(Grids);
    savefile.close();
    std::cout << "obstacle grid saved" << std::endl;
          //     // Print the coordinates of all voxels whose vector value has
          //     // a length greater than 10, and print the bounding box coordinates
          //     // of all tiles whose vector value length is greater than 10.
          //     if (value.length() > 10.0) {
          //         if (iter.isVoxelValue()) {
          //             std::cout << iter.getCoord() << std::endl;
          //         } else {
          //             openvdb::CoordBBox bbox;
          //             iter.getBoundingBox(bbox);
          //             std::cout << bbox << std::endl;
          //         }
          //     }
          // }


          //       if(rand()%5==0){
          // //20% chance of generating obstacle.
          // //          std::cout << "11" << std::endl;
          // openvdb::Vec3d worldVec = _plannerInstance->plannerManager()->getWorldVecFromPlannerCoord(voxel);
          // //          std::cout << "12" << std::endl;
          // openvdb::Coord gridCoord = openvdb::Coord::round(_simGrid->worldToIndex(worldVec));
          // //          std::cout << "13" << std::endl;
          // openvdb::CoordBBox bbox(gridCoord, gridCoord+coordStep);
          // //          std::cout << "14" << std::endl;
          // for(auto iter = bbox.begin(); iter!= bbox.end(); ++iter){
          //   simAcc.setValue(*iter, 1);
          //   simChangeAcc.setValue(*iter,1);
          // }
      }

      void GymInstance::generateObjectsOnPath(){
        //THIS MUST BE CALLED AFTER AGENTS HAVE BEEN RESET
        //CALLING THIS BEFORE THEN WILL FAIL AS THE AGENT TRAJECTORY HASN'T BEEN CREATED

        //For each agent
        auto simAcc = _simGrid->getAccessor();
        auto simChangeAcc = _simGridChanges->getAccessor();
        openvdb::Coord coordStep = openvdb::Coord(_config->leafEdge()-1,_config->leafEdge()-1,_config->leafEdge()-1);
        for(int x = 0; x < _agentManager->getAgents().size(); x++){
          //Get trajectory
          //std::cout << "0" << std::endl;
          Pose initialPose = _agentManager->getAgentByIndex(x)->agentData()->pose();
                    //std::cout << "1" << std::endl;
          //For the purpose of training, we only want to create obstacles after the initial trajectory.
          std::vector<std::pair<Pose, int>> trajectoryGoals = _agentManager->getTrajectoryGoalsByIndex(x);
                    //std::cout << "2" << std::endl;
          //For each tile the trajectory passes through we roll on whether or not to occupy it with a block.
          //More complex obstacles can be created in the future, this is just for training purposes/proof of concept
          for(int x = 0; x < trajectoryGoals.size()-1; x++){
                      //std::cout << "3" << std::endl;
            openvdb::Coord initialPlannerSpaceCoord = 
              _plannerInstance->plannerManager()->getPlannerCoordFromWorldVec(openvdb::Vec3d(trajectoryGoals[x].first.position(0),
                                                                              trajectoryGoals[x].first.position(1),
                                                                              trajectoryGoals[x].first.position(2)));
            openvdb::Coord destinationPlannerSpaceCoord = 
              _plannerInstance->plannerManager()->getPlannerCoordFromWorldVec(openvdb::Vec3d(trajectoryGoals[x+1].first.position(0),
                                                                              trajectoryGoals[x+1].first.position(1),
                                                                              trajectoryGoals[x+1].first.position(2)));
            //generate a ray from these two coordinates. 
                      //std::cout << "4" << std::endl;
            openvdb::Vec3d ray_origin = initialPlannerSpaceCoord.asVec3d()+openvdb::Vec3d(0.5,0.5,0.5);
            openvdb::Vec3d ray_dest = destinationPlannerSpaceCoord.asVec3d()+openvdb::Vec3d(0.5,0.5,0.5);
            openvdb::Vec3d ray_dir = (ray_dest-ray_origin);
            ray_dir.normalize();
            double ray_length = (ray_dest-ray_origin).length();
            openvdb::math::Ray<double> ray;
            openvdb::math::DDA<openvdb::math::Ray<double>,0> dda;
            ray.setEye(ray_origin);
            ray.setDir(ray_dir);
            dda.init(ray, 0, ray_length);
            openvdb::Coord voxel = dda.voxel();
                      //std::cout << "5" << std::endl;
            openvdb::Coord oldVoxel = voxel;
            while(dda.step() && voxel != destinationPlannerSpaceCoord){
              voxel = dda.voxel();
              if(voxel!=oldVoxel && voxel != destinationPlannerSpaceCoord){
                oldVoxel = voxel;
                //std::cout << "voxel " << voxel.z()<< "/" <<voxel.y() << "/" << voxel.z()<<  std::endl;
                if(rand()%5==0){
                  //20% chance of generating obstacle.
                  //          std::cout << "11" << std::endl;
                  openvdb::Vec3d worldVec = _plannerInstance->plannerManager()->getWorldVecFromPlannerCoord(voxel);
                  //          std::cout << "12" << std::endl;
                  openvdb::Coord gridCoord = openvdb::Coord::round(_simGrid->worldToIndex(worldVec));
                  //          std::cout << "13" << std::endl;
                  openvdb::CoordBBox bbox(gridCoord, gridCoord+coordStep);
                  //          std::cout << "14" << std::endl;
                  for(auto iter = bbox.begin(); iter!= bbox.end(); ++iter){
                    simAcc.setValue(*iter, 1);
                    simChangeAcc.setValue(*iter,1);
                  }
                }
              }
            }
          } 
        }
      }

      void GymInstance::gymStep(){
        //std::cout << "1 " << std::endl;
        generateAgentViews();
        //std::cout << "1 " << std::endl;
        processAgentViews();
        //std::cout << "1 " << std::endl;
        agentManager()->getAgentByIndex(0)->updateAgentObservations();
        // if(_agentManager->getAgentByIndex(0)->needsMapReset()){
        //   std::cout << "needsMapReset " << std::endl;
        //   _agentManager->getAgentByIndex(0)->resetAgentMap();
        //   initialiseEnvironmentKnowledge();
        //   generateAgentViews();
        //   processAgentViews();
        //   updateAgentObservations();
        // }
      }

      void GymInstance::processAgentViews(){
        for(int i = 0; i <_agentManager->getAgents().size(); i++){
          std::vector<bool> tempSeenStatus;
          if(_targetPositions.size() == 0){
            _targetPositions.push_back(EigenVec(0.0,0.0,0.0));
          }
          if(_targetObservedStatus.size() == 0){
            _targetObservedStatus.resize(1);
          }
          tempSeenStatus.resize(_targetPositions.size(),false);
          std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgentByIndex(i);
          for(int x = 0; x < agent->sensors().size(); x++){
            //std::cout << "sensorNames = " << agent->sensors()[x]->sensorData()->sensorName() << std::endl;
            _manager->insertPointCloud(
              agent->sensors()[x],
              agent->map(),
              _config->serialUpdate(),
              _config->updateType(),
              agent->voxelCount(),
              _targetPositions,
              tempSeenStatus
            );
          }
          _targetObservedStatus[i] = tempSeenStatus;
        }
      }

      bool GymInstance::isSearchGoalComplete(int agentIndex, Eigen::Vector3f goalPosition){
        _agentManager->isSearchGoalComplete(agentIndex, goalPosition);
      }

      void GymInstance::processAgentViews(std::string agentName){
        std::vector<bool> tempSeenStatus;
        tempSeenStatus.resize(_targetPositions.size(),false);
        if(_targetPositions.size() == 0){
            _targetPositions.push_back(EigenVec(0.0,0.0,0.0));
          }
          if(_targetObservedStatus.size() == 0){
            _targetObservedStatus.resize(1);
          }
        std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgent(agentName);
        for(int x = 0; x < agent->sensors().size(); x++){
          _manager->insertPointCloud(
            agent->sensors()[x],
            agent->map(),
            _config->serialUpdate(),
            _config->updateType(),
            agent->voxelCount(),
            _targetPositions,
              tempSeenStatus
          );
        }
        _targetObservedStatus[_agentManager->getAgentIndex(agent->agentData()->agentId())] = tempSeenStatus;
      }
      void GymInstance::processAgentViews(int agentId){
        std::vector<bool> tempSeenStatus;
        tempSeenStatus.resize(_targetPositions.size(),false);
        if(_targetPositions.size() == 0){
            _targetPositions.push_back(EigenVec(0.0,0.0,0.0));
          }
          if(_targetObservedStatus.size() == 0){
            _targetObservedStatus.resize(1);
          }
        std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgent(agentId);
        for(int x = 0; x < agent->sensors().size(); x++){
          _manager->insertPointCloud(
            agent->sensors()[x],
            agent->map(),
            _config->serialUpdate(),
            _config->updateType(),
            agent->voxelCount(),
            _targetPositions,
              tempSeenStatus
          );
        }
        _targetObservedStatus[_agentManager->getAgentIndex(agent->agentData()->agentId())] = tempSeenStatus;
      }
  }
}