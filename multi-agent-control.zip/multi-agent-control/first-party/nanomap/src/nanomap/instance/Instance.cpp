      
#include "nanomap/instance/Instance.h"
namespace nanomap{
    namespace instance{
        Instance::Instance(std::string mainConfig)
        :_manager(nullptr),_agentManager(nullptr){
        _config = std::make_shared<nanomap::config::Config>(mainConfig);
        _sensorManager = std::make_shared<nanomap::manager::SensorManager>(_config->sensorConfigs(), _config);
      }

      void Instance::createManager(){
        _manager = std::make_shared<nanomap::manager::Manager>(_sensorManager->sensorInfo(), _config->configInfo());
        createAgentManager();
      }

      void Instance::createAgentManager(){
        _agentManager = std::make_shared<nanomap::manager::AgentManager>(nanomap::manager::AgentManager());
        _agentManager->loadAgents(_config->agentConfigs(), _config, _sensorManager->sensorData());
      }

      void Instance::createHandler(){
        _manager->createHandler();
      }

      void Instance::updateAgentPose(int agentId, Pose pose){
        //std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgent(agentId);
        //agent->updatePose(pose);
        _agentManager->updateAgentPose(agentId, pose);
      }

      void Instance::updateAgentPoseFromFloat(int agentId, float x, float y, float z, float w, float qx, float qy, float qz){
        //std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgent(agentId);
        Pose pose;
        pose.setPositionFromFloat(x,y,z);
        pose.setOrientationFromFloat(w,qx,qy,qz);
        _agentManager->updateAgentPose(agentId, pose);
      }

      void Instance::updateAgentPose(std::string agentName, Pose pose){
        // std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgent(agentName);
        // agent->updatePose(pose);
        _agentManager->updateAgentPose(agentName, pose);
      }

      void Instance::updateAgentPoseFromVelocities(int agentId, float timeStep, float xVel, float yVel, float zVel, float rollVel, float pitchVel, float yawVel){
        _agentManager->updateAgentPoseFromVelocities(agentId, timeStep, xVel, yVel, zVel, rollVel, pitchVel, yawVel);
      }


      Eigen::Array<float, 7, 1> Instance::getAgentPoseAsFloat(int agentId){
        return getAgentPoseAsFloatByIndex(_agentManager->getAgentIndex(agentId));
      }

      Eigen::Array<float, 7, 1> Instance::getAgentPoseAsFloat(std::string agentName){
        return getAgentPoseAsFloatByIndex(_agentManager->getAgentIndex(agentName));
      }

      Eigen::Array<float, 7, 1> Instance::getAgentPoseAsFloatByIndex(int agentIndex){
        return _agentManager->getAgentPoseAsFloat(agentIndex);
      }


      void Instance::updateSensorPointCloud(int agentId, int sensorId, int pclWidth, int pclHeight, int pclStep, unsigned char * cloudPtr){
        _agentManager->updateSensorInputCloud(agentId, sensorId, pclWidth, pclHeight, pclStep, cloudPtr);
      }

      void Instance::processAgentViews(){
        for(int i = 0; i < _agentManager->getAgents().size(); i++){
          std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgentByIndex(i);
          for(int x = 0; x < agent->sensors().size(); x++){
            //std::cout << "sensorNames = " << agent->sensors()[x]->sensorData()->sensorName() << std::endl;
            _manager->insertPointCloud(
              agent->sensors()[x],
              agent->map()->occupiedGrid(),
              agent->map()->occAccessor(),
              agent->map()->gridConfig(),
              _config->serialUpdate(),
              _config->updateType()
              );
          }
        }
      }

      void Instance::processAgentViews(int agentId){
        std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgent(agentId);
        for(int x = 0; x < agent->sensors().size(); x++){
          //std::cout << "sensorNames = " << agent->sensors()[x]->sensorData()->sensorName() << std::endl;
          _manager->insertPointCloud(
            agent->sensors()[x],
            agent->map()->occupiedGrid(),
            agent->map()->occAccessor(),
            agent->map()->gridConfig(),
            _config->serialUpdate(),
            _config->updateType()
          );
        }
      }
      void Instance::processAgentViews(std::string agentName){
        std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgent(agentName);
        for(int x = 0; x < agent->sensors().size(); x++){
          _manager->insertPointCloud(
            agent->sensors()[x],
            agent->map()->occupiedGrid(),
            agent->map()->occAccessor(),
            agent->map()->gridConfig(),
            _config->serialUpdate(),
            _config->updateType()
          );
        }
      }

      void Instance::saveAgentGridToFile(int agentId, std::string fileName){
        std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgent(agentId);
        saveGridToFile(agent->map()->occupiedGrid(), fileName);
      }

      void Instance::saveGridToFile(openvdb::FloatGrid::Ptr grid, std::string fileName){
        openvdb::io::File(fileName).write({grid});
      }

      void Instance::resetAgent(int agentId){
        resetAgentByIndex(_agentManager->getAgentIndex(agentId));
      }
      void Instance::resetAgentByIndex(int agentIndex){
        _agentManager->resetAgentByIndex(agentIndex);
      }
      void Instance::resetAgent(std::string agentName){
        resetAgentByIndex(_agentManager->getAgentIndex(agentName));
      }
      void Instance::resetAgents(){
        _agentManager->resetAgents();
      }
      
      void Instance::updateAgentObservations(){
        _agentManager->updateAgentObservations();
        //TODO change to
        //_agentManager->updateAgentEnvironmentObservations();
        //_agentManager->updateAgentGoalObservations();
      }

      void Instance::updateAgentEnvironmentObservations(){
        _agentManager->updateAgentEnvironmentObservations();
      }
      // void Instance::updateAgentTransitObservations(){
      //   _agentManager->updateAgentEnvironmentObservations();
      // }
      

    }
}