      
#include "nanomap/instance/PlannerInstance.h"
namespace nanomap{
    namespace instance{
        PlannerInstance::PlannerInstance(std::string mainConfig)
        :_plannerManager(nullptr){
        _config = std::make_shared<nanomap::config::Config>(mainConfig);
      }

      // PlannerInstance::PlannerInstance(std::string& mainConfig)
      //   :_plannerManager(nullptr){
      //   _config = std::make_shared<nanomap::config::Config>(mainConfig);
      // }

      void PlannerInstance::createManager(){
        _plannerManager = std::make_shared<nanomap::manager::PlannerManager>(_config);
      }

      void PlannerInstance::createHandler(){
        _plannerManager->createHandler();
      }
      
      void PlannerInstance::solveSimGrid(){
        _plannerManager->solveMap(_simGrid);
      }

      void PlannerInstance::setSimGrid(openvdb::FloatGrid::Ptr grid){
        _simGrid = grid;
      }
      
      void PlannerInstance::solvePlannerGrid(){
        _plannerManager->solveMap(_plannerGrid);
      }

      void PlannerInstance::setPlannerGrid(openvdb::FloatGrid::Ptr plannerGrid){
        _plannerGrid = plannerGrid;
      }

      openvdb::Vec3d PlannerInstance::getWorldVecFromPlannerCoord(openvdb::Coord voxel){
        _plannerManager->getWorldVecFromPlannerCoord(voxel);
      }

      void PlannerInstance::processPlannerGrid(){
        openvdb::FloatGrid::Ptr gridTest = openvdb::FloatGrid::create(0.0);
        gridTest->setTransform(openvdb::math::Transform::createLinearTransform(0.1));
        auto acc = gridTest->getAccessor();
        
        
        auto setObstacle = [](float& voxel_value, bool& active) {
          voxel_value = 1.0;
          active = true;
        };
        auto setFree = [](float& voxel_value, bool& active) {
          voxel_value = 1.0;
          active = false;
        };

        auto newacc = _plannerGrid->getAccessor();

        openvdb::FloatGrid::ValueOnIter oniter = _plannerGrid->beginValueOn();
        bool mapFromFile = true;
        for (oniter; oniter.test(); ++oniter) {

          acc.modifyValueAndActiveState(oniter.getCoord(), setObstacle);

        }
        openvdb::FloatGrid::ValueOffIter offiter = _plannerGrid->beginValueOff();
        for (offiter; offiter.test(); ++offiter) {

              if(newacc.getValue(offiter.getCoord()) < 0.0){
                //std::cout << newacc.getValue(offiter.getCoord()) << std::endl;
                acc.modifyValueAndActiveState(offiter.getCoord(), setFree);
              }
        }
        _plannerGrid = gridTest;

      }

      //Performs extra steps to convert empty space internal space into active locations
      void PlannerInstance::loadPlannerGrid(std::string gridFile){
        openvdb::FloatGrid::Ptr gridTest = openvdb::FloatGrid::create(0.0);
        gridTest->setTransform(openvdb::math::Transform::createLinearTransform(0.1));
        auto acc = gridTest->getAccessor();
        auto setObstacle = [](float& voxel_value, bool& active) {
          voxel_value = 1.0;
          active = true;
        };
        auto setFree = [](float& voxel_value, bool& active) {
          voxel_value = 1.0;
          active = false;
        };
        openvdb::io::File file(gridFile);
        // Open the file.  This reads the file header, but not any grids.
        file.open();
        // Loop over all grids in the file and retrieve a shared pointer
        // to the one named "LevelSetSphere".  (This can also be done
        // more simply by calling file.readGrid("LevelSetSphere").)
        openvdb::GridBase::Ptr baseGrid;
        for (openvdb::io::File::NameIterator nameIter = file.beginName();
            nameIter != file.endName(); ++nameIter)
        {
            // Read in only the grid we are interested in.
            if (nameIter.gridName() == "grid") {
                baseGrid = file.readGrid(nameIter.gridName());
            } else {
                std::cout << "skipping grid " << nameIter.gridName() << std::endl;
            }
        }
        file.close();
      //
      //   int tileEdge = 8;
        openvdb::FloatGrid::Ptr grid = openvdb::gridPtrCast<openvdb::FloatGrid>(baseGrid);
        auto newacc = grid->getAccessor();

        openvdb::FloatGrid::ValueOnIter oniter = grid->beginValueOn();
        bool mapFromFile = true;
        if(mapFromFile){
          for (oniter; oniter.test(); ++oniter) {

            acc.modifyValueAndActiveState(oniter.getCoord(), setObstacle);

          }
          openvdb::FloatGrid::ValueOffIter offiter = grid->beginValueOff();
          for (offiter; offiter.test(); ++offiter) {

                if(newacc.getValue(offiter.getCoord()) < 0.0){
                  //std::cout << newacc.getValue(offiter.getCoord()) << std::endl;
                  acc.modifyValueAndActiveState(offiter.getCoord(), setFree);
                }
          }
          _plannerGrid = gridTest;
        }
      }

      // void PlannerInstance::setSimGrid(openvdb::FloatGrid::Ptr simGrid){
      //   _simGrid = simGrid;
      // }

      void PlannerInstance::loadSimGrid(){
        openvdb::io::File file(_config->simGridFile());
        // Open the file.  This reads the file header, but not any grids.
        file.open();
        openvdb::GridBase::Ptr baseGrid;
        for (openvdb::io::File::NameIterator nameIter = file.beginName();
        nameIter != file.endName(); ++nameIter)
        {
          // Read in only the grid we are interested in.
          if (nameIter.gridName() == "grid") {
            baseGrid = file.readGrid(nameIter.gridName());
          } else {
            std::cout << "skipping grid " << nameIter.gridName() << std::endl;
          }
        }
        file.close();
        _simGrid = openvdb::gridPtrCast<openvdb::FloatGrid>(baseGrid);
      }
    }
}