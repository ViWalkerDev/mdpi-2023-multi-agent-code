      
#include "nanomap/instance/SimInstance.h"
namespace nanomap{
    namespace instance{
        SimInstance::SimInstance(std::string mainConfig):Instance(mainConfig){
        // _config = std::make_shared<nanomap::config::Config>(mainConfig);
        // _sensorManager = std::make_shared<nanomap::manager::SensorManager>(_config->sensorConfigs(), _config);
        // _agentManager = std::make_shared<nanomap::manager::AgentManager>(_config->agentConfigs(),
        //                                                                 _config,
        //                                                                 _sensorManager->sensorData());

        }

      // void generateCloudFromSim(int agentId, int sensorId){
        
      //   _manager->generateCloudFromSim();
      // }

      void SimInstance::createManager(){
        _simGrid = loadSimGrid(_config->simGridFile());
        _manager = std::make_shared<nanomap::manager::SimManager>(nanomap::manager::SimManager(_sensorManager->sensorInfo(), _config->configInfo(), _simGrid));
        createAgentManager();
      }

      void SimInstance::createAgentManager(){
        _agentManager = std::make_shared<nanomap::manager::AgentManager>(nanomap::manager::AgentManager());
        _agentManager->loadAgents(_config->agentConfigs(), _config, _sensorManager->sensorData());
      
      }

      openvdb::FloatGrid::Ptr SimInstance::loadSimGrid(std::string simGridFile){
        openvdb::io::File file(simGridFile);
        // Open the file.  This reads the file header, but not any grids.
        file.open();
        openvdb::GridBase::Ptr baseGrid;
        for (openvdb::io::File::NameIterator nameIter = file.beginName();
        nameIter != file.endName(); ++nameIter)
        {
          // Read in only the grid we are interested in.
          if (nameIter.gridName() == "grid") {
            baseGrid = file.readGrid(nameIter.gridName());
          } else {
            std::cout << "skipping grid " << nameIter.gridName() << std::endl;
          }
        }
        file.close();
        return openvdb::gridPtrCast<openvdb::FloatGrid>(baseGrid);
      }


      void SimInstance::generateAgentViews(int agentId){
        std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgent(agentId);
        for(int x = 0; x < agent->sensors().size(); x++){
          _manager->generateCloudFromSim(agent->sensors()[x],_config->publishSensor());
        }
      }


      void SimInstance::generateAgentViews(){
        //std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgent(agentId);
        for(int i = 0; i < _agentManager->getAgents().size(); i++){
          std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgentByIndex(i);
          for(int x = 0; x < agent->sensors().size(); x++){
            _manager->generateCloudFromSim(agent->sensors()[x],_config->publishSensor());
          }
        }
      }

      // void SimInstance::updateAgentPose(int agentId, Pose pose){
      //   std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgent(agentId);

      // }
      // void SimInstance::updateAgentPose(std::string agentName, Pose pose){
      //   std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgent(agentName);
        
      // }


      // void SimInstance::updateSensorPointCloud(int agentId, int sensorId, int pclWidth, int pclHeight, int pclStep, unsigned char * cloudPtr){
      //   _agentManager->updateSensorInputCloud(agentId, sensorId, pclWidth, pclHeight, pclStep, cloudPtr);
      // }


      // void SimInstance::processAgentViews(int agentId){
      //   std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgent(agentId);
      //   for(int x = 0; x < agent->sensors().size(); x++){
      //     _manager->insertPointCloud(
      //       agent->sensors()[x],
      //       agent->map()->occupiedGrid(),
      //       agent->map()->occAccessor(),
      //       agent->map()->gridConfig(),
      //       _config->serialUpdate(),
      //       _config->updateType()
      //     );
      //   }
      // }
      // void SimInstance::processAgentViews(std::string agentName){
      //   std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgent(agentName);
      //   for(int x = 0; x < agent->sensors().size(); x++){
      //     _manager->insertPointCloud(
      //       agent->sensors()[x],
      //       agent->map()->occupiedGrid(),
      //       agent->map()->occAccessor(),
      //       agent->map()->gridConfig(),
      //       _config->serialUpdate(),
      //       _config->updateType()
      //     );
      //   }
      // }

      // void SimInstance::saveAgentGridToFile(int agentId, std::string fileName){
      //   std::shared_ptr<nanomap::agent::Agent> agent = _agentManager->getAgent(agentId);
      //   saveGridToFile(agent->map()->occupiedGrid(), fileName);
      // }

      // void SimInstance::saveGridToFile(openvdb::FloatGrid::Ptr grid, std::string fileName){
      //   openvdb::io::File(fileName).write({grid});
      // }

    }
}