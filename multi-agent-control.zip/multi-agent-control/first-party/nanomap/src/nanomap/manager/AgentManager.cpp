#include "nanomap/manager/AgentManager.h"

namespace nanomap{
    namespace manager{
        // AgentManager::AgentManager(std::vector<std::string> agentConfigs, 
        //                             std::shared_ptr<nanomap::config::Config> config, 
        //                             std::vector<std::shared_ptr<nanomap::sensor::SensorData>> sensorData){
        // }
        AgentManager::AgentManager(){}


        void AgentManager::loadAgents(std::vector<std::string> agentConfigs,
                        std::shared_ptr<nanomap::config::Config> config,
                        std::vector<std::shared_ptr<nanomap::sensor::SensorData>> sensorData){
            _agents.clear();
            for(int x = 0; x < agentConfigs.size(); x++){
                _agents.push_back(loadAgent(agentConfigs[x], config, sensorData));
            }
        }

        std::shared_ptr<nanomap::agent::Agent> AgentManager::loadAgent(std::string agentConfig,
                                                            std::shared_ptr<nanomap::config::Config> config,
                                                            std::vector<std::shared_ptr<nanomap::sensor::SensorData>> sensorData){
          std::shared_ptr<nanomap::map::Map> map = std::make_shared<nanomap::map::Map>(config->mappingRes(), 
                                                                        config->probHitThres(), 
                                                                        config->probMissThres());
          std::cout <<"reading in agent config file: " << agentConfig << std::endl;
          bool isRandom = false;
          ValueT x,y,z,qx,qy,qz,qw,lenObs, numObs, collisionDist;

          std::string agentName, name, line;
          int agentId;
          openvdb::Vec3f VecSpawn;
          Pose pose;
          Pose agentPose;
          std::vector<std::string> sensorNames;
          std::vector<Pose> sensorOrigins;
          std::ifstream *input = new std::ifstream(agentConfig.c_str(), std::ios::in | std::ios::binary);
          bool end = false;
          *input >> line;
          if(line.compare("#agentconfig") != 0){
            std::cout << "Error: first line reads [" << line << "] instead of [#agentconfig]" << std::endl;
            delete input;
            return NULL;
          }
          while(input->good()) {
            *input>>line;
            if(line.compare("AgentName:")==0){
                *input>>agentName;
            }else if(line.compare("AgentID:")==0){
                *input>>agentId;
            }else if(line.compare("Spawn:") == 0){
              *input >> line;
              *input >> line;
              if(line.compare("Random") == 0){
                isRandom = true;
                //VecSpawn = nanomap::util::getAgentSpawn(simGrid, _gridRes);
                agentPose.position = Eigen::Matrix<float, 3, 1>(0.0,0.0,0.0);
                Eigen::Matrix<float,3,3> rotation;
                //Right
                rotation.col(0)=Eigen::Matrix<float, 3, 1>(0.0,-1.0,0.0);
                //Forward
                rotation.col(1)=Eigen::Matrix<float, 3, 1>(1.0,0.0,0.0);
                //Up
                rotation.col(2)=Eigen::Matrix<float, 3, 1>(0.0,0.0,1.0);
                agentPose.orientation = Eigen::Quaternionf(rotation);
              }else{
                isRandom = false;
                *input>>line;
                *input>>x>>y>>z;
                *input>>line;
                *input>>qx>>qy>>qz>>qw;
                agentPose.position = Eigen::Vector3f(x,y,z);
                Eigen::Matrix<float,3,3> rotation;
                //Right
                rotation.col(0)=Eigen::Matrix<float, 3, 1>(0.0,-1.0,0.0);
                //Forward
                rotation.col(1)=Eigen::Matrix<float, 3, 1>(1.0,0.0,0.0);
                //Up
                rotation.col(2)=Eigen::Matrix<float, 3, 1>(0.0,0.0,1.0);
                agentPose.orientation = Eigen::Quaternionf(rotation);
              }
            }else if(line.compare("Observations:")==0){
              *input>>line;
              *input >> numObs;
              *input >> line;
              *input >> lenObs;
              *input >> line;
              *input >> collisionDist;
            }else if(line.compare("Sensor:")==0){
                *input>>line;
                *input>>name;
                *input>>line;
                *input>>x>>y>>z;
                *input>>line;
                *input>>qw>>qx>>qy>>qz;
                pose.position = Eigen::Vector3f(x,y,z);
                pose.orientation = Eigen::Quaternionf(qw,qx,qy,qz);
                sensorNames.push_back(name);
                sensorOrigins.push_back(pose);
            }else if (line.compare("#endconfig")==0){
                break;
            }
          }
          input->close(); 
          //Populate agent sensors
          std::vector<std::shared_ptr<nanomap::sensor::Sensor>> sensors;
          for(int x = 0; x < sensorNames.size(); x++){
            //std::cout << sensorNames[x] << std::endl;
            for(int y = 0; y < sensorData.size(); y++){
              //std::cout << sensorData[y]->sensorName() << std::endl;
                if(sensorNames[x].compare(sensorData[y]->sensorName()) == 0){
                  nanomap::sensor::SensorData newSensorData = *(sensorData[y]);
                    std::shared_ptr<nanomap::sensor::Sensor> sensor = std::make_shared<nanomap::sensor::Sensor>(newSensorData); 
                    //std::cout << sensor->sensorData()->sensorName() << std::endl;
                    sensor->sensorData()->agentPose() = sensorOrigins[x];
                    sensor->sensorData()->sensorId() = x;
                    sensors.push_back(sensor);
                }
            }
          }
          //
          std::shared_ptr<nanomap::agent::AgentData> agentData = std::make_shared<nanomap::agent::AgentData>(agentName, agentId, isRandom, agentPose);
          return std::make_shared<nanomap::agent::Agent>(nanomap::agent::Agent(agentData, sensors, map));
        }


        std::shared_ptr<nanomap::agent::Agent> AgentManager::getAgent(std::string agentName){
          for(int x = 0; x < _agents.size(); x++){
            if(_agents[x]->agentData()->agentName().compare(agentName) == 0){
              return _agents[x];
            }
          }
        }

        std::shared_ptr<nanomap::agent::Agent> AgentManager::getAgent(int agentId){
          for(int x = 0; x < _agents.size(); x++){
            if(_agents[x]->agentData()->agentId() == agentId){
              return _agents[x];
            }
          }
        }

        int AgentManager::getAgentIndex(std::string agentName){
          for(int x = 0; x < _agents.size(); x++){
            if(_agents[x]->agentData()->agentName().compare(agentName) == 0){
              return x;
            }
          }
        }

        int AgentManager::getAgentIndex(int agentId){
          for(int x = 0; x < _agents.size(); x++){
            if(_agents[x]->agentData()->agentId() == agentId){
              return x;
            }
          }
        }

        void AgentManager::updateAgentPose(std::string agentName, Pose pose){
          for(int x = 0; x < _agents.size(); x++){
            if(_agents[x]->agentData()->agentName().compare(agentName) == 0){
              _agents[x]->updatePose(pose);
              return;
            }
          }
        }

        void AgentManager::updateAgentPose(int agentId, Pose pose){
          for(int x = 0; x < _agents.size(); x++){
            if(_agents[x]->agentData()->agentId() == agentId){
              _agents[x]->updatePose(pose);
            return;
            } 
          }
        }

        void AgentManager::updateAgentPoseFromVelocities(int agentId, float timeStep, float xVel, float yVel, float zVel, float rollVel, float pitchVel, float yawVel){
          int agentIndex = getAgentIndex(agentId);
          Pose oldPose = _agents[agentIndex]->agentData()->pose();
          Eigen::Vector3f positionIncrement(0.0,0.0,0.0);
          positionIncrement(0) = xVel*timeStep;
          positionIncrement(1) = yVel*timeStep;
          positionIncrement(2) = zVel*timeStep;
          Eigen::Vector3f rotatedIncrement = oldPose.orientation * positionIncrement;
          Pose newPose;
          float yawStep = yawVel*timeStep;
          float rollStep = rollVel*timeStep;
          float pitchStep = pitchVel*timeStep;
          Eigen::AngleAxisf rollAngle(rollStep, Eigen::Vector3f::UnitX());
          Eigen::AngleAxisf pitchAngle(pitchStep, Eigen::Vector3f::UnitY());
          Eigen::AngleAxisf yawAngle(yawStep, Eigen::Vector3f::UnitZ());
          Eigen::Quaternionf qIncrement = yawAngle * pitchAngle * rollAngle;
          oldPose.orientation.normalize();
          qIncrement.normalize();
          newPose.position = oldPose.position + rotatedIncrement;
          newPose.orientation = oldPose.orientation*qIncrement;
          _agents[agentIndex]->updatePose(newPose);
        }

        void AgentManager::updateSensorInputCloud(int agentId, int sensorId, int pclWidth, int pclHeight, int pclStep, unsigned char* cloudPtr){
          for(int x = 0; x < _agents.size(); x++){
            if(_agents[x]->agentData()->agentId() == agentId){
              for(int sensorIdx = 0; _agents[x]->sensors().size(); sensorIdx++){
                if(_agents[x]->sensors()[sensorIdx]->sensorData()->sensorId() == sensorId){
                  //We are updating the correct sensor
                  _agents[x]->sensors()[sensorIdx]->inputCloud()->updateCloud(pclWidth, pclHeight, pclStep, cloudPtr);
                  return;
                }
              }
              std::cout << "Agent "<< agentId <<" exists, but sensor with sensorId: " << sensorId << " doesn't." << std::endl; 
              return;
            } 
          }
          std::cout << "Agent with agentId: "<< agentId <<" doesn't exist." << std::endl;
          return;
        }


        int AgentManager::getAgentId(std::string agentName){
          for(int x = 0; x < _agents.size(); x++){
            if(_agents[x]->agentData()->agentName().compare(agentName) == 0){
              return _agents[x]->agentData()->agentId();
            }
          }
        }
        void AgentManager::resetAgentByIndex(int agentIndex){
          _agents[agentIndex]->resetAgent();
        }

        void AgentManager::resetAgent(int agentId){
          std::vector<std::shared_ptr<nanomap::agent::Agent>>::iterator it; 
          for(it = _agents.begin(); it != _agents.end(); it++){
            if((*it)->agentData()->agentId() == agentId){
              (*it)->resetAgent();
            }
          }
        }

        void AgentManager::resetAgent(std::string agentName){
          std::vector<std::shared_ptr<nanomap::agent::Agent>>::iterator it; 
          for(it = _agents.begin(); it != _agents.end(); it++){
            if((*it)->agentData()->agentName() == agentName){
              (*it)->resetAgent();
            }
          }
        }

        void AgentManager::resetAgents(){
          std::vector<std::shared_ptr<nanomap::agent::Agent>>::iterator it; 
          for(it = _agents.begin(); it != _agents.end(); it++){
            (*it)->resetAgent();
          }
        }

        void AgentManager::updateAgentObservations(){
          std::vector<std::shared_ptr<nanomap::agent::Agent>>::iterator it; 
          for(it = _agents.begin(); it != _agents.end(); it++){
            (*it)->updateAgentObservations();
          }
        }

        void AgentManager::updateAgentEnvironmentObservations(){
          std::vector<std::shared_ptr<nanomap::agent::Agent>>::iterator it; 
          for(it = _agents.begin(); it != _agents.end(); it++){
            (*it)->updateAgentEnvironmentObservations();
          }
        }


    }
}