#include "nanomap/manager/GymAgentManager.h"

namespace nanomap{
    namespace manager{
        GymAgentManager::GymAgentManager(std::shared_ptr<nanomap::manager::PlannerManager> plannerManager, openvdb::FloatGrid::Ptr simGrid)
        : AgentManager(), _plannerManager(plannerManager), _simGrid(simGrid)
        {}

        void GymAgentManager::loadAgents(std::vector<std::string> agentConfigs,
                        std::shared_ptr<nanomap::config::Config> config,
                        std::vector<std::shared_ptr<nanomap::sensor::SensorData>> sensorData){
            for(int x = 0; x < agentConfigs.size(); x++){
                _agents.push_back(loadAgent(agentConfigs[x], config, sensorData));
            }
        }

        std::shared_ptr<nanomap::agent::Agent> GymAgentManager::loadAgent(std::string agentConfig,
                                                            std::shared_ptr<nanomap::config::Config> config,
                                                            std::vector<std::shared_ptr<nanomap::sensor::SensorData>> sensorData){
          std::shared_ptr<nanomap::map::Map> map = std::make_shared<nanomap::map::Map>(config->mappingRes(), 
                                                                        config->probHitThres(), 
                                                                        config->probMissThres());
          std::cout <<"reading in agent config file: " << agentConfig << std::endl;
          bool isRandom = false;
          ValueT x,y,z,qx,qy,qz,qw,lenObs, numObs, collisionDist;

          std::string agentName, name, line;
          int agentId;
          openvdb::Vec3f VecSpawn;
          Pose pose;
          Pose agentPose;
          std::vector<std::string> sensorNames;
          std::vector<Pose> sensorOrigins;
          std::ifstream *input = new std::ifstream(agentConfig.c_str(), std::ios::in | std::ios::binary);
          bool end = false;
          *input >> line;
          if(line.compare("#agentconfig") != 0){
            std::cout << "Error: first line reads [" << line << "] instead of [#agentconfig]" << std::endl;
            delete input;
            return NULL;
          }
          while(input->good()) {
            *input>>line;
            if(line.compare("AgentName:")==0){
                *input>>agentName;
            }else if(line.compare("AgentID:")==0){
                *input>>agentId;
            }else if(line.compare("Spawn:") == 0){
              *input >> line;
              *input >> line;
              if(line.compare("Random") == 0){
                isRandom = true;
                //VecSpawn = nanomap::util::getAgentSpawn(simGrid, _gridRes);
                agentPose.position = Eigen::Matrix<float, 3, 1>(0.0,0.0,0.0);
                Eigen::Matrix<float,3,3> rotation;
                //Right
                rotation.col(0)=Eigen::Matrix<float, 3, 1>(0.0,-1.0,0.0);
                //Forward
                rotation.col(1)=Eigen::Matrix<float, 3, 1>(1.0,0.0,0.0);
                //Up
                rotation.col(2)=Eigen::Matrix<float, 3, 1>(0.0,0.0,1.0);
                agentPose.orientation = Eigen::Quaternionf(rotation);
              }else{
                isRandom = false;
                *input>>line;
                *input>>x>>y>>z;
                *input>>line;
                *input>>qx>>qy>>qz>>qw;
                agentPose.position = Eigen::Vector3f(x,y,z);
                Eigen::Matrix<float,3,3> rotation;
                //Right
                rotation.col(0)=Eigen::Matrix<float, 3, 1>(0.0,-1.0,0.0);
                //Forward
                rotation.col(1)=Eigen::Matrix<float, 3, 1>(1.0,0.0,0.0);
                //Up
                rotation.col(2)=Eigen::Matrix<float, 3, 1>(0.0,0.0,1.0);
                agentPose.orientation = Eigen::Quaternionf(rotation);
              }
            }else if(line.compare("Observations:")==0){
              *input>>line;
              *input >> numObs;
              *input >> line;
              *input >> lenObs;
              *input >> line;
              *input >> collisionDist;
            }else if(line.compare("Sensor:")==0){
                *input>>line;
                *input>>name;
                *input>>line;
                *input>>x>>y>>z;
                *input>>line;
                *input>>qw>>qx>>qy>>qz;
                pose.position = Eigen::Vector3f(x,y,z);
                pose.orientation = Eigen::Quaternionf(qw,qx,qy,qz);
                sensorNames.push_back(name);
                sensorOrigins.push_back(pose);
            }else if (line.compare("#endconfig")==0){
                break;
            }
          }
          input->close(); 
          //Populate agent sensors
          std::vector<std::shared_ptr<nanomap::sensor::Sensor>> sensors;
          for(int x = 0; x < sensorNames.size(); x++){
            //std::cout << sensorNames[x] << std::endl;
            for(int y = 0; y < sensorData.size(); y++){
              //std::cout << sensorData[y]->sensorName() << std::endl;
                if(sensorNames[x].compare(sensorData[y]->sensorName()) == 0){
                  nanomap::sensor::SensorData newSensorData = *(sensorData[y]);
                    std::shared_ptr<nanomap::sensor::Sensor> sensor = std::make_shared<nanomap::sensor::Sensor>(newSensorData); 
                    //std::cout << sensor->sensorData()->sensorName() << std::endl;
                    sensor->sensorData()->agentPose() = sensorOrigins[x];
                    sensor->sensorData()->sensorId() = x;
                    sensors.push_back(sensor);
                }
            }
          }
          //
          std::shared_ptr<nanomap::agent::AgentData> agentData = std::make_shared<nanomap::agent::AgentData>(agentName, agentId, isRandom, agentPose);
          std::shared_ptr<nanomap::agent::GymData> gymData = std::make_shared<nanomap::agent::GymData>(numObs, lenObs, collisionDist, config->gridRes(), config->minimumSteps());
          return std::make_shared<nanomap::agent::GymAgent>(nanomap::agent::GymAgent(agentData, gymData, sensors, map, _plannerManager, _simGrid));
        }

    }
}