// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file GymManager.cpp
///
/// @author Violet Walker
///
#include "nanomap/manager/GymManager.h"


namespace nanomap{
    namespace manager{

      // GymManager::GymManager(){}

      // GymManager::GymManager(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo, std::shared_ptr<nanomap::gym::GPUInfo> gymInfo, std::shared_ptr<nanomap::config::GPUInfo> config, openvdb::FloatGrid::Ptr simGrid)
      // : SimManager(sensorInfo, config, simGrid), _gymInfo(gymInfo)
      // {}
        
      GymManager::GymManager(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo, std::shared_ptr<nanomap::config::GPUInfo> config, openvdb::FloatGrid::Ptr simGrid)
      : SimManager(sensorInfo, config, simGrid)
      {}

      void GymManager::createHandler(){
        _handler = std::make_unique<nanomap::handler::SimHandler>(nanomap::handler::SimHandler(_sensorInfo, _config, _simGrid));
      }




      // void GymManager::insertPointCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor, 
      //                                             openvdb::FloatGrid::Ptr floatGrid, 
      //                                             std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
      //                                             std::shared_ptr<nanomap::map::GPUInfo> gridConfig,
      //                                             bool serialUpdate,
      //                                             int updateType,
      //                                             int& voxelCount){
      //         //std::cout << "incrementing voxelCount " << std::endl;
      //         int newVoxelCount = 0;

      //         //For the given sensor, raycast the sensor information
      //         if(sensor->sensorData()->sharedParameters()._type == 0){
      //           //Perform GPU update
      //           //No option for block update within gym currently, not implemented.
      //           _handler->rayCastCloud(sensor);
      //           voxelUpdateFromFrustumBuffer(acc, gridConfig, newVoxelCount);
                
      //         }else if(sensor->sensorData()->sharedParameters()._type == 1){
      //           //insert point cloud CPU
      //           insertPointCloudCPU(sensor, floatGrid, acc, gridConfig, newVoxelCount);
      //         }
      //         voxelCount = newVoxelCount;
      //         //std::cout << newVoxelCount << std::endl;
      //       }

      // void GymManager::insertPointCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor, 
      //                                   std::shared_ptr<nanomap::map::Map> map,
      //                                                   bool serialUpdate,
      //                                                   int updateType,
      //                                                   int& voxelCount){
      //               //std::cout << "incrementing voxelCount " << std::endl;
      //               int newVoxelCount = 0;
      //               //For the given sensor, raycast the sensor information
      //               std::set<LeafNodeT*> visitedLeafNodes;
      //               if(sensor->sensorData()->sharedParameters()._type == 0){
      //                 //Perform GPU update
      //                 //No option for block update within gym currently, not implemented.
      //                 _handler->rayCastCloud(sensor);
      //                 voxelUpdateFromFrustumBuffer(map, newVoxelCount, visitedLeafNodes);
                      
      //               }else if(sensor->sensorData()->sharedParameters()._type == 1){
      //                 //insert point cloud CPU
      //                 insertPointCloudCPU(sensor, map, newVoxelCount, visitedLeafNodes);
      //               }

      //               updateSearchGrid(map, visitedLeafNodes);
      //               voxelCount = newVoxelCount;
      //               //std::cout << newVoxelCount << std::endl;
      //             }


      // void GymManager::updateSearchGrid(std::shared_ptr<nanomap::map::Map> map, std::set<LeafNodeT*>& visitedLeafNodes){
      //   int totalVoxelCount = 8*8*8;
      //   for(auto leafPointer : visitedLeafNodes){
      //     int knownVoxelCount = leafPointer->onVoxelCount();
      //     float knownRatio = (float)knownVoxelCount/(float)totalVoxelCount;
      //     if(knownRatio > 0.85){
      //               //         openvdb::Coord indexCoord = openvdb::Coord(iter.getCoord().x()/_plannerConfig->leafEdge, 
      //   //                                                   iter.getCoord().y()/_plannerConfig->leafEdge, 
      //   //                                                   iter.getCoord().z()/_plannerConfig->leafEdge);
      //   //         //In a tile/leaf, do planner map construction logic.
      //   //         //auto worldCoord = targetGrid->indexToWorld(iter.getCoord());
      //   //         //openvdb::Coord indexCoord = openvdb::Coord(std::floor(_plannerGrid->worldToIndex(worldCoord).x()),
      //   //         //                                          std::floor(_plannerGrid->worldToIndex(worldCoord).y()),
      //   //         //                                          std::floor(_plannerGrid->worldToIndex(worldCoord).z()));
      //       openvdb::Coord indexCoord = leafPointer->getNodeBoundingBox().min();
      //       openvdb::Coord searchCoord = openvdb::Coord(indexCoord.x()/8, 
      //                                     indexCoord.y()/8, 
      //                                     indexCoord.z()/8);
      //       //auto worldSpaceCoord = map->knownGrid()->indexToWorld(indexCoord);
      //       // openvdb::Coord searchSpaceCoord = openvdb::Coord(std::floor(map->searchGrid()->worldToIndex(worldSpaceCoord).x()),
      //       //                                                  std::floor(map->searchGrid()->worldToIndex(worldSpaceCoord).y()),
      //       //                                                   std::floor(map->searchGrid()->worldToIndex(worldSpaceCoord).z()));
      //       map->searchAccessor()->setValueOn(searchCoord);
      //     }
      //   }
      // }


      // void GymManager::insertPointCloudCPU(std::shared_ptr<nanomap::sensor::Sensor> sensor,
      //                                   std::shared_ptr<nanomap::map::Map> map,
      //                                   int& voxelCount,
      //                                   std::set<LeafNodeT*>& visitedLeafNodes){
      //   openvdb::FloatGrid::Ptr tempGrid = openvdb::FloatGrid::create(0.0);
      //   //tempGrid->setTransform(openvdb::math::Transform::createLinearTransform(_config->mappingRes()));
      //   auto tempAcc = tempGrid->getAccessor();
      //   populateTempGrid(tempAcc, sensor, map->occupiedGrid(), map->occAccessor(), map->gridConfig());

      //   return integrateTempGrid(tempGrid, map, voxelCount, visitedLeafNodes);
      // }


      // void GymManager::integrateTempGrid(openvdb::FloatGrid::Ptr tempGrid,
      //                                 std::shared_ptr<nanomap::map::Map> map,
      //                                 int& voxelCount,
      //                                 std::set<LeafNodeT*>& visitedLeafNodes){
          
      //     float emptyClampThres = map->gridConfig()->emptyClampingThreshold;
      //     float occClampThres = map->gridConfig()->occupiedClampingThreshold;
      //     float logodds_thres_min = map->gridConfig()->logOddsMissThreshold;
      //     float logodds_thres_max = map->gridConfig()->logOddsHitThreshold;
      //     float tempValue;
      //     int newVoxelCount = 0;
      //     //voxelCount = 0;
      //     // Probability update lambda for occupied grid elements
      //     // auto update = [&prob_thres_max = logodds_thres_max, &prob_thres_min = logodds_thres_min,
      //     //   &occ_clamp = occClampThres, &empty_clamp = emptyClampThres, &temp_value = tempValue, &voxel_count = voxelCount](float& voxel_value,
      //     //                                                                               bool& active) {
      //     //   bool unknownVoxel = false;
      //     //   if(voxel_value > prob_thres_min && voxel_value < prob_thres_max && active == false){
      //     //     //Voxel status is insufficiently explored
      //     //     unknownVoxel = true;
      //     //   }
            
      //     //   voxel_value += temp_value;
      //     //   if (voxel_value > occ_clamp)
      //     //   {
      //     //     voxel_value = occ_clamp;
      //     //   }else if(voxel_value < empty_clamp){
      //     //     voxel_value = empty_clamp;
      //     //   }

      //     //   if(voxel_value > prob_thres_max){
      //     //     active = true;
      //     //     if(unknownVoxel){
      //     //       voxel_count++;
      //     //     }
      //     //   }else if(voxel_value < prob_thres_min){
      //     //     active = false;
      //     //     if(unknownVoxel){
      //     //       voxel_count++;
      //     //     }
      //     //   }
      //     // };
      //               // Probability update lambda for occupied grid elements
      //     auto update = [&logodds_thres_max = logodds_thres_max, 
      //                     &logodds_thres_min = logodds_thres_min,
      //                     &occClampThres = occClampThres, 
      //                     &emptyClampThres = emptyClampThres, 
      //                     &tempValue = tempValue, 
      //                     &newVoxelCount = newVoxelCount](float& voxel_value,
      //                                                                                   bool& active) {
      //       //bool unknownVoxel = false;
      //       // std::cout << "Voxel Value = " << voxel_value << std::endl;
      //       // std::cout << "logodds_thres_max = " << logodds_thres_max << std::endl;
      //       // std::cout << "logodds_thres_min = " << logodds_thres_min << std::endl;
      //       // std::cout << "Active = " << active << std::endl;
      //       // if(voxel_value > logodds_thres_min && voxel_value < logodds_thres_max && active == false){
      //       //   //Voxel status is insufficiently explored
      //       //   unknownVoxel = true;
      //       // }
      //       //std::cout << "unknownVoxel = " << (int)unknownVoxel << std::endl;
      //       voxel_value += tempValue;
      //       if (voxel_value > occClampThres)
      //       {
      //         voxel_value = occClampThres;
      //       }else if(voxel_value < emptyClampThres){
      //         voxel_value = emptyClampThres;
      //       }

      //       if(voxel_value > logodds_thres_max){
      //         active = true;
      //         // if(unknownVoxel){
      //         //   newVoxelCount++;
      //         // }
      //       }else if(voxel_value < logodds_thres_min){
      //         active = false;
      //         // if(unknownVoxel){
      //         //   newVoxelCount++;
      //         // }
      //       }
      //     };
      //        auto knownUpdate = [&logodds_thres_max = logodds_thres_max, 
      //                     &logodds_thres_min = logodds_thres_min,
      //                     &occClampThres = occClampThres, 
      //                     &emptyClampThres = emptyClampThres, 
      //                     &tempValue = tempValue, 
      //                     &newVoxelCount = newVoxelCount](float& voxel_value,
      //                                                                                   bool& active) {
      //       bool unknownVoxel = false;
      //       //std::cout << voxel_value << std::endl;
      //       if(active == false){
      //           //Voxel status is insufficiently explored
      //           unknownVoxel = true;
      //       }
      //       // if(unknownVoxel){
      //       //   std::cout << "unknownVoxel = " << (int)unknownVoxel << std::endl;
      //       //   std::cout << "Voxel Value = " << voxel_value << std::endl;
      //       //   std::cout << "logodds_thres_max = " << logOddsHit << std::endl;
      //       //   std::cout << "logodds_thres_min = " << logOddsMiss << std::endl;
      //       //   std::cout << "value = " << value << std::endl;
      //       //   std::cout << "Active = " << active << std::endl;
      //       // }
      //                   voxel_value += tempValue;
      //       if (voxel_value > occClampThres)
      //       {
      //         voxel_value = occClampThres;
      //       }else if(voxel_value < emptyClampThres){
      //         voxel_value = emptyClampThres;
      //       }

      //       if(voxel_value > logodds_thres_max || voxel_value < logodds_thres_min){
      //         active = true;
      //         if(unknownVoxel){
      //           newVoxelCount++;
      //         }
      //       }else{
      //         active = false;
      //         // if(unknownVoxel){
      //         //   newVoxelCount++;
      //         // }
      //       }
      //   };
      //     // Integrating the data of the temporary grid into the map using the probability update functions
      //     for (openvdb::FloatGrid::ValueOnCIter iter = tempGrid->cbeginValueOn(); iter; ++iter)
      //     {
      //       tempValue = iter.getValue();
      //       if (tempValue!=0.0)
      //       {
      //         visitedLeafNodes.insert(map->knownAccessor()->touchLeaf(iter.getCoord()));
      //         map->knownAccessor()->modifyValueAndActiveState(iter.getCoord(), knownUpdate);
      //         map->occAccessor()->modifyValueAndActiveState(iter.getCoord(), update);
      //       }
      //     }
      //     voxelCount = newVoxelCount;
      //   }

      // //THIS METHOD UPDATES THE GRID USING THE BUFFER FROM THE GPU
      // void GymManager::voxelUpdateFromFrustumBuffer(std::shared_ptr<nanomap::map::Map> map,  int& voxelCount, std::set<LeafNodeT*>& visitedLeafNodes){
      //   int leafEdge = map->gridConfig()->leafEdge;
      //   int leafVolume = leafEdge*leafEdge*leafEdge;
      //   float logOddsHit = map->gridConfig()->logOddsHitThreshold;
      //   float logOddsMiss = map->gridConfig()->logOddsMissThreshold;
      //   float occClamp =  map->gridConfig()->occupiedClampingThreshold;
      //   float emptyClamp =  map->gridConfig()->emptyClampingThreshold;
      //   //std::cout << "loh = " << logOddsHit << " / lom = " << logOddsMiss << " / occClamp = " << occClamp << " / emptyClamp = " << emptyClamp << std::endl;
      //   float probeValue;
      //   float value;
      //   float targetActive = false;
      //   int newVoxelCount = 0;
      //   // auto update = [&log_hit_thres = logOddsHit,
      //   //                 &log_miss_thres = logOddsMiss,
      //   //                 &occ_clamp = occClamp,
      //   //                 &empty_clamp = emptyClamp,
      //   //                 &probe_value = probeValue,
      //   //                 &temp_value = value,
      //   //                 &voxel_count = voxelCount]
      //   //                 (float& voxel_value, bool& active) {
      //   //     bool unknownVoxel = false;
      //   //     if(voxel_value > log_miss_thres && voxel_value < log_hit_thres && active == false){
      //   //       //Voxel status is insufficiently explored
      //   //       unknownVoxel = true;
      //   //     }
            
      //   //     voxel_value += temp_value;
      //   //     if (voxel_value > occ_clamp){
      //   //       voxel_value = occ_clamp;
      //   //     }else if(voxel_value < empty_clamp){
      //   //       voxel_value = empty_clamp;
      //   //     }

      //   //     if(voxel_value > log_hit_thres){
      //   //       active = true;
      //   //       if(unknownVoxel){
      //   //         voxel_count++;
      //   //       }
      //   //     }else if(voxel_value < log_miss_thres){
      //   //       active = false;
      //   //       if(unknownVoxel){
      //   //         voxel_count++;
      //   //       }
      //   //     }
      //   // };
      //   auto update = [&logOddsHit = logOddsHit,
      //                   &logOddsMiss = logOddsMiss,
      //                   &occClamp = occClamp,
      //                   &emptyClamp = emptyClamp,
      //                   //&probeValue,
      //                   &value = value,
      //                   &newVoxelCount = newVoxelCount]
      //                   (float& voxel_value, bool& active) {
      //       // bool unknownVoxel = false;
      //       // //std::cout << voxel_value << std::endl;
      //       // if(voxel_value > logOddsMiss && voxel_value < logOddsHit && active == false){
      //       //   //Voxel status is insufficiently explored
      //       //   unknownVoxel = true;
      //       // }
      //       // if(unknownVoxel){
      //       //   std::cout << "unknownVoxel = " << (int)unknownVoxel << std::endl;
      //       //   std::cout << "Voxel Value = " << voxel_value << std::endl;
      //       //   std::cout << "logodds_thres_max = " << logOddsHit << std::endl;
      //       //   std::cout << "logodds_thres_min = " << logOddsMiss << std::endl;
      //       //   std::cout << "value = " << value << std::endl;
      //       //   std::cout << "Active = " << active << std::endl;
      //       // }
      //       voxel_value += value;
      //       if (voxel_value > occClamp){
      //         voxel_value = occClamp;
      //       }else if(voxel_value < emptyClamp){
      //         voxel_value = emptyClamp;
      //       }

      //       if(voxel_value > logOddsHit){
      //         active = true;
      //         // if(unknownVoxel){
      //         //   newVoxelCount++;
      //         // }
      //       }else if(voxel_value < logOddsMiss){
      //         active = false;
      //         // if(unknownVoxel){
      //         //   newVoxelCount++;
      //         // }
      //       }
      //   };


      //   auto knownUpdate = [&logOddsHit = logOddsHit,
      //                   &logOddsMiss = logOddsMiss,
      //                   &occClamp = occClamp,
      //                   &emptyClamp = emptyClamp,
      //                   //&probeValue,
      //                   &value = value,
      //                   &newVoxelCount = newVoxelCount]
      //                   (float& voxel_value, bool& active) {
      //       bool unknownVoxel = false;
      //       //std::cout << voxel_value << std::endl;
      //       if(active == false){
      //           //Voxel status is insufficiently explored
      //           unknownVoxel = true;
      //       }
      //       // if(unknownVoxel){
      //       //   std::cout << "unknownVoxel = " << (int)unknownVoxel << std::endl;
      //       //   std::cout << "Voxel Value = " << voxel_value << std::endl;
      //       //   std::cout << "logodds_thres_max = " << logOddsHit << std::endl;
      //       //   std::cout << "logodds_thres_min = " << logOddsMiss << std::endl;
      //       //   std::cout << "value = " << value << std::endl;
      //       //   std::cout << "Active = " << active << std::endl;
      //       // }
      //       voxel_value += value;
      //       if (voxel_value > occClamp){
      //         voxel_value = occClamp;
      //       }else if(voxel_value < emptyClamp){
      //         voxel_value = emptyClamp;
      //       }

      //       if(voxel_value > logOddsHit || voxel_value < logOddsMiss){
      //         active = true;
      //         if(unknownVoxel){
      //           newVoxelCount++;
      //         }
      //       }else{
      //         active = false;
      //       }
      //   };


        
      //   int nodeIndex, voxelIndex, voxelBufferIndex;
      //   int gpuFrustumLeafCount = _handler->getFrustumLeafCount();
      //   int* gpuFrustumLeafBuffer = _handler->getFrustumLeafBuffer();
      //   int8_t* gpuFrustumVoxelBuffer = _handler->getFrustumVoxelBuffer();
      //   //std::cout << gpuFrustumLeafCount: " << gpuFrustumLeafCount << std::endl;
      //   for(int i = 0; i < gpuFrustumLeafCount; i++){
      //     int nodeX = gpuFrustumLeafBuffer[i*3];
      //     int nodeY = gpuFrustumLeafBuffer[i*3+1];
      //     int nodeZ = gpuFrustumLeafBuffer[i*3+2];
      //     for(int x = 0; x < leafEdge; x++){
      //       for(int y = 0; y < leafEdge ; y++){
      //         for(int z = 0; z < leafEdge; z++){
      //           nodeIndex = i*leafVolume;
      //           voxelIndex = z+y*leafEdge + x*leafEdge*leafEdge;
      //           voxelBufferIndex = nodeIndex+voxelIndex;
      //           value = (float)(gpuFrustumVoxelBuffer[voxelBufferIndex])/100;
      //           //std::cout << "valueFromBuffer : " << value << std::endl;
      //           if(value != 0.0){
      //             //std::cout << "new info" << std::endl;
      //             visitedLeafNodes.insert(map->knownAccessor()->touchLeaf(openvdb::Coord(nodeX+x,nodeY+y,nodeZ+z)));
      //             map->knownAccessor()->modifyValueAndActiveState(openvdb::Coord(nodeX+x,nodeY+y,nodeZ+z), knownUpdate);
      //             map->occAccessor()->modifyValueAndActiveState(openvdb::Coord(nodeX+x,nodeY+y,nodeZ+z), update);
      //           }
      //         }
      //       }
      //     }
      //   }
      //   voxelCount = newVoxelCount;
      // }

      void GymManager::insertPointCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor, 
                                        std::shared_ptr<nanomap::map::Map> map,
                                                        bool serialUpdate,
                                                        int updateType,
                                                        int& voxelCount,
                                      std::vector<Eigen::Vector3f> targetPositions,
                                              std::vector<bool>& targetSeenStatus){
                    //std::cout << "incrementing voxelCount " << std::endl;
                    std::vector<openvdb::Coord> targetCoords;
                    if(targetPositions.size() > 0){
                      //convert positions to map coord space.
                      for(Eigen::Vector3f position : targetPositions){
                        openvdb::Vec3d worldVec = map->occupiedGrid()->worldToIndex(openvdb::Vec3d(position.x(), position.y(), position.z()));
                        targetCoords.push_back(openvdb::Coord(std::round(worldVec.x()),std::round(worldVec.y()),std::round(worldVec.z())));
                      }
                    }
                    int newVoxelCount = 0;
                    //For the given sensor, raycast the sensor information
                    std::set<LeafNodeT*> visitedLeafNodes;
                    if(sensor->sensorData()->sharedParameters()._type == 0){
                      //Perform GPU update
                      //No option for block update within gym currently, not implemented.
                      _handler->rayCastCloud(sensor);
                      voxelUpdateFromFrustumBuffer(map, newVoxelCount, visitedLeafNodes, targetCoords, targetSeenStatus);
                      
                    }else if(sensor->sensorData()->sharedParameters()._type == 1){
                      //insert point cloud CPU
                      insertPointCloudCPU(sensor, map, newVoxelCount, visitedLeafNodes,  targetCoords, targetSeenStatus);
                    }

                    updateSearchGrid(map, visitedLeafNodes);
                    voxelCount = newVoxelCount;
                    //std::cout << newVoxelCount << std::endl;
                  }


      void GymManager::updateSearchGrid(std::shared_ptr<nanomap::map::Map> map, std::set<LeafNodeT*>& visitedLeafNodes){
        int totalVoxelCount = 8*8*8;
        for(auto leafPointer : visitedLeafNodes){
          int knownVoxelCount = leafPointer->onVoxelCount();
          float knownRatio = (float)knownVoxelCount/(float)totalVoxelCount;
          openvdb::Coord leafOriginCoord;
          leafPointer->getOrigin(leafOriginCoord);
          //leafOriginCoord = leafOriginCoord + (openvdb::Coord(1,1,1));
          //std::cout << "leafIndexCoord = " << leafOriginCoord.x()<<" / " << leafOriginCoord.y()<<" / "<< leafOriginCoord.z() << std::endl;

          openvdb::Vec3d worldVec = map->knownGrid()->transform().indexToWorld(leafOriginCoord.asVec3d());
          //std::cout << "worldVec = " << worldVec.x() << " ; " << worldVec.y()<< " ; " << worldVec.z() << std::endl;
          //openvdb::Vec3d searchVec = 
          //std::cout << "searchIndexCoord = " << searchVec.x()<<" / " << searchVec.y()<<" / "<< searchVec.z() << std::endl;
          openvdb::Coord searchCoord = openvdb::Coord::round(map->searchGrid()->transform().worldToIndex(worldVec));
          //std::cout << "searchIndexCoord = " << searchCoord.x()<<" / " << searchCoord.y()<<" / "<< searchCoord.z() << std::endl;
          LeafNodeT* occupiedLeaf = map->occAccessor()->touchLeaf(leafOriginCoord);
          int hazardVoxelCount = occupiedLeaf->onVoxelCount();
          if(knownRatio > 0.8 || hazardVoxelCount > 0){
                    //         openvdb::Coord indexCoord = openvdb::Coord(iter.getCoord().x()/_plannerConfig->leafEdge, 
        //                                                   iter.getCoord().y()/_plannerConfig->leafEdge, 
        //                                                   iter.getCoord().z()/_plannerConfig->leafEdge);
        //         //In a tile/leaf, do planner map construction logic.
        //         //auto worldCoord = targetGrid->indexToWorld(iter.getCoord());
        //         //openvdb::Coord indexCoord = openvdb::Coord(std::floor(_plannerGrid->worldToIndex(worldCoord).x()),
        //         //                                          std::floor(_plannerGrid->worldToIndex(worldCoord).y()),
        //         //                                          std::floor(_plannerGrid->worldToIndex(worldCoord).z()));
            //openvdb::Coord indexCoord = leafPointer->getOrigin();

            // openvdb::Coord searchCoord = openvdb::Coord(indexCoord.x()/8, 
            //                               indexCoord.y()/8, 
            //                               indexCoord.z()/8);
            // //std::cout << "searchIndexCoord = " << searchCoord.x()<<" / " << searchCoord.y()<<" / "<< searchCoord.z() << std::endl;
            //auto worldSpaceCoord = map->knownGrid()->indexToWorld(indexCoord);
            // openvdb::Coord searchSpaceCoord = openvdb::Coord(std::floor(map->searchGrid()->worldToIndex(worldSpaceCoord).x()),
            //                                                  std::floor(map->searchGrid()->worldToIndex(worldSpaceCoord).y()),
            //                                                   std::floor(map->searchGrid()->worldToIndex(worldSpaceCoord).z()));
            map->searchAccessor()->setValueOn(searchCoord);
          }
        }
      }


      void GymManager::insertPointCloudCPU(std::shared_ptr<nanomap::sensor::Sensor> sensor,
                                        std::shared_ptr<nanomap::map::Map> map,
                                        int& voxelCount,
                                        std::set<LeafNodeT*>& visitedLeafNodes,
                                        std::vector<openvdb::Coord> targetCoords,
                                          std::vector<bool>& targetSeenStatus){
        openvdb::FloatGrid::Ptr tempGrid = openvdb::FloatGrid::create(0.0);
        //tempGrid->setTransform(openvdb::math::Transform::createLinearTransform(_config->mappingRes()));
        auto tempAcc = tempGrid->getAccessor();
        populateTempGrid(tempAcc, sensor, map->occupiedGrid(), map->occAccessor(), map->gridConfig());

        return integrateTempGrid(tempGrid, map, voxelCount, visitedLeafNodes, targetCoords, targetSeenStatus);
      }


      void GymManager::integrateTempGrid(openvdb::FloatGrid::Ptr tempGrid,
                                      std::shared_ptr<nanomap::map::Map> map,
                                      int& voxelCount,
                                      std::set<LeafNodeT*>& visitedLeafNodes,
                                      std::vector<openvdb::Coord> targetCoords,
                                          std::vector<bool>& targetSeenStatus){
          
          float emptyClampThres = map->gridConfig()->emptyClampingThreshold;
          float occClampThres = map->gridConfig()->occupiedClampingThreshold;
          float logodds_thres_min = map->gridConfig()->logOddsMissThreshold;
          float logodds_thres_max = map->gridConfig()->logOddsHitThreshold;
          float tempValue;
          int newVoxelCount = 0;
          //voxelCount = 0;
          // Probability update lambda for occupied grid elements
          // auto update = [&prob_thres_max = logodds_thres_max, &prob_thres_min = logodds_thres_min,
          //   &occ_clamp = occClampThres, &empty_clamp = emptyClampThres, &temp_value = tempValue, &voxel_count = voxelCount](float& voxel_value,
          //                                                                               bool& active) {
          //   bool unknownVoxel = false;
          //   if(voxel_value > prob_thres_min && voxel_value < prob_thres_max && active == false){
          //     //Voxel status is insufficiently explored
          //     unknownVoxel = true;
          //   }
            
          //   voxel_value += temp_value;
          //   if (voxel_value > occ_clamp)
          //   {
          //     voxel_value = occ_clamp;
          //   }else if(voxel_value < empty_clamp){
          //     voxel_value = empty_clamp;
          //   }

          //   if(voxel_value > prob_thres_max){
          //     active = true;
          //     if(unknownVoxel){
          //       voxel_count++;
          //     }
          //   }else if(voxel_value < prob_thres_min){
          //     active = false;
          //     if(unknownVoxel){
          //       voxel_count++;
          //     }
          //   }
          // };
                    // Probability update lambda for occupied grid elements
          auto update = [&logodds_thres_max = logodds_thres_max, 
                          &logodds_thres_min = logodds_thres_min,
                          &occClampThres = occClampThres, 
                          &emptyClampThres = emptyClampThres, 
                          &tempValue = tempValue, 
                          &newVoxelCount = newVoxelCount](float& voxel_value,
                                                                                        bool& active) {
            //bool unknownVoxel = false;
            // std::cout << "Voxel Value = " << voxel_value << std::endl;
            // std::cout << "logodds_thres_max = " << logodds_thres_max << std::endl;
            // std::cout << "logodds_thres_min = " << logodds_thres_min << std::endl;
            // std::cout << "Active = " << active << std::endl;
            // if(voxel_value > logodds_thres_min && voxel_value < logodds_thres_max && active == false){
            //   //Voxel status is insufficiently explored
            //   unknownVoxel = true;
            // }
            //std::cout << "unknownVoxel = " << (int)unknownVoxel << std::endl;
            voxel_value += tempValue;
            if (voxel_value > occClampThres)
            {
              voxel_value = occClampThres;
            }else if(voxel_value < emptyClampThres){
              voxel_value = emptyClampThres;
            }

            if(voxel_value > logodds_thres_max){
              active = true;
              // if(unknownVoxel){
              //   newVoxelCount++;
              // }
            }else if(voxel_value < logodds_thres_min){
              active = false;
              // if(unknownVoxel){
              //   newVoxelCount++;
              // }
            }
          };
             auto knownUpdate = [&logodds_thres_max = logodds_thres_max, 
                          &logodds_thres_min = logodds_thres_min,
                          &occClampThres = occClampThres, 
                          &emptyClampThres = emptyClampThres, 
                          &tempValue = tempValue, 
                          &newVoxelCount = newVoxelCount](float& voxel_value,
                                                                                        bool& active) {
            bool unknownVoxel = false;
            //std::cout << voxel_value << std::endl;
            if(active == false){
                //Voxel status is insufficiently explored
                unknownVoxel = true;
            }
            // if(unknownVoxel){
            //   std::cout << "unknownVoxel = " << (int)unknownVoxel << std::endl;
            //   std::cout << "Voxel Value = " << voxel_value << std::endl;
            //   std::cout << "logodds_thres_max = " << logOddsHit << std::endl;
            //   std::cout << "logodds_thres_min = " << logOddsMiss << std::endl;
            //   std::cout << "value = " << value << std::endl;
            //   std::cout << "Active = " << active << std::endl;
            // }
                        voxel_value += tempValue;
            if (voxel_value > occClampThres)
            {
              voxel_value = occClampThres;
            }else if(voxel_value < emptyClampThres){
              voxel_value = emptyClampThres;
            }

            if(voxel_value > logodds_thres_max || voxel_value < logodds_thres_min){
              active = true;
              if(unknownVoxel){
                newVoxelCount++;
              }
            }else{
              active = false;
              // if(unknownVoxel){
              //   newVoxelCount++;
              // }
            }
        };
          // Integrating the data of the temporary grid into the map using the probability update functions
          for (openvdb::FloatGrid::ValueOnCIter iter = tempGrid->cbeginValueOn(); iter; ++iter)
          {
            tempValue = iter.getValue();
            if (tempValue!=0.0)
            {
              //We have information about this cell! so if there is a target there, we can assume it is seen.
              if(targetCoords.size() > 0){
                int index = 0;
                for(auto coord : targetCoords){
                  if(coord == iter.getCoord()){
                    targetSeenStatus[index] = true;
                  }
                  index++;
                }
              }
              visitedLeafNodes.insert(map->knownAccessor()->touchLeaf(iter.getCoord()));
              map->knownAccessor()->modifyValueAndActiveState(iter.getCoord(), knownUpdate);
              map->occAccessor()->modifyValueAndActiveState(iter.getCoord(), update);
            }
          }
          voxelCount = newVoxelCount;
        }

      //THIS METHOD UPDATES THE GRID USING THE BUFFER FROM THE GPU
      void GymManager::voxelUpdateFromFrustumBuffer(std::shared_ptr<nanomap::map::Map> map,  
                                                                            int& voxelCount, 
                                                    std::set<LeafNodeT*>& visitedLeafNodes,
                                                    std::vector<openvdb::Coord> targetCoords,
                                                    std::vector<bool>& targetSeenStatus){
        int leafEdge = map->gridConfig()->leafEdge;
        int leafVolume = leafEdge*leafEdge*leafEdge;
        float logOddsHit = map->gridConfig()->logOddsHitThreshold;
        float logOddsMiss = map->gridConfig()->logOddsMissThreshold;
        float occClamp =  map->gridConfig()->occupiedClampingThreshold;
        float emptyClamp =  map->gridConfig()->emptyClampingThreshold;
        //std::cout << "loh = " << logOddsHit << " / lom = " << logOddsMiss << " / occClamp = " << occClamp << " / emptyClamp = " << emptyClamp << std::endl;
        float probeValue;
        float value;
        float targetActive = false;
        int newVoxelCount = 0;

        auto update = [&logOddsHit = logOddsHit,
                        &logOddsMiss = logOddsMiss,
                        &occClamp = occClamp,
                        &emptyClamp = emptyClamp,
                        //&probeValue,
                        &value = value,
                        &newVoxelCount = newVoxelCount]
                        (float& voxel_value, bool& active) {

            voxel_value += value;
            if (voxel_value > occClamp){
              voxel_value = occClamp;
            }else if(voxel_value < emptyClamp){
              voxel_value = emptyClamp;
            }

            if(voxel_value > logOddsHit){
              active = true;
              // if(unknownVoxel){
              //   newVoxelCount++;
              // }
            }else if(voxel_value < logOddsMiss){
              active = false;
              // if(unknownVoxel){
              //   newVoxelCount++;
              // }
            }
        };


        auto knownUpdate = [&logOddsHit = logOddsHit,
                        &logOddsMiss = logOddsMiss,
                        &occClamp = occClamp,
                        &emptyClamp = emptyClamp,
                        //&probeValue,
                        &value = value,
                        &newVoxelCount = newVoxelCount]
                        (float& voxel_value, bool& active) {
            bool unknownVoxel = false;
            //std::cout << voxel_value << std::endl;
            if(active == false){
                //Voxel status is insufficiently explored
                unknownVoxel = true;
            }

            voxel_value += value;
            if (voxel_value > occClamp){
              voxel_value = occClamp;
            }else if(voxel_value < emptyClamp){
              voxel_value = emptyClamp;
            }

            if(voxel_value > logOddsHit || voxel_value < logOddsMiss){
              active = true;
              if(unknownVoxel){
                newVoxelCount++;
              }
            }else{
              active = false;
            }
        };


        
        int nodeIndex, voxelIndex, voxelBufferIndex;
        int gpuFrustumLeafCount = _handler->getFrustumLeafCount();
        int* gpuFrustumLeafBuffer = _handler->getFrustumLeafBuffer();
        int8_t* gpuFrustumVoxelBuffer = _handler->getFrustumVoxelBuffer();
        for(int i = 0; i < gpuFrustumLeafCount; i++){
          int nodeX = gpuFrustumLeafBuffer[i*3];
          int nodeY = gpuFrustumLeafBuffer[i*3+1];
          int nodeZ = gpuFrustumLeafBuffer[i*3+2];
          for(int x = 0; x < leafEdge; x++){
            for(int y = 0; y < leafEdge ; y++){
              for(int z = 0; z < leafEdge; z++){
                nodeIndex = i*leafVolume;
                voxelIndex = z+y*leafEdge + x*leafEdge*leafEdge;
                voxelBufferIndex = nodeIndex+voxelIndex;
                value = (float)(gpuFrustumVoxelBuffer[voxelBufferIndex])/100;
                if(value != 0.0){
                  openvdb::Coord valueCoord(nodeX+x, nodeY+y, nodeZ+z);
                  if(targetCoords.size() > 0){
                    int index = 0;
                    for(auto coord : targetCoords){
                      if(coord == valueCoord){
                        targetSeenStatus[index] = true;
                      }
                      index++;
                    }
                  }
                  visitedLeafNodes.insert(map->knownAccessor()->touchLeaf(valueCoord));
                  map->knownAccessor()->modifyValueAndActiveState(valueCoord, knownUpdate);
                  map->occAccessor()->modifyValueAndActiveState(valueCoord, update);
                }
              }
            }
          }
        }
        voxelCount = newVoxelCount;
      }


      void GymManager::simulateAgentSearch(std::shared_ptr<nanomap::map::Map> map,std::shared_ptr<nanomap::manager::PlannerManager> plannerManager, Eigen::Vector3f position){
        std::vector<openvdb::Coord> listOfNodesToSearch = plannerManager->getClusterSearchCoords(position);
        auto simAcc = _simGrid->getAccessor();
        for(auto coord : listOfNodesToSearch){
          if(!(map->searchAccessor()->isValueOn(coord))){
            //This coord hasn't been searched.
            //Lets 'search' it. 
            //first we get the sim/occ/known grid coord
            openvdb::Coord occCoord = openvdb::Coord(coord.x()*8, coord.y()*8, coord.z()*8);
            //for this crude simulation, we just copy the leaf node from the sim grid into the correspond occupied grid,
            //LeafNodeT* simLeafNodePtr = simAcc.touchLeaf(occCoord);
            map->occAccessor()->touchLeaf(occCoord)->fill(1.0, true);
            //Then we activate the search grid
            map->searchAccessor()->setValueOn(coord);
          }
        }
      }

      void GymManager::simulateAgentSearch(std::shared_ptr<nanomap::map::Map> map,std::shared_ptr<nanomap::manager::PlannerManager> plannerManager, int cluster){
        std::vector<openvdb::Coord> listOfNodesToSearch = plannerManager->getClusterCoords(cluster);
        auto simAcc = _simGrid->getAccessor();
        for(auto coord : listOfNodesToSearch){
          if(!(map->searchAccessor()->isValueOn(coord))){
            //This coord hasn't been searched.
            //Lets 'search' it. 
            //first we get the sim/occ/known grid coord
            openvdb::Coord occCoord = openvdb::Coord(coord.x()*8, coord.y()*8, coord.z()*8);
            //for this crude simulation, we just copy the leaf node from the sim grid into the correspond occupied grid,
            //LeafNodeT* simLeafNodePtr = simAcc.touchLeaf(occCoord);
            map->occAccessor()->touchLeaf(occCoord)->fill(1.0, true);
            //Then we activate the search grid
            map->searchAccessor()->setValueOn(coord);
          }
        }
      }



    } //manager namepsace
} //nanomap namespace
