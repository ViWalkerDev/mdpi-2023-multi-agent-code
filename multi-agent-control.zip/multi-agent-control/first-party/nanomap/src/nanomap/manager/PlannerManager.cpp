// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file PlannerManager.cpp
///
/// @author Violet Walker
///
#include "nanomap/manager/PlannerManager.h"


namespace nanomap{
    namespace manager{

      // PlannerManager::PlannerManager(){}


//PUBLIC METHODS

      PlannerManager::PlannerManager(std::shared_ptr<nanomap::config::Config> config)
      : _handler(nullptr), _config(config), _plannerObjects(std::make_shared<nanomap::map::PlannerObjects>()),
      _plannerConfig(std::make_shared<nanomap::planner::GPUInfo>(nanomap::planner::GPUInfo(config->gridRes(),
                                                                                           config->mappingRes(),
                                                                                           config->plannerRes(),
                                                                                           config->leafEdge())))
      {startTime = std::time(0);}

    
    std::vector<Eigen::Vector3f> PlannerManager::getWorldPathToClusterFromWorldPosition(int clusterIndex, Eigen::Vector3f position){
      //std::cout << "clusterIndex = " << clusterIndex <<  std::endl;
      int globalPositionIndex = getGlobalIndexFromCoord(getPlannerCoordFromWorldVec(openvdb::Vec3d(position.x(), position.y(), position.z())));
      std::vector<int> indexPath = pathBetweenNodeAndCluster(globalPositionIndex, clusterIndex);
      std::vector<Eigen::Vector3f> eigenPath = getEigenPathFromGlobalIndexPath(indexPath);
      // std::vector<int> clusterBoundaries = 
      for(auto boundaryPoint : _plannerObjects->boundaryPoints[clusterIndex]){
        eigenPath.push_back((boundaryPoint));
      }
      // std::cout << "transitGoals = " << std::endl;
      // for(int x = 0; x < eigenPath.size(); x++){
      //   std::cout << eigenPath[x].x() << " / " << eigenPath[x].y() << " / " << eigenPath[x].z() << std::endl;
      // }
      return eigenPath;
    }

    Eigen::Vector3f PlannerManager::getDestinationBoundaryPoint(int currentCluster, int targetCluster){
      for(auto neighbourEntry : _plannerObjects->clusterGraph[currentCluster]){
          if(neighbourEntry.first == targetCluster){
            int targetClusterBoundary = _plannerObjects->clusterBoundaryPoints[targetCluster][neighbourEntry.second[0].second];
            return getPositionFromGlobalIndex(targetClusterBoundary);
          }
      }
    }

    std::vector<int> PlannerManager::checkSearchTargets(std::vector<Eigen::Vector3f> searchTargets, std::shared_ptr<nanomap::map::Map> map){
      int targetIndex = 0;
      std::vector<int> searchCompletion;
      for(auto target : searchTargets){
        int globalIndex = getGlobalIndexFromPosition(target);
        // std::cout << "cheackSearchposition = " << target.x() << "/" << target.y() << "/"<< target.z() << std::endl;
        // std::cout << "globalIndex = " << globalIndex << std::endl;

        openvdb::Coord plannerCoord = getCoordFromGlobalIndex(globalIndex);
        if((map->searchAccessor()->isValueOn(plannerCoord))){
          //target is searched
          searchCompletion.push_back(targetIndex);
        }
        targetIndex++;
      }
      return searchCompletion;
    }
    

    std::vector<Eigen::Vector3f> PlannerManager::getClusterSearchNodesInWorld(int clusterIndex){
      //std::vector<Eigen::Vector3f> clusterSearchNodes;
      std::vector<int> clusterSpaceNodes = _plannerObjects->clusterSearchNodes[clusterIndex];
      std::vector<int> globalSpace = getGlobalPathFromClusterPath(clusterIndex, clusterSpaceNodes);
      std::vector<Eigen::Vector3f> eigenPath = getEigenPathFromGlobalIndexPath(globalSpace);
      //for(int x = 0; x < eigenPath; )
      return eigenPath;
    }

    float PlannerManager::getDistanceToClusterFromGlobalIndex(int clusterIndex, int globalIndex){
      std::vector<int> boundaryPoints = _plannerObjects->clusterBoundaryPoints[clusterIndex];
      float minDist = FLT_MAX;
      for(int clusterBoundary : boundaryPoints){
        float dist = getShortestPathAndScore(globalIndex, clusterBoundary).first;
        if(minDist > dist){
          minDist = dist;
        }
      }
      return minDist;
    }

    float PlannerManager::getDistanceToClusterFromPosition(int clusterIndex, Eigen::Vector3f position){
      int globalPositionIndex = getGlobalIndexFromPosition(position);
      return getDistanceToClusterFromGlobalIndex(clusterIndex, globalPositionIndex);
    }

    std::vector<int> PlannerManager::getClusterSearchPathFromBoundary(int clusterIndex, int clusterNodeStart){
      return _plannerObjects->clusterSearchPaths[clusterIndex][std::make_pair(clusterNodeStart, clusterNodeStart)];
    }

    std::vector<Eigen::Vector3f> PlannerManager::getWorldSearchGoalsFromPosition(Eigen::Vector3f position){
      int globalPositionIndex = getGlobalIndexFromCoord(getPlannerCoordFromWorldVec(openvdb::Vec3d(position.x(), position.y(), position.z())));
      int clusterIndex = _plannerObjects->globalClusterMap[globalPositionIndex];
      return getClusterSearchNodesInWorld(clusterIndex);
    }

    std::vector<Eigen::Vector3f> PlannerManager::getWorldSearchGoalsForCluster(int clusterIndex){
      return getClusterSearchNodesInWorld(clusterIndex);
    }

    void PlannerManager::calculateBoundaryPointAverages(){
      _boundaryPointAverages.clear();
      for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
        int numBounds = _plannerObjects->clustersSafe[x].size();
        Eigen::Vector3f averagePoint = Eigen::Vector3f(0.0,0.0,0.0);
        for(int clusterBoundaryPoint : _plannerObjects->clustersSafe[x]){
          averagePoint = averagePoint + getPositionFromGlobalIndex(clusterBoundaryPoint);
        }
        averagePoint = averagePoint/numBounds;
        _boundaryPointAverages.push_back(averagePoint);
        // std::vector<int> clusterBoundaryPoints = _plannerObjects->clusterBoundaryPoints[x];
        // int numBounds = clusterBoundaryPoints.size();
        // Eigen::Vector3f averagePoint = Eigen::Vector3f(0.0,0.0,0.0);
        // for(int clusterBoundaryPoint : clusterBoundaryPoints){
        //   averagePoint = averagePoint + getPositionFromGlobalIndex(clusterBoundaryPoint);
        // }
        // averagePoint = averagePoint/numBounds;
        // _boundaryPointAverages.push_back(averagePoint);
      }
    }



    Eigen::Vector3f PlannerManager::getClusterBoundaryAverage(int cluster){
      return _boundaryPointAverages[cluster];
    }

    std::vector<Eigen::Vector3f> PlannerManager::getWorldSearchPathForClusterFromPosition(Eigen::Vector3f position){
      //NEED TO REDO, CURRENTLY NOT FUNCTIONAL
      int globalPositionIndex = getGlobalIndexFromCoord(getPlannerCoordFromWorldVec(openvdb::Vec3d(position.x(), position.y(), position.z())));
      int clusterIndex = _plannerObjects->globalClusterMap[globalPositionIndex];
      int clusterNodeStart = _plannerObjects->globalClusterNodeMap[globalPositionIndex];
      //std::vector<int> clusterSearchNodes = sampleClusterForSearch(clusterIndex);
      //std::vector<int> clusterPathFromStart = clusterPathFromStart(clusterIndex, clusterNodeStart, clusterSearchNodes);
      std::vector<int> clusterPath = getClusterSearchPathFromBoundary(clusterIndex, clusterNodeStart);
      std::vector<int> globalPath = getGlobalPathFromClusterPath(clusterIndex, clusterPath);
      std::vector<Eigen::Vector3f> eigenPath = getEigenPathFromGlobalIndexPath(globalPath);
      return eigenPath;
    }

    std::vector<int> PlannerManager::getClusterNeighbours(int currentCluster){
      std::vector<int> clusterNeighbours;
      for(auto neighbourEntry : _plannerObjects->clusterGraph[currentCluster]){
        clusterNeighbours.push_back(neighbourEntry.first);
      }
      return clusterNeighbours;
    }
    
    int PlannerManager::getGlobalIndexFromPosition(Eigen::Vector3f position){
      return getGlobalIndexFromCoord(getPlannerCoordFromWorldVec(openvdb::Vec3d(position.x(), position.y(), position.z())));
    }
    
    int  PlannerManager::getNearestClusterFromList(Eigen::Vector3f position, std::vector<int> clusterList){
      int nearestCluster = -1;
      float distanceToCluster = FLT_MAX;
      int globalPositionIndex = getGlobalIndexFromCoord(getPlannerCoordFromWorldVec(openvdb::Vec3d(position.x(), position.y(), position.z())));
      for(int cluster : clusterList){
        float dist = getDistanceToClusterFromGlobalIndex(cluster, globalPositionIndex);
        if(dist < distanceToCluster){
            nearestCluster = cluster;
            distanceToCluster = dist;
        }
      }      
      return nearestCluster;
    }
    

    // std::pair<openvdb::Vec3d, openvdb::Vec3d> getVecBoundingBoxForClusterNode(clusterIndex, clusterNodeIndex){
    //   int globalIndex = _plannerObjects->clustersSafe[clusterIndex][clusterNodeIndex];
    //   openvdb::Vec3d globalVec = getCoordFromGlobalIndex(globalIndex).asVec3d();
    //   openvdb::Vec3d minVec = _plannerMap->plannerGrid()->transform().indexToWorld(globalVec);
    //   openvdb::Vec3d maxVec = _plannerMap->plannerGrid()->transform().indexToWorld(globalVec + openvdb::Vec3d(1.0,1.0,1.0));
    //   return std::make_pair(minVec, maxVec);
    // }

    std::vector<openvdb::Coord> PlannerManager::getClusterSearchCoords(Eigen::Vector3f position){
       int globalPositionIndex = getGlobalIndexFromPosition(position);
      int clusterIndex = _plannerObjects->globalClusterMap[globalPositionIndex];
      int clusterNodeIndex = _plannerObjects->globalClusterNodeMap[globalPositionIndex];
      std::vector<int> searchTargets = _plannerObjects->clusterSearchInfo[clusterIndex][clusterNodeIndex];
      std::vector<openvdb::Coord> targetCoords;
      for(int target : searchTargets){
        targetCoords.push_back(getCoordFromGlobalIndex(_plannerObjects->clustersSafe[clusterIndex][target]));
      }
      return targetCoords;
    }

    std::vector<openvdb::Coord> PlannerManager::getClusterCoords(int cluster){
       //int globalPositionIndex = getGlobalIndexFromPosition(position);
      //int clusterIndex = _plannerObjects->globalClusterMap[globalPositionIndex];
      //int clusterNodeIndex = _plannerObjects->globalClusterNodeMap[globalPositionIndex];
      std::vector<int> searchTargets = _plannerObjects->clustersSafe[cluster];
      std::vector<openvdb::Coord> targetCoords;
      for(int target : searchTargets){
        targetCoords.push_back(getCoordFromGlobalIndex(target));
      }
      return targetCoords;
    }





std::map<float, Eigen::Vector3f> PlannerManager::getSearchClusterTargetsByDistanceAndGoal(Eigen::Vector3f position, 
                                                                                            int _currentCluster, 
                                                                                            Eigen::Vector3f _clusterGoal,
                                                                        std::shared_ptr<nanomap::map::Map> map){
      std::map<float, Eigen::Vector3f> searchClusterMap;
      int globalGoalIndex = getGlobalIndexFromPosition(_clusterGoal);
      int clusterSpaceGoal = _plannerObjects->globalClusterNodeMap[globalGoalIndex];
      std::vector<int> clusterSpaceSearchTargets = _plannerObjects->clusterSearchInfo[_currentCluster][clusterSpaceGoal];
      std::vector<int> searchTargets = getGlobalPathFromClusterPath(_currentCluster, clusterSpaceSearchTargets);
      //std::vector<int> searchTargets = _plannerObjects->clustersSafe[_currentCluster];
      for(int globalIndex : searchTargets){
        openvdb::Coord plannerCoord = getCoordFromGlobalIndex(globalIndex);
        if(!(map->searchAccessor()->isValueOn(plannerCoord))){
          //node is unsearched, add it to the cluster targets by distance
          openvdb::Vec3d worldCoord = _plannerMap->plannerGrid()->transform().indexToWorld(plannerCoord.asVec3d() + openvdb::Vec3d(0.5,0.5,0.5));
          EigenVec targetPosition = EigenVec(worldCoord.x(), worldCoord.y(), worldCoord.z());
          float dist = getDistanceBetweenPositions(position, targetPosition);
          searchClusterMap.insert(std::make_pair(dist, targetPosition));
        }
      }
      return searchClusterMap;
    }

    std::map<float, Eigen::Vector3f> PlannerManager::getSearchClusterTargetsByDistance(Eigen::Vector3f position, 
                                                                                            int _currentCluster, 
                                                                        std::shared_ptr<nanomap::map::Map> map){
      std::map<float, Eigen::Vector3f> searchClusterMap;
      std::vector<int> searchTargets = _plannerObjects->clustersSafe[_currentCluster];
      // std::cout << "searchTargets size = " <<searchTargets.size() << std::endl;
      // std::cout << "clusterIndex " << _currentCluster << std::endl;
      for(int globalIndex : searchTargets){
          //std::cout << "initial searchtargets globalIndex = " << globalIndex << std::endl;

        openvdb::Coord plannerCoord = getCoordFromGlobalIndex(globalIndex);

        openvdb::Vec3d worldCoord = _plannerMap->plannerGrid()->transform().indexToWorld(plannerCoord.asVec3d() + openvdb::Vec3d(0.5,0.5,0.5));
        EigenVec targetPosition = EigenVec(worldCoord.x(), worldCoord.y(), worldCoord.z());
        //std::cout << "init search targets position = " << targetPosition.x() << "/" << targetPosition.y() << "/"<< targetPosition.z() << std::endl;
        if(!(map->searchAccessor()->isValueOn(plannerCoord))){
          //node is unsearched, add it to the cluster targets by distance
          
          float dist = getDistanceBetweenPositions(position, targetPosition);
          searchClusterMap.insert(std::make_pair(dist, targetPosition));
        }
      }
      // std::cout << "searchCLusterMap size before return = " << searchClusterMap.size();
      return searchClusterMap;
    }

    int PlannerManager::closestUnsearchedCluster(Eigen::Vector3f position, std::vector<bool> searchedClusters){
      float minDist = FLT_MAX;
      int clusterIndex = 0;
      std::vector<int> clusterList;
      for(bool searchStatus : searchedClusters){
        if(!searchStatus){
          clusterList.push_back(clusterIndex); 
        }
        clusterIndex++;
      }
      return getNearestClusterFromList(position, clusterList);
    }

    std::map<float, Eigen::Vector3f> PlannerManager::sortSearchClusterTargetsByDistance(Eigen::Vector3f position, 
                                      std::map<float, Eigen::Vector3f> searchTargetsMap,
                                                  std::vector<int> searchCompletion,
                                        std::vector<Eigen::Vector3f> searchTargets){
      float dist;
      std::map<float, Eigen::Vector3f> newMap;
      for(auto mapPair : searchTargetsMap){
        Eigen::Vector3f target = mapPair.second;
        bool isSearched = false;
        for(auto searchTarget : searchTargets){
          //std::cout << "searchCompletion Index = " << index << std::endl;
          if(target == searchTarget){
            isSearched = true;
          }
        }
        if(!isSearched){
          dist = getDistanceBetweenPositions(position, target);
          newMap.insert(std::make_pair(dist, target));
        }
      }
      return newMap;
    }

    bool PlannerManager::isSearchGoalComplete(Eigen::Vector3f goalPosition, std::shared_ptr<nanomap::map::Map> map){
      bool goalComplete = false;
      //std::cout << " 1 " << std::endl;
      int globalPositionIndex = getGlobalIndexFromPosition(goalPosition);
      //std::cout << " 1 " << std::endl;
      int clusterIndex = _plannerObjects->globalClusterMap[globalPositionIndex];
      //std::cout << " 1 " << std::endl;
      int clusterNodeIndex = _plannerObjects->globalClusterNodeMap[globalPositionIndex];
      //std::cout << " 1 " << std::endl;
      std::vector<int> searchTargets = _plannerObjects->clusterSearchInfo[clusterIndex][clusterNodeIndex];
      //std::set<openvdb::Coord> searchedTiles = _searchedTiles;
      //std::cout << " 1 " << std::endl;
      int numTargets = searchTargets.size();
      //std::cout << " 1 " << std::endl;
      int searchedCount = 0;
      //std::cout << " 1 " << std::endl;
      auto searchAcc = map->searchGrid()->getAccessor();
      for(int target : searchTargets){
        //std::cout << "Before getCoordFromGlobalINdex" << std::endl;
        openvdb::Coord targetCoord = getCoordFromGlobalIndex(_plannerObjects->clustersSafe[clusterIndex][target]);
        //std::cout << "trying to access search accessor" << std::endl;

        if(searchAcc.isValueOn(targetCoord)){
          searchedCount++;
        }
        //std::cout << "We could access the search accessor " << std::endl;
      }
      //std::cout << "wefinished? " << std::endl;
      if((float)searchedCount/(float)numTargets > 0.85){
        goalComplete = true;
      }
      return goalComplete;
    }


    bool PlannerManager::isClusterSearchComplete(int cluster, std::shared_ptr<nanomap::map::Map> map){
      bool goalComplete = false;
      //std::cout << " 1 " << std::endl;
      int clusterIndex = cluster;
      //std::cout << " 1 " << std::endl;
      //std::cout << " 1 " << std::endl;
      std::cout << "clusterIndex " << cluster << std::endl;
      std::vector<int> searchTargets = _plannerObjects->clustersSafe[clusterIndex];
      //std::set<openvdb::Coord> searchedTiles = _searchedTiles;
      //std::cout << " 1 " << std::endl;
      int numTargets = searchTargets.size();
      //std::cout << " 1 " << std::endl;
      int searchedCount = 0;
      //std::cout << " 1 " << std::endl;
      
      for(int target : searchTargets){
        //std::cout << "Before getCoordFromGlobalINdex" << std::endl;
        openvdb::Coord targetCoord = getCoordFromGlobalIndex(target);
        //std::cout << "trying to access search accessor" << std::endl;

        if(map->searchAccessor()->isValueOn(targetCoord)){
          searchedCount++;
        }
        //std::cout << "We could access the search accessor " << std::endl;
      }
      //std::cout << "wefinished? " << std::endl;
      std::cout << "searchedCount = " << searchedCount << std::endl;
      std::cout << "numTargets = " << numTargets << std::endl;
      if((float)searchedCount/(float)numTargets > 0.9){
        goalComplete = true;
      }
      return goalComplete;
    }

      //For each search target, check the corresponding tile. If less than 10% are background values,
      //we consider the tile searched. 
      //If 80% of all the targets are searched, we consider that enough.
        // using GridType = openvdb::FloatGrid;
        // using FloatTreeT = GridType::TreeType;
        // using RootType = FloatTreeT::RootNodeType;   // level 3 RootNode
        // //assert(RootType::LEVEL == 3);
        // using Int1Type = RootType::ChildNodeType;  // level 2 InternalNode
        // using Int2Type = Int1Type::ChildNodeType;  // level 1 InternalNode
        // using LeafType = FloatTreeT::LeafNodeType;
        // //std::cout << "ASDJNQWKJDNQWDJNQWDKJNQWKDJWQND" << std::endl;
        // //auto gridAccessor = targetGrid->getAccessor();
        // float gridRes = (float)((targetGrid->voxelSize())[0]);
        // int index = 1;
        // int safeCount = 0;
        // int validCount = 0;
        // //std::cout << "HERERERERERERERERERE" << std::endl;
        // //std::cout << "plannerRes " << _plannerRes <<std::endl;
        // //std::cout << "tileEdge " << _tileEdge <<std::endl;
        // //std::cout << "gridRes " << _gridRes <<std::endl;
        // //std::cout << "plannerRes/tileEdge" << _plannerRes/_tileEdge <<std::endl;
        // if(_plannerConfig->plannerRes/_plannerConfig->leafEdge == gridRes){
        //   //std::cout << "tile logic" << std::endl;
        //   _plannerConfig->useTileLogic = true;
        // }
        // if(_plannerConfig->useTileLogic){
        //   FloatTreeT::NodeIter iter{targetGrid->tree()};
        //   //int depth = grid->tree().treeDepth();
        //   //grid_info->node_counts_.clear();
        //   //grid_info->node_counts_.resize(depth,0);
        //   //node_info->active_counts_.resize(depth,0);
        //   //node_info->inactive_counts_.resize(depth,0);
        //   for ( ; iter; ++iter) {
        //   //if we are in a leaf node perform leaf/tile logic for building planner map
        //     if(iter.getDepth()==3){
        //       LeafType* node = nullptr;
        //       iter.getNode(node);
        //       if (node){
        //         //std::cout << "Node Bounds" << std::endl;
        //         //std::cout << node->getNodeBoundingBox() << std::endl;
        //         //std::cout << "Node Coord" << std::endl;
        //         //std::cout << iter.getCoord() << std::endl;

        //         openvdb::Coord indexCoord = openvdb::Coord(iter.getCoord().x()/_plannerConfig->leafEdge, 
        //                                                   iter.getCoord().y()/_plannerConfig->leafEdge, 
        //                                                   iter.getCoord().z()/_plannerConfig->leafEdge);
        //         //In a tile/leaf, do planner map construction logic.
        //         //auto worldCoord = targetGrid->indexToWorld(iter.getCoord());
        //         //openvdb::Coord indexCoord = openvdb::Coord(std::floor(_plannerGrid->worldToIndex(worldCoord).x()),
        //         //                                          std::floor(_plannerGrid->worldToIndex(worldCoord).y()),
        //         //                                          std::floor(_plannerGrid->worldToIndex(worldCoord).z()));
        //         //std::cout << "Voxel Count = "<<node->onVoxelCount() << std::endl;
        //         if(node->onVoxelCount()==0){

        //           //this is a safe leaf node
        //           safeAcc.setValueOn(indexCoord);
        //           _plannerMap->plannerAccessor()->setValue(indexCoord,index);
        //           safeCount+=1;
        //         }else{
        //           _plannerMap->plannerAccessor()->setValue(indexCoord,-1*index);
        //           //this is a non-safe but potentially still valid leaf node.
        //         }
        //         index += 1;
        //         validCount+=1;
        //       }
        //     }
        //   }
        // }//else{


    //}

    std::vector<Eigen::Vector3f> PlannerManager::generateRandomTargetPositions(int numTargets){
      std::vector<Eigen::Vector3f> targetPositions;
      for(int x = 0; x < numTargets; x++){
        int safeIndex = rand()%(_plannerObjects->safeCount);
        int globalIndex = _handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[safeIndex];
        openvdb::Vec3d globalVec = getCoordFromGlobalIndex(globalIndex).asVec3d();
        openvdb::Vec3d worldCoord = _plannerMap->plannerGrid()->transform().indexToWorld(globalVec + openvdb::Vec3d(0.5,0.5,0.5));
        targetPositions.push_back(EigenVec(worldCoord.x(), worldCoord.y(), worldCoord.z()));
      }
      return targetPositions;
    }

    int PlannerManager::getClusterFromPosition(Eigen::Vector3f position){
      int globalPositionIndex = getGlobalIndexFromCoord(getPlannerCoordFromWorldVec(openvdb::Vec3d(position.x(), position.y(), position.z())));
      int clusterIndex = _plannerObjects->globalClusterMap[globalPositionIndex];
      return clusterIndex;
    }

    std::vector<int> PlannerManager::getUniformOccupancy(){
      std::vector<int> occupancy;
      for(int x = 0; x < _plannerObjects->clustersSafe.size(); x++){
        occupancy.push_back(_plannerObjects->clustersSafe[x].size());
      }
      return occupancy;
    }

    void PlannerManager::calculateClusterBounds(){
      _plannerObjects->clusterBounds.clear();
      for(int clusterIndex = 0; clusterIndex < _plannerObjects->clusterIDs.size(); clusterIndex++){
        int xMax = INT_MIN;
        int yMax = INT_MIN;
        int zMax = INT_MIN;
        int xMin = INT_MAX;
        int yMin = INT_MAX;
        int zMin = INT_MAX;
        int clusterNodeIndex = 0;
        for(int clusterNode = 0; clusterNode < _plannerObjects->clustersSafe[clusterIndex].size(); clusterNode++){
          openvdb::Coord coord = getCoordFromGlobalIndex(_plannerObjects->clustersSafe[clusterIndex][clusterNode]);
          if(coord.x() > xMax){
            xMax = coord.x();
          }
          if(coord.x() < xMin){
            xMin = coord.x();
          }
          if(coord.y() > yMax){
            yMax = coord.y();
          }
          if(coord.y() < yMin){
            yMin = coord.y();
          }
          if(coord.z() > zMax){
            zMax = coord.z();
          }
          if(coord.z() < zMin){
            zMin = coord.z();
          }
          //clusterNodeIndex++;
        }
        _plannerObjects->clusterBounds.push_back(openvdb::CoordBBox(openvdb::Coord(xMin, yMin, zMin), openvdb::Coord(xMax, yMax, zMax)));
      }
    }

    //BOTH OF THESE COULD BE GPU ACCELERATED IN THE FUTURE. NOT ENOUGH TIME TO IMPLEMENT NOW

    void PlannerManager::sampleClustersForSearch(){
      calculateClusterBounds();
      _plannerObjects->clusterSearchNodes.clear();
      _plannerObjects->clusterSearchInfo.clear();
      for(int clusterIndex = 0; clusterIndex < _plannerObjects->clusterIDs.size(); clusterIndex++){
        sampleClusterForSearch(clusterIndex);
      }
      std::cout << "plannerObjectsClusterSearchNodesSIZE" << _plannerObjects->clusterSearchNodes.size();
    }

    void PlannerManager::sampleClusterForSearch(int clusterIndex){
      std::cout << "starting cluster sampling " << std::endl;
      openvdb::CoordBBox startBbox = _plannerObjects->clusterBounds[clusterIndex];
      openvdb::Coord bboxMax = startBbox.max();
      openvdb::Coord bboxMin = startBbox.min();
      openvdb::Coord bboxMid = openvdb::Coord(std::floor((bboxMax.x()+bboxMin.x())/2),
                                              std::floor((bboxMax.y()+bboxMin.y())/2),
                                              std::floor((bboxMax.z()+bboxMin.z())/2));
      std::vector<int> xSeries;
      std::vector<int> ySeries;
      std::vector<int> zSeries;
      if((bboxMax.x()-bboxMin.x()) < _plannerObjects->clusterSearchDensity){
        xSeries.push_back(bboxMid.x());
      }else{
        int currentX = bboxMin.x();
        while(currentX < (bboxMid.x()-std::floor(_plannerObjects->clusterSearchDensity/2))){
          xSeries.push_back(currentX);
          currentX+=_plannerObjects->clusterSearchDensity;
        }
        currentX = bboxMax.x();
        xSeries.push_back(bboxMid.x());
        while(currentX > (bboxMid.x()+std::floor(_plannerObjects->clusterSearchDensity/2))){
          xSeries.push_back(currentX);
          currentX-=_plannerObjects->clusterSearchDensity;
        }
      }
      if((bboxMax.y()-bboxMin.y()) < _plannerObjects->clusterSearchDensity){
        ySeries.push_back(bboxMid.y());
      }else{
        int currentY = bboxMin.y();
        while(currentY < (bboxMid.y()-std::floor(_plannerObjects->clusterSearchDensity/2))){
          ySeries.push_back(currentY);
          currentY+=_plannerObjects->clusterSearchDensity;
        }
        currentY = bboxMax.y();
        ySeries.push_back(bboxMid.y());
        while(currentY > (bboxMid.y()+std::floor(_plannerObjects->clusterSearchDensity/2))){
          ySeries.push_back(currentY);
          currentY-=_plannerObjects->clusterSearchDensity;
        }
      }
      if((bboxMax.z()-bboxMin.z()) < _plannerObjects->clusterSearchDensity){
        zSeries.push_back(bboxMid.z());
      }else{
        int currentZ = bboxMin.z();
        while(currentZ < (bboxMid.z()-std::floor(_plannerObjects->clusterSearchDensity/2))){
          zSeries.push_back(currentZ);
          currentZ+=_plannerObjects->clusterSearchDensity;
        }
        zSeries.push_back(bboxMid.z());
        currentZ = bboxMax.z();
        while(currentZ > (bboxMid.z()+std::floor(_plannerObjects->clusterSearchDensity/2))){
          zSeries.push_back(currentZ);
          currentZ-=_plannerObjects->clusterSearchDensity;
        }
      }
      std::set<int> clustersAddedToSearch;
      std::vector<int> clusterSearchNodes;
      std::map<int, std::vector<int>> thisClusterSearchInfo;
      //std::cout << "clusterindex sampling = " << clusterIndex;
      for(int xCoord : xSeries){
        for(int yCoord : ySeries){
          // std::cout << xCoord << std::endl;
          for(int zCoord : zSeries){
            // std::cout << xCoord << std::endl;
            openvdb::Coord seriesCoord(xCoord, yCoord, zCoord);
            if(isCoordSafe(seriesCoord)){
              int globalIndex = getGlobalIndexFromCoord(seriesCoord);
              int nodeCluster = _plannerObjects->globalClusterMap[globalIndex];
              if(clusterIndex == nodeCluster){
                //std::cout << "globalindex = " << globalIndex << std::endl;
                //std::cout << "series Coord " <<seriesCoord.x()<< " / " <<seriesCoord.y()<< " / " << seriesCoord.z()<<std::endl;
                //Valid safe node in desired cluster
                std::vector<int> localTargets;
                
                int searchTarget = _plannerObjects->globalClusterNodeMap[globalIndex];
                localTargets.push_back(searchTarget);
                //std::cout << "globalIndex according to clustersSafe " << _plannerObjects->clustersSafe[clusterIndex][searchTarget] << std::endl;
                //openvdb::Coord testCoord = getCoordFromGlobalIndex(globalIndex);
                //std::cout <<"testCoord = "<< testCoord.x() << "/" << testCoord.y() << "/" << testCoord.z() << std::endl;
                clustersAddedToSearch.insert(searchTarget);
                clusterSearchNodes.push_back(searchTarget);
                //Check local nodes to add to search targets
                for(int x = xCoord-_plannerObjects->clusterSearchRadius; x <= xCoord+_plannerObjects->clusterSearchRadius; x++){
                  for(int y = yCoord-_plannerObjects->clusterSearchRadius; y <= yCoord+_plannerObjects->clusterSearchRadius; y++){
                    for(int z = zCoord-_plannerObjects->clusterSearchRadius; z <= zCoord+_plannerObjects->clusterSearchRadius; z++){
                      openvdb::Coord localCoord(x, y, z);
                      if(localCoord != seriesCoord){
                      
                        if(isCoordSafe(localCoord)){
                          int localTargetGlobalIndex = getGlobalIndexFromCoord(localCoord);
                          int localTargetCluster = _plannerObjects->globalClusterMap[localTargetGlobalIndex];
                          if(clusterIndex == localTargetCluster){
                            //local coord is safe and is in the cluster we want to search
                            //Get the cluster space index
                            //and add it to the clusters add to search set, adn the local targetsvector
                            int localTarget = _plannerObjects->globalClusterNodeMap[localTargetGlobalIndex];
                            clustersAddedToSearch.insert(localTarget);
                            localTargets.push_back(localTarget);
                          }
                        }
                      }
                    }                
                  }
                }
                //We have iterated over all local search targets
                thisClusterSearchInfo.insert(std::make_pair(searchTarget, localTargets));
              }
            }
          }
        }
      }
      _plannerObjects->clusterSearchNodes.push_back(clusterSearchNodes);
      _plannerObjects->clusterSearchInfo.insert(std::make_pair(clusterIndex, thisClusterSearchInfo));
    }


    std::vector<int> PlannerManager::getGlobalPathFromClusterPath(int clusterIndex, std::vector<int> clusterPath){
      std::vector<int> globalPath;
      //std::cout << "gGPFCP ClusterIndex = " << clusterIndex << std::endl;
      for(int clusterNode : clusterPath){
        //std::cout << "globalClusterNode = " << _plannerObjects->clustersSafe[clusterIndex][clusterNode] << std::endl;
        globalPath.push_back(_plannerObjects->clustersSafe[clusterIndex][clusterNode]);
      }
      //TODO
      return globalPath;
    }

    void PlannerManager::calculateClusterSearchPaths(int clusterIndex){
      //TODO
    }

    Eigen::Vector3f PlannerManager::getPositionFromGlobalIndex(int globalIndex){
      openvdb::Vec3d globalVec = getCoordFromGlobalIndex(globalIndex).asVec3d();
      openvdb::Vec3d worldCoord = _plannerMap->plannerGrid()->transform().indexToWorld(globalVec + openvdb::Vec3d(0.5,0.5,0.5));
      return Eigen::Vector3f((float)worldCoord.x(), (float)worldCoord.y(), (float)worldCoord.z());
    }

    Eigen::Vector3f PlannerManager::getRandomPositionInCluster(int clusterIndex){
      int clusterNodeSize = _plannerObjects->clustersSafe[clusterIndex].size();
      int randomNode = rand()%clusterNodeSize;
      int globalPositionIndex = _plannerObjects->clustersSafe[clusterIndex][randomNode];
      return getPositionFromGlobalIndex(globalPositionIndex);
    }
    // std::vector<Eigen::Vector3f> PlannerManager::EigenPathThroughSearchGoals(std::vector<int> globalSearchNodes, int globalStart){
    //   int startPosition = 
    // }



    std::vector<Eigen::Vector3f> PlannerManager::getEigenPathFromGlobalIndexPath(std::vector<int> globalIndexPath){
      std::vector<Eigen::Vector3f> eigenPath;
      for(int node = 0; node < globalIndexPath.size(); node++){
        openvdb::Vec3d globalVec = getCoordFromGlobalIndex(globalIndexPath[node]).asVec3d();
        //std::cout <<"globalVec = "<< globalVec.x() << "/" << globalVec.y() << "/" << globalVec.z() << std::endl;
        openvdb::Vec3d worldCoord = _plannerMap->plannerGrid()->transform().indexToWorld(globalVec + openvdb::Vec3d(0.5,0.5,0.5));
        eigenPath.push_back(Eigen::Vector3f((float)worldCoord.x(), (float)worldCoord.y(), (float)worldCoord.z()));
      }
      return eigenPath;
    }

    std::vector<int> PlannerManager::getShortestClusterPathBetweenBoundaries(int sourceCluster, int sourceBoundary, int destCluster){
        // std::vector<int> srcBoundaries = _plannerObjects->clusterBoundaryPoints[sourceCluster];
        // int sourceBoundaryGlobalIndex = srcBoundaries[sourceBoundary];
        int sourceBoundaryGlobalIndex = _plannerObjects->clustersSafe[sourceCluster][sourceBoundary];
        std::vector<int> destBoundaries = _plannerObjects->clusterBoundaryPoints[destCluster];
        double moveCost = DBL_MAX;
        std::vector<int> currentBestPath;
        for(int destBoundariesIndex = 0; destBoundariesIndex < destBoundaries.size(); destBoundariesIndex++){
          int destBoundaryGlobalIndex = destBoundaries[destBoundariesIndex];
          auto pathCostPair = getShortestPathAndScoreBetweenClusters(sourceCluster, sourceBoundaryGlobalIndex, destCluster, destBoundaryGlobalIndex);
          if(pathCostPair.first < moveCost){
            moveCost = pathCostPair.first;
            currentBestPath = pathCostPair.second;
          }
        }
        std::vector<int> clusterPath;
        int currentCluster = sourceCluster;
        for(int pathIndex = 0; pathIndex < currentBestPath.size(); pathIndex++){
          int pathCluster = _plannerObjects->globalClusterMap[currentBestPath[pathIndex]];
          if(pathCluster != currentCluster){
            clusterPath.push_back(pathCluster);
            currentCluster = pathCluster;
          }
        }
        return clusterPath;
    }

    void PlannerManager::calculateBoundaryLinesFromGraph(){

      calculateBoundaryPointAverages();
      _plannerObjects->boundaryLines.clear();
      _plannerObjects->boundaryPoints.clear();
      _plannerObjects->boundaryPoints.resize(_plannerObjects->clusterGraph.size());
      for(int clusterIndex = 0; clusterIndex < _plannerObjects->clusterGraph.size(); clusterIndex++){
              //DO ALL THE BOUNDARY PAIRS IN CLUSTER
        for(int neighbourIndex = 0; neighbourIndex < _plannerObjects->clusterGraph[clusterIndex].size(); neighbourIndex++){
          int neighbourCluster = _plannerObjects->clusterGraph[clusterIndex][neighbourIndex].first;
          for(int neighbourPair = 0; neighbourPair < _plannerObjects->clusterGraph[clusterIndex][neighbourIndex].second.size(); neighbourPair++){
            
            std::pair<int, int> boundaryPair = _plannerObjects->clusterGraph[clusterIndex][neighbourIndex].second[neighbourPair];
            int clusterBoundary = _plannerObjects->clusterBoundaryPoints[clusterIndex][boundaryPair.first];
            int neighbourBoundary = _plannerObjects->clusterBoundaryPoints[neighbourCluster][boundaryPair.second];
            openvdb::Vec3d globalVec = getCoordFromGlobalIndex(clusterBoundary).asVec3d();
            openvdb::Vec3d worldCoord = _plannerMap->plannerGrid()->transform().indexToWorld(globalVec + openvdb::Vec3d(0.5,0.5,0.5));
            Eigen::Vector3f clusterBoundaryInWorld = EigenVec(worldCoord.x(), worldCoord.y(), worldCoord.z());
            _plannerObjects->boundaryPoints[clusterIndex].push_back(clusterBoundaryInWorld);
            globalVec = getCoordFromGlobalIndex(neighbourBoundary).asVec3d();
            worldCoord = _plannerMap->plannerGrid()->transform().indexToWorld(globalVec + openvdb::Vec3d(0.5,0.5,0.5));
            Eigen::Vector3f neighbourBoundaryInWorld = EigenVec(worldCoord.x(), worldCoord.y(), worldCoord.z());
            //_plannerObjects->boundaryLines.push_back(std::make_pair(clusterBoundaryInWorld, neighbourBoundaryInWorld));
            _plannerObjects->boundaryLines.push_back(clusterBoundaryInWorld);
            _plannerObjects->boundaryLines.push_back(neighbourBoundaryInWorld);
          
          } 
        }
      //Do a sanity check of the cluster graph. 
      // for(int x = 0; )

      //THEN DO ALL THE INTERNAL PATHS BETWEEN BOUNDARIES
        std::vector<int> clusterBoundaries = _plannerObjects->clusterBoundaryPoints[clusterIndex];
        for(int sourceBoundaryIndex = 0; sourceBoundaryIndex < clusterBoundaries.size(); sourceBoundaryIndex++){
            int sourceGlobal = clusterBoundaries[sourceBoundaryIndex];
          for(int destBoundaryIndex = 0; destBoundaryIndex < clusterBoundaries.size(); destBoundaryIndex++){
            if(sourceBoundaryIndex != destBoundaryIndex){
              //Get path
              int destGlobal = clusterBoundaries[destBoundaryIndex];
              std::vector<int> shortestPath = getShortestPathAsIndex(sourceGlobal, destGlobal);
              int steps = shortestPath.size();
              openvdb::Vec3d globalVec = getCoordFromGlobalIndex(sourceGlobal).asVec3d();
              openvdb::Vec3d worldCoord = _plannerMap->plannerGrid()->transform().indexToWorld(globalVec + openvdb::Vec3d(0.5,0.5,0.5));
              Eigen::Vector3f startPointInWorld = EigenVec(worldCoord.x(), worldCoord.y(), worldCoord.z());
              for(int coord = 0; coord < steps ; coord++){
                globalVec = getCoordFromGlobalIndex(shortestPath[coord]).asVec3d();
                worldCoord = _plannerMap->plannerGrid()->transform().indexToWorld(globalVec + openvdb::Vec3d(0.5,0.5,0.5));
                Eigen::Vector3f endPointInWorld = EigenVec(worldCoord.x(), worldCoord.y(), worldCoord.z());
                //openvdb::Coord globalCoord = getCoordFromGlobalIndex(coordPathInPlannerSpace[coord]);
                  //openvdb::
                //_plannerObjects->boundaryLines.push_back(std::make_pair(startPointInWorld, endPointInWorld));
                _plannerObjects->boundaryLines.push_back(startPointInWorld);
                _plannerObjects->boundaryLines.push_back(endPointInWorld);
                startPointInWorld = endPointInWorld;
              }        
            } 
          }
        //NEED TO IMPLEMENT ORIENTATION CHECKS. AS IT IS, THIS IS JUST TRANSIT TRAINING
        } 
      }
    }

    std::vector<Eigen::Vector3f> PlannerManager::getBoundaryLinesFromGraph(){
      return _plannerObjects->boundaryLines;
    }
    
      //ClusterGraph is cluster entry -> list of neighbours entries (which map to actions)
    //Each entry is a pair, with the int representing the cluster index of the neighbour,
    //And the other half of the pair is a vector of pairs that represent each boundary the neighbours share and the cluster boundary index for those boundaries.  
   
      std::vector<std::vector<std::pair<int,std::vector<std::pair<int,int>>>>> PlannerManager::returnClusterGraph(){
        return _plannerObjects->clusterGraph;
      }

    //Takes a cluster index, the source boundary within that cluster(in cluster reference space), and the destination cluster.
    //Returns pair, int = destination boundary in destination cluster space, and double  = distance between those two boundaries. 
      std::pair<int, double> PlannerManager::getDestinationBoundaryAndCostFromClusterBoundary(int sourceCluster, int sourceBoundary, int destCluster){
        //std::vector<int> srcBoundaries = _plannerObjects->clusterBoundaryPoints[sourceCluster];
        //int sourceBoundaryGlobalIndex = srcBoundaries[sourceBoundary];
        int sourceBoundaryGlobalIndex = _plannerObjects->clustersSafe[sourceCluster][sourceBoundary];
        
        std::vector<int> destBoundaries = _plannerObjects->clusterBoundaryPoints[destCluster];
        double moveCost = DBL_MAX;
        int currentBestDestIndex = -1;
        for(int destBoundariesIndex = 0; destBoundariesIndex < destBoundaries.size(); destBoundariesIndex++){
          int destBoundaryGlobalIndex = destBoundaries[destBoundariesIndex];
          auto pathCostPair = getShortestPathAndScoreBetweenClusters(sourceCluster, sourceBoundaryGlobalIndex, destCluster, destBoundaryGlobalIndex);
          if(pathCostPair.first < moveCost){
            moveCost = pathCostPair.first;
            currentBestDestIndex = destBoundariesIndex;
          }
        }
        return std::make_pair(currentBestDestIndex, moveCost);
      }

      std::vector<int> PlannerManager::clusterPathBetweenGlobalIndexPair(int startIndex, int destIndex){
        std::vector<int> indexPath = getShortestPathAsIndex(startIndex, destIndex);
        std::vector<int> clusterPath;
        for(int index : indexPath){
          int cluster = _plannerObjects->globalClusterMap[index];
          if(clusterPath.size()>0){
            if(cluster != clusterPath.back()){
              clusterPath.push_back(cluster);
            }
          }else{
            clusterPath.push_back(cluster);
          }
        }
        return clusterPath;
      }

      std::pair<int, int> PlannerManager::getRandomPairWithMinDistance(float minDistance){
        float dist = 0.0;
        int safeStartIndex;
        int globalStartIndex;
        int safeEndIndex; 
        int globalEndIndex;
        while(dist < minDistance){
          bool valid = false;

          while(!valid){
            safeStartIndex = rand()%(_plannerObjects->safeCount);
            globalStartIndex = _handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[safeStartIndex];
            if(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[globalStartIndex]!=-1){
              valid = true;
            }
          }
          valid = false;
          while(!valid){
            safeEndIndex = rand()%(_plannerObjects->safeCount);
            globalEndIndex = _handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[safeEndIndex];
            if(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[globalEndIndex]!=-1){
              valid = true;
            }
          }

          int startCluster = _plannerObjects->globalClusterMap[globalStartIndex];
          int endCluster = _plannerObjects->globalClusterMap[globalEndIndex];
          //std::cout << startIndex << endIndex << xCluster << yCluster << std::endl;
          if(startCluster!=endCluster){
            //Get path between those safe nodes
            dist = getShortestPathAndScore(globalStartIndex, globalEndIndex).first;
            //dist = coordPathInPlannerSpace.size();
          }
        }
        return std::make_pair(globalStartIndex, globalEndIndex);
      }

      int PlannerManager::getRandomDestinationWithMinDistanceAndPosition(float minDistance, Eigen::Vector3f position){
        int globalStartIndex = getGlobalIndexFromPosition(position);
        float dist = 0.0;
        int globalEndIndex;
        int safeEndIndex; 
        while(dist < minDistance){
          bool valid = false;
          //int safeStartIndex;
          //int globalStartIndex;


          // while(!valid){
          //   safeStartIndex = rand()%(_plannerObjects->safeCount);
          //   globalStartIndex = _handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[safeStartIndex];
          //   if(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[globalStartIndex]!=-1){
          //     valid = true;
          //   }
          // }
          //valid = false;
          while(!valid){
            safeEndIndex = rand()%(_plannerObjects->safeCount);
            globalEndIndex = _handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[safeEndIndex];
            if(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[globalEndIndex]!=-1){
              valid = true;
            }
          }

          int startCluster = _plannerObjects->globalClusterMap[globalStartIndex];
          int endCluster = _plannerObjects->globalClusterMap[globalEndIndex];
          //std::cout << startIndex << endIndex << xCluster << yCluster << std::endl;
          if(startCluster!=endCluster){
            //Get path between those safe nodes
            dist = getShortestPathAndScore(globalStartIndex, globalEndIndex).first;
            //dist = coordPathInPlannerSpace.size();
          }
        }
        return globalEndIndex;
      }

      
      std::vector<std::pair<Pose, int>> PlannerManager::getRandomPathWithStart(int minSteps, int startPlannerCoord){
        std::vector<std::pair<Pose, int>> trajectoryGoals;
        int steps = 0;
        std::vector<int> coordPathInPlannerSpace;
        //srand(time(0));
        int globalStartIndex = startPlannerCoord;
        while(steps < minSteps){
          bool valid = false;
          int safeEndIndex; 
          int globalEndIndex;
          // while(!valid){
          //   //safeStartIndex = rand()%(_plannerObjects->safeCount);
          //   //globalStartIndex = _handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[safeStartIndex];
          //   if(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[globalStartIndex]!=-1){
          //     valid = true;
          //   }
          // }
          //valid = false;
          while(!valid){
            safeEndIndex = rand()%(_plannerObjects->safeCount);
            globalEndIndex = _handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[safeEndIndex];
            if(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[globalEndIndex]!=-1){
              valid = true;
            }
          }

          int startCluster = _plannerObjects->globalClusterMap[globalStartIndex];
          int endCluster = _plannerObjects->globalClusterMap[globalEndIndex];
          //std::cout << startIndex << endIndex << xCluster << yCluster << std::endl;
          if(startCluster!=endCluster){
            //Get path between those safe nodes
            coordPathInPlannerSpace = getShortestPathAsIndex(globalStartIndex, globalEndIndex);
            steps = coordPathInPlannerSpace.size();
          }
        }
        //NEED TO IMPLEMENT ORIENTATION CHECKS. AS IT IS, THIS IS JUST TRANSIT TRAINING
        for(int coord = 0; coord < steps ; coord++){
          Pose pose;
          //openvdb::Coord globalCoord = getCoordFromGlobalIndex(coordPathInPlannerSpace[coord]);
          //openvdb::
          openvdb::Vec3d globalVec = getCoordFromGlobalIndex(coordPathInPlannerSpace[coord]).asVec3d();
          openvdb::Vec3d worldCoord = _plannerMap->plannerGrid()->transform().indexToWorld(globalVec + openvdb::Vec3d(0.5,0.5,0.5));
          pose.position = EigenVec(worldCoord.x(), worldCoord.y(), worldCoord.z());
          //std::cout << "Position " << coord << " = " << "("<<worldCoord.x() << ","<<worldCoord.y()<<","<<worldCoord.z()<<")"<<std::endl;
          pose.orientation = Eigen::Quaternionf(1,0,0,0);
          trajectoryGoals.push_back(std::pair<Pose, int>(pose, 0));     
        }
        return trajectoryGoals;
      }


      std::pair<int, int> PlannerManager::getClusterBoundaryPairFromPos(Eigen::Vector3f position){
        //Get global node index from position
        openvdb::Vec3d vecPos(position.x(), position.y(), position.z());
        openvdb::Coord plannerCoord = getPlannerCoordFromWorldVec(vecPos);
        int globalPlannerIndex = getGlobalIndexFromCoord(plannerCoord);
        int clusterIndex = _plannerObjects->globalClusterMap[globalPlannerIndex];
        std::vector<int> clusterBoundaries = _plannerObjects->clusterBoundaryPoints[clusterIndex];
        float minDist = FLT_MAX;
        int closestBoundary = -1;
        for(int boundaryPoint = 0; boundaryPoint < clusterBoundaries.size(); boundaryPoint++){
          float dist = getShortestPathAndScore(globalPlannerIndex, clusterBoundaries[boundaryPoint]).first;
          if(dist<minDist){
            minDist = dist;
            closestBoundary = boundaryPoint;
          }
        }
        return std::make_pair(clusterIndex, closestBoundary);
      }

      std::vector<std::pair<Pose, int>> PlannerManager::getRandomPath(int minSteps){
        std::vector<std::pair<Pose, int>> trajectoryGoals;
        int steps = 0;
        std::vector<int> coordPathInPlannerSpace;
        //srand(time(0));
        while(steps < minSteps){

          bool valid = false;
          int safeStartIndex; 
          int safeEndIndex;
          int globalStartIndex; 
          int globalEndIndex;
          while(!valid){
            safeStartIndex = rand()%(_plannerObjects->safeCount);
            globalStartIndex = _handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[safeStartIndex];
            if(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[globalStartIndex]!=-1){
              valid = true;
            }
          }
          valid = false;
          while(!valid){
            safeEndIndex = rand()%(_plannerObjects->safeCount);
            globalEndIndex = _handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[safeEndIndex];
            if(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[globalEndIndex]!=-1){
              valid = true;
            }
          }

          int startCluster = _plannerObjects->globalClusterMap[globalStartIndex];
          int endCluster = _plannerObjects->globalClusterMap[globalEndIndex];
          //std::cout << startIndex << endIndex << xCluster << yCluster << std::endl;
          if(startCluster!=endCluster){
            //Get path between those safe nodes
            coordPathInPlannerSpace = getShortestPathAsIndex(globalStartIndex, globalEndIndex);
            steps = coordPathInPlannerSpace.size();
          }
        }
        //NEED TO IMPLEMENT ORIENTATION CHECKS. AS IT IS, THIS IS JUST TRANSIT TRAINING
        for(int coord = 0; coord < steps ; coord++){
          Pose pose;
          //openvdb::Coord globalCoord = getCoordFromGlobalIndex(coordPathInPlannerSpace[coord]);
          //openvdb::
          openvdb::Vec3d globalVec = getCoordFromGlobalIndex(coordPathInPlannerSpace[coord]).asVec3d();
          openvdb::Vec3d worldCoord = _plannerMap->plannerGrid()->transform().indexToWorld(globalVec + openvdb::Vec3d(0.5,0.5,0.5));
          pose.position = EigenVec(worldCoord.x(), worldCoord.y(), worldCoord.z());
          //std::cout << "Position " << coord << " = " << "("<<worldCoord.x() << ","<<worldCoord.y()<<","<<worldCoord.z()<<")"<<std::endl;
          pose.orientation = Eigen::Quaternionf(1,0,0,0);
          trajectoryGoals.push_back(std::pair<Pose, int>(pose, 0));     
        }
        return trajectoryGoals;
      }

      void PlannerManager::createHandler(){
        _handler = std::make_unique<nanomap::handler::PlannerHandler>(nanomap::handler::PlannerHandler(_plannerConfig));
      }
      
      openvdb::Vec3d PlannerManager::getWorldVecFromPlannerCoord(openvdb::Coord voxel){
        return _plannerMap->plannerGrid()->transform().indexToWorld(voxel);
      }


      void PlannerManager::solveMap(openvdb::FloatGrid::Ptr gridToSolve){
                // bool renderClusterParents = true;
        createHandler();
        if(GRIDRENDER == 1){
          openvdb::GridPtrVec Grids;
          Grids.push_back(gridToSolve);
            // Write out the contents of the container
          openvdb::io::File savefile("startGrid"+std::to_string(startTime)+".vdb");
          savefile.write(Grids);
          savefile.close();
        }
        createPlannerMapFromGrid(gridToSolve);
        std::cout << "extracting clusters" << std::endl;
        extractClustersFromPlannerMap();
        std::cout << "solving clusters" << std::endl;
        solveClusters();


          if(GRIDRENDER==1){
              int clustCount = 0;
              openvdb::GridPtrVec Grids;



              openvdb::FloatGrid::Ptr clusterFull;
              clusterFull = openvdb::FloatGrid::create(0.0);
              auto acc = clusterFull->getAccessor();
              for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
                if(_plannerObjects->clusterIDs[x]!=-1){

                  clusterFull->setGridClass(openvdb::GRID_LEVEL_SET);
                  clusterFull->setName("cluster " + std::to_string(x));
                  clusterFull->setTransform(openvdb::math::Transform::createLinearTransform(0.8));


                  for(int y = 0; y < *(_handler->plannerAllocator()->plannerCluster(x)->hostVertexCount()); y++){
                      int clusterIndex = _handler->plannerAllocator()->plannerCluster(x)->hostVertexBuffer()[y];
                      Eigen::Matrix<int, 3, 1> eigenNode = _handler->plannerAllocator()->getGridIndexNode(_plannerObjects->clustersSafe[x][clusterIndex]);
                      openvdb::Coord node(eigenNode(0), eigenNode(1), eigenNode(2));
                      acc.setValueOn(node);
                  }

                }
              }
              Grids.push_back(clusterFull);

                // Write out the contents of the container. 
              
              openvdb::io::File savefile("vertexGrid"+std::to_string(startTime)+".vdb");
              savefile.write(Grids);
              savefile.close();
            }


        std::cout << "creating and solving boundary graph" << std::endl;
        createAndSolveBoundaryGraph();
      }


      openvdb::Coord PlannerManager::getPlannerCoordFromWorldVec(openvdb::Vec3d worldVec){
        openvdb::Vec3d plannerVec = _plannerMap->plannerGrid()->transform().worldToIndex(worldVec);
        if(plannerVec.x() >= 0.9999){
          plannerVec.x() += 0.1;
        }
        if(plannerVec.y() >= 0.9999){
          plannerVec.y() += 0.1;
        }
        if(plannerVec.z() >= 0.9999){
          plannerVec.z() += 0.1;
        }
        
        return openvdb::Coord::floor(plannerVec);
        
        //return openvdb::Coord(indexVec.x())
      }





//PRIVATE METHODS


      void PlannerManager::createPlannerGrid(openvdb::FloatGrid::Ptr targetGrid){
        //Take a grid and create the planner grid object
        //yyyyyyyyyprintf("ASDOJNQWDJNQIDNJQWIDJNQWIDJNQWIDJN");
        std::cout << _config->plannerRes() << std::endl;
        _plannerMap = std::make_shared<nanomap::map::PlannerMap>(nanomap::map::PlannerMap(_config->plannerRes()));
              openvdb::FloatGrid::Ptr safeDebug = openvdb::FloatGrid::create(0.0);
              safeDebug->setTransform(openvdb::math::Transform::createLinearTransform(0.8));
              auto safeAcc = safeDebug->getAccessor();
        using GridType = openvdb::FloatGrid;
        using FloatTreeT = GridType::TreeType;
        using RootType = FloatTreeT::RootNodeType;   // level 3 RootNode
        //assert(RootType::LEVEL == 3);
        using Int1Type = RootType::ChildNodeType;  // level 2 InternalNode
        using Int2Type = Int1Type::ChildNodeType;  // level 1 InternalNode
        using LeafType = FloatTreeT::LeafNodeType;
        //std::cout << "ASDJNQWKJDNQWDJNQWDKJNQWKDJWQND" << std::endl;
        //auto gridAccessor = targetGrid->getAccessor();
        float gridRes = (float)((targetGrid->voxelSize())[0]);
        int index = 1;
        int safeCount = 0;
        int validCount = 0;
        //std::cout << "HERERERERERERERERERE" << std::endl;
        //std::cout << "plannerRes " << _plannerRes <<std::endl;
        //std::cout << "tileEdge " << _tileEdge <<std::endl;
        //std::cout << "gridRes " << _gridRes <<std::endl;
        //std::cout << "plannerRes/tileEdge" << _plannerRes/_tileEdge <<std::endl;
        if(_plannerConfig->plannerRes/_plannerConfig->leafEdge == gridRes){
          //std::cout << "tile logic" << std::endl;
          _plannerConfig->useTileLogic = true;
        }
        if(_plannerConfig->useTileLogic){
          FloatTreeT::NodeIter iter{targetGrid->tree()};
          //int depth = grid->tree().treeDepth();
          //grid_info->node_counts_.clear();
          //grid_info->node_counts_.resize(depth,0);
          //node_info->active_counts_.resize(depth,0);
          //node_info->inactive_counts_.resize(depth,0);
          for ( ; iter; ++iter) {
          //if we are in a leaf node perform leaf/tile logic for building planner map
            if(iter.getDepth()==3){
              LeafType* node = nullptr;
              iter.getNode(node);
              if (node){
                //std::cout << "Node Bounds" << std::endl;
                //std::cout << node->getNodeBoundingBox() << std::endl;
                //std::cout << "Node Coord" << std::endl;
                //std::cout << iter.getCoord() << std::endl;
                openvdb::Coord leafOrigin = node->origin();
                openvdb::Coord indexCoord = openvdb::Coord::round(openvdb::Vec3d(leafOrigin.x()/_plannerConfig->leafEdge, 
                                                          leafOrigin.y()/_plannerConfig->leafEdge, 
                                                          leafOrigin.z()/_plannerConfig->leafEdge));
                //In a tile/leaf, do planner map construction logic.
                //auto worldCoord = targetGrid->indexToWorld(iter.getCoord());
                //openvdb::Coord indexCoord = openvdb::Coord(std::floor(_plannerGrid->worldToIndex(worldCoord).x()),
                //                                          std::floor(_plannerGrid->worldToIndex(worldCoord).y()),
                //                                          std::floor(_plannerGrid->worldToIndex(worldCoord).z()));
                //std::cout << "Voxel Count = "<<node->onVoxelCount() << std::endl;
                if(node->onVoxelCount()==0){

                  //this is a safe leaf node
                  safeAcc.setValueOn(indexCoord);
                  _plannerMap->plannerAccessor()->setValue(indexCoord,index);
                  safeCount+=1;
                }else{
                  _plannerMap->plannerAccessor()->setValue(indexCoord,-1*index);
                  //this is a non-safe but potentially still valid leaf node.
                }
                index += 1;
                validCount+=1;
              }
            }
          }
        }//else{

          //TODO
        //}
        //iterate over all
        std::cout << "validCount = "<<validCount << std::endl;
        std::cout << "safeCount = " << safeCount << std::endl;
        //std::cout << "9" << std::endl;
        //_pa->plannerBucket()->allocateValidVoxels(validCount);
        //_pa->allocateValidAndSafe(validCount, safeCount);
        //_handler->allocateValidAndSafe(validCount, safeCount);
        _plannerObjects->validCount = validCount;
        _plannerObjects->safeCount = safeCount;
                  //std::cout << "Saving...SaveDebug" << std::endl;
        if(GRIDRENDER == 1){
          safeDebug->setName("grid");
          openvdb::io::File("safeDebug"+std::to_string(startTime)+".vdb").write({safeDebug});
        }
        //populateGridIndexAndVoxels();
        //populateValidVoxels();
      }


      void PlannerManager::createPlannerMapFromGrid(openvdb::FloatGrid::Ptr grid){
        createPlannerGrid(grid);
        _handler->allocateValidAndSafe(_plannerObjects->validCount, _plannerObjects->safeCount); 
        populateGridIndexAndVoxels();
        _handler->uploadPlannerGrid(_plannerMap->plannerGrid());
      }


      void PlannerManager::extractClustersFromPlannerMap(){
          std::cout << "extracting clusters on handler" << std::endl;
          _handler->extractClusters();
          std::cout << "merging clusters " << std::endl;
          mergeClusters();
          refineClusters();
          mergeClusters();
          populateClusters();
          std::cout << "getting cluster graph" << std::endl;
          getClusterGraph();
          std::cout << "populating global cluster map" << std::endl;
          populateGlobalClusterMap();
          std::cout << "cluster GPU allocation start" << std::endl;
          _handler->setAllocatorClusterInfo(_plannerObjects->clusterIDs, _plannerObjects->clustersSafe);
          _handler->createGPUClusters(_plannerObjects->clusterIDs, _plannerObjects->clustersSafe);
          std::cout << "cluster GPU allocation finished " << std::endl;
      }

      void PlannerManager::solveClusters(){
          //This does double duty, it extracts the vertex nodes for each cluster and then solves them
        _handler->solveClusters();
      }

      void PlannerManager::refineClusters(){
        _handler->refineClusters();
      }

      void PlannerManager::createAndSolveBoundaryGraph(){
          //Calculate boundary nodes between clusters before creating the necessary GPU containers
          getClusterBoundaries();
          getClosestVertices();
          processBoundaries();
          _handler->prepareBoundaryArrays();
          populateBoundaryContainers();
          _handler->copyBoundaryContainers();
          //plannerBucket()->copyBoundaryContainers();
          //FINALLY WE CAN SOLVE THE BOUNDARY GRAPH
          _handler->solveBoundaryGraph();
          //RESIZING IS NOT WORKING ATM, MAKE SURE TO SET A SUFFICIENT LEVEL DEPTH FOR YOUR ENVIRONMENT!
          // while(!_handler->depthLevelSufficient()){
          //   _handler->increaseLevelDepth();
          //   _handler->prepareBoundaryArrays();
          //   populateBoundaryContainers();
          //   _handler->copyBoundaryContainers();
          //   _handler->startBoundarySolve();
          // }
          //_handler->finishBoundarySolve();
          //WE THE BOUNDARY PATH SOLUTIONS THAT WE JUST CALCULATED INTO USABLE SEARCHABLE OBJECTS
          getAllBoundaryPaths();
          // bool renderClusterParents = true;
          if(GRIDRENDER == 1){
              int clustCount = 0;
              openvdb::GridPtrVec Grids;




              for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
                openvdb::FloatGrid::Ptr clusterFull;
                clusterFull = openvdb::FloatGrid::create(0.0);
                auto acc = clusterFull->getAccessor();
                clusterFull->setGridClass(openvdb::GRID_LEVEL_SET);
                clusterFull->setName("cluster " + std::to_string(x));
                clusterFull->setTransform(openvdb::math::Transform::createLinearTransform(0.8));


                for(int y = 0; y < _plannerObjects->clustersSafe[x].size(); y++){
                    int clusterIndex = _plannerObjects->clustersSafe[x][y];
                    Eigen::Matrix<int, 3, 1> eigenNode = _handler->plannerAllocator()->getGridIndexNode(clusterIndex);
                    openvdb::Coord node(eigenNode(0), eigenNode(1), eigenNode(2));
                    acc.setValueOn(node);
                }
                Grids.push_back(clusterFull);
              }


                // Write out the contents of the container.

              openvdb::io::File savefile("clusterGrid.vdb");
              savefile.write(Grids);
              savefile.close();
            }
      }


void PlannerManager::getClusterGraph(){
          auto acc = _plannerMap->plannerGrid()->getAccessor();
          //std::cout << "cluster Count = " << _plannerObjects->clusterIDs.size() << std::endl;
          std::map<int, int> clusterParentIndicesMap;
          for(int y = 0; y < _plannerObjects->clusterIDs.size() ; y++){
            _plannerObjects->clusterIndices.insert(std::pair<int,int>(_plannerObjects->clusterIDs[y], y));
            clusterParentIndicesMap.insert(std::pair<int,int>(y,_plannerObjects->clusterIDs[y]));
            std::set<int> emptySet;
            _plannerObjects->clusterNeighbours.push_back(emptySet);
          }

          for(int x = 0; x < *_handler->plannerAllocator()->plannerBucket()->hostSafeCount(); x++){
            int nodeIndex = _handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[x];
            Eigen::Matrix<int, 3, 1> eigenNode = _handler->plannerAllocator()->getGridIndexNode(nodeIndex);
            openvdb::Coord node(eigenNode(0), eigenNode(1), eigenNode(2));
            
            int clusterParent = _handler->plannerAllocator()->plannerBucket()->hostClusterParents()[nodeIndex];
            int clusterIndex = _plannerObjects->clusterIndices[clusterParent];
            int neighbourID;
            int neighbourParent;
            
            //std::cout << std::endl << std::endl;
            //std::cout << clusterParent << " ? " << clusterIndex << std::endl;
            //std::cout << "neighbours = " ;
            for(int i = -1; i <= 1; i+=2){
              neighbourID = acc.getValue(openvdb::Coord(node.x()+i, node.y(), node.z()))-1;
              if(neighbourID >= 0){
                neighbourParent = _handler->plannerAllocator()->plannerBucket()->hostClusterParents()[neighbourID];
                //std::cout << neighbourParent << " / " ;
                if(neighbourParent != clusterParent){
                  _plannerObjects->clusterNeighbours[clusterIndex].insert(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[neighbourID]);
                }
              }
            }
              for(int y = -1; y <= 1; y+=2){
                neighbourID = acc.getValue(openvdb::Coord(node.x(), node.y()+y, node.z()))-1;
                if(neighbourID >= 0){
                  neighbourParent = _handler->plannerAllocator()->plannerBucket()->hostClusterParents()[neighbourID];
                  //std::cout << neighbourParent << " / " ;
                  if(neighbourParent != clusterParent){
                    _plannerObjects->clusterNeighbours[clusterIndex].insert(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[neighbourID]);
                  }
                }
              }
                for(int z = -1; z <= 1; z+=2){
                  neighbourID = acc.getValue(openvdb::Coord(node.x(), node.y(), node.z()+z))-1;
                  if(neighbourID >= 0){
                    neighbourParent = _handler->plannerAllocator()->plannerBucket()->hostClusterParents()[neighbourID];
                    //std::cout << neighbourParent << " / " ;
                    if(neighbourParent != clusterParent){
                      _plannerObjects->clusterNeighbours[clusterIndex].insert(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[neighbourID]);
                    }
                  }
            }
          }
          // //CLUSTER NEIGHBOUR DEBUG
          //     int clusterIDCount = 0;
          //     std::cout << "neighbour sanity check" << std::endl;
              
          //     auto clusterNeighboursIt = _plannerObjects->clusterNeighbours.begin();
          //     while( clusterNeighboursIt!=_plannerObjects->clusterNeighbours.end()){
          //       std::cout << "clusterParent = " << clusterParentIndicesMap[clusterIDCount] << std::endl;  
          //       std::cout << "cluster Index/Count = " << clusterIDCount << std::endl;
                
          //       auto clusterIt = (*clusterNeighboursIt).begin();
          //       std::cout << "Neighbours" ; 
          //       while(clusterIt != (*clusterNeighboursIt).end()){
          //         std::cout << " /" << *clusterIt;
          //         clusterIt++;
          //       }
          //       std::cout << std::endl << std::endl; 
          //       clusterIDCount++;
          //       clusterNeighboursIt++;
          //     }

          //               bool renderClusterParents = true;
          if(GRIDRENDER == 1){
              int clustCount = 0;
              openvdb::GridPtrVec Grids;




              for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
                if(_plannerObjects->clusterIDs[x]!=-1){
                  openvdb::FloatGrid::Ptr clusterFull;
                  clusterFull = openvdb::FloatGrid::create(0.0);
                  auto acc = clusterFull->getAccessor();
                  clusterFull->setGridClass(openvdb::GRID_LEVEL_SET);
                  clusterFull->setName("cluster " + std::to_string(x));
                  clusterFull->setTransform(openvdb::math::Transform::createLinearTransform(0.8));


                  for(int y = 0; y < _plannerObjects->clustersSafe[x].size(); y++){
                      int clusterIndex = _plannerObjects->clustersSafe[x][y];
                      Eigen::Matrix<int, 3, 1> eigenNode = _handler->plannerAllocator()->getGridIndexNode(clusterIndex);
                      openvdb::Coord node(eigenNode(0), eigenNode(1), eigenNode(2));
                      acc.setValueOn(node);
                  }
                  Grids.push_back(clusterFull);
                }
              }


                // Write out the contents of the container.

              openvdb::io::File savefile("clusterGrid"+std::to_string(startTime)+".vdb");
              savefile.write(Grids);
              savefile.close();
            }
          removeDisconnectedClusters();
          std::cout << "resizing clusters" << std::endl;
          resizeClusters();
          std::cout << "performing graph continuity check" << std::endl;
          graphContinuityCheck();
//                    if(renderClusterParents){
          if(GRIDRENDER == 1){
          openvdb::GridPtrVec Grids;
              for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
                if(_plannerObjects->clusterIDs[x]!=-1){
                  openvdb::FloatGrid::Ptr clusterFull;
                  clusterFull = openvdb::FloatGrid::create(0.0);
                  auto acc = clusterFull->getAccessor();
                  clusterFull->setGridClass(openvdb::GRID_LEVEL_SET);
                  clusterFull->setName("cluster " + std::to_string(x));
                  clusterFull->setTransform(openvdb::math::Transform::createLinearTransform(0.8));


                  for(int y = 0; y < _plannerObjects->clustersSafe[x].size(); y++){
                      int clusterIndex = _plannerObjects->clustersSafe[x][y];
                      Eigen::Matrix<int, 3, 1> eigenNode = _handler->plannerAllocator()->getGridIndexNode(clusterIndex);
                      openvdb::Coord node(eigenNode(0), eigenNode(1), eigenNode(2));
                      acc.setValueOn(node);
                  }
                  Grids.push_back(clusterFull);
                }
              }


                // Write out the contents of the container.

              openvdb::io::File savefile("continuousClusters"+std::to_string(startTime)+".vdb");
              savefile.write(Grids);
              savefile.close();
          }
  //      if(renderClusterParents){
          if(GRIDRENDER ==1 ){
          openvdb::GridPtrVec Grids;
          openvdb::FloatGrid::Ptr clusterFull;
          clusterFull = openvdb::FloatGrid::create(0.0);
          auto acc = clusterFull->getAccessor();
          clusterFull->setGridClass(openvdb::GRID_LEVEL_SET);
          clusterFull->setName("continuous clusters");
          clusterFull->setTransform(openvdb::math::Transform::createLinearTransform(0.8));

              for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
                if(_plannerObjects->clusterIDs[x]!=-1){
                  for(int y = 0; y < _plannerObjects->clustersSafe[x].size(); y++){
                      int clusterIndex = _plannerObjects->clustersSafe[x][y];
                      Eigen::Matrix<int, 3, 1> eigenNode = _handler->plannerAllocator()->getGridIndexNode(clusterIndex);
                      openvdb::Coord node(eigenNode(0), eigenNode(1), eigenNode(2));
                      acc.setValueOn(node);
                  }
                  
                }
              }
          Grids.push_back(clusterFull);

                // Write out the contents of the container.

              openvdb::io::File savefile("reducedGraph"+std::to_string(startTime)+".vdb");
              savefile.write(Grids);
              savefile.close();
          }
          std::cout << "resizing containers" << std::endl;
          resizeContainers();
        }

        void PlannerManager::removeDisconnectedClusters(){
          //iterate over clusters, for any clusters with no neighbours, remove from consideration.
          //This means also removing them from the safe 
          for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
            //if no neighbours
            if(_plannerObjects->clusterNeighbours[x].size() == 0){
              removeDisconnectedCluster(_plannerObjects->clusterIDs[x]);
            }
          }
          
        }

        void PlannerManager::removeDisconnectedCluster(int clusterIndex){
          //for a given cluster. set relevant cluster information to -1
          for(int x = 0; x < *_handler->plannerAllocator()->plannerBucket()->hostSafeCount(); x++){
            if(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[_handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[x]] == clusterIndex){
              _handler->plannerAllocator()->plannerBucket()->hostClusterParents()[_handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[x]] = -1;
            }
          }
          _plannerObjects->clusterNeighbours[_plannerObjects->clusterIndices[clusterIndex]].clear();
          _plannerObjects->clustersSafe[_plannerObjects->clusterIndices[clusterIndex]].clear();
          _plannerObjects->clusterIDs[_plannerObjects->clusterIndices[clusterIndex]] = -1;
          _plannerObjects->clusterIndices.erase(clusterIndex);
          
        }

        void PlannerManager::graphContinuityCheck(){
          //Checks for seperation of clusters if there are any groups of clusters that aren't connected, we remove them
          //As currently operation does not permit path planning solutions of unconnected regions. 
          //THIS WILL NOT BE NECESSARY ONCE PLANNING MODULE IS FURTHER UPDATED 
          //TO ENABLE PLANNING WITH MORE COMPLEX/DISCONNECTED ENVIRONMENTS
                      std::set<int> visitedClusters;
            //std::set<int> clusters;
            std::set<int> clusters;
            std::vector<int> clusterQueue;
          //std::cout << parents.size() << std::endl;
            for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
              if(_plannerObjects->clusterIDs[x]!=-1){
                clusters.insert(x);
              }
            }
            std::set<int>::iterator it = clusters.begin();
            std::vector<std::set<int>> clusterConnections;


            
            while (it != clusters.end())
            {
              int startCluster = *it;
              std::set<int> clusterConnection;
              if(visitedClusters.find(*it) == visitedClusters.end()){
                clusterQueue.push_back(*it);
              }
              while(clusterQueue.size()>0){
                
                int clusterID = clusterQueue.back();
                clusterQueue.pop_back();
                if(visitedClusters.find(clusterID) == visitedClusters.end()){
                  //VISIT CLUSTER
                  visitedClusters.insert(clusterID);
                  clusterConnection.insert(clusterID);
                  if(clusterID!=startCluster){
                    clusters.erase(clusterID);
                  }
                  //GET NEIGHBOURS OF CLUSTERID
                  std::set<int>::iterator neighbourIt = _plannerObjects->clusterNeighbours[clusterID].begin();
                  while(neighbourIt!=_plannerObjects->clusterNeighbours[clusterID].end()){
                    int neighbourIndex = _plannerObjects->clusterIndices[*neighbourIt];
                    //IF NEIGHBOUR HASN'T BEEN VISITED, ADD TO QUEUE TO VISIT
                    if(visitedClusters.find(neighbourIndex)==visitedClusters.end()){
                      clusterQueue.push_back(neighbourIndex);
                    }
                    neighbourIt++;
                  }
                }
              }
              clusterConnections.push_back(clusterConnection);
              if(clusters.size()>1){
                it = clusters.erase(it);
              }else{
                break;
              }
            }
            if(clusterConnections.size() > 1){
              //we have disconnected groups of clusters.
              int maxConnections = 0;
              int clusterConnectionIndex = -1;
              for(int x = 0; x < clusterConnections.size(); x++){
                if(maxConnections < clusterConnections[x].size()){
                  maxConnections = clusterConnections[x].size();
                  clusterConnectionIndex = x;
                }
              }
              for(int x = 0; x < clusterConnections.size(); x++){
                if(x != clusterConnectionIndex){
                  //Remove all clusters in cluster connection set
                    auto clusterIt = clusterConnections[x].begin();
                    while(clusterIt!= clusterConnections[x].end()){
                      removeDisconnectedCluster(_plannerObjects->clusterIDs[*clusterIt]);
                      clusterIt++;
                  }
                }
              }
            }
        }

        

        void PlannerManager::resizeClusters(){
          int minClusterSize = 0;
          int minClusterIndex = -1;
          int maxClusterSize = MAX_INT;
          int maxClusterIndex = -1;
          while(minClusterSize < 35){
            int count = 0;
            for(int x = 0; x < _plannerObjects->clusterIDs.size() ; x++){
              if(_plannerObjects->clusterIDs[x]!= -1){
                count++;
              }
            }
            //std::cout << count << std::endl;
            minClusterSize = MAX_INT;
            minClusterIndex = -1;
            for(int x = 0; x < _plannerObjects->clusterIDs.size() ; x++){
              if(_plannerObjects->clusterIDs[x]!=-1){
                if(_plannerObjects->clustersSafe[x].size() < minClusterSize){
                  minClusterSize = _plannerObjects->clustersSafe[x].size();
                  //std::cout << "minClusterSize = " << minClusterSize << std::endl;
                  minClusterIndex = _plannerObjects->clusterIDs[x];
                  //std::cout << "minClusterIndex = "<< minClusterIndex << std::endl;
                }
              }
            }
            if(minClusterSize < 35){
              //Merge Cluster with smallest neighbour.
              int minNeighbourIndex = -1;
              int minNeighbourSize = MAX_INT;
              int clusterIndex = -1;
              //if(!_plannerObjects->clusterNeighbours[_plannerObjects->clusterIndices[minClusterIndex]].empty)
              if(_plannerObjects->clusterNeighbours[_plannerObjects->clusterIndices[minClusterIndex]].size() != 0){
                std::set<int>::iterator it = _plannerObjects->clusterNeighbours[_plannerObjects->clusterIndices[minClusterIndex]].begin();
    // Iterate till the end of set
                //std::cout << "minCluster = " << minClusterIndex << " / ";
                while (it != _plannerObjects->clusterNeighbours[_plannerObjects->clusterIndices[minClusterIndex]].end())
                {
                  //std::cout << *it << " / ";
                  clusterIndex = _plannerObjects->clusterIndices[*it];
                  if(_plannerObjects->clustersSafe[clusterIndex].size() < minNeighbourSize && *it != minClusterIndex){
                    minNeighbourSize = _plannerObjects->clustersSafe[clusterIndex].size();
                    minNeighbourIndex = *it;
                  }
                  it++;
                //for(int x = 0; x < _plannerObjects->clusterNeighbours[minClusterIndex].size() < x++){
                }
                //std::cout << std::endl;
                if(minNeighbourIndex != minClusterIndex){
                //std::cout <<"combining " << minClusterIndex << " and " << minNeighbourIndex << std::endl;
                  combineClusters(minClusterIndex, minNeighbourIndex);
                }else{
                  break;
                }
              }else{
                //std::cout << "removing disconnected cluster" << std::endl;
                removeDisconnectedCluster(minClusterIndex);
              }

            }
          }
        }
        void PlannerManager::combineClusters(int cluster1Index, int cluster2Index){
          //For two clusters cluster 1 and cluster 2, combine cluster 1 into cluster 2,
          //changing all references to cluster 1 to cluster 2.
          for(int x = 0; x < *_handler->plannerAllocator()->plannerBucket()->hostSafeCount(); x++){
            if(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[_handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[x]] == cluster1Index){
              _handler->plannerAllocator()->plannerBucket()->hostClusterParents()[_handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[x]] = cluster2Index;
            }
          }
          for(int x = 0; x < _plannerObjects->clustersSafe[_plannerObjects->clusterIndices[cluster1Index]].size(); x++){
            _plannerObjects->clustersSafe[_plannerObjects->clusterIndices[cluster2Index]].push_back(_plannerObjects->clustersSafe[_plannerObjects->clusterIndices[cluster1Index]][x]);
          }
          _plannerObjects->clustersSafe[_plannerObjects->clusterIndices[cluster1Index]].clear();
          _plannerObjects->clusterIDs[_plannerObjects->clusterIndices[cluster1Index]] = -1;
          //_handler->plannerAllocator()->clusterIDs()[_plannerObjects->clusterIndices[cluster1Index]] = -1;
          std::set<int>::iterator it = _plannerObjects->clusterNeighbours[_plannerObjects->clusterIndices[cluster1Index]].begin();
  // Iterate till the end of set
          while (it != _plannerObjects->clusterNeighbours[_plannerObjects->clusterIndices[cluster1Index]].end())
          {
            if(*it != cluster2Index){
              _plannerObjects->clusterNeighbours[_plannerObjects->clusterIndices[*it]].insert(cluster2Index);
              _plannerObjects->clusterNeighbours[_plannerObjects->clusterIndices[cluster2Index]].insert(*it);
            }
            _plannerObjects->clusterNeighbours[_plannerObjects->clusterIndices[*it]].erase(cluster1Index);
            it++;
          }
          _plannerObjects->clusterNeighbours[_plannerObjects->clusterIndices[cluster1Index]].clear();

        }

        void PlannerManager::populateClusters(){
          for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
            std::vector<int> cluster;
            for(int y = 0; y < *(_handler->plannerAllocator()->plannerBucket()->hostSafeCount()); y++){
              if(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[_handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[y]] == _plannerObjects->clusterIDs[x]){
                cluster.push_back(_handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[y]);
              }
            }
            _plannerObjects->clustersSafe.push_back(cluster);
          }
        }

        void PlannerManager::mergeClusters(){
            std::set<int> visitedParents;
            std::set<int> parents;
            std::vector<int> parentQueue;
            _plannerObjects->clusterParents.clear();
            //std::vector<int> cluster;
            //std::cout << "1" << std::endl;
            auto acc = _plannerMap->plannerGrid()->getAccessor();
            for(int x = 0; x < *(_handler->plannerAllocator()->plannerBucket()->hostSafeCount()); x++){
              parents.insert(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[_handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[x]]);
              
              //std::cout << (_handler->plannerAllocator()->plannerBucket()->hostClusterParents())[x] << std::endl;
            }
            // auto parentIt = parents.begin();
            // while(parentIt!=parents.end()){
            //   std::cout << "parentsID = " << *parentIt << std::endl;
            //   parentIt++;
            // }
            //std::cout << parents.size() << std::endl;
            std::set<int>::iterator it = parents.begin();
            // Iterate till the end of set
            while (it != parents.end())
            {
              //check if cluster parent has been processed into visitedParents
              if((visitedParents.find(*it) == visitedParents.end())){

                //If it hasn't, add it to the parentQueue.
                parentQueue.push_back(*it);
                //std::cout << *it << std::endl;
                std::vector<int> cluster;
                // cluster.clear();
                while(parentQueue.size()>0){
                //   //while there are parents not visited,
                    int parentID = parentQueue.back();
                    //std::cout << parentID << std::endl;
                    int neighbourID;
                    visitedParents.insert(parentID);
                    parentQueue.pop_back();
                    //nanovdb::Coord node = (_handler->plannerAllocator()->plannerBucket()->hostGridIndex())[parentID];
                    Eigen::Matrix<int, 3, 1> eigenNode = _handler->plannerAllocator()->getGridIndexNode(parentID);
                    openvdb::Coord node(eigenNode(0), eigenNode(1), eigenNode(2));
                  
                  // for(int i = -1 ; i <=1 ; i++){
                  //   for(int j = -1 ; j <=1 ; j++){
                  //     for(int k = -1 ; k <=1 ; k++){
                  //       if(!(i==0 && j == 0 && k==0)){
                  //         neighbourID = acc.getValue(openvdb::Coord(node.x()+i, node.y()+j, node.z()+k))-1;
                  //           if(neighbourID >= 0){
                  //             //std::cout << neighbourID << std::endl;
                  //             //std::cout << *(_handler->plannerAllocator()->plannerBucket()->hostClusterMask()+neighbourID) << std::endl;
                  //               if(*(_handler->plannerAllocator()->plannerBucket()->hostClusterMask()+neighbourID) == 1){
                  //                 if((visitedParents.find(neighbourID) == visitedParents.end())){
                  //                   parentQueue.push_back(neighbourID);
                  //                   visitedParents.insert(neighbourID);
                  //                 }
                  //               //std::cout << "0" << std::endl;
                  //             }
                  //           }
                  //       }
                  //     }
                  //   }
                  // }

                  for(int i = -1; i<=1 ; i +=2){
                    int j = 0;
                    int k = 0;
                    neighbourID = acc.getValue(openvdb::Coord(node.x()+i, node.y()+j, node.z()+k))-1;
                    if(neighbourID >= 0){
                    //std::cout << neighbourID << std::endl;
                    //std::cout << *(_handler->plannerAllocator()->plannerBucket()->hostClusterMask()+neighbourID) << std::endl;
                      if(*(_handler->plannerAllocator()->plannerBucket()->hostClusterMask()+neighbourID) == 1){
                        if((visitedParents.find(neighbourID) == visitedParents.end())){
                          parentQueue.push_back(neighbourID);
                          visitedParents.insert(neighbourID);
                        }
                      //std::cout << "0" << std::endl;
                      }
                    }
                  }
                  for(int j = -1; j<=1 ; j +=2){
                    int i = 0;
                    int k = 0;
                    neighbourID = acc.getValue(openvdb::Coord(node.x()+i, node.y()+j, node.z()+k))-1;
                    if(neighbourID >= 0){
                    //std::cout << neighbourID << std::endl;
                    //std::cout << *(_handler->plannerAllocator()->plannerBucket()->hostClusterMask()+neighbourID) << std::endl;
                      if(*(_handler->plannerAllocator()->plannerBucket()->hostClusterMask()+neighbourID) == 1){
                        if((visitedParents.find(neighbourID) == visitedParents.end())){
                          parentQueue.push_back(neighbourID);
                          visitedParents.insert(neighbourID);
                        }
                      //std::cout << "0" << std::endl;
                      }
                    }
                  }

                  for(int k= -1; k<=1 ; k +=2){
                    int j = 0;
                    int i = 0;
                    neighbourID = acc.getValue(openvdb::Coord(node.x()+i, node.y()+j, node.z()+k))-1;
                    if(neighbourID >= 0){
                    //std::cout << neighbourID << std::endl;
                    //std::cout << *(_handler->plannerAllocator()->plannerBucket()->hostClusterMask()+neighbourID) << std::endl;
                      if(*(_handler->plannerAllocator()->plannerBucket()->hostClusterMask()+neighbourID) == 1){
                        if((visitedParents.find(neighbourID) == visitedParents.end())){
                          parentQueue.push_back(neighbourID);
                          visitedParents.insert(neighbourID);
                        }
                      //std::cout << "0" << std::endl;
                      }
                    }
                  }



                  //check if there are any neighbours
                  cluster.push_back(parentID);
                }

                //Increment the iterator
                _plannerObjects->clusterParents.push_back(cluster);
              }

              it++;
            }
        //std::cout << "20" << std::endl;
        _clusterMap.clear();
        _plannerObjects->clusterIDs.clear();
        //std::cout << "30" << std::endl;

        //std::vector<int> clusterTemp;
        for(int x = 0; x < _plannerObjects->clusterParents.size(); x++){
          int minID = MAX_INT;
          //clusterTemp.clear();
          for(int y = 0; y < _plannerObjects->clusterParents[x].size(); y++){
            if(_plannerObjects->clusterParents[x][y] < minID){
              minID = _plannerObjects->clusterParents[x][y];
            }
          }
          _plannerObjects->clusterIDs.push_back(minID);
          //_handler->plannerAllocator()->clusterIDs().push_back(minID);
        }
        //std::cout << "10" << std::endl;
        for(int x = 0; x < _plannerObjects->clusterParents.size(); x++){
          for(int y = 0; y < _plannerObjects->clusterParents[x].size(); y++){
            //std::cout << "ogClusterID = " << _plannerObjects->clusterParents[x][y] << "mappedCID = " << _plannerObjects->clusterIDs[x] << std::endl;
            _clusterMap.insert(std::pair<int,int>(_plannerObjects->clusterParents[x][y], _plannerObjects->clusterIDs[x]));
          }
        }
        for(int x = 0; x < *(_handler->plannerAllocator()->plannerBucket()->hostSafeCount()) ; x++){
          //std::cout << x << std::endl;
          int node = _handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[x];
          int key = _handler->plannerAllocator()->plannerBucket()->hostClusterParents()[node];

          if (_clusterMap.find(key) != _clusterMap.end()) {
            _handler->plannerAllocator()->plannerBucket()->hostClusterParents()[_handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[x]] = _clusterMap[key];
          }
          //std::cout << "Node " << node << "with parent " << key << " mapped to new parents" << _clusterMap[key] << std::endl;
          //}else{
          //  std::cout << "ERROR: Node " << node << "with parent " << key << " cannot be mapped to cluster parents" << std::endl;
          //}
        }

      }

      void PlannerManager::getClusterBoundaries(){
        for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
          std::vector<int> emptyNodeVec;
          std::set<int> emptyNodeSet;
          std::vector<std::set<int>> emptySetVec;
          _plannerObjects->clusterBoundaryNodes.push_back(emptyNodeSet);
          _plannerObjects->clusterBoundaryPoints.push_back(emptyNodeVec);
          _plannerObjects->clusterBoundarySets.push_back(emptySetVec);
        }
        //Iterate over all safe nodes for each safe node
        //check if it neighbours a node from a different cluster
        //If the node neighbours a node from a different cluster,
        //Add the node to the vector of boundary nodes for the parent cluster
        //std::cout << "gettingBoundaryNodes" << std::endl;
        auto acc = _plannerMap->plannerGrid()->getAccessor();
        for(int x = 0; x < *_handler->plannerAllocator()->plannerBucket()->hostSafeCount(); x++){
          int nodeIndex = _handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[x];
          //nanovdb::Coord node = _handler->plannerAllocator()->plannerBucket()->hostGridIndex()[nodeIndex];
          Eigen::Matrix<int, 3, 1> eigenNode = _handler->plannerAllocator()->getGridIndexNode(nodeIndex);
          openvdb::Coord node(eigenNode(0), eigenNode(1), eigenNode(2));
          int clusterParent = _handler->plannerAllocator()->plannerBucket()->hostClusterParents()[nodeIndex];
          int clusterIndex = _plannerObjects->clusterIndices[clusterParent];
          int neighbourID;
          bool isBorder = false;
          if(isBorder == false){
            for(int i = -1; i <= 1; i+=2){
              neighbourID = acc.getValue(openvdb::Coord(node.x()+i, node.y(), node.z()))-1;
              if(neighbourID >= 0){
                if(*(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()+neighbourID) != clusterParent){
                  _plannerObjects->clusterBoundaryNodes[clusterIndex].insert(nodeIndex);
                  //std::cout << "clusterIndex = " << clusterIndex << " nodeIndex = " <<  nodeIndex << std::endl;
                  isBorder = true;
                  break;
                  //_plannerObjects->clusterNeighbours[clusterIndex].insert(*(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()+neighbourID));
                }
              }
            }
          }
          if(isBorder == false){
              for(int y = -1; y <= 1; y+=2){
                neighbourID = acc.getValue(openvdb::Coord(node.x(), node.y()+y, node.z()))-1;
                if(neighbourID >= 0){
                  if(*(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()+neighbourID) != clusterParent){
                    _plannerObjects->clusterBoundaryNodes[clusterIndex].insert(nodeIndex);
                    //std::cout << "clusterIndex = " << clusterIndex << " nodeIndex = " <<  nodeIndex << std::endl;
                    isBorder = true;
                    break;
                    //_plannerObjects->clusterNeighbours[clusterIndex].insert(*(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()+neighbourID));
                  }
                }
              }
            }
          if(isBorder == false){
              for(int z = -1; z <= 1; z+=2){
                neighbourID = acc.getValue(openvdb::Coord(node.x(), node.y(), node.z()+z))-1;
                if(neighbourID >= 0){
                  if(*(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()+neighbourID) != clusterParent){
                    _plannerObjects->clusterBoundaryNodes[clusterIndex].insert(nodeIndex);
                    //std::cout << "clusterIndex = " << clusterIndex << " nodeIndex = " <<  nodeIndex << std::endl;
                    isBorder = true;
                    break;
                    //_plannerObjects->clusterNeighbours[clusterIndex].insert(*(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()+neighbourID));
                  }
                }
              }
          }
        }
        //For the boundary nodes for each cluster, sort them into sets of nodes based on their adjacency
        //std::cout << "gettingBoundarySets" << std::endl;
        for(int x = 0; x < _plannerObjects->clusterBoundaryNodes.size() ; x++){
          //std::cout << x << std::endl;
          if(_plannerObjects->clusterIDs[x]!=-1){
          std::set<int> visitedNodes;
          //std::set<int> Nodes;
          std::vector<int> nodeQueue;
          //std::vector<int> cluster;
          //std::cout << "1" << std::endl;
          //auto acc = _plannerMap->plannerGrid()->getAccessor();
          //for(int y = 0; y < _plannerObjects->clusterBoundaryNodes[x].size()); y++){
            //parents.insert(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()[_handler->plannerAllocator()->plannerBucket()->hostSafeIndex()[x]]);
            //std::cout << (_handler->plannerAllocator()->plannerBucket()->hostClusterParents())[x] << std::endl;
          //}
          //std::cout << parents.size() << std::endl;
          std::set<int>::iterator it = _plannerObjects->clusterBoundaryNodes[x].begin();
          // Iterate till the end of set
          while (it != _plannerObjects->clusterBoundaryNodes[x].end())
          {
            //check if boundary node has been processed into visitedNodes
            if((visitedNodes.find(*it) == visitedNodes.end())){
              //std::cout <<"iteratorNode" << (*it) << std::endl;
              //If it hasn't, add it to the parentQueue.
              nodeQueue.push_back(*it);
              //std::cout << *it << std::endl;
              std::set<int> boundarySet;
              // cluster.clear();
              while(nodeQueue.size()>0){
              //   //while there are parents not visited,
                int parentID = nodeQueue.back();
                //std::cout  << "queue node: "<<parentID << std::endl;
                int clusterID = _plannerObjects->clusterIDs[x];
                //std::cout << parentID << std::endl;
                int neighbourID;
                visitedNodes.insert(parentID);
                nodeQueue.pop_back();
                //nanovdb::Coord node = (_handler->plannerAllocator()->plannerBucket()->hostGridIndex())[parentID];
                Eigen::Matrix<int, 3, 1> eigenNode = _handler->plannerAllocator()->getGridIndexNode(parentID);
                openvdb::Coord node(eigenNode(0), eigenNode(1), eigenNode(2));
                //std::cout << "check" << std::endl;
                for(int i = -1 ; i <=1 ; i++){
                  for(int j = -1 ; j <=1 ; j++){
                    for(int k = -1 ; k <=1 ; k++){
                      if(!(i==0 && j == 0 && k==0)){
                        neighbourID = acc.getValue(openvdb::Coord(node.x()+i, node.y()+j, node.z()+k))-1;
                          if(neighbourID >= 0){
                            //std::cout << neighbourID << std::endl;
                            //std::cout << *(_handler->plannerAllocator()->plannerBucket()->hostClusterMask()+neighbourID) << std::endl;

                            //if(*(_handler->plannerAllocator()->plannerBucket()->hostClusterParents()+neighbourID) == clusterID){
                            if((_plannerObjects->clusterBoundaryNodes[x].find(neighbourID) != _plannerObjects->clusterBoundaryNodes[x].end())){
                              if((visitedNodes.find(neighbourID) == visitedNodes.end())){
                                nodeQueue.push_back(neighbourID);
                                visitedNodes.insert(neighbourID);
                              }
                              //std::cout << "0" << std::endl;
                            }
                          }
                      }
                    }
                  }
                }

              //check if there are any neighbours
              //std::cout << "insertingNodeIntoBoundarySet: " <<  parentID <<std::endl;
              boundarySet.insert(parentID);
            }

          //Increment the iterator

          //std::cout << "insertingBoundarySetIntoVector: " <<  x <<std::endl;
          _plannerObjects->clusterBoundarySets[x].push_back(boundarySet);
          }

          it++;
        }
      }
      }
        //Get cluster boundary points
        //std::cout << "gettingBoundaryPoints" << std::endl;
        for(int x = 0; x < _plannerObjects->clusterBoundarySets.size(); x++){
          if(_plannerObjects->clusterIDs[x]!=-1){
          for(int y = 0; y < _plannerObjects->clusterBoundarySets[x].size(); y++){
            //int nodePoint;
            openvdb::Coord meanNode = openvdb::Coord(0,0,0);
            float count = 0;
            std::set<int>::iterator it = _plannerObjects->clusterBoundarySets[x][y].begin();
            // Iterate till the end of set
            while (it != _plannerObjects->clusterBoundarySets[x][y].end())
              {
                //std::cout << *it << std::endl;
                Eigen::Matrix<int, 3, 1> eigenNode = _handler->plannerAllocator()->getGridIndexNode(*it);
                openvdb::Coord node(eigenNode(0), eigenNode(1), eigenNode(2));
                meanNode += node; //openvdb::Coord(meanNode[0]+_handler->plannerAllocator()->plannerBucket()->hostGridIndex()[*it][0],
                                        //   meanNode[1]+_handler->plannerAllocator()->plannerBucket()->hostGridIndex()[*it][1],
                                        //   meanNode[2]+_handler->plannerAllocator()->plannerBucket()->hostGridIndex()[*it][2]
                                        // );
                it++;
                count+=1.0;
              }
              meanNode = openvdb::Coord(std::floor((float)meanNode.x()/count),
                                        std::floor((float)meanNode.y()/count),
                                        std::floor((float)meanNode.z()/count));
              int meanIndex = acc.getValue(meanNode);
              if(meanIndex < 0){
                  meanIndex = abs(meanIndex)-1;
              }
              if((_plannerObjects->clusterBoundarySets[x][y].find(meanIndex) != _plannerObjects->clusterBoundarySets[x][y].end())){
                //If mean index is part of boundary set, then
                _plannerObjects->clusterBoundaryPoints[x].push_back(meanIndex);
              }else{
                //calculate distance between meanNode and each node in boundaryset.
                std::set<int>::iterator distIt = _plannerObjects->clusterBoundarySets[x][y].begin();
                float minDistance = 1000.0;
                int boundaryIndex = -1;
                //openvdb::Vec3D difference;
                while (distIt != _plannerObjects->clusterBoundarySets[x][y].end())
                  {
                    //difference = openvdb::Vec3D(meanNode[0]-_handler->plannerAllocator()->plannerBucket()->hostGridIndex);
                    
                    Eigen::Matrix<int, 3, 1> eigenNode = _handler->plannerAllocator()->getGridIndexNode(*distIt);
                    openvdb::Coord node(eigenNode(0), eigenNode(1), eigenNode(2));
                    float dist = (meanNode - node).asVec3d().length();
                    // float dist = openvdb::Vec3d(meanNode[0]-_handler->plannerAllocator()->plannerBucket()->hostGridIndex()[*distIt][0],
                    //                             meanNode[1]-_handler->plannerAllocator()->plannerBucket()->hostGridIndex()[*distIt][1],
                    //                             meanNode[2]-_handler->plannerAllocator()->plannerBucket()->hostGridIndex()[*distIt][2]).length();
                    if(dist < minDistance){
                      minDistance = dist;
                      boundaryIndex = *distIt;
                    }
                    distIt++;
                    //count+=1.0;
                  }
                  //std::cout << boundaryIndex << std::endl;
                _plannerObjects->boundaryCount++;
                _plannerObjects->clusterBoundaryPoints[x].push_back(boundaryIndex);
              }
            }
            }
          }
            _plannerObjects->boundaryScoreSize = (_plannerObjects->boundaryCount)*((_plannerObjects->boundaryCount)-1)/2;
          // for(int x =  0; x < _plannerObjects->clusterBoundaryPoints.size(); x++){
          //   std::cout << _plannerObjects->clusterBoundaryPoints[x].size() << std::endl;
          // }
        }


        void PlannerManager::populateFullClusters(){
          populateValidClusters();
          for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
            std::vector<int> clusterFull;
            for(int i = 0; i < _plannerObjects->clustersSafe[x].size(); i++){
              clusterFull.push_back(_plannerObjects->clustersSafe[x][i]);
            }
            for(int i = 0;  i < _plannerObjects->clustersValid[x].size(); i++){
              clusterFull.push_back(_plannerObjects->clustersValid[x][i]);
            }
            _plannerObjects->clustersFull.push_back(clusterFull);
          }
        }
        void PlannerManager::populateValidClusters(){
          auto acc = _plannerMap->plannerGrid()->getAccessor();

          for(int x = 0; x < _plannerObjects->clustersSafe.size(); x++){
            std::set<int> validNodeSet;
            for(int y = 0; y < _plannerObjects->clustersSafe[x].size(); y++){
              //nanovdb::Coord node = (_handler->plannerAllocator()->plannerBucket()->hostGridIndex())[_plannerObjects->clustersSafe[x][y]];
              Eigen::Matrix<int, 3, 1> eigenNode = _handler->plannerAllocator()->getGridIndexNode(_plannerObjects->clustersSafe[x][y]);
              openvdb::Coord node(eigenNode(0), eigenNode(1), eigenNode(2));
              int neighbourID;
              for(int i = -1 ; i <=1 ; i++){
                for(int j = -1 ; j <=1 ; j++){
                  for(int k = -1 ; k <=1 ; k++){
                    if(!(i==0 && j == 0 && k==0)){
                      neighbourID = acc.getValue(openvdb::Coord(node.x()+i, node.y()+j, node.z()+k));
                        if(neighbourID < 0){
                          neighbourID = abs(neighbourID)-1;
                          //If the set doesn't already include the ID
                          if((validNodeSet.find(neighbourID) == validNodeSet.end())){
                            //nodeQueue.push_back(neighbourID);
                            validNodeSet.insert(neighbourID);
                          }
                        }
                    }
                  }
                }
              }
            }
            std::vector<int> validVec;
            std::set<int>::iterator it = validNodeSet.begin();
            while(it!= validNodeSet.end()){
              validVec.push_back(*it);
              it++;
            }
            _plannerObjects->clustersValid.push_back(validVec);
          }


          return;
        }
        void PlannerManager::resizeContainers(){
          //After having combined clusters, many entries are zeroed. We should remove these and update the appropiate index
          //_plannerObjects->clusterIndices
          //_plannerObjects->clustersSafe
          //_plannerObjects->clusterIDs
          std::vector<std::vector<int>>  tempClustersSafe;
          std::vector<int> tempClusterIDs;
          std::map<int,int> tempClusterIndices;
          std::vector<std::set<int>> tempNeighbours;
          //std::cout  << "old size = " <<_plannerObjects->clustersSafe.size() << std::endl;
          int count = 0;
          for(int x = 0; x < _plannerObjects->clusterIDs.size() ; x++){
            if(_plannerObjects->clusterIDs[x] != -1){
              std::vector<int> tempCluster;
              for(int y = 0; y< _plannerObjects->clustersSafe[x].size(); y++){
                tempCluster.push_back(_plannerObjects->clustersSafe[x][y]);
              }
              std::set<int> tempNeighbour;
              std::set<int>::iterator it = _plannerObjects->clusterNeighbours[x].begin();
              while(it != _plannerObjects->clusterNeighbours[x].end()){
                tempNeighbour.insert(*it);
                it++;
              }
              tempNeighbours.push_back(tempNeighbour);
              tempClustersSafe.push_back(tempCluster);
              tempClusterIDs.push_back(_plannerObjects->clusterIDs[x]);
              tempClusterIndices.insert(std::pair<int,int>(_plannerObjects->clusterIDs[x],count));
              count++;
            }

          }
          _plannerObjects->clusterNeighbours = tempNeighbours;
          _plannerObjects->clustersSafe = tempClustersSafe;
          _plannerObjects->clusterIDs = tempClusterIDs;
          _plannerObjects->clusterIndices = tempClusterIndices;
          //std::cout  << "new size = " <<_plannerObjects->clustersSafe.size() << std::endl;

          // for(int x = 0; x < _plannerObjects->clusterIDs.size() ; x++){
          //   if(_plannerObjects->clusterIDs != -1){
          //     tempClusterIndices.insert(_plannerObjects->clusterIDs)
          //   }
          // }
        }

        void PlannerManager::populateGlobalClusterMap(){
          for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
            //std::map<int, int> clusterMap;
            //_plannerObjects->globalClusterMap.push_back(clusterMap);
            for(int y = 0; y < _plannerObjects->clustersSafe[x].size(); y++){
              _plannerObjects->globalClusterMap.insert(std::pair<int,int>(_plannerObjects->clustersSafe[x][y], x));
            }
          }
        }

        void PlannerManager::populateEdges(){
          populateClusterEdges();
          populateClusterEdgeCombos();
        }

        void PlannerManager::populateClusterEdges(){
          for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
            std::vector<int> tempVec;
            _plannerObjects->clusterEdges.push_back(tempVec);
            _plannerObjects->clusterEdgeCombos.push_back(tempVec);
          }
          int totalVerts = 0;
          for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
              //int clusterIndex = _handler->plannerAllocator()->plannerCluster(x)->;
              totalVerts += *(_handler->plannerAllocator()->plannerCluster(x)->hostVertexCount());
              for(int y = 0; y < *(_handler->plannerAllocator()->plannerCluster(x)->hostVertexCount()) ; y++){
              int index = _handler->plannerAllocator()->plannerCluster(x)->hostVertexBuffer()[y];

              //std::cout <<  _handler->plannerAllocator()->plannerCluster(x)->hostVertexBuffer()[y] << std::endl;
              _plannerObjects->clusterEdges[x].push_back(index);
              _plannerObjects->clusterEdgeCombos[x].push_back(index);
            }
          }
          //std::cout << "Total Vertex Count = " << totalVerts << std::endl;
        }

        void PlannerManager::populateClusterEdgeCombos(){
          for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
            std::set<int>::iterator it = _plannerObjects->clusterNeighbours[x].begin();
            while(it != _plannerObjects->clusterNeighbours[x].end()){
              int index = _plannerObjects->clusterIndices[*it];
              for(int y = 0; y < _plannerObjects->clusterEdges[index].size(); y++){
                _plannerObjects->clusterEdgeCombos[x].push_back(_plannerObjects->clusterEdges[index][y]);
              }
              it++;
            }
          }
        }

        void PlannerManager::getClosestVertices(){
          //for each cluster, create an std::map that maps the cluster index
          // of a node to the vertex index of the closest vertex node.
          for(int i = 0; i < _plannerObjects->clusterIDs.size() ; i++){
            int clusterCount = *(_handler->plannerAllocator()->plannerCluster(i)->hostClusterCount());
            std::map<int,int> clusterVertexMap;
            //std::map<int,int> clusterGlobalMap;
            _plannerObjects->clusterVertexNodeMap.push_back(clusterVertexMap);
            //_plannerObjects->globalClusterNodeMap.push_back(clusterGlobalMap);
            for(int x = 0; x < *(_handler->plannerAllocator()->plannerCluster(i)->hostVertexCount()); x++){
              //For each vertex node, add the cluster node and vertex node index to the clusterVertexMap first.
              int clusterIndex = _handler->plannerAllocator()->plannerCluster(i)->hostVertexBuffer()[x];
              //std::cout << "x = " << x << " vertexBuffer = " << _handler->plannerAllocator()->plannerCluster(i)->hostVertexBuffer()[x] << std::endl;
              _plannerObjects->clusterVertexNodeMap[i].insert(std::pair<int,int>(clusterIndex, x));
            }


            for(int x = 0; x < clusterCount; x++){
              //Lets insert this cluster node into the global map
              int globalIndex = _handler->plannerAllocator()->plannerCluster(i)->hostClusterIndex()[x];
              _plannerObjects->globalClusterNodeMap.insert(std::pair<int,int>(globalIndex, x));
              //First check if cluster node is a vertex node already.
              if(_plannerObjects->clusterVertexNodeMap[i].count(x)==0){
                //if not a vertex, then lets get the closest vertex for this cluster node.

                int minVertexIndex = -1;
                float minVertexDistance = FLT_MAX;
                for(int y = 0; y < *(_handler->plannerAllocator()->plannerCluster(i)->hostVertexCount()); y++){
                  int vertexClusterIndex = _handler->plannerAllocator()->plannerCluster(i)->hostVertexBuffer()[y];
                  float dist = _handler->plannerAllocator()->plannerCluster(i)->hostClusterDistances()[x*clusterCount+vertexClusterIndex];
                  if(dist < minVertexDistance && dist > 0){
                    minVertexDistance = dist;
                    minVertexIndex = y;
                  }
                }
                //DEBUG
                // if(minVertexIndex == -1){
                //  for(int y = 0; y < *(_handler->plannerAllocator()->plannerCluster(i)->hostVertexCount()); y++){
                //   int vertexClusterIndex = _handler->plannerAllocator()->plannerCluster(i)->hostVertexBuffer()[y];
                //   float dist = _handler->plannerAllocator()->plannerCluster(i)->hostClusterDistances()[x*clusterCount+vertexClusterIndex];
                //   std::cout << "vertexDist = " << dist << std::endl;
                //   //if(dist < minVertexDistance && dist > 0){
                //   //  minVertexDistance = dist;
                //   //  minVertexIndex = y;
                //   //}
                // } 
                // }


                _plannerObjects->clusterVertexNodeMap[i].insert(std::pair<int,int>(x,minVertexIndex));
              }
            }
          }
        }
        
        bool PlannerManager::isCoordSafe(openvdb::Coord coord){
          if((_plannerMap->plannerAccessor()->getValue(coord)) <= 0){
            return false;
          }else{
            return true;
          }
        }

        int PlannerManager::getGlobalIndexFromCoord(openvdb::Coord coord){
          return abs(_plannerMap->plannerAccessor()->getValue(coord))-1; //IMPLEMENT HERE
        }

        openvdb::Coord PlannerManager::getCoordFromGlobalIndex(int index){
          return openvdb::Coord(_handler->plannerAllocator()->getGridIndexNode(index)(0),
                                _handler->plannerAllocator()->getGridIndexNode(index)(1),
                                _handler->plannerAllocator()->getGridIndexNode(index)(2));
        }


        // getShortestPathBetweenClusters(){
        //
        //
        // }

        void PlannerManager::getAverageNodePathScores(){
          //_plannerObjects->meanNodePathScores.resize(,(_plannerObjects->clusterIDs.size());
          _plannerObjects->meanNodePathScores.resize(_plannerObjects->clusterIDs.size(), std::vector<float>(_plannerObjects->clusterIDs.size()));
          _plannerObjects->nodePathCounts.resize(_plannerObjects->clusterIDs.size(), std::vector<int>(_plannerObjects->clusterIDs.size()));
          //Iterate over all cluster pairs, getting score between all pairs of boundary paths.
          for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
            for(int y = 0; y < _plannerObjects->clusterIDs.size(); y++){
              if(x < y){
                _plannerObjects->nodePathCounts[x][y] = _plannerObjects->clusterBoundaryPoints[x].size() * _plannerObjects->clusterBoundaryPoints[y].size();
                _plannerObjects->nodePathCounts[y][x] = _plannerObjects->clusterBoundaryPoints[x].size() * _plannerObjects->clusterBoundaryPoints[y].size();
                //for each boundary point in cluster x
                std::vector<int> xBoundaries = _plannerObjects->clusterBoundaryPoints[x];
                std::vector<int> yBoundaries = _plannerObjects->clusterBoundaryPoints[y];
                for(int xp = 0; xp < xBoundaries.size(); xp++){
                  //for each boundary point in cluster y
                  int xPoint = _plannerObjects->clusterBoundaryPoints[x][xp];
                  int bSrc = _plannerObjects->globalToBoundaryMap[xPoint];
                  for(int yp = 0; yp < yBoundaries.size(); yp++){
                    int yPoint = _plannerObjects->clusterBoundaryPoints[y][yp];
                    int bDest = _plannerObjects->globalToBoundaryMap[yPoint];
                    std::pair<int, int> bpair;
                    if(bSrc < bDest){
                      bpair = std::pair<int, int>(bSrc, bDest);
                    }else{
                      bpair = std::pair<int, int>(bDest, bSrc);
                    }
                    if(_plannerObjects->boundaryPaths.count(bpair)>0){
                    float score = _plannerObjects->boundaryPaths[bpair].first;
                    _plannerObjects->meanNodePathScores[x][y]+=score;
                    _plannerObjects->meanNodePathScores[y][x]+=score;
                    }else{
                      _plannerObjects->nodePathCounts[x][y]-=1;
                      _plannerObjects->nodePathCounts[y][x]-=1;
                    }
                  }
                }
              }
            }
          }
          _plannerObjects->maxMovePenalty = 0.0;
          for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
            for(int y = 0; y < _plannerObjects->clusterIDs.size(); y++){
              if(x < y){
                if(_plannerObjects->nodePathCounts[x][y] > 0){
                  _plannerObjects->meanNodePathScores[x][y] = _plannerObjects->meanNodePathScores[x][y]/((float)_plannerObjects->nodePathCounts[x][y]);
                  _plannerObjects->meanNodePathScores[y][x] = _plannerObjects->meanNodePathScores[y][x]/((float)_plannerObjects->nodePathCounts[y][x]);
                  if(_plannerObjects->meanNodePathScores[x][y]>_plannerObjects->maxMovePenalty){
                    _plannerObjects->maxMovePenalty = _plannerObjects->meanNodePathScores[x][y];
                  }
                }else{
                  _plannerObjects->meanNodePathScores[x][y] = -1.0;
                  _plannerObjects->meanNodePathScores[y][x] = -1.0;
                }
              }
            }
          }
        }



        void PlannerManager::getAllBoundaryPaths(){
          //std::cout << _plannerObjects->boundaryCount << std::endl;
          //std::cout << _plannerObjects->boundaryScoreSize << std::endl;
          for(int index = 0; index < _plannerObjects->boundaryScoreSize; index++){
            //std::cout << "index "<< index << std::endl;
            int x = _handler->plannerAllocator()->plannerBucket()->hostBoundaryPairs()[index];
            //std::cout << "x = "  << x << std::endl;
            int y = _handler->plannerAllocator()->plannerBucket()->hostBoundaryPairs()[index + _plannerObjects->boundaryScoreSize];
            std::pair<int, int> srcPair = std::pair<int, int>(x,y);
            //std::cout << "y = " <<  y << std::endl;
            if(_plannerObjects->boundaryPaths.count(srcPair) == 0){
              float score = _handler->plannerAllocator()->plannerBucket()->hostGraphScores()[index];
              std::vector<int> path;
              //int startNode = _plannerObjects->boundaryToGlobalMap[x].second;
              ////std::cout << "1" << std::endl;
              //int endNode = _plannerObjects->boundaryToGlobalMap[y].second;
              path.push_back(x);
              //std::cout << "startNode = " << x << std::endl;
              int stepIndex = 1;
              ////std::cout << "hostLevel = "<<*_handler->plannerAllocator()->plannerBucket()->hostLevel() << std::endl;
              int bnextIndex = _handler->plannerAllocator()->plannerBucket()->hostBoundaryPaths()[index*(*(_handler->plannerAllocator()->plannerBucket()->hostLevel()))];
              //std::cout << "bnextIndex "<< bnextIndex << std::endl;
              //int nextIndex = _plannerObjects->boundaryToGlobalMap[bnextIndex].second;
              ////std::cout << "1" << std::endl;
              ////std::cout << "nextNode = " << nextIndex << std::endl;
              while(bnextIndex != y && bnextIndex != -1){
                path.push_back(bnextIndex);
                bnextIndex = _handler->plannerAllocator()->plannerBucket()->hostBoundaryPaths()[index*(*(_handler->plannerAllocator()->plannerBucket()->hostLevel()))+stepIndex];
                //nextIndex = _plannerObjects->boundaryToGlobalMap[bnextIndex].second;
                ////std::cout << "nextNode = " << nextIndex << std::endl;
                //std::cout << "bnextIndex "<< bnextIndex << std::endl;
                stepIndex++;
              }
              ////std::cout << "endNode = " << y << std::endl;
              path.push_back(y);
              std::vector<int> globalPath = getGlobalPathFromBoundaryPath(path);
              //for(int i = 0; i < path.size(); i++){
              //  //std::cout << path[i] << " / ";
              //}
              // //std::cout << std::endl;

              ////std::cout << "1" << std::endl;
              std::pair<float, std::vector<int>> pathPair = std::pair<float, std::vector<int>>(score, globalPath);
              _plannerObjects->boundaryPaths.insert(std::pair<std::pair<int,int>, std::pair<float, std::vector<int>>>(srcPair, pathPair));
              //std::cout << "score = " << score << std::endl;
              for(int x = 0; x < path.size(); x++){
                //std::cout << "node = " << globalPath[x] << std::endl;
              }
            }else{
              //std::cout << "score = " << _plannerObjects->boundaryPaths[srcPair].first << std::endl;
              std::vector<int> path = _plannerObjects->boundaryPaths[srcPair].second;
              if(path.size()!=0){
                for(int x = 0; x < path.size(); x++){
                  //std::cout << "node = " << path[x] << std::endl;
                }
              }else{
                //std::cout << "node = " << _plannerObjects->boundaryToGlobalMap[x].second << std::endl;
                //std::cout << "node = " << _plannerObjects->boundaryToGlobalMap[y].second << std::endl;
              }
            }

          }
          //std::cout << "2" << std::endl;
        }

        std::vector<int> PlannerManager::getGlobalPathFromBoundaryPath(std::vector<int> path){
          std::vector<int> globalPath;
          int currentBPoint = path[0];
          int nextBPoint;
          globalPath.push_back(_plannerObjects->boundaryToGlobalMap[currentBPoint].second);
          for(int x = 1; x < path.size(); x++){
            //std::cout << "currentBPoint: " << currentBPoint << std::endl;
            nextBPoint = path[x];
            std::pair<int, int> pair;
            bool reversePath;
            if(currentBPoint < nextBPoint){
              pair = std::pair<int, int>(currentBPoint, nextBPoint);
              reversePath = false;
            }else{
              pair = std::pair<int, int>(nextBPoint, currentBPoint);
              reversePath = true;
            }
            std::vector<int> intermediatePath = _plannerObjects->boundaryPaths[pair].second;
            if(intermediatePath.size() > 0){
              if(reversePath){
                std::reverse(intermediatePath.begin(), intermediatePath.end());
              }
              for(int y = 1; y < intermediatePath.size()-1; y++){
                //std::cout << "intermediateGlobal: " << intermediatePath[y]  << std::endl;
                //std::cout << "intermediateGlobal: " << _plannerObjects->boundaryToGlobalMap[intermediatePath[y]].second <<  std::endl;
                globalPath.push_back(intermediatePath[y]);
              }
            }
            //std::cout << "nextBPoint: " << nextBPoint << std::endl;
            globalPath.push_back(_plannerObjects->boundaryToGlobalMap[nextBPoint].second);
            currentBPoint = nextBPoint;
          }
          return globalPath;
        }




        void PlannerManager::checkVertexValidity(int vertex){
          if(vertex<0){
              throw std::invalid_argument("closest vertex can't be -1");
          }
        }


        std::vector<int> PlannerManager::getShortestPathBetweenClusters(int srcCluster, int srcIndex, int destCluster, int destIndex){
          std::vector<int> srcBoundaries = _plannerObjects->clusterBoundaryPoints[srcCluster];
          std::vector<int> destBoundaries = _plannerObjects->clusterBoundaryPoints[destCluster];

          float minScore = FLT_MAX;
          //int minSrcIndex = -1;
          //int minDestIndex = -1;
          int minSrcBoundary = -1;
          int minDestBoundary = -1;
          int minSrcCluster = -1;
          int minDestCluster = -1;
          std::vector<int> srcPath;
          std::vector<int> destPath;
          //std::cout << "0" << std::endl;
          //std::cout << "srcBoundaryCount "<< srcBoundaries.size() << std::endl;
          //std::cout << "destBoundaryCount "<< destBoundaries.size() << std::endl;
          for(int x = 0; x < srcBoundaries.size(); x++){
            //std::cout << "src x.1 = " << x << std::endl;
            float srcBoundaryDist = 0.0;
            std::vector<int> tempSrcPath;
            int bSrc = _plannerObjects->globalToBoundaryMap[srcBoundaries[x]];
            if(srcIndex != srcBoundaries[x]){
              tempSrcPath = getShortestPathWithinCluster(srcCluster, _plannerObjects->globalClusterNodeMap[srcIndex], _plannerObjects->globalClusterNodeMap[srcBoundaries[x]]);
              srcBoundaryDist = getScoreOfClusterPath(srcCluster, tempSrcPath);
            }else{
              tempSrcPath.push_back(_plannerObjects->globalClusterNodeMap[srcIndex]);
            }
            //std::cout << "src x.2 = " << x << std::endl;
            //std::cout << "tempSrcPath size = " <<  tempSrcPath.size() << std::endl;
            //std::cout << "src x.3 = " << x << std::endl;
            for(int y = 0; y < destBoundaries.size(); y++){
              //std::cout << "dest y.1 = " << y << std::endl;
              float destBoundaryDist = 0.0;
              std::vector<int> tempDestPath;
              int bDest = _plannerObjects->globalToBoundaryMap[destBoundaries[y]];
              if(destIndex != destBoundaries[y]){
                //std::cout << "dest y.2 = " << y << std::endl;
                tempDestPath = getShortestPathWithinCluster(destCluster, _plannerObjects->globalClusterNodeMap[destBoundaries[y]],  _plannerObjects->globalClusterNodeMap[destIndex]);
                //std::cout << "dest y.3 = " << y << std::endl;
                destBoundaryDist = getScoreOfClusterPath(destCluster, tempDestPath);
              }else{
                tempDestPath.push_back(_plannerObjects->globalClusterNodeMap[destIndex]);
              }
              //std::cout << "pairScoreComp" << std::endl;
              std::pair<int,int> pair;
              if(bSrc < bDest){
                pair = std::pair<int,int>(bSrc, bDest);
              }else{
                pair = std::pair<int,int>(bDest, bSrc);
              }
              float score = srcBoundaryDist+destBoundaryDist+_plannerObjects->boundaryPaths[pair].first;
              //std::cout << "scrBScore = " << srcBoundaryDist << "|"
                        // << "destBScore = " << destBoundaryDist << "|"
                        // << "boundaryScore = " << _plannerObjects->boundaryPaths[pair].first << "|"
                        // << "score = " << score << "|" << std::endl;
              if(score < minScore){
                minScore = score;
                //minSrcIndex = x;
                //minDestIndex = y;
                minSrcBoundary = bSrc;
                minDestBoundary = bDest;
                srcPath = tempSrcPath;
                destPath = tempDestPath;
                //minSrcCluster = _plannerObjects->globalClusterNodeMap[srcBoundaries[x]]
                //minDestCluster = _plannerObjects->globalClusterNodeMap[destBoundaries[y]]

              }
            }
          }

          srcPath = globalPathFromClusterPath(srcCluster, srcPath);
          destPath = globalPathFromClusterPath(destCluster, destPath);
          bool reversed = false;
          if(minSrcBoundary > minDestBoundary){
            reversed = true;
          }
          std::pair<int, int> bpair;
          if(reversed){
            bpair = std::pair<int, int>(minDestBoundary, minSrcBoundary);
          }else{
            bpair = std::pair<int, int>(minSrcBoundary, minDestBoundary);
          }
          std::vector<int> path = _plannerObjects->boundaryPaths[bpair].second;
          if(path.size()>0){
            if(reversed){
              std::reverse(path.begin(), path.end());
            }
          }else{
            path.push_back(_plannerObjects->boundaryToGlobalMap[minSrcBoundary].second);
            path.push_back(_plannerObjects->boundaryToGlobalMap[minDestBoundary].second);
          }
          //std::vector<int> srcPath  = getShortestPathWithinCluster();
          //std::vector<int> destPath = getShortestPathWithinCluster();
          std::vector<int> fullPath;
          for(int x = 0; x < srcPath.size(); x++){
            fullPath.push_back(srcPath[x]);
            //std::cout << srcPath[x] << std::endl;
          }
          //std::cout << "-" << std::endl;
          for(int x = 1; x < path.size(); x++){
            fullPath.push_back(path[x]);
            //std::cout << path[x] << std::endl;
          }
          //std::cout << "-" << std::endl;
          for(int x = 1; x < destPath.size(); x++){
            fullPath.push_back(destPath[x]);
            //std::cout << destPath[x] << std::endl;
          }
          return fullPath;
        }

        std::pair<float, std::vector<int>> PlannerManager::getShortestPathAndScoreBetweenClusters(int srcCluster, int srcIndex, int destCluster, int destIndex){
          std::vector<int> srcBoundaries = _plannerObjects->clusterBoundaryPoints[srcCluster];
          std::vector<int> destBoundaries = _plannerObjects->clusterBoundaryPoints[destCluster];

          float minScore = FLT_MAX;
          //int minSrcIndex = -1;
          //int minDestIndex = -1;
          int minSrcBoundary = -1;
          int minDestBoundary = -1;
          int minSrcCluster = -1;
          int minDestCluster = -1;
          std::vector<int> srcPath;
          std::vector<int> destPath;
          //std::cout << "0" << std::endl;
          //std::cout << "srcBoundaryCount "<< srcBoundaries.size() << std::endl;
          //std::cout << "destBoundaryCount "<< destBoundaries.size() << std::endl;
          for(int x = 0; x < srcBoundaries.size(); x++){
            //std::cout << "src x.1 = " << x << std::endl;
            float srcBoundaryDist = 0.0;
            std::vector<int> tempSrcPath;
            int bSrc = _plannerObjects->globalToBoundaryMap[srcBoundaries[x]];
            if(srcIndex != srcBoundaries[x]){
              tempSrcPath = getShortestPathWithinCluster(srcCluster, _plannerObjects->globalClusterNodeMap[srcIndex], _plannerObjects->globalClusterNodeMap[srcBoundaries[x]]);
              srcBoundaryDist = getScoreOfClusterPath(srcCluster, tempSrcPath);
            }else{
              tempSrcPath.push_back(_plannerObjects->globalClusterNodeMap[srcIndex]);
            }
            //std::cout << "tempSRCPath= "<< std::endl;
            //for(int x = 0; x < tempSrcPath.size(); x++){
            //   std::cout << _plannerClusters[srcCluster]->hostClusterIndex()[tempSrcPath[x]] << "/";
            // }
            //  std::cout << std::endl;
            //std::cout << "src x.2 = " << x << std::endl;
            //std::cout << "tempSrcPath size = " <<  tempSrcPath.size() << std::endl;
            //std::cout << "src x.3 = " << x << std::endl;
            for(int y = 0; y < destBoundaries.size(); y++){
              //std::cout << "dest y.1 = " << y << std::endl;
              float destBoundaryDist = 0.0;
              std::vector<int> tempDestPath;
              int bDest = _plannerObjects->globalToBoundaryMap[destBoundaries[y]];
              if(destIndex != destBoundaries[y]){
                //std::cout << "dest y.2 = " << y << std::endl;
                tempDestPath = getShortestPathWithinCluster(destCluster, _plannerObjects->globalClusterNodeMap[destBoundaries[y]],  _plannerObjects->globalClusterNodeMap[destIndex]);

                //std::cout << "dest y.3 = " << y << std::endl;
                destBoundaryDist = getScoreOfClusterPath(destCluster, tempDestPath);
              }else{
                tempDestPath.push_back(_plannerObjects->globalClusterNodeMap[destIndex]);
              }
              // std::cout << "tempDestPath= "<< std::endl;
              // for(int x = 0; x < tempDestPath.size(); x++){
              //   std::cout << _plannerClusters[destCluster]->hostClusterIndex()[tempDestPath[x]] << "/";
              // }
              //  std::cout << std::endl;
              //std::cout << "pairScoreComp" << std::endl;
              std::pair<int,int> pair;
              if(bSrc < bDest){
                pair = std::pair<int,int>(bSrc, bDest);
              }else{
                pair = std::pair<int,int>(bDest, bSrc);
              }
              float score = srcBoundaryDist+destBoundaryDist+_plannerObjects->boundaryPaths[pair].first;
              //std::cout << "scrBScore = " << srcBoundaryDist << "|"
                        // << "destBScore = " << destBoundaryDist << "|"
                        // << "boundaryScore = " << _plannerObjects->boundaryPaths[pair].first << "|"
                        // << "score = " << score << "|" << std::endl;
              if(score < minScore){
                minScore = score;
                //minSrcIndex = x;
                //minDestIndex = y;
                minSrcBoundary = bSrc;
                minDestBoundary = bDest;
                srcPath = tempSrcPath;
                destPath = tempDestPath;
                //minSrcCluster = _plannerObjects->globalClusterNodeMap[srcBoundaries[x]]
                //minDestCluster = _plannerObjects->globalClusterNodeMap[destBoundaries[y]]

              }
            }
          }

          //if(srcPath.size() > 0){
          srcPath = globalPathFromClusterPath(srcCluster, srcPath);
          //}
          //if(destPath.size() > 0){
          destPath = globalPathFromClusterPath(destCluster, destPath);
          //}
          bool reversed = false;
          if(minSrcBoundary > minDestBoundary){
            reversed = true;
          }
          std::pair<int, int> bpair;
          if(reversed){
            bpair = std::pair<int, int>(minDestBoundary, minSrcBoundary);
          }else{
            bpair = std::pair<int, int>(minSrcBoundary, minDestBoundary);
          }
          std::vector<int> path = _plannerObjects->boundaryPaths[bpair].second;
          //std::vector<int> path = _plannerObjects->boundaryPaths[bpair].second;
          if(path.size()>0){
            if(reversed){
              std::reverse(path.begin(), path.end());
            }
          }else{
            path.push_back(_plannerObjects->boundaryToGlobalMap[minSrcBoundary].second);
            path.push_back(_plannerObjects->boundaryToGlobalMap[minDestBoundary].second);
          }
          //std::cout << "boundaryPath = " ;
          // for(int z = 0; z < path.size(); z++){
          //   std::cout << path[z] << " / ";
          // }
          // std::cout << std::endl;

          //std::vector<int> srcPath  = getShortestPathWithinCluster();
          //std::vector<int> destPath = getShortestPathWithinCluster();
          std::vector<int> fullPath;
          for(int x = 0; x < srcPath.size(); x++){
            fullPath.push_back(srcPath[x]);
            //std::cout << srcPath[x] << std::endl;
          }
          //std::cout << "-" << std::endl;
          for(int x = 1; x < path.size(); x++){
            fullPath.push_back(path[x]);
            //std::cout << path[x] << std::endl;
          }
          //std::cout << "-" << std::endl;
          for(int x = 1; x < destPath.size(); x++){
            fullPath.push_back(destPath[x]);
            //std::cout << destPath[x] << std::endl;
          }
          return std::make_pair(minScore, fullPath);
        }

        float PlannerManager::getDistanceBetweenPositions(Eigen::Vector3f startPosition, Eigen::Vector3f endPosition){
          int sourceIndex = getGlobalIndexFromCoord(getPlannerCoordFromWorldVec(openvdb::Vec3d(startPosition.x(), startPosition.y(), startPosition.z())));
          int destIndex = getGlobalIndexFromCoord(getPlannerCoordFromWorldVec(openvdb::Vec3d(endPosition.x(), endPosition.y(), endPosition.z())));
          float score;
          //std::vector<int> globalPath;
          //std::tie(score, globalPath) = getShortestPathAndScore(sourceIndex, destIndex);
          //return score;//getEigenPathFromGlobalIndexPath(globalPath);    
          return getShortestPathAndScore(sourceIndex, destIndex).first;
        }

        std::pair<float, std::vector<int>> PlannerManager::getShortestPathAndScore(int sourceIndex, int destIndex){
          std::vector<int> path; //IMPLEMENT HERE
          int sourceCluster = _plannerObjects->globalClusterMap[sourceIndex];
          int sourceClusterNode = _plannerObjects->globalClusterNodeMap[sourceIndex];
          int destCluster = _plannerObjects->globalClusterMap[destIndex];
          int destClusterNode = _plannerObjects->globalClusterNodeMap[destIndex];
          float score = 0.0;
          if(sourceCluster != destCluster){
            //Do multi path setup.
            //std::cout << "shortest Path between clusters not currently implemented" << std::endl;
            std::pair<float, std::vector<int>> scorePair =
                      getShortestPathAndScoreBetweenClusters(sourceCluster, sourceIndex, destCluster, destIndex);

            /*
            getBoundaryPaths(sourceCluster, destCluster)


            */
            return scorePair;
          }else{
            path = getShortestPathWithinCluster(sourceCluster, sourceClusterNode, destClusterNode);
            score = getScoreOfClusterPath(sourceCluster, path);
            std::vector<int> globalPath = globalPathFromClusterPath(sourceCluster, path);
            return std::make_pair(score, globalPath);
          }
        }
        //return path;

        std::vector<int> PlannerManager::pathBetweenNodeAndCluster(int sourceIndex, int destCluster){
          //std::cout << "nClusters " << _plannerObjects->clusterIDs.size()<< std::endl;
          //std::cout << "pathBetweenNodeAndClusterCalc = " << std::endl;
          //std::cout << "destCluster = " << destCluster << std::endl;
          std::vector<int> potentialDests = _plannerObjects->clusterBoundaryPoints[destCluster];
          //std::cout << "PotentialDests = " << std::endl;

          float minScore = FLT_MAX;
          std::vector<int> path;
          std::pair<float, std::vector<int>> scorePair;
          for(int x = 0; x < potentialDests.size(); x++){
            //std::cout << "TargetBoundary = " << potentialDests[x] << std::endl;
            scorePair = getShortestPathAndScore(sourceIndex,potentialDests[x]);
            //std::cout << "score= "<< scorePair.first << "/ dest= " << potentialDests[x] << std::endl;
            if(scorePair.first < minScore){
              minScore = scorePair.first;
              path = scorePair.second;
            }
          }
          return path;
        }


        std::vector<int> PlannerManager::getShortestPathAsIndex(int sourceIndex, int destIndex){
          std::vector<int> path; //IMPLEMENT HERE
          int sourceCluster = _plannerObjects->globalClusterMap[sourceIndex];
          int sourceClusterNode = _plannerObjects->globalClusterNodeMap[sourceIndex];
          int destCluster = _plannerObjects->globalClusterMap[destIndex];
          int destClusterNode = _plannerObjects->globalClusterNodeMap[destIndex];

          if(sourceCluster != destCluster){
            //Do multi path setup.
            //std::cout << "shortest Path between clusters not currently implemented" << std::endl;
            path = getShortestPathBetweenClusters(sourceCluster, sourceIndex, destCluster, destIndex);
            /*
            getBoundaryPaths(sourceCluster, destCluster)


            */
            return path;
          }else{
            path = getShortestPathWithinCluster(sourceCluster, sourceClusterNode, destClusterNode);
            return globalPathFromClusterPath(sourceCluster, path);
          }
          //return path;
        }

        int PlannerManager::getIntermediateToVertex(int clusterID, int sourceIndex){
            int clusterCount = *_handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterCount();
            //float dist = FLT_MAX;
            //float minimumDistToVertex = FLT_MAX;
            float distToVertex = FLT_MAX;
            int intermediateNode = -1;
            for(int destIndex = 0; destIndex < clusterCount; destIndex++){
              float dist = _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[sourceIndex*clusterCount+destIndex];
              if(dist > 0){
                int closestDestVertex = _plannerObjects->clusterVertexNodeMap[clusterID][destIndex];
                if(closestDestVertex != -1){
                  int closestDestVertexAsCluster = _handler->plannerAllocator()->plannerCluster(clusterID)->hostVertexBuffer()[closestDestVertex];
                  float distFromIntermediateToVertex = _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[destIndex*clusterCount+closestDestVertexAsCluster];
                  if(distToVertex > distFromIntermediateToVertex+dist){
                    distToVertex = distFromIntermediateToVertex+dist;
                    intermediateNode = destIndex;
                  }
                }
              }
            }
            return intermediateNode;
          }

        std::vector<int> PlannerManager::getShortestPathWithinCluster(int clusterID, int sourceIndex, int destIndex){
          //std::vector<int> globalPath;
          std::vector<int> path;
          //std::cout << "2" << std::endl;
          if(sourceIndex != destIndex){
            int clusterCount = *_handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterCount();
            float dist = _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[sourceIndex*clusterCount+destIndex];
            //std::cout << "2" << std::endl;
            //IF DIST IS NEGATIVE< THAT MEANS OBSTACLES EXIST BETWEEN BOTH NODES AND WE MUST USE VERTEX PATH FOR SHORTEST PATH
            if(dist < 0){

              //In vertex Space
              int closestSourceVertex = _plannerObjects->clusterVertexNodeMap[clusterID][sourceIndex];
              //int sourceVertexClusterIndex = _plannerClusters->hostVertexBuffer()[closestSourceVertex];
              // if(sourceIndex == sourceVertexClusterIndex){
              //     path.push_back(sourceIndex);
              // }else{
              //   path.push_back(sourceIndex);
              //   path.push_back(sourceVertexClusterIndex);
              // }
              int closestDestVertex = _plannerObjects->clusterVertexNodeMap[clusterID][destIndex];
              int intermediateNodes[2] = {-1,-1};
              if(closestSourceVertex == -1){
                intermediateNodes[0] = getIntermediateToVertex(clusterID, sourceIndex);
                closestSourceVertex = _plannerObjects->clusterVertexNodeMap[clusterID][intermediateNodes[0]];
                path.push_back(sourceIndex);
                //path.push_back(intermediateNodes[0]);
              }else{
                path.push_back(sourceIndex);
              }
              
              //int destVertexClusterIndex = _plannerClusters->hostVertexBuffer()[closestSourceVertex];

              //std::cout << "2" << std::endl;
              if(closestSourceVertex != closestDestVertex){
                //std::cout << "Dist = " << dist << std::endl;
                //std::cout << "ClusterID = " << clusterID << std::endl;
                //std::cout << "ClusterCount = " << clusterCount << std::endl;
                //std::cout << "VertexCount = "  << *_handler->plannerAllocator()->plannerCluster(clusterID)->hostVertexCount() << std::endl;
                //std::cout << "sourceIndex = " << sourceIndex << std::endl;
                //std::cout << "destIndex = " << destIndex << std::endl;
                //std::cout << "closestSourceVertex = " << closestSourceVertex << std::endl;
                //std::cout << "closestDestVertex = " << closestDestVertex << std::endl;
                //std::cout << "closestSourceVertexAsCluster = " << sourceIndex << std::endl;
                //std::cout << "closestDestVertexAsCluster = " << destIndex << std::endl;
                //closestSourceVertex = -1;


                if(closestDestVertex == -1){
                  intermediateNodes[1] = getIntermediateToVertex(clusterID, destIndex);
                  closestDestVertex = _plannerObjects->clusterVertexNodeMap[clusterID][intermediateNodes[1]];
                }

                try{
                  checkVertexValidity(closestSourceVertex);
                }catch(std::invalid_argument& e){
                  std::cerr << e.what() << std::endl;
                  exit(1);
                }
                try{
                  checkVertexValidity(closestDestVertex);
                }catch(std::invalid_argument& e){
                  std::cerr << e.what() << std::endl;
                  exit(1);
                }
                std::vector<int> vertexPath = getVertexPath(clusterID, closestSourceVertex, closestDestVertex);
                //std::cout << "VertexPath = ";
                // for(int x = 0; x < vertexPath.size(); x++){

                //   //std::cout << vertexPath[x];
                //   //std::cout << " / ";
                // }
                //std::cout << std::endl;
                int startVertex = 0;
                //std::cout << "vertexPath Size: " << vertexPath.size() << std::endl;
                int destVertex = vertexPath.size()-1;
                //std::cout << "2" << std::endl;


                // if(intermediateNodes[0]==-1){
                //   for(int x = 0; x < vertexPath.size(); x++){
                //     float dist = _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[sourceIndex*clusterCount+vertexPath[x]];
                //     //std::cout << dist << std::endl;
                //     if(dist < 0){
                //       startVertex = x - 1;
                //       break;
                //     }
                //   }
                //std::cout << "sourceNodeDists" << std::endl;
                //if(intermediateNodes[0]==-1){
                float currentStartBest = FLT_MAX;
                int bestStartVertex = -1;
                bool skipStartIntermediate = true;
                for(int x = 0; x < vertexPath.size(); x++){
                  float dist = _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[sourceIndex*clusterCount+vertexPath[x]];
                    //std::cout << dist << std::endl;
                  if(dist > 0){
                    startVertex = x;
                    currentStartBest = dist;
                    //std::cout << "currentStartBest " << currentStartBest << std::endl;
                    //std::cout << "startVertex "  << startVertex << std::endl;
                  }
                }
                if(intermediateNodes[0]!=-1){
                  skipStartIntermediate = false;
                  int intermediateStartVertex = 0;
                  float currentIntermediateBest = FLT_MAX;
                  float distToIntermediate = _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[sourceIndex*clusterCount+intermediateNodes[0]];
                  for(int x = 0; x < vertexPath.size(); x++){
                    float dist = _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[intermediateNodes[0]*clusterCount+vertexPath[x]];
                    //std::cout << dist << std::endl;
                    if(dist > 0){
                      intermediateStartVertex = x;
                      currentIntermediateBest = dist;
                      //std::cout << "currentIntBest " << currentIntermediateBest << std::endl;
                    }
                  }
                  if(intermediateStartVertex <= startVertex){
                    //We don't need intermediate node anymore
                    skipStartIntermediate = true;
                  }else if(intermediateStartVertex > startVertex){
                    //Going to the intermediate node might still be faster.
                    int tempStartVertex = startVertex;
                    while(tempStartVertex != intermediateStartVertex){
                      currentStartBest +=  _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[vertexPath[tempStartVertex]*clusterCount+vertexPath[tempStartVertex+1]];
                      tempStartVertex++;
                    }
                    if(currentIntermediateBest+distToIntermediate < currentStartBest){
                      //We want to use the intermediate node.
                      bestStartVertex = intermediateStartVertex;
                      skipStartIntermediate = false;
                    }else{
                      //we want to use the start node and skip the intermediate node
                      skipStartIntermediate = true;
                      bestStartVertex = startVertex;
                    }
                  }
                  

                }else{
                  bestStartVertex = startVertex;
                }
                //}
                //std::cout << "2" << std::endl;
                //std::cout << "endNodeDists" << std::endl;
                float currentDestBest = FLT_MAX;
                int bestDestVertex = -1;
                bool skipDestIntermediate = true;
                for(int x = vertexPath.size()-1; x >= 0; x--){
                  //std::cout << dist << std::endl;
                  float dist = _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[destIndex*clusterCount+vertexPath[x]];
                  if(dist > 0){
                    destVertex = x;
                    currentDestBest = dist;
                    //std::cout << "currentDestBest " << currentDestBest << std::endl;
                    //std::cout << "destVertex" << destVertex  << std::endl;
                    //break;
                  }
                }

                if(intermediateNodes[1]!=-1){
                  skipDestIntermediate = false;
                  int intermediateDestVertex = vertexPath.size()-1;
                  float currentIntermediateBest = FLT_MAX;
                  float distToDestIntermediate = _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[destIndex*clusterCount+intermediateNodes[1]];
                  for(int x = vertexPath.size()-1; x>=0; x--){
                    float dist = _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[intermediateNodes[1]*clusterCount+vertexPath[x]];
                    //std::cout << dist << std::endl;
                    if(dist > 0){
                      intermediateDestVertex = x;
                      currentIntermediateBest = dist;
                      //std::cout << "currentIntBest " << currentIntermediateBest << std::endl;
                    }
                  }
                  if(intermediateDestVertex >= destVertex){
                    //We don't need intermediate node anymore
                    skipDestIntermediate = true;
                  }else if(intermediateDestVertex < destVertex){
                    //Going to the intermediate node might still be faster.
                    int tempDestVertex = destVertex;
                    while(tempDestVertex != intermediateDestVertex){
                      currentDestBest +=  _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[vertexPath[tempDestVertex]*clusterCount+vertexPath[tempDestVertex+1]];
                      tempDestVertex++;
                    }
                    if(currentIntermediateBest+distToDestIntermediate < currentDestBest){
                      //We want to use the intermediate node.
                      bestDestVertex = intermediateDestVertex;
                      skipDestIntermediate = false;
                    }else{
                      //we want to use the start node and skip the intermediate node
                      skipDestIntermediate = true;
                      bestDestVertex = destVertex;
                    }
                  }
                  }else{
                    bestDestVertex = destVertex;
                  }
                //std::cout << "startVertex = " << startVertex <<  std::endl;
                //std::cout << "endVertex = " << endVertex <<std::endl;
                //std::cout << "2" << std::endl;
                if(!skipStartIntermediate){
                  path.push_back(intermediateNodes[0]);
                }
                
                if(bestStartVertex > bestDestVertex){
                  //std::cout << "processing weird edge case" << std::endl;
                  //Weird edge case. Compare the lengths of the paths in both directions. 
                  float startPathScore = 0.0;
                  float destPathScore = 0.0;
                  int startNode;
                  int destNode;
                  if(!skipStartIntermediate){
                    startNode = intermediateNodes[0];  
                  }else{
                    startNode = sourceIndex;
                  }
                  if(!skipDestIntermediate){
                    destNode = intermediateNodes[1];
                  }else{
                    destNode = destIndex;
                  }
                  int tempStartVertex = bestStartVertex;
                  int tempDestVertex = bestDestVertex;
                  float startTerminalPathScore = FLT_MAX;
                  float startTerminalVertex = -1;
                  while(tempStartVertex < vertexPath.size()){
                    int currentVertex = startNode;
                    startPathScore += _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[currentVertex*clusterCount+vertexPath[tempStartVertex]];
                    if(_handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[destNode*clusterCount+vertexPath[tempStartVertex]]>0){
                      float newTerminalScore = startPathScore + _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[destNode*clusterCount+vertexPath[tempStartVertex]];
                      if(newTerminalScore < startTerminalPathScore){
                        startTerminalPathScore = newTerminalScore;
                        startTerminalVertex = tempStartVertex;
                      }
                    }
                    currentVertex = vertexPath[tempStartVertex];
                    tempStartVertex++;
                  }
                  float destTerminalPathScore = FLT_MAX;
                  float destTerminalVertex = -1;
                  while(tempDestVertex>=0){
                    int currentVertex = destNode;
                    destPathScore += _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[currentVertex*clusterCount+vertexPath[tempDestVertex]];
                    //And check to see if the current vertex can reach the start node. 
                    if(_handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[startNode*clusterCount+vertexPath[tempDestVertex]]>0){
                      float newTerminalScore = destPathScore + _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[startNode*clusterCount+vertexPath[tempDestVertex]];
                      if(newTerminalScore < destTerminalPathScore){
                        destTerminalPathScore = newTerminalScore;
                        destTerminalVertex = tempDestVertex;
                      }
                    }
                    currentVertex = vertexPath[tempDestVertex];
                    tempDestVertex--;
                  }
                  if(startTerminalPathScore <= destTerminalPathScore){
                    bestDestVertex = startTerminalVertex;
                  }else{
                    bestStartVertex = destTerminalVertex;
                  }
                }

                  for(int x = bestStartVertex; x <= bestDestVertex; x++){
                    if(x==-1){
                      continue;
                    }
                    if(x>=vertexPath.size()){
                      break;
                    }
                    if(vertexPath[x] == sourceIndex || vertexPath[x] ==destIndex){
                      continue;
                    }
                    path.push_back(vertexPath[x]);
                  }
                  //std::cout << "endVertex = " << vertexPath[endVertex] << "destIndex = " << destIndex << std::endl;
                  if(!skipDestIntermediate){
                    path.push_back(intermediateNodes[1]);
                    path.push_back(destIndex);
                  }else{
                    path.push_back(destIndex);
                  }
                // std::cout << "cluster Path = ";
                // for(int x = 0; x < path.size(); x++){
                //   std::cout << path[x];
                //   std::cout << " / ";
                // }
                // std::cout << std::endl;
                // std::cout << "scores = " << std::endl;
                // int currScoreIndex = path[0];
                // for(int x = 1; x < path.size(); x++){
                //   int nextIndex = path[x];
                //   std::cout << _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[currScoreIndex*clusterCount+nextIndex];
                //   std::cout << " / ";
                //   currScoreIndex = nextIndex;
                // }
                // std::cout << std::endl;
                //int nextVertex = _handler->plannerAllocator()->plannerCluster(clusterID)->hostVertexPaths()[closestSourceVertex*(*(_handler->plannerAllocator()->plannerCluster(clusterID)->hostLevel()))];
                ///while(nextIndex != closestDestVertex){
                //  getPathVertexPaths
                //}

                //std::cout << "2" << std::endl;
              }else{
                path.push_back(_handler->plannerAllocator()->plannerCluster(clusterID)->hostVertexBuffer()[closestSourceVertex]);
                path.push_back(destIndex);
              }
            }else{
              path.push_back(sourceIndex);
              path.push_back(destIndex);
            }
            //std::cout << "2" << std::endl;

            return path;
          }else{
            return path;
          }
        }



        std::vector<int> PlannerManager::globalPathFromClusterPath(int clusterID, std::vector<int> clusterPath){
          std::vector<int> globalPath;
          for(int x = 0; x < clusterPath.size(); x++){
            globalPath.push_back(_handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterIndex()[clusterPath[x]]);
          }
          return globalPath;
        }

        std::vector<int> PlannerManager::getVertexPath(int clusterID, int closestSourceVertex, int closestDestVertex){
          std::vector<int> vertexPath;
          //vertexPath.push_back(closestSourceVertex);
          std::vector<int> clusterPath;
          int solutionIndex;
          int vertexCount = *(_handler->plannerAllocator()->plannerCluster(clusterID)->hostVertexCount());
          bool reversePath = false;
          if(closestSourceVertex < closestDestVertex){
            solutionIndex = closestSourceVertex*(vertexCount-1)-(closestSourceVertex*(closestSourceVertex-1)/2) + (closestDestVertex-closestSourceVertex-1);
          }else{
            solutionIndex = closestDestVertex*(vertexCount-1)-(closestDestVertex*(closestDestVertex-1)/2) + (closestSourceVertex-closestDestVertex-1);
            reversePath = true;
          }
          int startNode, endNode;
          if(reversePath){
            //vertexPath.push_back(closestDestVertex);
            startNode = closestDestVertex;
            endNode = closestSourceVertex;
          }else{
            //vertexPath.push_back(closestSourceVertex);
            startNode = closestSourceVertex;
            endNode = closestDestVertex;
          }
          vertexPath.push_back(startNode);
          //std::cout << "startNode = : " << startNode << std::endl;
          int stepIndex = 1;
          int vertexIndex = _handler->plannerAllocator()->plannerCluster(clusterID)->hostVertexPaths()[solutionIndex*(*(_handler->plannerAllocator()->plannerCluster(clusterID)->hostLevel()))];
          //std::cout << "vertexIndex = : "<< vertexIndex << std::endl;
          while(vertexIndex != endNode && vertexIndex != -1){
            vertexPath.push_back(vertexIndex);
            vertexIndex = _handler->plannerAllocator()->plannerCluster(clusterID)->hostVertexPaths()[solutionIndex*(*(_handler->plannerAllocator()->plannerCluster(clusterID)->hostLevel()))+stepIndex];
            //std::cout << "vertexIndex = : "<< vertexIndex << std::endl;
            stepIndex++;
          }
          //if(reversePath){
          //  vertexPath.push_back(endNode);
          //}else{

          //std::cout << "endNode = : " << endNode << std::endl;
          vertexPath.push_back(endNode);
          //}

          //if(reversePath){
          for(int x = 0; x<vertexPath.size(); x++){
            //std::cout << "vertexPath[x] = " << vertexPath[x] << std::endl;
            //std::cout << "hostVertexBufferSize = " << _handler->plannerAllocator()->plannerCluster(clusterID)->vertexAllocation()<<std::endl;
            clusterPath.push_back(_handler->plannerAllocator()->plannerCluster(clusterID)->hostVertexBuffer()[vertexPath[x]]);
            
          }
          if(reversePath){
            std::reverse(clusterPath.begin(), clusterPath.end());
          }
          //}else{
          //  for(int x = 0; x < vertexPath.size(); x++){
          //    clusterPath.push_back(_handler->plannerAllocator()->plannerCluster(clusterID)->hostVertexBuffer()[vertexPath[x]]);
          //  }
          //}
          return clusterPath;
          //return vertexPath;
        }

        std::vector<int> PlannerManager::getShortestPathAsIndex(openvdb::Coord sourceNode, openvdb::Coord destNode){
          int sourceIndex = getGlobalIndexFromCoord(sourceNode);
          int destIndex = getGlobalIndexFromCoord(destNode);
          std::vector<int> path = getShortestPathAsIndex(sourceIndex, destIndex);
          return path;
        }

        std::vector<openvdb::Coord> PlannerManager::getShortestPathAsCoord(int sourceIndex, int destIndex){
          std::vector<int> indexPath = getShortestPathAsIndex(sourceIndex, destIndex);
          std::vector<openvdb::Coord> path;
          std::vector<int>::iterator it = indexPath.begin();
          while(it != indexPath.end()){
            path.push_back(getCoordFromGlobalIndex(*it));
            it++;
          }
          return path;
        }

        std::vector<openvdb::Coord> PlannerManager::getShortestPathAsCoord(openvdb::Coord sourceNode, openvdb::Coord destNode){
          int sourceIndex = getGlobalIndexFromCoord(sourceNode);
          int destIndex = getGlobalIndexFromCoord(destNode);
          return getShortestPathAsCoord(sourceIndex, destIndex);
        }

        // std::vector<openvdb::Coord> PlannerManager::getShortestFullPathAsCoord(){
        //   std::vector<openvdb::Coord> path;
        //   return path;
        // }
        //For each cluster, this structure maps the pair of boundary coords, the distance between them (should be close to 1) to the correspondering neighbour cluster.
        //std::vector<std::map<int, std::tuple<int,int,float>>> _boundaryPairs;
        // void getBoundaryPairs(){
        //   for(int x = 0; x < _plannerObjects->clusterIDs.size() ; x++){
        //     std::map<int, std::tuple<int, int, float>> boundaryPairs;
        //     _boundaryPairs.push_back(boundaryPairs);
        //     for(int y = 0; y < _plannerObjects->clusterBoundaryPoints[x].size(); y++){
        //       int boundaryIndex = _plannerObjects->clusterBoundaryPoints[x][y];
        //       int closestBoundaryPoint = -1;
        //       float minDist = FLT_MAX;
        //       for(int i = 0; i < _plannerObjects->clusterIDs.size(); i++){
        //         if(i != x){
        //           for(int k = 0; k < _plannerObjects->clusterBoundaryPoints[i].size(); k++){
        //             int testIndex = _plannerObjects->clusterBoundaryPoints[i][k];
        //             float dist = (_handler->plannerAllocator()->plannerBucket()()->hostGridIndex()[boundaryIndex]
        //                           -_handler->plannerAllocator()->plannerBucket()()->hostGridIndex()[testIndex]).length();
        //             if(dist < minDist){
        //               minDist = dist;
        //               closestBoundaryPoint = testIndex;
        //             }
        //           }
        //         }
        //       }
        //       _boundaryPairs[x].insert(std::pair<int, std::tuple<int,int,float>>(i, boundaryIndex, closestBoundaryPoint, minDist));
        //     }
        //   }
        //   return;
        // }
        
        std::vector<int> PlannerManager::boundariesInClusterSpace(int clusterIndex){
          std::vector<int> clusterBoundaries;
          for(int globalBoundary : _plannerObjects->clusterBoundaryPoints[clusterIndex]){
            clusterBoundaries.push_back(_plannerObjects->globalClusterNodeMap[globalBoundary]);
          }
          return clusterBoundaries;
        }
        
        void PlannerManager::getBoundaryPairs(){
          _plannerObjects->clusterGraph.clear();
          
          for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
            int sourceCluster = x;
            std::vector<std::pair<int,std::vector<std::pair<int,int>>>> clusterEntry;
            std::vector<std::vector<std::pair<int, int>>> neighbourPairs;
            neighbourPairs.resize(_plannerObjects->clusterIDs.size());
            //std::map<int, std::tuple<int, int, float>> boundaryPairs;
            //_boundaryPairs.push_back(boundaryPairs);
            for(int y = 0; y < _plannerObjects->clusterBoundaryPoints[x].size(); y++){
              int boundaryIndex = _plannerObjects->clusterBoundaryPoints[x][y];
              int closestBoundaryPoint = -1;
              float minDist = FLT_MAX;
              int sourceClusterBoundaryIndex = y;
              int destCluster = -1;
              int destClusterBoundaryIndex = -1;
              for(int i = 0; i < _plannerObjects->clusterIDs.size(); i++){
                if(i != x){
                  for(int k = 0; k < _plannerObjects->clusterBoundaryPoints[i].size(); k++){
                    int testIndex = _plannerObjects->clusterBoundaryPoints[i][k];
                    Eigen::Matrix<int, 3, 1> eigenBoundary = _handler->plannerAllocator()->getGridIndexNode(boundaryIndex);
                    openvdb::Coord boundaryNode(eigenBoundary(0), eigenBoundary(1), eigenBoundary(2));
                    Eigen::Matrix<int, 3, 1> eigenTest = _handler->plannerAllocator()->getGridIndexNode(testIndex);
                    openvdb::Coord testNode(eigenTest(0), eigenTest(1), eigenTest(2));
                    // nanovdb::Coord diff = (_handler->plannerAllocator()->plannerBucket()->hostGridIndex()[boundaryIndex]
                    //               -_handler->plannerAllocator()->plannerBucket()->hostGridIndex()[testIndex]);
                    openvdb::Coord diff = boundaryNode-testNode;
                    float dist  = diff.asVec3d().length();
                    if(dist < minDist){
                      minDist = dist;
                      closestBoundaryPoint = testIndex;
                      destCluster = i;
                      destClusterBoundaryIndex = k;
                    }
                  }
                }
              }
              neighbourPairs[destCluster].push_back(std::make_pair(sourceClusterBoundaryIndex, destClusterBoundaryIndex));

              //_boundaryPairs[x].insert(std::pair<int, std::tuple<int,int,float>>(i, boundaryIndex, closestBoundaryPoint, minDist));
              int sourcePoint = _plannerObjects->globalToBoundaryMap[boundaryIndex];
              int destPoint = _plannerObjects->globalToBoundaryMap[closestBoundaryPoint];
              if(sourcePoint < destPoint){
                _plannerObjects->boundaryNeighbourCount+=2;
                std::pair<int,int> srcPair = std::pair<int, int>(sourcePoint, destPoint);
                std::vector<int> emptyPath;
                std::pair<float, std::vector<int>> pathPair = std::pair<float, std::vector<int>>(minDist, emptyPath);
                _plannerObjects->boundaryPaths.insert(std::pair<std::pair<int,int>, std::pair<float, std::vector<int>>>(srcPair,pathPair));
              }
            }
            for(int neighbourIndex = 0; neighbourIndex < _plannerObjects->clusterIDs.size(); neighbourIndex++){
              if(neighbourPairs[neighbourIndex].size()>0){
                //THIS CLUSTER IS NEIGHBOURS WITH THE SOURCE. 
                std::vector<std::pair<int,int>> pairs;
                for(int pairIndex = 0; pairIndex < neighbourPairs[neighbourIndex].size(); pairIndex++){
                  pairs.push_back(neighbourPairs[neighbourIndex][pairIndex]);
                }
                clusterEntry.push_back(std::make_pair(neighbourIndex, pairs));
              }
            }
            _plannerObjects->clusterGraph.push_back(clusterEntry);
          }
          //Sanitize the cluster graph
          for(int clusterIndex = 0; clusterIndex < _plannerObjects->clusterGraph.size() ;clusterIndex++){
            //std::vector<int> sourceNeighbours;
            for(int neighbourIndex = 0; neighbourIndex < _plannerObjects->clusterGraph[clusterIndex].size(); neighbourIndex++){
              int neighbourClusterIndex = _plannerObjects->clusterGraph[clusterIndex][neighbourIndex].first;
              bool isNeighbour = false;
              for(int neighbourEntryIndex = 0; neighbourEntryIndex < _plannerObjects->clusterGraph[neighbourClusterIndex].size(); neighbourEntryIndex++){
                if(_plannerObjects->clusterGraph[neighbourClusterIndex][neighbourEntryIndex].first == clusterIndex){
                  //neighbour and source have corresponding entries! we think?
                  isNeighbour = true;
                }
              }
              if(isNeighbour!=true){
                //entry missing from neighbour. add the entry from the cluster. 
                std::vector<std::pair<int, int>> boundaryPairs;
                for(int pairIndex = 0; pairIndex < _plannerObjects->clusterGraph[clusterIndex][neighbourIndex].second.size(); pairIndex++){
                  boundaryPairs.push_back(std::make_pair(_plannerObjects->clusterGraph[clusterIndex][neighbourIndex].second[pairIndex].second,_plannerObjects->clusterGraph[clusterIndex][neighbourIndex].second[pairIndex].first));
                }
                auto neighbourEntry = std::make_pair(clusterIndex, boundaryPairs);
                _plannerObjects->clusterGraph[neighbourClusterIndex].push_back(neighbourEntry);
              }
            }   
          }
          
          std::cout << "calculating boundary lines from graph " << std::endl;
          calculateBoundaryLinesFromGraph();
          std::cout << "sampling clusters for search" << std::endl;
          sampleClustersForSearch();
          return;
        }
        void PlannerManager::getClusterBoundaryPaths(){
          for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
            for(int y = 0; y < _plannerObjects->clusterBoundaryPoints[x].size(); y++){
              int sourceGlobal = _plannerObjects->clusterBoundaryPoints[x][y];
              int sourceCPoint = _plannerObjects->globalClusterNodeMap[sourceGlobal];
              int sourceBIndex = _plannerObjects->globalToBoundaryMap[sourceGlobal];
              for(int z = 0; z < _plannerObjects->clusterBoundaryPoints[x].size(); z++){
                if(y!=z){
                  int destGlobal = _plannerObjects->clusterBoundaryPoints[x][z];
                  int destCPoint = _plannerObjects->globalClusterNodeMap[destGlobal];
                  int destBIndex = _plannerObjects->globalToBoundaryMap[destGlobal];
                  if(sourceBIndex < destBIndex){
                    _plannerObjects->boundaryNeighbourCount+=2;
                    //std::cout << "1" << std::endl;
                    std::vector<int> clusterPath = getShortestPathWithinCluster(x, sourceCPoint, destCPoint);
                    //std::cout << "1" << std::endl;
                    float score = getScoreOfClusterPath(x, clusterPath);
                    //std::cout << "path score = " << score << std::endl;
                    std::vector<int> globalPath = globalPathFromClusterPath(x, clusterPath);
                    //std::cout << "1" << std::endl;
                    std::pair<int, int> srcPair = std::pair<int, int>(sourceBIndex, destBIndex);
                    //std::cout << "1" << std::endl;
                    std::pair<float, std::vector<int>> pathPair = std::pair<float, std::vector<int>>(score, globalPath);
                    //std::cout << "1" << std::endl;
                    _plannerObjects->boundaryPaths.insert(std::pair<std::pair<int,int>, std::pair<float, std::vector<int>>>(srcPair, pathPair));
                  }
                }
              }
            }
          }
        }




        float PlannerManager::getScoreOfClusterPath(int clusterID, std::vector<int> path){
          float score = 0;
          if(path.size()>1){
          int currentNode = path[0];
          int destNode;
          float newScore;
          int clusterCount = *(_handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterCount());
          //std::cout << currentNode;
          for(int x = 1; x < path.size(); x++){
            destNode = path[x];
            //std::cout << " / " << destNode;
            newScore = _handler->plannerAllocator()->plannerCluster(clusterID)->hostClusterDistances()[currentNode*clusterCount+destNode];
            //std::cout << " ("<< newScore <<") ";
            score+=newScore;
            currentNode = destNode;
          }
          //std::cout << std::endl;
          }
          return score;
        }

        void PlannerManager::getInitialBoundaryPaths(){
          //First get all boundary pairs between clusters
          getBoundaryPairs();


          //Then calculate the paths between boundary pairs WITHIN clusters
          getClusterBoundaryPaths();
          //With this info, we can then solve the boundary point graph.
        }

        void PlannerManager::mapBoundaryPoints(){
          int boundaryIndex = 0;
          for(int x = 0; x < _plannerObjects->clusterBoundaryPoints.size(); x++){
            for(int y = 0; y < _plannerObjects->clusterBoundaryPoints[x].size(); y++){
              int globalIndex = _plannerObjects->clusterBoundaryPoints[x][y];
              _plannerObjects->boundaryToGlobalMap.insert(std::pair<int, std::pair<int, int>>(boundaryIndex, std::pair<int, int>(x, globalIndex)));
              _plannerObjects->globalToBoundaryMap.insert(std::pair<int,int>(globalIndex, boundaryIndex));
              boundaryIndex++;
            }
          }
        }

        //This contains the score for the paths between the boundary nodes WITHIN a cluster.
        //std::vector<std::vector<std::vector<int>>> _boundaryScores;
        // void PlannerManager::getBoundaryScores(){
        //   for(int x = 0; x < _plannerObjects->clusterBoundaryPoints.size(); x++){
        //     for(int y = 0; y < _plannerObjects->clusterBoundaryPoints[x].size(); y++){
        //       for(int z = 0; z <  _plannerObjects->clusterBoundaryPoints[x].size(); z++){

        //       }
        //     }
        //   }
        //   return;
        // }


        void PlannerManager::populateBoundaryContainers(){
          _handler->plannerAllocator()->plannerBucket()->populateBoundaryPairs();
          populateNeighbours();
          populateGraphScores();
        }

        void PlannerManager::populateNeighbours(){
          //allocateNeighbours();
          cudaDeviceSynchronize();
          int index = 0;
          for(int x = 0; x<_plannerObjects->boundaryCount; x++){
            _handler->plannerAllocator()->plannerBucket()->hostNeighbourIndices()[x] = index;
            int count = 0;
            for(int y = 0; y<_plannerObjects->boundaryCount; y++){

              if(x!=y){
                std::pair<int, int> pair;
                if(x<y){
                  pair = std::pair<int, int>(x,y);
                }else{
                  pair = std::pair<int, int>(y,x);
                }
                if(_plannerObjects->boundaryPaths.count(pair) > 0){
                      //x and y are neighbours.
                  _handler->plannerAllocator()->plannerBucket()->hostNeighbourCounts()[x]++;
                  //_handler->plannerAllocator()->plannerBucket()->hostNeighbourCounts()[y]++;
                  //std::cout  << "hostNeighbourCounts " << _handler->plannerAllocator()->plannerBucket()->hostNeighbourCounts()[x] << std::endl;
                  //std::cout << "hostNeighbourPairDistance = " << _plannerObjects->boundaryPaths[pair].first << std::endl;
                  _handler->plannerAllocator()->plannerBucket()->hostNeighbourMap()[index] = y;
                  _handler->plannerAllocator()->plannerBucket()->hostNeighbourDistances()[index] = _plannerObjects->boundaryPaths[pair].first;
                  index+=1;
                  count+=1;
                }
              }
            }
          }
          //}
        }

        void PlannerManager::populateGraphScores(){
          for(int index = 0; index < _plannerObjects->boundaryScoreSize; index++){
            int x = _handler->plannerAllocator()->plannerBucket()->hostBoundaryPairs()[index];
            int y = _handler->plannerAllocator()->plannerBucket()->hostBoundaryPairs()[index+_plannerObjects->boundaryScoreSize];
            std::pair<int, int> pair = std::pair<int, int>(x, y);
            if(_plannerObjects->boundaryPaths.count(pair)>0){
              float score = (float)_plannerObjects->boundaryPaths[pair].first;
              //std::cout << "score = " << score << std::endl;
              _handler->plannerAllocator()->plannerBucket()->hostGraphLevels()[index] = (float)score;
              _handler->plannerAllocator()->plannerBucket()->hostGraphScores()[index] = (float)score;
              _handler->plannerAllocator()->plannerBucket()->hostGraphScores()[index+_plannerObjects->boundaryScoreSize] = 0.0;
            }
            // }else{
            //   _handler->plannerAllocator()->plannerBucket()->hostGraphLevels()[index] = -1.0;
            //   _handler->plannerAllocator()->plannerBucket()->hostGraphScores()[index] = 100000.0;
            //   _handler->plannerAllocator()->plannerBucket()->hostGraphScores()[index+_plannerObjects->boundaryScoreSize] = 100000.0;
            //
            // }
          }
          _handler->plannerAllocator()->plannerBucket()->hostSolutionCounts()[0] = 1;
        }

        void PlannerManager::createBoundaryContainers(){
          _handler->plannerAllocator()->plannerBucket()->allocateBoundaryContainers(_plannerObjects->boundaryCount, _plannerObjects->boundaryScoreSize, _plannerObjects->boundaryNeighbourCount);
          return;
        }

        void PlannerManager::setupBoundaryGraph(){
          createBoundaryContainers();
          return;
        }

        void PlannerManager::processBoundaries(){
          mapBoundaryPoints();
          getInitialBoundaryPaths();
          setupBoundaryGraph();
          return;
        }

        //std::vector<std::vector<int>> _clusterShortestPaths;
        // void PlannerManager::getShortestClusterPaths(){
        //   return;
        // }

        // std::pair<float, std::vector<int>> shortestPathWithScore(int sourceIndex, int endIndex){
        //   int sourceClusterIndex =
        //   return path;
        // }
        // void populateEdges(){
        //   populateClusterEdges();
        //   populateClusterEdgeCombos();
        // }
        //
        // void populateClusterEdges(){
        //   for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
        //     std::vector<int> tempVec;
        //     _plannerObjects->clusterEdges.push_back(tempVec);
        //     _plannerObjects->clusterEdgeCombos.push_back(tempVec);
        //   }
        //   for(int x = 0; x < *(_handler->plannerAllocator()->plannerBucket()->hostVertexCount()) ; x++){
        //     int index = _handler->plannerAllocator()->plannerBucket()->hostVertexBuffer()[x];
        //     int clusterIndex = _handler->plannerAllocator()->plannerBucket()->hostClusterParents()[index];
        //     //std::cout << _handler->plannerAllocator()->plannerBucket()->hostVertexBuffer()[x] << std::endl;
        //     _plannerObjects->clusterEdges[_plannerObjects->clusterIndices[clusterIndex]].push_back(index);
        //     _plannerObjects->clusterEdgeCombos[_plannerObjects->clusterIndices[clusterIndex]].push_back(index);
        //   }
        // }
        //
        // void populateClusterEdgeCombos(){
        //   for(int x = 0; x < _plannerObjects->clusterIDs.size(); x++){
        //     std::set<int>::iterator it = _plannerObjects->clusterNeighbours[x].begin();
        //     while(it != _plannerObjects->clusterNeighbours[x].end()){
        //       int index = _plannerObjects->clusterIndices[*it];
        //       for(int y = 0; y < _plannerObjects->clusterEdges[index].size(); y++){
        //         _plannerObjects->clusterEdgeCombos[x].push_back(_plannerObjects->clusterEdges[index][y]);
        //       }
        //       it++;
        //     }
        //   }
        // }




        void PlannerManager::populateGridIndexAndVoxels(){
            openvdb::Coord coord;
            int value;
            // openvdb::FloatGrid::Accessor acc = targetGrid->getAccessor();
            int count = 0;
            for (openvdb::Int32Grid::ValueOnCIter iter = _plannerMap->plannerGrid()->cbeginValueOn(); iter; ++iter) {
              coord = iter.getCoord();
              //value = _plannerAccessor->getValue(coord);
              //value = getGlobalIndexFromCoord(coord);
              value = _plannerMap->plannerAccessor()->getValue(coord);
              if(value < 1){
                value = value*-1;
              }else{
                  _handler->plannerAllocator()->setHostSafeIndex(count,value-1);
                  count++;
              }
              _handler->plannerAllocator()->setHostGridIndex(value-1, coord.x(), coord.y(), coord.z());
                //_handler->plannerAllocator()->plannerBucket()->hostGridIndex()+value-1) = nanovdb::Coord(coord.x(), coord.y(), coord.z());
            }
            //cudaCheck(cudaMemcpy(_handler->plannerAllocator()->plannerBucket()->devValidVoxels(), _handler->plannerAllocator()->plannerBucket()->hostValidVoxels(), (*_handler->plannerAllocator()->plannerBucket()->hostValidCount())*8*sizeof(uint8_t), cudaMemcpyHostToDevice));
            _handler->plannerAllocator()->copySafeAndGridIndexToDev();
          //   cudaCheck(cudaMemcpy(_handler->plannerAllocator()->plannerBucket()->devSafeIndex(), _handler->plannerAllocator()->plannerBucket()->hostSafeIndex(), (*_handler->plannerAllocator()->plannerBucket()->hostSafeCount())*sizeof(int), cudaMemcpyHostToDevice));

          //   cudaCheck(cudaMemcpy(_handler->plannerAllocator()->plannerBucket()->devGridIndex(), _handler->plannerAllocator()->plannerBucket()->hostGridIndex(), (*_handler->plannerAllocator()->plannerBucket()->hostValidCount())*sizeof(nanovdb::Coord), cudaMemcpyHostToDevice));
        }






      void PlannerManager::closeHandler(){
        _handler->closeHandler();
        _handler.reset();
      }


    } //manager namepsace
} //nanomap namespace
