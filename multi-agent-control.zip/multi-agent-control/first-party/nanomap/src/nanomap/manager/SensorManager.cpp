#include "nanomap/manager/SensorManager.h"


namespace nanomap{
    namespace manager{
        
        SensorManager::SensorManager(std::vector<std::string> sensorConfigs, std::shared_ptr<nanomap::config::Config> config){
            _sensorInfo = std::make_shared<nanomap::sensor::GPUInfo>();
            _sensorData.clear();
            loadSensors(sensorConfigs, config);
            int frustumLeafBufferSize = 0;
            int frustumPCLSize = 0;
            for(int i = 0; i < _sensorData.size(); i++){
                if(_sensorData[i]->sharedParameters()._pclSize> frustumPCLSize){
                    frustumPCLSize = _sensorData[i]->sharedParameters()._pclSize;
                }
                if(_sensorData[i]->sharedParameters()._maxLeafBufferSize > frustumLeafBufferSize){
                    frustumLeafBufferSize = _sensorData[i]->sharedParameters()._maxLeafBufferSize;
                }
            }
            _sensorInfo->frustumPCLSize = frustumPCLSize;
            _sensorInfo->frustumAllocationFactor = config->frustumAllocationFactor();
            _sensorInfo->frustumLeafBufferSize = frustumLeafBufferSize;
        }



      void SensorManager::loadSensors(std::vector<std::string> sensorConfigs, std::shared_ptr<nanomap::config::Config> config){
            for(int i = 0; i < sensorConfigs.size(); i++){  
              _sensorData.push_back(loadSensorData(sensorConfigs[i], config));
            }
        }


      std::shared_ptr<nanomap::sensor::SensorData> SensorManager::loadSensorData(std::string sensorConfig, std::shared_ptr<nanomap::config::Config> config)
      {
          std::cout <<"reading in sensor config file: " << sensorConfig << std::endl;
          std::string line;
          std::string name;
          bool fillInfinity;
          int fillInf;
          int id, rate, hRes, vRes;
          float aHRes, aVRes, vfov, hfov, maxRange, minRange, probHit, probMiss;
          Eigen::Matrix<float, 3, 3> frameTransform;
          std::ifstream *input = new std::ifstream(sensorConfig.c_str(), std::ios::in | std::ios::binary);
          *input >> line;
          //check if file is frustumconfig
           if(line.compare("#laserconfig") == 0){
             while(input->good()) {
                 *input >> line;
                 if (line.compare("Name:") == 0){
                   *input >> name;
                 }else if(line.compare("Id:") == 0){
                   *input >> id;
                 }else if(line.compare("AngularHRes:") == 0){
                   *input >> aHRes;
                 }else if(line.compare("AngularVRes:") == 0){
                   *input >> aVRes;
                 }else if(line.compare("HFOV:") == 0){
                   *input >> hfov;
                 }else if(line.compare("VFOV:") == 0){
                   *input >> vfov;
                 }else if(line.compare("Rate:") == 0){
                   *input >> rate;
                 }else if(line.compare("MaxRange:") == 0){
                   *input >> maxRange;
                 }else if(line.compare("MinRange:") == 0){
                   *input >> minRange;
                 }else if(line.compare("ProbHit:") == 0){
                   *input >> probHit;
                 }else if(line.compare("ProbMiss:") == 0){
                   *input >> probMiss;
                 }else if(line.compare("FillInfinity:") == 0){
                   *input >> fillInf;
                   if(fillInfinity = 0){
                    fillInfinity = false;
                   }else if(fillInfinity = 1){
                    fillInfinity = true;
                   }
                 }else if(line.compare("FrameTransform:") == 0){
                   float x;
                   for(int i = 0; i <3 ; i++){
                     for(int j = 0; j<3; j++){
                       *input >> x;
                       frameTransform.col(i)(j) = x ;
                     }
                   }
                 }else if (line.compare("#endconfig")==0){
                             break;
                 }
               }
             input->close();
             return std::make_shared<nanomap::sensor::SensorData>(nanomap::sensor::LaserData(name, id, frameTransform, config->gridRes(), config->leafEdge(), aHRes, aVRes, hfov,
                                                     vfov, rate, maxRange, minRange,
                                                   probHit, probMiss, fillInfinity));
          }else if(line.compare("#frustumconfig")==0){
            while(input->good()) {
                *input >> line;
                if (line.compare("Name:") == 0){
                  *input >> name;
                }else if(line.compare("Id:") == 0){
                  *input >> id;
                }else if(line.compare("HRes:") == 0){
                  *input >> hRes;
                }else if(line.compare("VRes:") == 0){
                  *input >> vRes;
                }else if(line.compare("VFOV:") == 0){
                  *input >> vfov;
                }else if(line.compare("Rate:") == 0){
                  *input >> rate;
                }else if(line.compare("MaxRange:") == 0){
                  *input >> maxRange;
                }else if(line.compare("MinRange:") == 0){
                  *input >> minRange;
                }else if(line.compare("ProbHit:") == 0){
                  *input >> probHit;
                }else if(line.compare("ProbMiss:") == 0){
                  *input >> probMiss;
                }else if(line.compare("FillInfinity:") == 0){
                   *input >> fillInf;
                   if(fillInfinity = 0){
                    fillInfinity = false;
                   }else if(fillInfinity = 1){
                    fillInfinity = true;
                   }
                }else if(line.compare("FrameTransform:") == 0){
                  float x;
                  for(int i = 0; i <3 ; i++){
                    for(int j = 0; j<3; j++){
                      *input >> x;
                      frameTransform.col(i)(j) = x ;
                    }
                  }
                }else if (line.compare("#endconfig")==0){
                            break;
                }
              }
            input->close();
            return std::make_shared<nanomap::sensor::SensorData>(nanomap::sensor::FrustumData(name, id, frameTransform, config->gridRes(), config->leafEdge(), hRes, vRes,
                                                    vfov, rate, maxRange, minRange,
                                                  probHit, probMiss, fillInfinity));
          }
          return nullptr;
        }



    }
}