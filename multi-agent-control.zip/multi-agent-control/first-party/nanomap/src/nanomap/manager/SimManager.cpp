// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file SimManager.cpp
///
/// @author Violet Walker
///
#include "nanomap/manager/SimManager.h"


namespace nanomap{
    namespace manager{

      // SimManager::SimManager(){}

      SimManager::SimManager(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo, std::shared_ptr<nanomap::config::GPUInfo> config, openvdb::FloatGrid::Ptr simGrid)
      : Manager(sensorInfo, config), _simGrid(simGrid)
      {}
        
      void SimManager::createHandler(){
        _handler = std::make_unique<nanomap::handler::SimHandler>(nanomap::handler::SimHandler(_sensorInfo, _config, _simGrid));
      }
      void SimManager::generateCloudFromSim(std::shared_ptr<nanomap::sensor::Sensor> sensor, int publishSensor){
        //Generate sensor input cloud from sim
        _handler->generateCloudFromSensor(sensor, publishSensor);
      }

      // SimManager::init(std::shared_ptr<nanomap::sensor::GPUInfo> sensorInfo){
      //   _handler->init(sensorInfo);
      // }

      // void SimManager::insertPointCloud(std::shared_ptr<nanomap::sensor::Sensor> sensor, 
      //                                       openvdb::FloatGrid::Ptr floatGrid, 
      //                                       std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
      //                                       std::shared_ptr<nanomap::map::GPUInfo> gridConfig,
      //                                       bool serialUpdate,
      //                                       int updateType){
      //   //For the given sensor, raycast the sensor information
      //   _handler->rayCastCloud(sensor);
      //   if(updateType == 0){
      //     voxelUpdateFromFrustumBuffer(acc, gridConfig);
      //   }else if(updateType == 1){
      //     blockUpdateFromFrustumBuffer(serialUpdate, acc, gridConfig);
      //   }
      // }

      // void SimManager::insertPointCloudCPU(std::shared_ptr<nanomap::sensor::Sensor> sensor,
      //                                       openvdb::FloatGrid::Ptr floatGrid, 
      //                                       std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
      //                                   std::shared_ptr<nanomap::map::GPUInfo> gridConfig){
      //   openvdb::FloatGrid::Ptr tempGrid = openvdb::FloatGrid::create(0.0);
      //   //tempGrid->setTransform(openvdb::math::Transform::createLinearTransform(_config->mappingRes()));
      //   auto tempAcc = tempGrid->getAccessor();
      //   populateTempGrid(tempAcc, sensor, floatGrid, acc, gridConfig);

      //   integrateTempGrid(tempGrid, acc, gridConfig);
      // }

      // void SimManager::populateTempGrid(openvdb::FloatGrid::Accessor& tempAcc, 
      //               std::shared_ptr<nanomap::sensor::Sensor> sensor, 
      //                                     openvdb::FloatGrid::Ptr floatGrid, 
      //                                     std::shared_ptr<openvdb::FloatGrid::Accessor> acc,
      //                std::shared_ptr<nanomap::map::GPUInfo> gridConfig){
      //   openvdb::math::Ray<double> ray;
      //   openvdb::math::DDA<openvdb::math::Ray<double> ,0> dda;
      //   nanomap::Pose pose = sensor->sensorData()->worldPose();
      //   openvdb::Vec3d ray_origin_world(pose.position(0), pose.position(1), pose.position(2));
      //   openvdb::Vec3d ray_origin_index(floatGrid->worldToIndex(ray_origin_world));
      //   openvdb::Vec3d ray_direction;
      //   bool max_range_ray;
      //   openvdb::Vec3d x;
      //   double ray_length;
      //   float max_time = sensor->sensorData()->sharedParameters()._maxRange/gridConfig->gridRes;
      //   float pointx, pointy, pointz;
      //   Eigen::Matrix<float,3,3> rotation = pose.orientation.normalized().toRotationMatrix()*sensor->sensorData()->sharedParameters()._frameTransform;
      //   float prob_miss = sensor->sensorData()->sharedParameters()._probMiss;
      //   float prob_hit = sensor->sensorData()->sharedParameters()._probMiss;
      //   float logodds_miss = log(prob_miss)-log(1-prob_miss);
      //   float logodds_hit = log(prob_hit)-log(1-prob_hit);
      //   // Probability update lambda for empty grid elements
      //   auto miss = [&prob_miss = logodds_miss](float& voxel_value, bool& active) {
      //     voxel_value += prob_miss;
      //     active = true;
      //   };

      //   // Probability update lambda for occupied grid elements
      //   auto hit = [&prob_hit = logodds_hit](float& voxel_value, bool& active) {
      //     voxel_value += prob_hit;
      //     active = true;
      //   };
      //   // Raycasting of every point in the input cloud
      //   for (int i = 0; i < sensor->inputCloud()->width()*sensor->inputCloud()->height(); i++)
      //   {
      //     unsigned char* byte_ptr = sensor->inputCloud()->cloudPtr() + i*sensor->inputCloud()->step();
      //     pointx = *(reinterpret_cast<float*>(byte_ptr+0));
      //     pointy = *(reinterpret_cast<float*>(byte_ptr+4));
      //     pointz = *(reinterpret_cast<float*>(byte_ptr+8));
      //     max_range_ray = false;
      //     ray_direction = openvdb::Vec3d(
      //       rotation(0,0)*pointx+rotation(0,1)*pointy+rotation(0,2)*pointz,
      //                   rotation(1,0)*pointx+rotation(1,1)*pointy+rotation(1,2)*pointz,
      //                   rotation(2,0)*pointx+rotation(2,1)*pointy+rotation(2,2)*pointz);

      //     ray_length = ray_direction.length()/gridConfig->gridRes;
      //     if(ray_length  < max_time){
      //       ray_direction.normalize();
      //       ray.setEye(ray_origin_index);
      //       ray.setDir(ray_direction);
      //       dda.init(ray,0,ray_length);
      //       openvdb::Coord voxel = dda.voxel();
      //       while(dda.step()){
      //           tempAcc.modifyValueAndActiveState(voxel, miss);
      //           voxel = dda.voxel();
      //       }
      //       if(dda.time()<max_time){
      //           tempAcc.modifyValueAndActiveState(voxel, hit);
      //       }
      //     }
      //   }
      // }
      // void SimManager::integrateTempGrid(openvdb::FloatGrid::Ptr tempGrid,
      //                                     std::shared_ptr<openvdb::FloatGrid::Accessor> acc, 
      //                                 std::shared_ptr<nanomap::map::GPUInfo> gridConfig){
          
      //     float emptyClampThres = gridConfig->emptyClampingThreshold;
      //     float occClampThres = gridConfig->occupiedClampingThreshold;
      //     float logodds_thres_min = gridConfig->logOddsMissThreshold;
      //     float logodds_thres_max = gridConfig->logOddsHitThreshold;
      //     float tempValue;
      //     // Probability update lambda for occupied grid elements
      //     auto update = [&prob_thres_max = logodds_thres_max, &prob_thres_min = logodds_thres_min,
      //       &occ_clamp = occClampThres, &empty_clamp = emptyClampThres, &temp_value = tempValue](float& voxel_value,
      //                                                                                   bool& active) {
      //       voxel_value += temp_value;
      //       if (voxel_value > occ_clamp)
      //       {
      //         voxel_value = occ_clamp;
      //       }else if(voxel_value < empty_clamp){
      //         voxel_value = empty_clamp;
      //       }

      //       if(voxel_value > prob_thres_max){
      //         active = true;
      //       }else if(voxel_value < prob_thres_min){
      //         active = false;
      //       }
      //     };
      //     // Integrating the data of the temporary grid into the map using the probability update functions
      //     for (openvdb::FloatGrid::ValueOnCIter iter = tempGrid->cbeginValueOn(); iter; ++iter)
      //     {
      //       tempValue = iter.getValue();
      //       if (tempValue!=0.0)
      //       {
      //         acc->modifyValueAndActiveState(iter.getCoord(), update);
      //       }
      //     }
      //     return;
      //   }
      // // void SimManager::integrateTempGrid(openvdb::FloatGrid::Ptr tempGrid, std::shared_ptr<nanomap::map::Map> map){
      // //   // Probability update lambda for occupied grid elements
      // //   float occClampThres = map->occupiedClampingThreshold();
      // //   float emptyClampThres = map->emptyClampingThreshold();
      // //   float logodds_thres_max = map->logOddsHitThreshold();
      // //   float logodds_thres_min = map->logOddsMissThreshold();
      // //   auto update = [&prob_thres_max = logodds_thres_max, &prob_thres_min = logodds_thres_min,
      // //                   &occ_clamp = occClampThres, &empty_clamp = emptyClampThres, &temp_value = tempValue]
      // //                   (float& voxel_value, bool& active) {
      // //     voxel_value += temp_value;
      // //     if (voxel_value > occ_clamp)
      // //     {
      // //       voxel_value = occ_clamp;
      // //     }else if(voxel_value < empty_clamp){
      // //       voxel_value = empty_clamp;
      // //     }

      // //     if(voxel_value > prob_thres_max){
      // //       active = true;
      // //     }else if(voxel_value < prob_thres_min){
      // //       active = false;
      // //     }
      // //   };
      // //   // Integrating the data of the temporary grid into the map using the probability update functions
      // //   for (openvdb::FloatGrid::ValueOnCIter iter = tempGrid->cbeginValueOn(); iter; ++iter)
      // //   {
      // //     tempValue = iter.getValue();
      // //     if (tempValue!=0.0)
      // //     {
      // //       map->occAccessor()->modifyValueAndActiveState(iter.getCoord(), update);
      // //     }
      // //   }
      // // return;
      // // }






      // //THESE METHODS UPDATE THE GRID USING THE BUFFER FROM THE GPU
      // void SimManager::voxelUpdateFromFrustumBuffer(std::shared_ptr<openvdb::FloatGrid::Accessor> acc, std::shared_ptr<nanomap::map::GPUInfo> gridConfig){
      //   int leafEdge = gridConfig->leafEdge;
      //   int leafVolume = leafEdge*leafEdge*leafEdge;
      //   float logOddsHit = gridConfig->logOddsHitThreshold;
      //   float logOddsMiss = gridConfig->logOddsMissThreshold;
      //   float occClamp =  gridConfig->occupiedClampingThreshold;
      //   float emptyClamp =  gridConfig->emptyClampingThreshold;
      //   float probeValue;
      //   float value;
      //   float targetActive = false;
      //   auto update = [&log_hit_thres = logOddsHit,
      //                   &log_miss_thres = logOddsMiss,
      //                   &occ_clamp = occClamp,
      //                   &empty_clamp = emptyClamp,
      //                   &probe_value = probeValue,
      //                   &temp_value = value]
      //                   (float& voxel_value, bool& active) {
      //       voxel_value += temp_value;
      //       if (voxel_value > occ_clamp){
      //         voxel_value = occ_clamp;
      //       }else if(voxel_value < empty_clamp){
      //         voxel_value = empty_clamp;
      //       }
      //       if(voxel_value > log_hit_thres){
      //         active = true;
      //       }else if(voxel_value < log_miss_thres){
      //         active = false;
      //       }
      //   };
      //   int nodeIndex, voxelIndex, voxelBufferIndex;
      //   int gpuFrustumLeafCount = _handler->getFrustumLeafCount();
      //   int* gpuFrustumLeafBuffer = _handler->getFrustumLeafBuffer();
      //   int8_t* gpuFrustumVoxelBuffer = _handler->getFrustumVoxelBuffer();
      //   for(int i = 0; i < gpuFrustumLeafCount; i++){
      //     int nodeX = gpuFrustumLeafBuffer[i*3];
      //     int nodeY = gpuFrustumLeafBuffer[i*3+1];
      //     int nodeZ = gpuFrustumLeafBuffer[i*3+2];
      //     for(int x = 0; x < leafEdge; x++){
      //       for(int y = 0; y < leafEdge ; y++){
      //         for(int z = 0; z < leafEdge; z++){
      //           nodeIndex = i*leafVolume;
      //           voxelIndex = z+y*leafEdge + x*leafEdge*leafEdge;
      //           voxelBufferIndex = nodeIndex+voxelIndex;
      //           value = (float)(gpuFrustumVoxelBuffer[voxelBufferIndex])/100;
      //           if(value != 0.0){
      //             //std::cout << "new info" << std::endl;
      //             acc->modifyValueAndActiveState(openvdb::Coord(nodeX+x,nodeY+y,nodeZ+z), update);
      //           }
      //         }
      //       }
      //     }
      //   }
      // }



      //   void SimManager::blockUpdateFromFrustumBuffer(bool serialUpdate, std::shared_ptr<openvdb::FloatGrid::Accessor> acc, std::shared_ptr<nanomap::map::GPUInfo> gridConfig){
      //     int gpuFrustumLeafCount = _handler->getFrustumLeafCount();
      //     int* gpuFrustumLeafBuffer = _handler->getFrustumLeafBuffer();
      //     int8_t* gpuFrustumVoxelBuffer = _handler->getFrustumVoxelBuffer();
      //     int leafEdge = gridConfig->leafEdge;
      //     BlockWorker occBlockWorker(leafEdge,
      //                               gridConfig->occupiedClampingThreshold,
      //                               gridConfig->emptyClampingThreshold,
      //                               gridConfig->logOddsHitThreshold,
      //                               gridConfig->logOddsMissThreshold,
      //                               acc,
      //                               gpuFrustumVoxelBuffer,
      //                               gpuFrustumLeafBuffer,
      //                               gpuFrustumLeafCount);

          
      //     occBlockWorker.processBlocks(serialUpdate);
      //     for(int i = 0; i < gpuFrustumLeafCount; i++){
      //       BlockWorker::Block& occBlock = (*(occBlockWorker._blocks))[i];
      //       if (occBlock.leaf) {
      //         acc->addLeaf(occBlock.leaf);
      //       }
      //     }
      //     occBlockWorker.destroyBlocks();
      //   }
        

      // void SimManager::printUpdateTime(int count){
      //   _handler->printUpdateTime(count);
      // }

      // void SimManager::closeHandler(){
      //   _handler->closeHandler();
      //   _handler.reset();
      // }


    } //manager namepsace
} //nanomap namespace
