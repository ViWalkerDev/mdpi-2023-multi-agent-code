#include "nanomap/map/PlannerMap.h"


namespace nanomap{
  namespace map{

      using IntGrid = openvdb::Int32Grid;
      using IntTreeT = IntGrid::TreeType;
      using IntLeafT = IntTreeT::LeafNodeType;
      using IntAccessorT = openvdb::tree::ValueAccessor<IntTreeT>;
    //Base Map Class, contains a single grid.
        PlannerMap::PlannerMap(float plannerRes)
            {
            _plannerRes = plannerRes;

         
            _plannerGrid = IntGrid::create(0);
            _plannerGrid->setTransform(openvdb::math::Transform::createLinearTransform(_plannerRes));
            _plannerGrid->setName("PlannerGrid");
            _plannerAccessor = std::make_shared<IntAccessorT>(_plannerGrid->getAccessor());
          }

        // int getCoordIndex(openvdb::Coord coord){
        //   return _plannerAccessor->getValue(coord);
        // }

        openvdb::Int32Grid::Ptr PlannerMap::plannerGrid(){return _plannerGrid;}
        std::shared_ptr<IntAccessorT> PlannerMap::plannerAccessor(){return _plannerAccessor;}
        //float PlannerMap::gridRes(){return _gridRes;}
        //int PlannerMap::safeCount(){return _safeCount;}
        //int PlannerMap::validCount(){return _validCount;}
  }//namespace map
}//namespace nanomap
