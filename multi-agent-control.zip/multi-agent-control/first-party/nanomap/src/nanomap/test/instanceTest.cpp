// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file test2DCaveGen.cpp
///
/// @author Violet Walker
///
#include <openvdb/openvdb.h>
#include "nanomap/instance/SimInstance.h"
#include "nanomap/nanomap.h"

int main(int argc, char **argv){
  using EigenVec = Eigen::Matrix<ValueT, 3, 1>;
  using EigenMat = Eigen::Matrix<ValueT, 3, 3>;
  std::string config_file;
  config_file = "/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/config.txt";
  openvdb::initialize();
  nanomap::instance::SimInstance instance(config_file);
  std::cout << "instance created" << std::endl;
  instance.createManager();
  std::cout << "managerCreated" << std::endl;
  instance.createHandler();
  std::cout << "handlerCreated" << std::endl;
  nanomap::Pose pose;
  pose.position = EigenVec(0,0,0);
  pose.orientation =Eigen::Quaternionf(1.0, 0.0,0.0,0.0);
  
  int loopCount =0;
  for(float yaw = 0; yaw < 6.29; yaw+=(6.28/20.0)){
    std::cout << loopCount << std::endl;
    loopCount++;
    Eigen::Quaternionf q;
    q = Eigen::AngleAxisf(0.0, Eigen::Vector3f::UnitX())
        * Eigen::AngleAxisf(0.0, Eigen::Vector3f::UnitY())
        * Eigen::AngleAxisf(yaw, Eigen::Vector3f::UnitZ());
    pose.orientation = q;
    instance.updateAgentPose(0, pose);
    //std::cout << "attempting to generate agent views for agent with id 0" << std::endl;
    instance.generateAgentViews(0);
    //std::cout << "success!" << std::endl;
    //std::cout << "attempting to process agent views for agent with id 0" << std::endl;
    instance.processAgentViews(0);
    //std::cout << "success!" << std::endl;
    //std::cout << attempting to save Grid to file for agent with id 0" << std::endl;

    //std::cout << "success!" << std::endl;

  }
  instance.saveAgentGridToFile(0,"testGrid.vdb");
}

