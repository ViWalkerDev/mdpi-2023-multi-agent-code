// Nanomap Copyright
// Nanomap Copyright
// SPDX-License-Identifier: GPLv3

/// @file test2DCaveGen.cpp
///
/// @author Violet Walker
///
#include <openvdb/openvdb.h>
#include "nanomap/instance/PlannerInstance.h"
#include "nanomap/mapgen/procedural/MapGen.h"
#include "nanomap/nanomap.h"

// openvdb::FloatGrid::Ptr loadGridForPlanning(std::string gridFile){
//     openvdb::FloatGrid::Ptr gridTest = openvdb::FloatGrid::create(0.0);
//     gridTest->setTransform(openvdb::math::Transform::createLinearTransform(0.1));
//     auto acc = gridTest->getAccessor();
//     auto setObstacle = [](float& voxel_value, bool& active) {
//       voxel_value = 1.0;
//       active = true;
//     };
//     auto setFree = [](float& voxel_value, bool& active) {
//       voxel_value = 1.0;
//       active = false;
//     };
//     openvdb::io::File file(gridFile);
//     // Open the file.  This reads the file header, but not any grids.
//     file.open();
//     // Loop over all grids in the file and retrieve a shared pointer
//     // to the one named "LevelSetSphere".  (This can also be done
//     // more simply by calling file.readGrid("LevelSetSphere").)
//     openvdb::GridBase::Ptr baseGrid;
//     for (openvdb::io::File::NameIterator nameIter = file.beginName();
//         nameIter != file.endName(); ++nameIter)
//     {
//         // Read in only the grid we are interested in.
//         if (nameIter.gridName() == "grid") {
//             baseGrid = file.readGrid(nameIter.gridName());
//         } else {
//             std::cout << "skipping grid " << nameIter.gridName() << std::endl;
//         }
//     }
//     file.close();
//   //
//   //   int tileEdge = 8;
//     openvdb::FloatGrid::Ptr grid = openvdb::gridPtrCast<openvdb::FloatGrid>(baseGrid);
//     auto newacc = grid->getAccessor();

//     openvdb::FloatGrid::ValueOnIter oniter = grid->beginValueOn();
//   bool mapFromFile = true;
//   if(mapFromFile){
//     for (oniter; oniter.test(); ++oniter) {

//       acc.modifyValueAndActiveState(oniter.getCoord(), setObstacle);

//     }
//     openvdb::FloatGrid::ValueOffIter offiter = grid->beginValueOff();
//     for (offiter; offiter.test(); ++offiter) {

//           if(newacc.getValue(offiter.getCoord()) < 0.0){
//             //std::cout << newacc.getValue(offiter.getCoord()) << std::endl;
//             acc.modifyValueAndActiveState(offiter.getCoord(), setFree);
//           }
//     }
//     return gridTest;
//   }
//   // }else{
//   // int tileEdge = 8;
//   //   for(int z = 0; z<map.size(); z++){
//   //     for(int y = 0; y<map[z].size();y++){
//   //       for(int x = 0; x<map[z][y].size(); x++){
//   //         if(map[z][y][x]==0){
//   //           for(int a = 0; a < tileEdge; a++){
//   //             for(int b = 0; b < tileEdge; b++){
//   //               for(int c = 0; c < tileEdge; c++){
//   //                 acc.modifyValueAndActiveState(openvdb::Coord(x*tileEdge+a,y*tileEdge+b,z*tileEdge+c), setFree);
//   //               }
//   //             }
//   //           }
//   //         }else{
//   //           for(int a = 0; a < tileEdge; a++){
//   //             for(int b = 0; b < tileEdge; b++){
//   //               for(int c = 0; c < tileEdge; c++){
//   //                 acc.modifyValueAndActiveState(openvdb::Coord(x*tileEdge+a,y*tileEdge+b,z*tileEdge+c), setObstacle);
//   //               }
//   //             }
//   //           }
//   //         }
//   //       }
//   //     }
//   //   }
//   // }
// }


int main(int argc, char **argv){
  using ValueT = float;
  using EigenVec = Eigen::Matrix<ValueT, 3, 1>;
  using EigenMat = Eigen::Matrix<ValueT, 3, 3>;
  std::string config_file, grid_file, mapGenConfig;
  config_file = "/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/config.txt";
  grid_file = "/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/simGrid.vdb";
  mapGenConfig = "/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/mapGenConfig.txt";
  
  openvdb::initialize();
  int count = 0;
  int seed = time(0);
  //int seed =1684387604;
  //int seed = 1684374453;
  //int seed = 1684377470;
  //int seed =1684383650;
  srand(seed);
  std::cout << "Seed for test = " << seed << std::endl;
  nanomap::instance::PlannerInstance instance(config_file);
  std::cout << "instance created" << std::endl;
  instance.createManager();
  std::cout << "managerCreated" << std::endl;
  instance.createHandler();
  nanomap::mapgen::MapGen generator;
  
  openvdb::FloatGrid::Ptr simGrid = generator.generateAndReturnMap(mapGenConfig); 
  instance.setPlannerGrid(simGrid);
  instance.processPlannerGrid();
  //instance.loadPlannerGrid(grid_file);
  

  instance.solvePlannerGrid();

  for(int x = 0; x < 5; x++){
    std::vector<std::pair<nanomap::Pose, int>> path;
    path = instance.plannerManager()->getRandomPath(5);
    std::cout << path[0].first.position(0)<< " | " << path[0].first.position(1)<< " | " << path[0].first.position(2) << " --> " << 
    path[path.size()-1].first.position(0) << " | " << path[path.size()-1].first.position(1) << " | " << path[path.size()-1].first.position(2) << std::endl;
      
    int count = 0;
    for(auto& goal : path){
      std::cout << "Position " << count << " : "<< goal.first.position(0)<< " | " << goal.first.position(1)<< " | " << goal.first.position(2) << std::endl;
      count++;
    }
    std::cout << std::endl;
  }
nanomap::instance::PlannerInstance instance2(config_file);
int breakpoint;
          //   std::cout << "instance created" << std::endl;
          //   instance2.createManager();
          //   std::cout << "managerCreated" << std::endl;
          //   instance2.createHandler();
          //   nanomap::mapgen::MapGen generator2;
            
          //   openvdb::FloatGrid::Ptr simGrid2 = generator2.generateAndReturnMap(mapGenConfig); 
          //   instance2.setPlannerGrid(simGrid2);
          //   instance2.processPlannerGrid();
          //   //instance2.loadPlannerGrid(grid_file);
            

          //   instance2.solvePlannerGrid();

          // //  for(int x = 0; x < 5; x++){
          // //     std::vector<std::pair<nanomap::Pose, int>> path;
          // //     path = instance2.plannerManager()->getRandomPath(5);
          // //     std::cout << path[0].first.position(0)<< " | " << path[0].first.position(1)<< " | " << path[0].first.position(2) << " --> " << 
          // //     path[path.size()-1].first.position(0) << " | " << path[path.size()-1].first.position(1) << " | " << path[path.size()-1].first.position(2) << std::endl;
                
          // //     int count = 0;
          // //     for(auto& goal : path){
          // //       std::cout << "Position " << count << " : "<< goal.first.position(0)<< " | " << goal.first.position(1)<< " | " << goal.first.position(2) << std::endl;
          // //       count++;
          // //     }
          // //     std::cout << std::endl;
          // //   }
          //     nanomap::instance::PlannerInstance instance3(config_file);
          //   std::cout << "instance created" << std::endl;
          //   instance3.createManager();
          //   std::cout << "managerCreated" << std::endl;
          //   instance3.createHandler();
          //   nanomap::mapgen::MapGen generator3;
            
          //   openvdb::FloatGrid::Ptr simGrid3 = generator3.generateAndReturnMap(mapGenConfig); 
          //   instance3.setPlannerGrid(simGrid3);
          //   instance3.processPlannerGrid();
          //   //instance3.loadPlannerGrid(grid_file);
            

          //   instance3.solvePlannerGrid();

          // //  for(int x = 0; x < 5; x++){
          // //     std::vector<std::pair<nanomap::Pose, int>> path;
          // //     path = instance3.plannerManager()->getRandomPath(5);
          // //     std::cout << path[0].first.position(0)<< " | " << path[0].first.position(1)<< " | " << path[0].first.position(2) << " --> " << 
          // //     path[path.size()-1].first.position(0) << " | " << path[path.size()-1].first.position(1) << " | " << path[path.size()-1].first.position(2) << std::endl;
                
          // //     int count = 0;
          // //     for(auto& goal : path){
          // //       std::cout << "Position " << count << " : "<< goal.first.position(0)<< " | " << goal.first.position(1)<< " | " << goal.first.position(2) << std::endl;
          // //       count++;
          // //     }
          // //     std::cout << std::endl;
          // //   }
          //     nanomap::instance::PlannerInstance instance4(config_file);
          //   std::cout << "instance created" << std::endl;
          //   instance4.createManager();
          //   std::cout << "managerCreated" << std::endl;
          //   instance4.createHandler();
          //   nanomap::mapgen::MapGen generator4;
            
          //   openvdb::FloatGrid::Ptr simGrid4 = generator4.generateAndReturnMap(mapGenConfig); 
          //   instance4.setPlannerGrid(simGrid4);
          //   instance4.processPlannerGrid();
          //   //instance4.loadPlannerGrid(grid_file);
            

          //   instance4.solvePlannerGrid();


          // //  for(int x = 0; x < 5; x++){
          // //     std::vector<std::pair<nanomap::Pose, int>> path;
          // //     path = instance4.plannerManager()->getRandomPath(5);
          // //     std::cout << path[0].first.position(0)<< " | " << path[0].first.position(1)<< " | " << path[0].first.position(2) << " --> " << 
          // //     path[path.size()-1].first.position(0) << " | " << path[path.size()-1].first.position(1) << " | " << path[path.size()-1].first.position(2) << std::endl;
                
          // //     int count = 0;
          // //     for(auto& goal : path){
          // //       std::cout << "Position " << count << " : "<< goal.first.position(0)<< " | " << goal.first.position(1)<< " | " << goal.first.position(2) << std::endl;
          // //       count++;
          // //     }
          // //     std::cout << std::endl;
          // //   }

          //     nanomap::instance::PlannerInstance instance5(config_file);
          //   std::cout << "instance created" << std::endl;
          //   instance5.createManager();
          //   std::cout << "managerCreated" << std::endl;
          //   instance5.createHandler();
          //   nanomap::mapgen::MapGen generator5;
            
          //   openvdb::FloatGrid::Ptr simGrid5 = generator5.generateAndReturnMap(mapGenConfig); 
          //   instance5.setPlannerGrid(simGrid5);
          //   instance5.processPlannerGrid();
          //   //instance5.loadPlannerGrid(grid_file);
            

          //   instance5.solvePlannerGrid();
//  for(int x = 0; x < 5; x++){
//     std::vector<std::pair<nanomap::Pose, int>> path;
//     path = instance5.plannerManager()->getRandomPath(5);
//     std::cout << path[0].first.position(0)<< " | " << path[0].first.position(1)<< " | " << path[0].first.position(2) << " --> " << 
//     path[path.size()-1].first.position(0) << " | " << path[path.size()-1].first.position(1) << " | " << path[path.size()-1].first.position(2) << std::endl;
      
//     int count = 0;
//     for(auto& goal : path){
//       std::cout << "Position " << count << " : "<< goal.first.position(0)<< " | " << goal.first.position(1)<< " | " << goal.first.position(2) << std::endl;
//       count++;
//     }
//     std::cout << std::endl;
//   }

}

