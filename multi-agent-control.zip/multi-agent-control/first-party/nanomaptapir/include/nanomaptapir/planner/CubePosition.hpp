/** @file CubePosition.hpp
 *
 * Defines a handy struct to represent 2-D grid indices, in the form of (i, j) == (row, column),
 * as well as some useful methods for dealing with them.
 */
#ifndef CUBEPOSITION_HPP_
#define CUBEPOSITION_HPP_

#include <cmath>                        // for abs, pow, sqrt

#include <iostream>
#include <sstream>

#include "global.hpp"

/** Represents a position within a 2-D grid, using a zero-based row and column index.
 *
 * i = 0, 1, ... is the row, from top to bottom.
 * j = 0, 1, ... is the column, from left to right.
 */
struct CubePosition {
	/**  maps to 3d grid x  */
    long i;
    /** maps to 3d grid y */
    long j;
    /** The height number starting from 0 for the bottommost layer */
    long k;
    /** the direction, represented by an integer between 0 and 7 */
    long heading;
    /** Makes a new CubePosition with i=0 and j=0. */
    CubePosition() :
        i(0),
        j(0),
        k(0),
        heading(0){
    }
    /** Makes a new CubePosition with the given row (_i) and column (_j). */
    CubePosition(long _i, long _j, long _k , long _heading) :
        i(_i),
        j(_j),
        k(_k),
        heading(_heading) {
    }

    /** Returns the Euclidean distance from this CubePosition to the given CubePosition. */
    double euclideanDistanceTo(CubePosition const &other) const {
        long heading_dist = std::abs(heading-other.heading);
        if(heading_dist > 4){
          heading_dist = 8-heading_dist;
        }
        //double double_dist = ((float)heading_dist);///2.0;
        return (std::sqrt(std::pow(i - other.i, 2) + std::pow(j - other.j, 2) + std::pow(k-other.k,2))+(float)heading_dist);
    }

    /** Returns the Manhattan distance from this CubePosition to the given CubePosition. */
    long manhattanDistanceTo(CubePosition const &other) const {
      long heading_dist = std::abs(heading-other.heading);
      if(heading_dist > 4){
        heading_dist = 8-heading_dist;
      }
        return std::abs(i - other.i) + std::abs(j - other.j) + std::abs(k-other.k) + heading_dist;
    }
};

namespace std {
/** We define a hash function directly in the std:: namespace, so that this will be the
 * default hash function for CubePosition.
 */
template<> struct hash<CubePosition> {
    /** Returns the hash value for the given CubePosition. */
    std::size_t operator()(CubePosition const &pos) const {
        std::size_t hashValue = 0;
        tapir::hash_combine(hashValue, pos.i);
        tapir::hash_combine(hashValue, pos.j);
        tapir::hash_combine(hashValue, pos.k);
        tapir::hash_combine(hashValue, pos.heading);
        return hashValue;
    }
};
} /* namespace std */

/** A handy insertion operator for printing grid positions. */
inline std::ostream &operator<<(std::ostream &os, CubePosition const &obj) {
    os << "(" << obj.i << ", " << obj.j << << ", " << obj.k << ", " << obj.heading << ")";
    return os;
}

/** A handy extraction operator for reading CubePositions from a file. */
inline std::istream &operator>>(std::istream &is, CubePosition &obj) {
    std::string tmpStr;
    std::getline(is, tmpStr, '(');
    std::getline(is, tmpStr, ',');
    std::istringstream(tmpStr) >> obj.i;
    std::getline(is, tmpStr, ',');
    std::istringstream(tmpStr) >> obj.j;
    std::getline(is, tmpStr, ',');
    std::istringstream(tmpStr) >> obj.k;
    std::getline(is, tmpStr, ')');
    std::istringstream(tmpStr) >> obj.heading;
    return is;
}

/** Two grid positions are equal iff they have the same row and column. */
inline bool operator==(CubePosition const &lhs, CubePosition const &rhs) {
    return lhs.i == rhs.i && lhs.j == rhs.j && lhs.k == rhs.k && lhs.heading == rhs.heading;
}

/** Two grid positions are equal iff they have the same row and column. */
inline bool operator!=(CubePosition const &lhs, CubePosition const &rhs) {
    return lhs.i != rhs.i || lhs.j != rhs.j || lhs.k != rhs.k || lhs.heading != rhs.heading;
}

#endif /* GRIDPOSITION_HPP_ */
