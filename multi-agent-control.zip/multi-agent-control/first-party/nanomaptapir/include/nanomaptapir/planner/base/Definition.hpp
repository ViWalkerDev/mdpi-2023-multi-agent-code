/** @file Options.hpp
 *
 * Defines the ProblemDefinition class, which specifies the runtime variables for a problem
 */
#ifndef NANOMAPTAPIR_BASEDEFINITION_HPP_
#define NANOMAPTAPIR_BASEDEFINITION_HPP_
//#include "nanomap/planner/ProblemDefinition.hpp"

namespace nanomaptapir {
  namespace planner{
    namespace base{

/** A class defining a structure containing variables required for accurately
*   defining a problem at runtime. */
      struct Definition {
          Definition() = default;
          virtual ~Definition() = default;
          //virtual void setVars(){};
            //Needs to be defined on a problem by problem basis.
          void setCfgPath(std::string cfgPath){
            cfgPath_ = cfgPath;
          }
          std::string cfgPath_;
      };
    }
  }
}
#endif /* NANOMAP_PLANNER_PROBLEMDEFINITION_HPP_ */
