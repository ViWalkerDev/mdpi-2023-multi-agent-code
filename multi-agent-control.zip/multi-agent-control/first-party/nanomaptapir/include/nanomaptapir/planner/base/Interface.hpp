/** @file interface.hpp
 *
 * Defines the basic TAPIR solver interface,
 * further problem specific implementation required by inheriting this class
 */

#ifndef NANOMAPTAPIR_INTERFACE_HPP_
#define NANOMAPTAPIR_INTERFACE_HPP_

#include <memory>                   // For unique_ptr
#include <iostream>                     // for cout

#include "tapirsolver/global.hpp"
#include "tapirsolver/solver/Agent.hpp"
#include "tapirsolver/solver/Solver.hpp"
#include "tapirsolver/solver/Simulator.hpp"
#include "tapirsolver/solver/BeliefTree.hpp"
#include "tapirsolver/solver/BeliefNode.hpp"
#include "nanomaptapir/planner/base/Definition.hpp"
namespace nanomaptapir{
	namespace planner{
		namespace base{
template <class Options, class Model, class Observation, class Action, class Definition>


class Interface {
protected:
	solver::Agent* agent_;
	Model* solverModel_;
	std::unique_ptr<solver::Solver> solver_;
	std::unique_ptr<solver::Simulator> simulator_;
	std::vector<Observation> observations_;
	Options options_;

	RandomGenerator solverGen_;
	RandomGenerator simulatorGen_;


public:
	Interface() :
			agent_(nullptr),
			solverModel_(nullptr),
			options_(),
			stepNumber_(0),
			finished_(false){
	}

	virtual ~Interface() {
		//if (!internalSimulation_) {
		delete agent_;
		//}
	}

	virtual void addObservation(std::vector<int> obsVec){}
	
	virtual void addObservation(std::pair<std::vector<int>, std::vector<std::vector<bool>>> obsPair){}

	virtual void addObservation(Observation* newObservationPtr){
		observationQueue_.push_back(std::shared_ptr<Observation>(newObservationPtr));
	}

	// virtual void addObservation(Observation observation){
	// 	observationQueue_.push_back(observation);
	// }
	// virtual void addObservation(Observation* newObservationPtr){
	// 	std::shared_ptr<Observation> obsPtr(newObservationPtr);
	// 	std::cout << "pushing back into obs queue" << std::endl;
	// 	observationQueue_.push_back(obsPtr);
	// 	std::cout << "success?" << std::endl;
	// }
	// virtual void addObservation(Observation newObservation){
	// 	observations_.push_back(newObservation);
	// 	std::shared_ptr<Observation> obsPtr(std::make_shared<Observation>(observations_.back()));
	// 	std::cout << "pushing back into obs queue" << std::endl;
	// 	observationQueue_.push_back(obsPtr);
	// 	std::cout << "success?" << std::endl;
	// }

	//std::vector<std::shared_ptr<Observation>> observationQueue_;
	std::vector<std::shared_ptr<Observation>> observationQueue_;
	//std::shared_ptr<Action> desiredAction_;
	std::unique_ptr<Action> lastAction_;
	long stepNumber_;
	bool finished_;

	// solver::BeliefNode *phantomBelief_;
	solver::BeliefNode *currentBelief_;

	//std::unique_ptr<Observation> lastObservation_;

	/** Return a current observation. Left for user implementation  */
	//virtual std::unique_ptr<Observation> getObservation() {
	//	return nullptr;
	//}

	/** Set the action. Left for user implementation */
	// virtual void setAction() {
	// 	desiredAction_ = std::make_shared<Action>(*lastAction_);
	// }

	/** Load options from file. problemPath should be path to folder containing
	 *  configuration files, default <ROS package path>/problems/<problemName>
	 *  cfgFile is the cfg file to load, the default is default.cfg
	 */
	virtual void loadOptions(std::string problemPath) {
		//options_.problemDefinition_ = problemDefinition;
		//options_.setVars(problemDefinition);
		std::string problemPath_ = problemPath;
		std::unique_ptr<options::OptionParser> parser = Options::makeParser(false, problemPath);
		try {
			parser->setOptions(&options_);
			parser->parseCfgFile(problemPath+"/default.cfg");
			parser->finalize();

			// Change directory, as code assumes this location for e.g.
			// loading maps from file
			tapir::change_directory(problemPath);
		} catch (options::OptionParsingException const &e) {
			std::cerr << e.what() << std::endl;
		}
	}
	/** Initialise models, solver, and simulator (if required). The Simulator
	 *  class is only used if internalSimulation == true, in this case
	 *  resulting observations and states are generated.
	 *  If generatePolicy is set to false, a starting policy is not
	 *  automatically generated. solver_->improvePolicy must then be manually
	 *  called before starting.
	 */

	void printAgentBeliefProportions(){
		solver::BeliefNode *currentBelief = agent_->getCurrentBelief();
		std::vector<std::vector<float>> agentBeliefProportions = solverModel_->getAgentBeliefProportions(currentBelief);
		int agentIndex = 0;
		for(std::vector<float> agentProportions : agentBeliefProportions){
			int cluster = 0;
			std::cout << "agent " << agentIndex <<" cluster belief = " ;
			for(float proportion : agentProportions){
				if(proportion != 0){
					std::cout << " " << cluster << "-" << proportion;
				}
				cluster++;
			}
			agentIndex++;
		}
	}
	void printBeliefProportions(){
		solver::BeliefNode *currentBelief = agent_->getCurrentBelief();
		std::vector<std::vector<float>> agentBeliefProportions = solverModel_->getBeliefProportions(currentBelief);
		int agentIndex = 0;
		for(std::vector<float> agentProportions : agentBeliefProportions){
			int cluster = 0;
			std::cout << "opponent " << agentIndex <<" cluster belief = " ;
			for(float proportion : agentProportions){
				if(proportion != 0){
					std::cout << " " << cluster << "-" << proportion;
				}
				cluster++;
			}
			agentIndex++;
		}
	}


	virtual void initSolver(std::shared_ptr<Definition> problemDefinition, bool generatePolicy = true) {

		// If seed is not specified in options, seed using current time
		if (options_.seed == 0) {
			options_.seed = std::time(nullptr);
		}
		solverGen_.seed(options_.seed);
		solverGen_.discard(10);

		// Init solver
		std::cout << "Global seed: " << options_.seed << std::endl;
		std::unique_ptr<Model> solverModel = std::make_unique<Model>(
				&solverGen_, std::make_unique<Options>(options_), problemDefinition);
		solver_ = std::make_unique<solver::Solver>(std::move(solverModel));
		solver_->initializeEmpty();
		solverModel_ = static_cast<Model *>(solver_->getModel());

		// Generate policy
		if (generatePolicy) {
			double totT;
			double tStart;
			tStart = tapir::clock_ms();
			solver_->improvePolicy();
			totT = tapir::clock_ms() - tStart;
			std::cout << "Total solving time: " << totT << "ms" << std::endl;
		}

		// // Init simulator
		// if (internalSimulation_) {
		// 	simulatorGen_.seed(options_.seed);
		// 	simulatorGen_.discard(10000);
		// 	std::unique_ptr<Model> simModel = std::make_unique<Model>(
		// 			&simulatorGen_, std::make_unique<Options>(options_));
		// 	simulator_ = std::make_unique<solver::Simulator>(
		// 			std::move(simModel), solver_.get(), options_.areDynamic);
		// 	if (options_.hasChanges) {
		// 		simulator_->loadChangeSequence(options_.changesPath);
		// 	}
		// 	simulator_->setMaxStepCount(options_.nSimulationSteps);
		// 	agent_ = simulator_->getAgent();
		// } else {
		agent_ = new solver::Agent(solver_.get());
		// }
	}

	virtual void improvePolicy(){
		std::stringstream prevStream;
		solver::BeliefNode *currentBelief = agent_->getCurrentBelief();
		std::cout << std::endl << std::endl << "t-" << stepNumber_ << std::endl;
		std::cout << "Belief #" << currentBelief->getId() << std::endl;

			// solver::HistoricalData *data = currentBelief->getHistoricalData();
			// if (data != nullptr) {
			// 	std::cout << std::endl;
			// 	std::cout << *data;
			// 	std::cout << std::endl;
			// }
		prevStream << "Before:" << std::endl;
		solver_->printBelief(currentBelief, prevStream);

		solver_->improvePolicy(currentBelief);
		std::stringstream newStream;
		
					newStream << "After:" << std::endl;
					solver_->printBelief(currentBelief, newStream);
					while (prevStream.good() || newStream.good()) {
						std::string s1, s2;
						std::getline(prevStream, s1);
						std::getline(newStream, s2);
						std::cout << s1 << std::setw(40 - s1.size()) << "";
						std::cout << s2 << std::setw(40 - s2.size()) << "";
						std::cout << std::endl;
					}
	}

	// virtual void phantomInit(){
	// 	phantomBelief_ = agent_->getCurrentBelief();
	// 	currentBelief_ = agent_->getCurrentBelief();
	// }

	// virtual void phantomStep(std::shared_ptr<Action> action, std::shared_ptr<Observation> obs) {
	// 	// if (internalSimulation_) {
	// 	// 	finished_ = !simulator_->stepSimulation();
	// 	// 	return;
	// 	// }
	// 	agent_->setCurrentBelief(phantomBelief_);
	// 	agent_->updateBelief(*action, *obs);
	// 	phantomBelief_ = agent_->getCurrentBelief();
	// }

	// virtual int getPhantomAction(){ //std::unique_ptr<solver::Action> getPhantomAction(){
	// 	//return phantomBelief_->getRecommendedAction();
	// }

	// virtual void phantomImprove(){
	// 	solver_->improvePolicy(phantomBelief_);
	// }

	// virtual void closePhantomInstance(){
	// 	agent_->setCurrentBelief(currentBelief_);
	// }


	virtual int getPreferredAction(){
		std::unique_ptr<solver::Action> sa = agent_->getPreferredAction();
			if (sa == nullptr) {
				std::cout << "ERROR: Could not choose an action." << std::endl;
			} else {
				if (options_.hasVerboseOutput) {
					std::cout << "Action: "  << *sa << std::endl;
				}
				lastAction_.reset(static_cast<Action *>(sa.release()));
				//setAction();
				return lastAction_->getAction();
			}
	}
	/** Tapir processing, typically called in a timer loop */
	virtual void stepSolver() {
		// if (internalSimulation_) {
		// 	finished_ = !simulator_->stepSimulation();
		// 	return;
		// }

		std::stringstream prevStream;
		solver::BeliefNode *currentBelief = agent_->getCurrentBelief();
		//solver::HistoricalData *data = currentBelief->getHistoricalData();
		solver::HistoricalData *data = currentBelief->getHistoricalData();
			if (data != nullptr) {
				std::cout << std::endl;
				std::cout << *data;
				std::cout << std::endl;
			}
		if (options_.hasVerboseOutput) {
			std::cout << std::endl << std::endl << "t-" << stepNumber_ << std::endl;
			std::cout << "Belief #" << currentBelief->getId() << std::endl;


			//prevStream << "Before:" << std::endl;
			//solver_->printBelief(currentBelief, prevStream);
		}

		if(stepNumber_==0){
			stepNumber_++;

			// Get preferred action. Needs to be cast into problem's action
			std::unique_ptr<solver::Action> sa = agent_->getPreferredAction();
			if (sa == nullptr) {
				std::cout << "ERROR: Could not choose an action." << std::endl;
			} else {
				if (options_.hasVerboseOutput) {
					std::cout << "Action: "  << *sa << std::endl;
				}
				lastAction_.reset(static_cast<Action *>(sa.release()));
				//setAction();
			}
		}
		if(observationQueue_.size()>0){
			if (stepNumber_ != 0) {

			// Get observation
				//lastObservation_ = std::make_unique;
					// if (options_.hasVerboseOutput) {
					// 	//std::cout << "Observation: "  << *lastObservation_ << std::endl;
					// 	std::cout << "Observation: " << *(observationQueue_[0]) << std::endl;
					// }

				//solverModel_->drawSimulationState(currentBelief, *((currentBelief->getStates())[0]), std::cout);
				// Update belief
				//solver_->replenishChild(currentBelief, *lastAction_, *lastObservation_);
				//agent_->updateBelief(*lastAction_, *lastObservation_);

				solver_->replenishChild(currentBelief, *lastAction_, *(observationQueue_[0]));
				agent_->updateBelief(*lastAction_, *(observationQueue_[0]));

				// If we're pruning on every step, we do it now.
				if (options_.pruneEveryStep) {
					double pruningTimeStart = tapir::clock_ms();
					long nSequencesDeleted = solver_->pruneSiblings(currentBelief);
					long pruningTime = tapir::clock_ms() - pruningTimeStart;
					if (options_.hasVerboseOutput) {
						std::cout << "Pruned " << nSequencesDeleted << " sequences in ";
						std::cout << pruningTime << "ms." << std::endl;
					}
				}

				if (currentBelief->getNumberOfParticles() == 0) {
					debug::show_message("ERROR: Resulting belief has zero particles!!");
				}

				// Improve policy
				currentBelief = agent_->getCurrentBelief();
				solver_->improvePolicy(currentBelief);

				if (options_.hasVerboseOutput) {
					std::stringstream newStream;
					newStream << "After:" << std::endl;
					solver_->printBelief(currentBelief, newStream);
					while (prevStream.good() || newStream.good()) {
						std::string s1, s2;
						std::getline(prevStream, s1);
						std::getline(newStream, s2);
						std::cout << s1 << std::setw(40 - s1.size()) << "";
						std::cout << s2 << std::setw(40 - s2.size()) << "";
						std::cout << std::endl;
					}
				}
			}
			stepNumber_++;

			// Get preferred action. Needs to be cast into problem's action
			std::unique_ptr<solver::Action> sa = agent_->getPreferredAction();
			if (sa == nullptr) {
				std::cout << "ERROR: Could not choose an action." << std::endl;
			} else {
				if (options_.hasVerboseOutput) {
					std::cout << "Action: "  << *sa << std::endl;
				}
				lastAction_.reset(static_cast<Action *>(sa.release()));
				//setAction();
			}
			observationQueue_.erase(observationQueue_.begin());
		}
	}

	/** Handle model changes */
	void handleChanges(
			std::vector<std::unique_ptr<solver::ModelChange>> const &changes,
			bool resetTree) {

		bool hasDynamicChanges = options_.areDynamic;
		// if (internalSimulation_) {
		// 	simulator_->handleChanges(changes, hasDynamicChanges, resetTree);
		// }
		if (hasDynamicChanges) {
			solver_->setChangeRoot(agent_->getCurrentBelief());
		} else {
			solver_->setChangeRoot(nullptr);
		}
		if (resetTree) {
			solver_->getModel()->applyChanges(changes, nullptr);
		} else {
			// The model only needs to inform the solver of changes if we intend
			// to keep the policy.
			solver_->getModel()->applyChanges(changes, solver_.get());
		}

		// Apply the changes, or simply reset the tree.
		if (resetTree) {
			solver_->resetTree(agent_->getCurrentBelief());
			agent_->setCurrentBelief(solver_->getPolicy()->getRoot());
		} else {
			solver_->applyChanges();
		}
	}



	virtual void initialisePlanner(std::shared_ptr<Definition> problemDefinition, std::string problemPath) {
		// std::string problemPath = ros::package::getPath("tapir") +
		// 				"/problems/" + problemName;
		loadOptions(problemPath);

		initSolver(problemDefinition);
	}

};
		}
	}
}

#endif /* TAPIR_NODE_HPP_ */
