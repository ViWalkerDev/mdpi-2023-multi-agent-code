/** @file BoundarySearchMultiAction.hpp
 *
 * Defines the BoundarySearchMultiAction class, which represents an action for the BoundarySearchMulti problem, and also the
 * ActionType enumeration, which enumerates the different types of actions for BoundarySearchMulti.
 */
#ifndef BOUNDARYSEARCHMULTI_ACTION_HPP_
#define BOUNDARYSEARCHMULTI_ACTION_HPP_

#include <cstddef>                      // for size_t

#include <ostream>                      // for ostream
#include <vector>                       // for vector

#include "tapirsolver/solver/abstract-problem/Action.hpp"
#include "tapirsolver/solver/abstract-problem/DiscretizedPoint.hpp"             // for DiscretizedPoint
namespace nanomap{
  namespace planner{
    namespace boundarysearchmulti {

//VARIABLE ACTION QTY. NUM ACTIONS = NUM ENVIRONMENT CLUSTERS
// /** An . */
// enum class ActionType : long {
//
// };

/** A class representing an action in the BoundarySearchMulti POMDP.
 *
 * This class also implements solver::DiscretizedPoint so that the solver can use a simplistic
 * enumerated action mapping approach (EnumeratedActionPool) to store the available actions from
 * each belief node.
 */
class BoundarySearchMultiAction : public solver::DiscretizedPoint {
    friend class BoundarySearchMultiTextSerializer;
  public:
    /** Constructs a new action from the given ActionType. */
    //BoundarySearchMultiAction(ActionType actionType);
    /** Constructs a new action from the given integer code. */
    BoundarySearchMultiAction(int node);

    virtual ~BoundarySearchMultiAction() = default;
    _NO_COPY_OR_MOVE(BoundarySearchMultiAction);

    std::unique_ptr<solver::Action> copy() const override;
    double distanceTo(solver::Action const &otherAction) const override;
    void print(std::ostream &os) const override;

    long getBinNumber() const override;
    /** Returns the action. */
    int getAction() const;

  private:
    /** The ActionType for this action in the BoundarySearchMulti POMDP. */
    //ActionType actionType_;
    int action_;
};
} /* namespace boundarySearch */
}
}
#endif /* BOUNDARYSEARCHMULTI_ACTION_HPP_ */
