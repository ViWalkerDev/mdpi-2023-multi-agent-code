/** @file Options.hpp
 *
 * Defines the TagOptions class, which specifies the configuration settings available for the
 * Tag problem.
 */
#ifndef NANOMAP_PLANNER_BOUNDARYSEARCHMULTI_BOUNDARYSEARCHMULTIDEFINITION_HPP_
#define NANOMAP_PLANNER_BOUNDARYSEARCHMULTI_BOUNDARYSEARCHMULTIDEFINITION_HPP_
#include "nanomap/planner/Definition.hpp"
#include "nanomap/map/PlannerMap.h"
namespace nanomap {
  namespace planner{
    namespace boundarysearchmulti {

/** A class defining the configuration settings for the Tag problem. */
struct BoundarySearchMultiDefinition : public Definition {
    BoundarySearchMultiDefinition() = default;
    virtual ~BoundarySearchMultiDefinition() = default;
    // void setVars(int initialNode,
    //               int nNodes,
    //               float maxMovePenalty,
    //               std::vector<int> initialOccupancy,
    //               std::vector<int> maxOccupancy,
    //               std::vector<std::vector<float>> nodeDistances,
    //               double clusterSearchReward){
    //   initialNode_ = initialNode;
    //   nNodes_ = nNodes;
    //   maxMovePenalty_ = maxMovePenalty;
    //   initialOccupancy_ = initialOccupancy;
    //   maxOccupancy_ = maxOccupancy;
    //   nodeDistances_ = nodeDistances;
    //   clusterSearchReward_ = clusterSearchReward;
    // }

    void populateFromMap(std::shared_ptr<nanomap::map::PlannerMap> plannerMap){
      plannerMap_ = plannerMap;
      //nodeDistances_ = plannerMap->_meanNodePathScores;
      //std::cout << "1" << std::endl;
      //maxMovePenalty_ = plannerMap->_maxMovePenalty;
      //std::cout << "1" << std::endl;
      nClusters_ = plannerMap->_clusterIDs.size();
      nBoundaryNodes_ = 0;
      boundaryNodes_.clear();
      for(int x = 0; x < nClusters_; x++){
        nBoundaryNodes_+=plannerMap_->_clusterBoundaryPoints[x].size();
        for(int y = 0; y < plannerMap_->_clusterBoundaryPoints[x].size(); y++){
          boundaryNodes_.push_back(plannerMap_->_clusterBoundaryPoints[x][y]);
        }
      }
      populateBoundaryMap();
      generateBoundaryToClusterPaths();
      //std::cout << "1" << std::endl;
      //maxOccupancy_.clear();
      initialOccupancy_.clear();
      //moveMatrix_.resize(plannerMap->_clusterIDs.size(),std::vector<int>(plannerMap->_clusterIDs.size()));
      //adjacencyMatrix_.resize(plannerMap->_clusterIDs.size(),std::vector<float>(plannerMap->_clusterIDs.size()));
      //initialOccupancy_.resize(plannerMap->_clusterIDs.size());
      //std::cout << "1" << std::endl;
      //maxOccupancy_.resize(plannerMap->_clusterIDs.size());
      //std::cout << "1" << std::endl;
      //std::cout << "clusterCount: "<< plannerMap->_clusterIDs.size() << std::endl;
      // for(int x = 0; x < plannerMap->_clusterIDs.size(); x++){
      //   //std::cout << "cluster: " << x << std::endl;
      //   //std::cout <<  " size: " << plannerMap->_clustersFull[x].size() << std::endl;
      //   maxOccupancy_.push_back(plannerMap->_clustersFull[x].size());
      //   //initialOccupancy_.push_back(plannerMap->_clustersFull[x].size());
      // }

      // for(int x = 0; x < plannerMap->_clusterIDs.size(); x++){
      //   std::vector<int> sourceBoundaries = _clusterBoundaryPoints[x];
      //   for(int y = 0; y < plannerMap->_clusterIDs.size(); y++){
      //     if(x!=y){
      //       std::vector<int> destBoundaries = _clusterBoundaryPoints[x];
      //       for(int z = 0; z < sourceBoundaries.size(); z++){
      //         for(int a = 0; a < destBoundaryies.size(); a++){
      //           int srcBoundary = _globalToBoundaryMap[sourceBoundaries[z]];
      //           int destBoundary = _globalToBoundaryMap[destBoundaries[a]];
      //           std::pair<int,int> boundaryPair;
      //           if(srcBoundary < destBoundary){
      //             boundaryPair = std::make_pair(srcBoundary, destBoundary);
      //           }else{
      //             boundaryPair = std::make_pair(destBoundary, srcBoundary);
      //           }
      //           if(_boundaryPaths[boundaryPair].second.size()==0){
      //             //then x cluster and y cluster are neighbours.
      //             adjacencyMatrix_[x][y] = nodeDistances_[x][y];
      //             break;
      //           }
      //         }
      //       }
      //     }
      //   }
      // }

      // for(int x = 0; x < plannerMap->_clusterIDs.size(); x++){
      //   int originNode = plannerMap->_clusterIDs[x];
      //   for(int y = 0; y < plannerMap->_clusterIDs.size(); y++){
      //     if(x != y){
      //       float score = 0.0;
      //       int currentCluster = x;
      //       std::vector<int> path = plannerMap->pathBetweenNodeAndCluster(originNode, y);
      //       int targetCluster;
      //       for(int z = 0; z < path.size(); z++){
      //         targetCluster = plannerMap->_globalClusterMap[path[z]];
      //         if(currentCluster == x){
      //           if(targetCluster != x){
      //             moveMatrix_[x][y] = targetCluster;
      //             score += nodeDistances_[currentCluster][targetCluster];
      //             currentCluster = targetCluster;
      //           //break;
      //           }
      //         }else{
      //           if(targetCluster != currentCluster){
      //             score+=nodeDistances_[currentCluster][targetCluster];
      //             currentCluster = targetCluster;
      //           }
      //         }
      //       }
      //       adjacencyMatrix_[x][y] = score;
      //     }
      //   }
      // }
      //std::cout << std::endl;
      //std::cout << "1" << std::endl;
    }

    void populateBoundaryMap(){
      boundaryMap_.clear();
      boundaryScores_.clear();
      moveData_.clear();
      for(int x = 0; x < boundaryNodes_.size() ; x++){
        int boundaryX = plannerMap_->_globalToBoundaryMap[boundaryNodes_[x]];
        std::vector<int> neighbours;
        std::vector<float> neighbourScores;
        for(int y = 0; y < boundaryNodes_.size(); y++){
          if(x!=y){
            int boundaryY = plannerMap_->_globalToBoundaryMap[boundaryNodes_[y]];
            std::pair<int, int> boundaryPair;
            if(boundaryX < boundaryY){
              boundaryPair = std::pair<int,int>(boundaryX,boundaryY);
            }else{
              boundaryPair = std::pair<int,int>(boundaryY,boundaryX);
            }
            std::pair<float, std::vector<int>> pathPair = plannerMap_->_boundaryPaths[boundaryPair];
            std::vector<int> path = pathPair.second;
            float score = pathPair.first;
            if(plannerMap_->_globalClusterMap[boundaryNodes_[x]] == plannerMap_->_globalClusterMap[boundaryNodes_[y]]){
                neighbours.push_back(y);
                neighbourScores.push_back(score);
            }else{
              if(path.size()<=0){
                //If the size of the path between the boundary points is == 0, then these points are visible to each other across boundary borders
                neighbours.push_back(y);
                neighbourScores.push_back(score);
                //std::cout << score << std::endl;
              }
            }
          }
        }
        moveData_.push_back(neighbours.size());
        boundaryMap_.push_back(neighbours);
        boundaryScores_.push_back(neighbourScores);
      }
      int maxConns = 0;
      for(int x = 0; x < boundaryMap_.size(); x++){
        if(boundaryMap_[x].size()>maxConns){
          maxConns = boundaryMap_[x].size();
        }
      }
      maxConnections_ = maxConns;
      maxMovePenalty_ = 0.0;

      for(int x = 0; x < boundaryScores_.size(); x++){
        for(int y = 0; y < boundaryScores_[x].size(); y++){
          if(maxMovePenalty_ < boundaryScores_[x][y]){
            maxMovePenalty_ = boundaryScores_[x][y];
            std::cout << maxMovePenalty_ << std::endl;
          }
        }
      }
    }

    void setInitialOccupancy(std::vector<int> occupancy){
      initialOccupancy_ = occupancy;
    }

    void setCfgPath(std::string cfgString){
      cfgPath_ = cfgString;
    }

    void generateBoundaryToClusterPaths(){
      //This gets the shortest path between all boundary points and each cluster
      //boundaryToClusterPaths_.resize(nBoundaryNodes_, std::vector<int>(nClusters_));
      boundaryToClusterPaths_.clear();
      for(int clusterID = 0; clusterID < plannerMap_->_clusterBoundaryPoints.size(); clusterID++){
        for(int boundary = 0; boundary < plannerMap_->_clusterBoundaryPoints[clusterID].size(); boundary++){
          int boundaryNode = plannerMap_->_clusterBoundaryPoints[clusterID][boundary];
          for(int targetCluster = 0; targetCluster < plannerMap_->_clusterBoundaryPoints.size(); targetCluster++){
            if(clusterID != targetCluster){
              std::vector<int> path = plannerMap_->pathBetweenNodeAndCluster(boundaryNode, targetCluster);
              std::vector<float> scorePath;
              int initialNode = path[0];
              for(int x = 1; x < path.size(); x++){
                int targetNode = path[x];
                float score = plannerMap_->getShortestPathAndScore(initialNode, targetNode).first;
                scorePath.push_back(score);
                initialNode = path[x];
              }
              std::pair<std::vector<int>, std::vector<float>> pathPair = std::pair<std::vector<int>, std::vector<float>>(path, scorePath);
              std::pair<int, int> nodeClusterPair = std::pair<int, int>(boundaryNode, targetCluster);
              boundaryToClusterPaths_.insert(std::pair<std::pair<int, int>, std::pair<std::vector<int>, std::vector<float>>>(nodeClusterPair, pathPair));
            }
          }
        }
      }
    }
    void generateQVals(float discountFactor){
      //This function generates the optimal and default QValues for the boundary search problem
      //Initialise the QValMatrices
      //defaultQValMatrix_.resize(nBoundaryNodes_, std::vector<float>(nClusters_));
      //optimalQValMatrix_.resize(nBoundaryNodes_, std::vector<float>(nClusters_));
      discountFactor_ = discountFactor;
      for ( const auto &entry : boundaryToClusterPaths_)
      {
        //
        int globalBoundaryIndex = entry.first.first;
        int clusterID = entry.first.second;
        std::vector<int> boundaryPath = entry.second.first;
        std::vector<float> scorePath = entry.second.second;
        float qval = 0.0;
        int step = 1;
        for(int x = 0; x < scorePath.size(); x++){
          qval += scorePath[x]*(std::pow(discountFactor, step));
          step++;
        }
        qval = qval/discountFactor;
        qval += clusterSearchReward_*std::pow(discountFactor,step);
        std::pair<int, int> boundaryClusterPair = std::pair<int, int>(globalBoundaryIndex, clusterID);
        optimalQValMap_.insert(std::pair<std::pair<int,int>, float>(boundaryClusterPair, qval));

        qval = 0.0;
        step = 1;
        for(int x = 0; x < scorePath.size(); x++){
          qval += scorePath[x]*(std::pow(discountFactor, step));
          step++;
          qval += scorePath[x]*(std::pow(discountFactor, step));
          step++;
        }
        qval = qval/discountFactor;
        qval += clusterSearchReward_*std::pow(discountFactor,step);
        defaultQValMap_.insert(std::pair<std::pair<int, int>, float>(boundaryClusterPair, qval));
      }
    }


    double getDefaultQVal(int robotBoundaryNode, int opponentCluster){
      //Fetches the qval from the default Q Val matrix
      int globalBoundaryNode = boundaryNodes_[robotBoundaryNode];
      std::pair<int, int> boundaryClusterPair = std::pair<int, int>(globalBoundaryNode, opponentCluster);
      if(defaultQValMap_.count(boundaryClusterPair)>0){
        return defaultQValMap_[boundaryClusterPair];
      }else{
        return clusterSearchReward_*discountFactor_;
      }
    }
    double getOptimalQVal(int robotBoundaryNode, int opponentCluster){
      //Fetches the qval from the optimal Q Val matrix
      int globalBoundaryNode = boundaryNodes_[robotBoundaryNode];
      std::pair<int, int> boundaryClusterPair = std::pair<int, int>(globalBoundaryNode, opponentCluster);
      if(optimalQValMap_.count(boundaryClusterPair)>0){
        return optimalQValMap_[boundaryClusterPair];
      }else{
        return clusterSearchReward_*discountFactor_;
      }
    }
    bool isRobotValid(int boundaryNode){
      if(boundaryNode >= nBoundaryNodes_){
        return false;
      }else{
        return true;
      }
    }
    bool isOpponentValid(int cluster){
      if(cluster >= nClusters_){
        return false;
      }else{
        return true;
      }
    }

    std::vector<int> getMoveData(){
        return moveData_;
    }

    std::pair<int, bool> getRobotMovedNode(int boundaryNode, int action){
      //action is 0->maxConnections_-1;
      if(action > boundaryMap_[boundaryNode].size() || action == 0){
        return std::pair<int, bool>(0, false);
      }else{
        int returnNode = boundaryMap_[boundaryNode][action-1];
        return std::pair<int, bool>(returnNode, true);
      }
    }

    //int getOpponentMovedPos(int cluster, int action){
    //NOT IMPLEMENTED YET THIS IS FOR MOVING OPPONENT
    //}

    int getBoundaryCluster(int boundaryNode){
      //return the cluster that the boundary node belongs to.
      int globalBoundaryNode = boundaryNodes_[boundaryNode];
      return plannerMap_->_globalClusterMap[globalBoundaryNode];
    }

    std::pair<float, bool> getTransitDistance(int boundaryNode, int action){
      if(action > boundaryScores_[boundaryNode].size() || action == 0){
        return std::pair<float, bool>(0.0, false);
      }else{
        float returnScore = boundaryScores_[boundaryNode][action-1];
        return std::pair<float, bool>(returnScore, true);
      }
    }

    double getTransitSteps(int boundaryNode, int cluster){
      //for ( const auto &entry : boundaryToClusterPaths_)
      //{
        //
        if(boundaryNode >= 0 && boundaryNode < nBoundaryNodes_ && cluster >=0 && cluster < nClusters_){
          if(cluster != plannerMap_->_globalClusterMap[boundaryNodes_[boundaryNode]]){
          //std::cout << (double)(boundaryToClusterPaths_[std::pair<int,int>(boundaryNodes_[boundaryNode],cluster)].first.size()) << std::endl;
            return (double)(boundaryToClusterPaths_[std::pair<int,int>(boundaryNodes_[boundaryNode],cluster)].first.size());
          }else{
            return 1.0;
          }
        }else{
          return 1.0;
        }

      //
      // int globalBoundaryIndex = boundaryNodes_[boundaryNode];
      // int clusterID = cluster;
      // std::pair<int, int> mapPair = std::pair<int, int>(globalBoundaryIndex, clusterID);
      // std::pair<std::vector<int>, std::vector<float>> result = boundaryToClusterPaths_[mapPair];
      // std::vector<int> boundaryPath = result.first;
      // std::vector<float> scorePath = result.second;
    }

bool isAccessible(int targetNode, int originNode){
  if(originNode == targetNode){
    return true;
  }else{
    bool neighbour = false;
    std::vector<int> neighbours = boundaryMap_[originNode];
    for(int x = 0; x < neighbours.size(); x++){
      if(targetNode == neighbours[x]){
        return true;
      }
    }
    return false;
  }
}
    // int randomEmptyBoundaryNode(){
    //
    // }
    // int randomEmptyCluster(){
    //
    // }
    ////getFullTransitDistance(boundaryNode, cluster)
    ////getFullTransitDistanceAndSteps(boundaryNode, cluster)

    std::string cfgPath_;
    std::shared_ptr<nanomap::map::PlannerMap> plannerMap_;
    /* -------- Settings specific to BoundarySearchMulti POMDP -------- */
    std::vector<int> initialBoundaryNodes_;
    int agentID_ = 0;
    int nAgents_ = 0;
    float discountFactor_ = 0.0;
    int nClusters_ = 0;
    int nBoundaryNodes_ = 0;
    int maxConnections_ = 0;
    std::vector<int> initialOccupancy_;

    double clusterSearchReward_ = 0.0;
    double clusterSearchCost_ = 0.0;
    double maxMovePenalty_ = 0.0;
    //std::vector<std::vector<std::vector<int>>> boundaryToClusterPaths_;

    //std::vector<std::vector<float>> defaultQValMap_;
    //std::vector<std::vector<float>> optimalQValMap_;

    //MAPS PAIR OF (BOUNDARY NODE (GLOBAL), CLUSTER ID) to Global Boundary path, and Float Score of each Step
    std::vector<std::vector<int>> boundaryMap_;
    std::vector<int> moveData_;
    std::vector<std::vector<float>> boundaryScores_;
    std::vector<int> boundaryNodes_;
    std::map<std::pair<int, int>, std::pair<std::vector<int>,std::vector<float>>> boundaryToClusterPaths_;


    std::map<std::pair<int, int>, float> defaultQValMap_;
    std::map<std::pair<int, int>, float> optimalQValMap_;
};
    } /* namespace boundarysearchmulti */
  }
}
#endif /* NANOMAP_PLANNER_BOUNDARYSEARCHMULTI_BOUNDARYSEARCHMULTIPROBLEMDEFINITION_HPP_ */
