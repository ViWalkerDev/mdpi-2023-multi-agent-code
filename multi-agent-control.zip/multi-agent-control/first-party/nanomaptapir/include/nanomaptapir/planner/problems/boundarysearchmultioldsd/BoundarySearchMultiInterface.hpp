/** @file TagNode.hpp
 *
 * Contains TagNode, which implements the TapirNode interface and acts as a ROS node.
 */
#ifndef BOUNDARYSEARCHMULTI_INTERFACE_HPP_
#define BOUNDARYSEARCHMULTI_INTERFACE_HPP_

#include <memory>                   // For unique_ptr
#include <vector>
#include <string>

#include "nanomap/planner/Interface.hpp"

#include "nanomap/planner/problems/boundarysearchmulti/BoundarySearchMultiAction.hpp"
#include "nanomap/planner/problems/boundarysearchmulti/BoundarySearchMultiObservation.hpp"
#include "nanomap/planner/problems/boundarysearchmulti/BoundarySearchMultiOptions.hpp"
#include "nanomap/planner/problems/boundarysearchmulti/BoundarySearchMultiState.hpp"
#include "nanomap/planner/problems/boundarysearchmulti/BoundarySearchMultiModel.hpp"
#include "nanomap/planner/problems/boundarysearchmulti/BoundarySearchMultiDefinition.hpp"

namespace nanomap{
	namespace planner{
		namespace boundarysearchmulti{

class BoundarySearchMultiInterface : public Interface<BoundarySearchMultiOptions, BoundarySearchMultiModel, BoundarySearchMultiObservation,
		BoundarySearchMultiAction, BoundarySearchMultiDefinition> {

public:

	BoundarySearchMultiInterface(){}
	~BoundarySearchMultiInterface(){}

	// void stepThroughPolicy(){
	//
	// }
	virtual int getPhantomAction() override {
		std::unique_ptr<solver::Action> solverAction = phantomBelief_->getRecommendedAction();
		BoundarySearchMultiAction* action = static_cast<BoundarySearchMultiAction *>(solverAction, solverAction.get());
		return action->getAction();
	}

};
		} /* namespace boundarysearchmulti */
	} /* namespace planner */
} /* namespace nanomap */

#endif /* BOUNDARYSEARCHMULTI_INTERFACE_HPP_ */
