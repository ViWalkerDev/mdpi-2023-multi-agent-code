/** @file BoundarySearchMultiObservation.hpp
 *
 * Defines the BoundarySearchMultiObservation class, which represents an observation in the BoundarySearchMulti POMDP.
 */
#ifndef BOUNDARYSEARCHMULTI_OBSERVATION_HPP_
#define BOUNDARYSEARCHMULTI_OBSERVATION_HPP_

#include <cstddef>                      // for size_t

#include <ostream>                      // for ostream
#include <vector>                       // for vector

#include "tapirsolver/global.hpp"                     // for RandomGenerator

//#include "tapirsolver/problems/shared/GridPosition.hpp"
#include "tapirsolver/solver/abstract-problem/DiscretizedPoint.hpp"
#include "tapirsolver/solver/abstract-problem/Observation.hpp"
namespace nanomap{
  namespace planner{
    namespace boundarysearchmulti{
class BoundarySearchMultiModel;

/** A class representing an observation in the BoundarySearchMulti POMDP.
 *
 * This includes an observation of the robot's own position, and a boolean flag representing
 * whether or not the robot sees the opponent (and hence is on the same grid square).
 */
class BoundarySearchMultiObservation : public solver::Point {
    friend class BoundarySearchMultiTextSerializer;
  public:
    /** Constructs a new BoundarySearchMultiObservation for the given robot position; seesOpponent should be true
     * iff the robot sees the opponent due to being on the same square.
     */
    //BoundarySearchMultiObservation(GridPosition myPosition, bool seesOpponent = false);
    BoundarySearchMultiObservation(std::vector<int> agentPositions, std::vector<bool> searchStatus, bool seesOpponent = false);

    virtual ~BoundarySearchMultiObservation() = default;
    _NO_COPY_OR_MOVE(BoundarySearchMultiObservation);

    std::unique_ptr<solver::Observation> copy() const override;
    double distanceTo(solver::Observation const &otherObs) const override;
    bool equals(solver::Observation const &otherObs) const override;
    std::size_t hash() const override;
    void print(std::ostream &os) const override;

    /** Returns the position the robot has observed itself in. */
    //GridPosition getPosition() const;
    /** Returns true iff the robot sees the opponent in the same square it is in. */
    bool seesOpponent() const;
    std::vector<bool> searchStatuses() const;
    bool searchStatus(int index) const;
    //int robotBoundaryNode() const;
    std::vector<int> agentPositions() const;
    int agentPosition(int index) const;
    std::vector<int> agentActions() const;
    int agentAction(int index) const;
    //int agentOnePosition() const;
    //int agentOneAction() const;
  private:
    /** The position the robot sees itself in. */
    //GridPosition position_;
    /** True iff the robot sees the opponent in the same square it is in. */
    bool seesOpponent_;
    std::vector<bool> searchStatus_;
    std::vector<int> agentPositions_;
    // std::vector<int> agentActions_;
    //int robotBoundaryNode_;
    //int agentOnePosition_;
    //int agentOneAction_;
};
} /* namespace boundarySearch */
}
}
#endif /* BOUNDARYSEARCHMULTI_OBSERVATION_HPP_ */
