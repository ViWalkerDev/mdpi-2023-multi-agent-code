/** @file BoundarySearchMultiOptions.hpp
 *
 * Defines the BoundarySearchMultiOptions class, which specifies the configuration settings available for the
 * BoundarySearchMulti problem.
 */
#ifndef BOUNDARYSEARCHMULTIOPTIONS_HPP_
#define BOUNDARYSEARCHMULTIOPTIONS_HPP_

#include <string>                       // for string

#include "tapirsolver/problems/shared/SharedOptions.hpp"
#include "nanomap/planner/problems/boundarysearchmulti/BoundarySearchMultiDefinition.hpp"
namespace nanomap{
  namespace planner{
    namespace boundarysearchmulti{
/** A class defining the configuration settings for the BoundarySearchMulti problem. */
struct BoundarySearchMultiOptions : public shared::SharedOptions {
    BoundarySearchMultiOptions() = default;
    virtual ~BoundarySearchMultiOptions() = default;

    /* -------- Settings specific to the BoundarySearchMulti POMDP -------- */
    /** Path to the map file (relative to SharedOptions::baseConfigPath) */
    //std::string mapPath = "";
    //int initialNode_ = 0;
    //int nNodes_ = 0;
    //float maxMovePenalty_ = 0.0;
    //std::vector<int> initialOccupancy_;
    //std::vector<int> maxOccupancy_;
    //std::vector<std::vector<float>> nodeDistances_;
    //double boundarySearchReward_ = 0.0;
    /** Cost per move. */
    //double moveCost = 0.0;
    /** Reward for boundarySearchging. */
    /** Penalty for a failed boundarySearch attempt. */
    //double failedBoundarySearchMultiPenalty = 0.0;
    /** Probability the opponent will stay in place. */
    //double opponentStayProbability = 0.0;
    /** Path to vrep scene boundarySearch.ttt */
    //std::string vrepScenePath = "";
    //std::shared_ptr<nanomap::planner::boundarysearchmulti::BoundarySearchMultiDefinition> problemDefinition_;
    // void setVars(std::shared_ptr<nanomap::planner::boundarysearchmulti::BoundarySearchMultiDefinition> problemDefinition){
    //   cfg_ = problemDefinition->cfgPath_;
    //   initialNode_ = problemDefinition->initialNode_;
    //   nNodes_ = problemDefinition->nNodes_;
    //   maxMovePenalty_ = problemDefinition->maxMovePenalty_;
    //   initialOccupancy_ = problemDefinition->initialOccupancy_;
    //   maxOccupancy_ = problemDefinition->maxOccupancy_;
    //   nodeDistances_ = problemDefinition->nodeDistances_;
    //   boundarySearchReward_ = problemDefinition->boundarySearchReward_;
    // }
    // std::string cfg_;
    // int initialNode_ = 0;
    // int nNodes_ = 0;
    // float maxMovePenalty_ = 0.0;
    double clusterSearchCost_ = 0.0;
    double clusterSearchReward_ = 0.0;
    double clusterMoveCost_ = 0.0;
    // std::vector<int> initialOccupancy_;
    // std::vector<int> maxOccupancy_;
    // std::vector<std::vector<float>> nodeDistances_;
    // double boundarySearchReward_ = 0.0;

    // static void addRuntimeVars(int initialNode,
    //                            int nNodes,
    //                            float maxMovePenalty,
    //                            std::vector<int> initialOccupancy,
    //                            std::vector<int> maxOccupancy,
    //                            std::vector<std::vector<float>> nodeDistances,
    //                            double boundarySearchReward){
    //     initialNode_ = initialNode;
    //     nNodes_ = nNodes;
    //     maxMoveCost_ = maxMoveCost;
    //     initialOccupancy_ = initialOccupancy;
    //     maxOccupancy_ = maxOccupancy;
    //     nodeDistances_ = nodeDistances;
    //     boundarySearchReward_ = boundarySearchReward;
    // }

    /** Constructs an OptionParser instance that will parse configuration settings for the BoundarySearchMulti
     * problem into an instance of BoundarySearchMultiOptions.
     */
    static std::unique_ptr<options::OptionParser> makeParser(bool simulating, std::string cfg) {
        std::unique_ptr<options::OptionParser> parser = SharedOptions::makeParser(simulating,
              cfg);
        addBoundarySearchMultiOptions(parser.get());
        return std::move(parser);
    }
    //
    /** Adds the core configuration settings for the BoundarySearchMulti problem to the given parser. */
    static void addBoundarySearchMultiOptions(options::OptionParser *parser) {
        parser->addOption<double>("problem", "clusterMoveCost", &BoundarySearchMultiOptions::clusterMoveCost_);
        parser->addOption<double>("problem", "clusterSearchReward", &BoundarySearchMultiOptions::clusterSearchReward_);
        parser->addOption<double>("problem", "clusterSearchCost", &BoundarySearchMultiOptions::clusterSearchCost_);
        // parser->addOption<double>("problem", "opponentStayProbability",
//                &BoundarySearchMultiOptions::opponentStayProbability);
    }

  };
} /* namespace boundarySearch */
}
}
#endif /* BOUNDARYSEARCHMULTIOPTIONS_HPP_ */
