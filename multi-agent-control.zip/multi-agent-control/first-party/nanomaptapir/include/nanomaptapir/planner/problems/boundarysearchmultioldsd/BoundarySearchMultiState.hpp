/** @file BoundarySearchMultiState.hpp
 *
 * Defines the BoundarySearchMultiState class, which represents a state of the BoundarySearchMulti problem.
 */
#ifndef BOUNDARYSEARCHMULTISTATE_HPP_
#define BOUNDARYSEARCHMULTISTATE_HPP_

#include <cstddef>                      // for size_t

#include <memory>
#include <ostream>                      // for ostream
#include <vector>

#include "tapirsolver/solver/abstract-problem/State.hpp"
#include "tapirsolver/solver/abstract-problem/VectorState.hpp"
namespace nanomap{
namespace planner{
namespace boundarysearchmulti{
/** A class representing a state in the BoundarySearchMulti POMDP.
 *
 * The state contains the positions of the robot and the opponent, as well as a boolean flag for
 * whether or not the opponent has been boundarySearchged; boundarySearchged => terminal state.
 *
 * This class also implements solver::VectorState in order to allow the state to be easily
 * converted to a vector<double>, which can then be used inside the standard R*-tree implementation
 * of StateIndex to allow spatial lookup of states.
 */
class BoundarySearchMultiState : public solver::VectorState {
    friend class BoundarySearchMultiTextSerializer;
  public:
    /** Constructs a new BoundarySearchMultiState with the given positions of the robot and opponent, and the
     * given boundarySearchged state.
     */
    BoundarySearchMultiState(std::vector<int> agentPositions, std::vector<bool> searchStatus, int opponentCluster, bool isFound);

    virtual ~BoundarySearchMultiState() = default;
    /** A copy constructor, for convenience. */
    BoundarySearchMultiState(BoundarySearchMultiState const &);
    /** The move constructor for BoundarySearchMultiState is forbidden. */
    //BoundarySearchMultiState(BoundarySearchMultiState &&) = delete;
    /** The copy assignment operator for BoundarySearchMultiState is forbidden. */
    //virtual BoundarySearchMultiState &operator=(BoundarySearchMultiState const &) = delete;
    /** The move assignment operator for BoundarySearchMultiState is forbidden. */
    //virtual BoundarySearchMultiState &operator=(BoundarySearchMultiState &&) = delete;

    std::unique_ptr<solver::State> copy() const override;

    double distanceTo(solver::State const &otherState) const override;
    bool equals(solver::State const &otherState) const override;
    std::size_t hash() const;

    std::vector<double> asVector() const override;
    void print(std::ostream &os) const override;

    /** Returns the position of the robot. */
    int getAgentPosition(int index) const;
    /** Returns the position of the robot. */
    // int getAgentAction(int index) const;

    std::vector<int> getAgentPositions() const;
    //
    // std::vector<int> getAgentActions() const;

    /** Returns the position of the opponent. */
    int getOpponentCluster() const;
    /** Returns true iff the opponent has already been boundarySearchged. */
    std::vector<bool> getSearchStatuses() const;
    bool getSearchStatus(int index) const;
    bool isFound() const;
  private:
    /** The current Node of the robot in the grid. */
    std::vector<int> agentPositions_;
    /** The current Node of the robot in the grid. */
    // std::vector<int> agentActions;
    // /** The position of the opponent in the grid. */
    int opponentCluster_;
    /** A flag that is true iff the opponent has been found. */
    std::vector<bool> searchStatus_;

    bool isFound_;
    //int currentAction_;
};
    } /* namespace boundarySearch */
  }
}
// We define a hash function directly in the std namespace.
namespace std {
/** A struct in the std namespace to define a standard hash function for the BoundarySearchMultiState class. */
template<> struct hash<nanomap::planner::boundarysearchmulti::BoundarySearchMultiState> {
    /** Returns the hash value for the given BoundarySearchMultiState. */
    std::size_t operator()(nanomap::planner::boundarysearchmulti::BoundarySearchMultiState const &state) const {
        return state.hash();
    }
};
} /* namespace std */
#endif /* BOUNDARYSEARCHMULTISTATE_HPP_ */
