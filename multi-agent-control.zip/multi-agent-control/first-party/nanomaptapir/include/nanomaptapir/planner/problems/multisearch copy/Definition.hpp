/** @file Options.hpp
 *
 * Defines the TagOptions class, which specifies the configuration settings available for the
 * Tag problem.
 */
#ifndef MULTISEARCH_DEFINITION_HPP_
#define MULTISEARCH_DEFINITION_HPP_
#include "nanomaptapir/planner/base/Definition.hpp"
#include "nanomaptapir/planner/problems/multisearch/Options.hpp"
#include "nanomap/manager/PlannerManager.h"
#include <float.h>
namespace nanomaptapir{
  namespace planner{
    namespace multisearch {
//class Options;
/** A class defining the configuration settings for the Tag problem. */
struct Definition : public base::Definition {
    Definition():plannerManager_(NULL), options_(NULL){}
    virtual ~Definition() = default;
    // void setVars(int initialNode,
    //               int nNodes,
    //               float maxMovePenalty,
    //               std::vector<int> initialOccupancy,
    //               std::vector<int> maxOccupancy,
    //               std::vector<std::vector<float>> nodeDistances,
    //               double clusterSearchReward){
    //   initialNode_ = initialNode;
    //   nNodes_ = nNodes;
    //   maxMovePenalty_ = maxMovePenalty;
    //   initialOccupancy_ = initialOccupancy;
    //   maxOccupancy_ = maxOccupancy;
    //   nodeDistances_ = nodeDistances;
    //   clusterSearchReward_ = clusterSearchReward;
    // }

    void setPlannerManager(std::shared_ptr<nanomap::manager::PlannerManager> plannerManager){
      plannerManager_ = plannerManager;
    }

    void setInitialOccupancy(std::vector<int> occupancy){
      //initialOccupancy_ = occupancy;
      initialOccupancy_ = occupancy;
    }

    void setUniformOccupancy(){
      initialOccupancy_ = plannerManager_->getUniformOccupancy();
      for(int x = 0; x < initialOccupancy_.size(); x++){
        initialOccupancy_[x] = std::sqrt(initialOccupancy_[x]);
      }
    }

    void setInitialOccupancy(){
      //initialOccupancy_ = occupancy;
      initialOccupancy_.resize(nClusters_);
      initialOccupancy_[0] = 1;
    }


    void setCfgPath(std::string cfgString){
      cfgPath_ = cfgString;
    }


    void setInitialPositions(int clusterBoundary, std::vector<int> agentClusters, int thisAgentId){
      //initialCluster_ = clusterBoundaryPair.first;
      initialBoundary_ = clusterBoundary;
      initialAgentClusters_ = agentClusters;
      numAgents_ = agentClusters.size();
      agentId_ = thisAgentId;
    }

    void setOptions(Options *options){
      options_ = options;
      discountFactor_ = options_->discountFactor;
      //Reward for finding target
      clusterSearchReward_ = options_->clusterSearchReward_;
      //Cost for simply waiting until the next observation;
      clusterWaitCost_ = options_->clusterWaitCost_;
      //Cost for being in the same cluster as another agent
      clusterClashCost_ = options_->clusterClashCost_;
      //Cost scaling for searching current cluster;
      clusterSearchScale_ = options_->clusterSearchCost_;
      //Cost sclaing for moving from current cluster;
      clusterMoveScale_ = options_->clusterMoveCost_;

      nTargets_ = options_->numTargets_;
    }
    void initialiseQVals(){
      getDefaultQValMap();
      //calculateDefaultQValMap();
      //getClusterInfoFromManager();
    }

    bool isRobotValid(int cluster, int boundary){
      if(cluster >= nClusters_ || boundary >= clusterBoundaryCounts_[cluster]){
        return false;
      }else{
        return true;
      }
    }
    bool isAgentValid(int cluster, int boundary){
      if(cluster >= nClusters_ || boundary >= clusterBoundaryCounts_[cluster]){
        return false;
      }else{
        return true;
      }
    }

    int agentId(){return agentId_;}

    bool isOpponentValid(int cluster){
      if(cluster >= nClusters_){
        return false;
      }else{
        return true;
      }
    }

    int nTargets(){return nTargets_;}

    int nClusters(){return nClusters_;}

    std::vector<int> getClusterNeighbourCounts(){
        return clusterNeighbourCounts_;
    }

    std::vector<int> getClusterBoundaryCounts(){
      return clusterBoundaryCounts_;
    }

void getClusterInfoFromManager(){
      clusterGraph_ = plannerManager_->returnClusterGraph();
      //clusterBoundaries_ = plannerManager_->getClusterBoundaries();
      nClusters_ = clusterGraph_.size();
      clusterBoundaryCounts_.clear();
      clusterNeighbourCounts_.clear();
      maxConnections_ = 0;
      for(int clusterIndex =0; clusterIndex < nClusters_; clusterIndex++){
        //int clusterBoundaryCount = 0;
        int neighbourCount = clusterGraph_[clusterIndex].size();
        std::set<int> boundaries;
        for(int neighbourEntry = 0; neighbourEntry < clusterGraph_[clusterIndex].size(); neighbourEntry++){
          for(int boundaryEntry = 0; boundaryEntry < clusterGraph_[clusterIndex][neighbourEntry].second.size(); boundaryEntry++){
            boundaries.insert(clusterGraph_[clusterIndex][neighbourEntry].second[boundaryEntry].first);
          }
        }
        int clusterBoundaryCount = boundaries.size();
        clusterBoundaryCounts_.push_back(clusterBoundaryCount);
        clusterNeighbourCounts_.push_back(neighbourCount);
        if(neighbourCount > maxConnections_){
          maxConnections_ = neighbourCount;
        }
      }
      getClusterMoveCosts();

      for(int x = 0; x < nClusters_; x++){
        double cost = (double)plannerManager_->getSafeCountForCluster(x);
        if(maxSearchCost_ < cost){
          maxSearchCost_ = cost;
        }
      }
    }

// void calculateDefaultQValMap(){
//   getDefaultQValMap();
// }

//ClusterMoveCosts, provide ((source cluster, source boundary), destination cluster), receive (destination boundary, cost);  
//std::map<std::pair<std::pair<std::pair<int,int>,int>,std::pair<int, double>>> clusterMoveCosts_;
    // void getClusterMoveCosts(){
    //   clusterMoveCosts_.clear();
    //   double maxCost = 0.0;
    //   //for each cluster
    //   for(int clusterIndex = 0; clusterIndex < nClusters_; clusterIndex++){
    //     //for each neighbour
    //     for(int neighbourIndex = 0; neighbourIndex < clusterGraph_[clusterIndex].size(); neighbourIndex++){
    //       int neighbourClusterIndex = clusterGraph_[clusterIndex][neighbourIndex].first;
    //       for(int boundaryEntry = 0; boundaryEntry < clusterGraph_[clusterIndex][neighbourIndex].second.size(); boundaryEntry++){
    //         int sourceBoundary = clusterGraph_[clusterIndex][neighbourIndex].second[boundaryEntry].first;
    //         std::pair<int, double> destBoundaryAndCost = plannerManager_->getDestinationBoundaryAndCostFromClusterBoundary(clusterIndex, sourceBoundary, neighbourClusterIndex);
    //         if(destBoundaryAndCost.second > maxCost){
    //           maxCost = destBoundaryAndCost.second;
    //         }
    //         std::pair<std::pair<int, int>, int> mapInput = std::make_pair(std::make_pair(clusterIndex,sourceBoundary),neighbourClusterIndex);
    //         clusterMoveCosts_.insert(std::make_pair(mapInput, destBoundaryAndCost));
    //       }
    //     }
    //   }
    // }

    void getClusterMoveCosts(){
      clusterMoveCosts_.clear();
      averageClusterMoveCosts_.clear();
      double maxCost = 0.0;
      //for each cluster
      for(int clusterIndex = 0; clusterIndex < nClusters_; clusterIndex++){
        std::vector<int> clusterBoundaryPoints = plannerManager_->boundariesInClusterSpace(clusterIndex);
        for(int neighbourIndex = 0; neighbourIndex < clusterGraph_[clusterIndex].size(); neighbourIndex++){
          int neighbourClusterIndex = clusterGraph_[clusterIndex][neighbourIndex].first;
          double totalNeighbourMoveCost = 0.0;
          int count = 0;
          for(int sourceBoundary : clusterBoundaryPoints){
            //Get the cost and destination boundary in the destination space for each index boundary point and the neighbour cluster
            std::pair<int, double> destBoundaryAndCost = plannerManager_->getDestinationBoundaryAndCostFromClusterBoundary(clusterIndex, sourceBoundary, neighbourClusterIndex);
            if(destBoundaryAndCost.second > maxCost){
              maxCost = destBoundaryAndCost.second;
            }
            totalNeighbourMoveCost += destBoundaryAndCost.second;
            //Add this to a map such that it returns the destination boundary point of the neighbour 
            //and the neighbours 
            std::pair<std::pair<int, int>, int> mapInput = std::make_pair(std::make_pair(clusterIndex,sourceBoundary),neighbourClusterIndex);
            clusterMoveCosts_.insert(std::make_pair(mapInput, destBoundaryAndCost));
            count++;
          }
          double averageMoveCost = totalNeighbourMoveCost / (double)count;
          averageClusterMoveCosts_.insert(std::make_pair(std::make_pair(clusterIndex, neighbourClusterIndex), averageMoveCost));
        }
      }
    }




    double maxMoveCost(){return maxMoveCost_;}

    void getDefaultQValMap(){
      //Get cluster Graph
    //std::map<std::pair<std::pair<int,int>,int>,double> 
      averageQValMap_.clear();
      for(int sourceCluster = 0; sourceCluster < nClusters_; sourceCluster++){
        //For each cluster
        std::vector<int> sourceBoundaries = plannerManager_->boundariesInClusterSpace(sourceCluster);
        for(int targetCluster = 0; targetCluster < nClusters_; targetCluster++){
          double qValSum = 0.0;
          int boundaryCount = 0;
          for(int sourceBoundary : sourceBoundaries){
            double qval = getQValToTargetCluster(sourceCluster, sourceBoundary, targetCluster);
            auto pairEntry = std::make_pair(std::make_pair(sourceCluster, sourceBoundary),targetCluster);
            defaultQValMap_.insert(std::make_pair(pairEntry,qval));
            qValSum += qval;
            boundaryCount++;
          }
          double qValAvg = qValSum/(double)boundaryCount;
          averageQValMap_.insert(std::make_pair(std::make_pair(sourceCluster, targetCluster), qValAvg));
        }
      }
    }      //   //for(int neighbourEntry = 0; neighbourEntry < clusterGraph_[sourceCluster].size(); neighbourEntry++){
      //     //for(int boundaryEntry = 0; boundaryEntry < clusterGraph_[sourceCluster][neighbourEntry].second.size(); boundaryEntry++){
      //       //int sourceBoundary = clusterGraph_[sourceCluster][neighbourEntry].second[boundaryEntry].first;
      //     //For each cluster clusterBoundary pair(neighbours + source cluster)
      //     // int sourceBoundary = -1;
      //     // int indexOfSourceFromPrevious = -1;
      //     // //If clusterBoundary is not sourceCluster
      //     // if(clusterBoundary != clusterNeighbours[sourceCluster.size()]){  
      //     //   // for(indexOfSourceFromPrevious = 0; clusterNeighbours_[clusterBoundary].size(); indexOfSourceFromPrevious++){
      //     //   //   if(clusterNeighbours_[clusterBoundary][indexOfSourceFromPrevious].first == sourceCluster){
      //     //   //     break;
      //     //   //   }
      //     //   // //sourceBoundary = clusterNeighbours_[clusterBoundary][indexOfSourceFromPrevious].second;
      //     //   // }
      //     // }
      //       for(int targetCluster = 0; targetCluster < nClusters_; targetCluster++){
      //         //double qval = 0;
      //         // if(indexOfSourceFromPrevious == -1){
      //         //   //Need average QVal
      //         //   double qval = getAverageQValToTargetCluster(sourceCluster, targetCluster);
      //         //   auto pairEntry = std::make_pair<std::pair<int, int>, int>(std::make_pair<int,int>(sourceCluster, sourceCluster),targetCluster);
      //         //   defaultQValMap.insert(std::make_pair<std::pair<std::pair<int, int>,int>,double>(pairEntry,double));
      //         //}else{
      //           //We can find 'exact' qval;
      //         double qval = getQValToTargetCluster(sourceCluster, sourceBoundary, targetCluster);
      //         auto pairEntry = std::make_pair(std::make_pair(sourceCluster, sourceBoundary),targetCluster);
      //         defaultQValMap_.insert(std::make_pair(pairEntry,qval));
      //         }
      //       }
      //     }  
      //   }
      // }


    // double getAverageQValToTargetCluster(int sourceCluster, int targetCluster){
    //   double qval;
    //   std::vector<int> clusterPath = 

    //   return qval;
    // }

    // double findBestMultiCombo(std::map<double, std::pair<int,int>> targetAgentDistanceMaps, int numTargets, int numAgents){
    //   std::vector<bool>
      
    // }


    double getMultiQVal(std::vector<int> sourceClusters, std::vector<int> targetClusters){
      //approximate calc
      //get the qval from each agent to each target cluster
      //get the shortest combination
      //map <target, <score, agent>>
      std::map<double, std::pair<int,int>> targetAgentDistanceMaps;
      //std::vector<std::map<double, int>> targetTargetDistanceMaps;
      //targetAgentDistanceMaps.resize(targetClusters.size());
      //targetTargetDistanceMaps.resize(targetClusters.size());
      int agentIndex = 0;
      for(int agentCluster : sourceClusters){
        int targetIndex = 0;
        for(int targetCluster : targetClusters){
          //We invert the qval, so that map does the sorting for us (the best qval will be the first entry)
          targetAgentDistanceMaps.insert(std::make_pair(-1*getAverageQVal(agentCluster, targetCluster),std::make_pair(targetIndex, agentIndex)));
          //Not worrying about this bit
          // if(targetClusters.size() > 1){
          //   for(int secondTargetCluster : targetClusters){
          //     if(targetCluster != secondTargetCluster){
          //       targetTargetDistanceMaps[targetIndex].insert(std::make_pair(-1*getAverageQVal(targetCluster, secondTargetCluster), secondTargetCluster));
          //     }
          //   }
          // }
          targetIndex++;
        }
        agentIndex++;
      }

      double minInvertedVal = 0.0;
      std::vector<bool> targetsAssigned;
      std::vector<bool> agentsAssigned;
      targetsAssigned.resize(targetClusters.size(), false);
      agentsAssigned.resize(sourceClusters.size(), false);
      for(auto mapPair : targetAgentDistanceMaps){
        double negQval = mapPair.first;
        int targetIndex = mapPair.second.first;
        int agentIndex = mapPair.second.second;
        if(targetsAssigned[targetIndex] == false && agentsAssigned[agentIndex] == false){
          minInvertedVal += negQval;
          targetsAssigned[targetIndex] = true;
          agentsAssigned[agentIndex] = true;
        }
        bool finished = true;
        for(bool assigned : targetsAssigned){
          if(assigned == false){
            finished = false;
          }
        }
        if(finished == true){
          break;
        }
      }
      //We have the Qvals maps for agents to targets. 
      // return -1*findBestMultiCombo(targetAgentDistanceMaps, targetClusters.size(), sourceClusters.size());
      // for(int x = 0; x < targetClusters.size(); x++){
      //   for(auto pair : targetAgentDistanceMaps[x]){
      //     int closestAgent = pair.second;
      //   }
      // }
      return -1 * minInvertedVal;
    }

    std::pair<std::pair<int, int>, bool> getRobotMovedCluster(int cluster, int boundary, int action){
      //action is 0->maxConnections_-1;
      if(action > clusterGraph_[cluster].size() || action < 0){
        return std::make_pair(std::make_pair(cluster, boundary), false);
      }else{
        // int returnNode = boundaryMap_[cluster][action-1];
        if(action <= 1){
          return std::make_pair(std::make_pair(cluster, boundary), true);
        }
        //int nextCluster = clusterGraph_[cluster][action-1].first;
        return std::make_pair((getClusterMove(cluster, boundary, action)).first, true);
      }
    }

    double getQValToTargetCluster(int sourceCluster, int sourceBoundary, int targetCluster){
      double qVal = 0.0; 
      if(sourceCluster == targetCluster){
        qVal = clusterSearchReward_;
        return qVal;
      }else{
        std::vector<int> shortestClusterPathFromClusterBoundary = plannerManager_->getShortestClusterPathBetweenBoundaries(sourceCluster, sourceBoundary, targetCluster);
        int currentSourceBoundary = sourceBoundary;
        int currentSourceCluster = sourceCluster;
        //int step = 0;
        int step = 0;
        double currentDiscount = 1.0;
        for(int x = 0; x < shortestClusterPathFromClusterBoundary.size(); x++){
          currentDiscount = (std::pow(discountFactor_, step));
          int localTargetCluster = shortestClusterPathFromClusterBoundary[x];
          std::pair<int, double> clusterMovePair = clusterMoveCosts_[std::make_pair(std::make_pair(currentSourceCluster,currentSourceBoundary),localTargetCluster)];
          qVal -= clusterMovePair.second*clusterMoveScale_*currentDiscount;
          currentSourceBoundary = clusterMovePair.first;
          currentSourceCluster = localTargetCluster;
          step++;
        }
        currentDiscount = (std::pow(discountFactor_, step));
        qVal-= getSearchCost(targetCluster)*clusterSearchScale_*currentDiscount;
        qVal+=clusterSearchReward_*currentDiscount;
        return qVal;
      }
    }

    double getAverageQVal(int robotCluster, int opponentCluster){
      return averageQValMap_[std::make_pair(robotCluster,opponentCluster)];
    }

    double getSearchCost(int cluster){
      return std::sqrt((double)plannerManager_->getSafeCountForCluster(cluster));
    }

    double maxSearchCost(){
      return maxSearchCost_;
    }

    int getNumberOfBoundaries(int cluster){
      return clusterBoundaryCounts_[cluster];
    }

    double getDefaultQVal(int robotCluster, int clusterBoundary, int opponentCluster){
      return defaultQValMap_[std::make_pair(std::make_pair(robotCluster, clusterBoundary),opponentCluster)];
    }
    //for a given cluster and boundary location, and action, returns pair of destination cluster and boundary, and cost of action. 
    std::pair<std::pair<int, int>, double> getClusterMove(int robotCluster, int robotBoundary, int action){
      //std::cout << "robotCluster " << robotCluster << std::endl;
      //std::cout << "action " << action << std::endl;
      if(action > 1){
        //std::pair<int, int> clusterBoundaryDestination;
        std::pair<int, int> clusterBoundarySource = std::make_pair(robotCluster, robotBoundary);
        //std::cout << "clusterGraph robotCluster entry size = " << clusterGraph_[robotCluster].size() << std::endl;
        int clusterDestination = clusterGraph_[robotCluster][action-2].first;
        
        std::pair<int, double> clusterMovePair = clusterMoveCosts_[std::make_pair(clusterBoundarySource, clusterDestination)];
        return std::make_pair(std::make_pair(clusterDestination, clusterMovePair.first),clusterMovePair.second);
      }else{
        return std::make_pair(std::make_pair(robotCluster, robotBoundary), 0.0);
      }
    }



    std::tuple<int, int, std::vector<bool>> getAgentActionOutcome(int agentCluster, int agentBoundary, int agentAction, std::vector<int> opponentClusters){
       std::vector<bool> foundNew;
       int destCluster;
       int destBoundary;
       bool valid;
       std::pair<int, int> destPair = std::make_pair(destCluster, destBoundary);
       foundNew.resize(opponentClusters.size(), false);
       if(agentAction == 0){
        //searching
        for(int x = 0; x < opponentClusters.size(); x++){
          if(opponentClusters[x] == agentCluster){
            foundNew[x] = true;
          }
        }
        destPair.first = agentCluster;
        destPair.second = agentBoundary;
       }else if(agentAction == 1){
        destPair.first = agentCluster;
        destPair.second = agentBoundary;
       }else if(agentAction >=2){
          std::tie(destPair, valid) = getRobotMovedCluster(agentCluster, agentBoundary, agentAction);
       }

      return std::make_tuple(destPair.first, destPair.second, foundNew);
    }

    std::vector<int> sampleActions(int agentTurn, std::vector<int> agentClusters, std::vector<int> agentActions, std::vector<bool> searchStatus){
      std::vector<int> actionSample;
      if(searchStatus[agentClusters[agentTurn]] == false){
        //We can search it
        actionSample.push_back(0);
      }
      actionSample.push_back(1);
      int actionIndex = 2;
      for(auto neighbourEntry : clusterGraph_[agentClusters[agentTurn]]){
        int neighbourCluster = neighbourEntry.first;
        bool valid = true;
        for(int cluster : agentClusters){
          if(neighbourCluster == cluster){
            valid = false;
            break;
          }
        }
        if(valid){
          actionSample.push_back(actionIndex);
        }
        actionIndex++;
      }
      return actionSample;
    }

    std::pair<int, double> getAverageMoveCost(int sourceCluster, int action){
      if(action == 0 || action == 1){
        //No move you dummy!
        return  std::make_pair(sourceCluster, 0.0);
      }
      int destCluster = clusterGraph_[sourceCluster][action].first;
      return std::make_pair(destCluster, averageClusterMoveCosts_[std::make_pair(sourceCluster, destCluster)]);
    }
    // int randomEmptycluster(){
    //
    // }
    // int randomEmptyCluster(){
    //
    // }
    ////getFullTransitDistance(cluster, cluster)
    ////getFullTransitDistanceAndSteps(cluster, cluster)

    std::string cfgPath_;
    //std::shared_ptr<nanomap::map::PlannerMap> plannerMap_;
    /* -------- Settings specific to  POMDP -------- */
    int initialCluster_ = 0;
    std::vector<int> initialAgentClusters_;
    int numAgents_;
    int agentId_;
    int initialBoundary_ = 0;
    //int initialcluster_ = 0;
    float discountFactor_ = 0.0;
    int nClusters_ = 0;
    int nTargets_ = 0;
    //int nclusters_ = 0;
    int maxConnections_ = 0;
    std::vector<int> initialOccupancy_;

    double maxSearchCost_ = 0.0;
    double maxMoveCost_ = 0.0;
    double clusterSearchReward_ = 0.0;
    double clusterSearchScale_ = 0.0;
    double maxMovePenalty_ = 0.0;
    double clusterMoveScale_ = 0.0;
    double clusterClashCost_ = 0.0;
    double clusterWaitCost_ = 0.0;


    //std::vector<std::vector<std::vector<int>>> boundaryToClusterPaths_;

    //std::vector<std::vector<float>> defaultQValMap_;
    //std::vector<std::vector<float>> optimalQValMap_;

    //MAPS PAIR OF (BOUNDARY NODE (GLOBAL), CLUSTER ID) to Global Boundary path, and Float Score of each Step
    //std::vector<std::vector<int>> boundaryMap_;
    //Move Data returns the number of neighbours a cluster has. 
    std::vector<int> clusterNeighbourCounts_;
    std::vector<int> clusterBoundaryCounts_;
    //List of cluster neighbours and the associated boundary node
    //ClusterGraph is cluster entry -> list of neighbours entries (which map to actions)
    //Each entry is a pair, with the int representing the cluster index of the neighbour,
    //And the other half of the pair is a vector of pairs that represent each boundary the neighbours share and the cluster boundary index for those boundaries.  
    std::vector<std::vector<std::pair<int,std::vector<std::pair<int,int>>>>> clusterGraph_;
    //std::vector<std::vector<std::pair<int, int>>> clusterNeighbours_;
    //This is the cost to move from any vertex node in a cluster to any of the boundaries. 
    //This is used as an approximate cost for a move to any neighbour following a search, as the model does not 
    //allow for knowing where in a cluster the agent is. 
    //std::vector<double> averageClusterMoveCost_;
    //the qval to travel from starting cluster pair (previous cluster and current cluster, std::pair<int,int>)
    //To the destination cluster, and then search that cluster.
    //Calculated at startup.

    //ClusterMoveCosts, provide ((source cluster, source boundary), destination cluster), receive (destination boundary, cost);  
    std::map<std::pair<std::pair<int,int>,int>,std::pair<int, double>> clusterMoveCosts_;
    std::map<std::pair<int,int>,double> averageClusterMoveCosts_;
    std::map<std::pair<std::pair<int,int>,int>,double> defaultQValMap_;
    std::map<std::pair<int, int>, double> averageQValMap_;

    //std::vector<std::vector<float>> boundaryScores_;
    //std::vector<int> clusters_;
    //std::map<std::pair<int, int>, std::pair<std::vector<int>,std::vector<float>>> boundaryToClusterPaths_;


    // std::map<std::pair<int, int>, float> defaultQValMap_;
    // std::map<std::pair<int, int>, float> optimalQValMap_;
    std::shared_ptr<nanomap::manager::PlannerManager> plannerManager_;
    //std::shared_ptr<nanomap::manager::GymManager> gymManager_;
    Options *options_;
    // void populateFromMap(std::shared_ptr<nanomap::map::PlannerMap> plannerMap){
    //   //plannerMap_ = plannerMap;
    //   //nodeDistances_ = plannerMap->_meanNodePathScores;
    //   //std::cout << "1" << std::endl;
    //   //maxMovePenalty_ = plannerMap->_maxMovePenalty;
    //   //std::cout << "1" << std::endl;
    //   nClusters_ = plannerMap->_clusterIDs.size();
    //   nclusters_ = 0;
    //   clusters_.clear();
    //   for(int x = 0; x < nClusters_; x++){
    //     nclusters_+=plannerMap_->_clusterBoundaryPoints[x].size();
    //     for(int y = 0; y < plannerMap_->_clusterBoundaryPoints[x].size(); y++){
    //       clusters_.push_back(plannerMap_->_clusterBoundaryPoints[x][y]);
    //     }
    //   }
    //   populateBoundaryMap();
    //   generateBoundaryToClusterPaths();
    //   //std::cout << "1" << std::endl;
    //   //maxOccupancy_.clear();
    //   initialOccupancy_.clear();
    //   //moveMatrix_.resize(plannerMap->_clusterIDs.size(),std::vector<int>(plannerMap->_clusterIDs.size()));
    //   //adjacencyMatrix_.resize(plannerMap->_clusterIDs.size(),std::vector<float>(plannerMap->_clusterIDs.size()));
    //   //initialOccupancy_.resize(plannerMap->_clusterIDs.size());
    //   //std::cout << "1" << std::endl;
    //   //maxOccupancy_.resize(plannerMap->_clusterIDs.size());
    //   //std::cout << "1" << std::endl;
    //   //std::cout << "clusterCount: "<< plannerMap->_clusterIDs.size() << std::endl;
    //   // for(int x = 0; x < plannerMap->_clusterIDs.size(); x++){
    //   //   //std::cout << "cluster: " << x << std::endl;
    //   //   //std::cout <<  " size: " << plannerMap->_clustersFull[x].size() << std::endl;
    //   //   maxOccupancy_.push_back(plannerMap->_clustersFull[x].size());
    //   //   //initialOccupancy_.push_back(plannerMap->_clustersFull[x].size());
    //   // }

    //   // for(int x = 0; x < plannerMap->_clusterIDs.size(); x++){
    //   //   std::vector<int> sourceBoundaries = _clusterBoundaryPoints[x];
    //   //   for(int y = 0; y < plannerMap->_clusterIDs.size(); y++){
    //   //     if(x!=y){
    //   //       std::vector<int> destBoundaries = _clusterBoundaryPoints[x];
    //   //       for(int z = 0; z < sourceBoundaries.size(); z++){
    //   //         for(int a = 0; a < destBoundaryies.size(); a++){
    //   //           int srcBoundary = _globalToBoundaryMap[sourceBoundaries[z]];
    //   //           int destBoundary = _globalToBoundaryMap[destBoundaries[a]];
    //   //           std::pair<int,int> boundaryPair;
    //   //           if(srcBoundary < destBoundary){
    //   //             boundaryPair = std::make_pair(srcBoundary, destBoundary);
    //   //           }else{
    //   //             boundaryPair = std::make_pair(destBoundary, srcBoundary);
    //   //           }
    //   //           if(_boundaryPaths[boundaryPair].second.size()==0){
    //   //             //then x cluster and y cluster are neighbours.
    //   //             adjacencyMatrix_[x][y] = nodeDistances_[x][y];
    //   //             break;
    //   //           }
    //   //         }
    //   //       }
    //   //     }
    //   //   }
    //   // }

    //   // for(int x = 0; x < plannerMap->_clusterIDs.size(); x++){
    //   //   int originNode = plannerMap->_clusterIDs[x];
    //   //   for(int y = 0; y < plannerMap->_clusterIDs.size(); y++){
    //   //     if(x != y){
    //   //       float score = 0.0;
    //   //       int currentCluster = x;
    //   //       std::vector<int> path = plannerMap->pathBetweenNodeAndCluster(originNode, y);
    //   //       int targetCluster;
    //   //       for(int z = 0; z < path.size(); z++){
    //   //         targetCluster = plannerMap->_globalClusterMap[path[z]];
    //   //         if(currentCluster == x){
    //   //           if(targetCluster != x){
    //   //             moveMatrix_[x][y] = targetCluster;
    //   //             score += nodeDistances_[currentCluster][targetCluster];
    //   //             currentCluster = targetCluster;
    //   //           //break;
    //   //           }
    //   //         }else{
    //   //           if(targetCluster != currentCluster){
    //   //             score+=nodeDistances_[currentCluster][targetCluster];
    //   //             currentCluster = targetCluster;
    //   //           }
    //   //         }
    //   //       }
    //   //       adjacencyMatrix_[x][y] = score;
    //   //     }
    //   //   }
    //   // }
    //   //std::cout << std::endl;
    //   //std::cout << "1" << std::endl;
    // }

    // void populateBoundaryMap(){
    //   boundaryMap_.clear();
    //   boundaryScores_.clear();
    //   moveData_.clear();
    //   for(int x = 0; x < clusters_.size() ; x++){
    //     int boundaryX = plannerMap_->_globalToBoundaryMap[clusters_[x]];
    //     std::vector<int> neighbours;
    //     std::vector<float> neighbourScores;
    //     for(int y = 0; y < clusters_.size(); y++){
    //       if(x!=y){
    //         int boundaryY = plannerMap_->_globalToBoundaryMap[clusters_[y]];
    //         std::pair<int, int> boundaryPair;
    //         if(boundaryX < boundaryY){
    //           boundaryPair = std::pair<int,int>(boundaryX,boundaryY);
    //         }else{
    //           boundaryPair = std::pair<int,int>(boundaryY,boundaryX);
    //         }
    //         std::pair<float, std::vector<int>> pathPair = plannerMap_->_boundaryPaths[boundaryPair];
    //         std::vector<int> path = pathPair.second;
    //         float score = pathPair.first;
    //         if(plannerMap_->_globalClusterMap[clusters_[x]] == plannerMap_->_globalClusterMap[clusters_[y]]){
    //             neighbours.push_back(y);
    //             neighbourScores.push_back(score);
    //         }else{
    //           if(path.size()<=0){
    //             //If the size of the path between the boundary points is == 0, then these points are visible to each other across boundary borders
    //             neighbours.push_back(y);
    //             neighbourScores.push_back(score);
    //             //std::cout << score << std::endl;
    //           }
    //         }
    //       }
    //     }
    //     moveData_.push_back(neighbours.size());
    //     boundaryMap_.push_back(neighbours);
    //     boundaryScores_.push_back(neighbourScores);
    //   }
    //   int maxConns = 0;
    //   for(int x = 0; x < boundaryMap_.size(); x++){
    //     if(boundaryMap_[x].size()>maxConns){
    //       maxConns = boundaryMap_[x].size();
    //     }
    //   }
    //   maxConnections_ = maxConns;
    //   maxMovePenalty_ = 0.0;

    //   for(int x = 0; x < boundaryScores_.size(); x++){
    //     for(int y = 0; y < boundaryScores_[x].size(); y++){
    //       if(maxMovePenalty_ < boundaryScores_[x][y]){
    //         maxMovePenalty_ = boundaryScores_[x][y];
    //         std::cout << maxMovePenalty_ << std::endl;
    //       }
    //     }
    //   }
    // }


    // void generateBoundaryToClusterPaths(){
    //   //This gets the shortest path between all boundary points and each cluster
    //   //boundaryToClusterPaths_.resize(nclusters_, std::vector<int>(nClusters_));
    //   boundaryToClusterPaths_.clear();
    //   for(int clusterID = 0; clusterID < plannerMap_->_clusterBoundaryPoints.size(); clusterID++){
    //     for(int boundary = 0; boundary < plannerMap_->_clusterBoundaryPoints[clusterID].size(); boundary++){
    //       int cluster = plannerMap_->_clusterBoundaryPoints[clusterID][boundary];
    //       for(int targetCluster = 0; targetCluster < plannerMap_->_clusterBoundaryPoints.size(); targetCluster++){
    //         if(clusterID != targetCluster){
    //           std::vector<int> path = plannerMap_->pathBetweenNodeAndCluster(cluster, targetCluster);
    //           std::vector<float> scorePath;
    //           int initialNode = path[0];
    //           for(int x = 1; x < path.size(); x++){
    //             int targetNode = path[x];
    //             float score = plannerMap_->getShortestPathAndScore(initialNode, targetNode).first;
    //             scorePath.push_back(score);
    //             initialNode = path[x];
    //           }
    //           std::pair<std::vector<int>, std::vector<float>> pathPair = std::pair<std::vector<int>, std::vector<float>>(path, scorePath);
    //           std::pair<int, int> nodeClusterPair = std::pair<int, int>(cluster, targetCluster);
    //           boundaryToClusterPaths_.insert(std::pair<std::pair<int, int>, std::pair<std::vector<int>, std::vector<float>>>(nodeClusterPair, pathPair));
    //         }
    //       }
    //     }
    //   }
    // }
    // void generateQVals(float discountFactor){
    //   //This function generates the optimal and default QValues for the boundary search problem
    //   //Initialise the QValMatrices
    //   //defaultQValMatrix_.resize(nclusters_, std::vector<float>(nClusters_));
    //   //optimalQValMatrix_.resize(nclusters_, std::vector<float>(nClusters_));
    //   discountFactor_ = discountFactor;
    //   for ( const auto &entry : boundaryToClusterPaths_)
    //   {
    //     //
    //     int globalBoundaryIndex = entry.first.first;
    //     int clusterID = entry.first.second;
    //     std::vector<int> boundaryPath = entry.second.first;
    //     std::vector<float> scorePath = entry.second.second;
    //     float qval = 0.0;
    //     int step = 1;
    //     for(int x = 0; x < scorePath.size(); x++){
    //       qval += scorePath[x]*(std::pow(discountFactor, step));
    //       step++;
    //     }
    //     qval = qval/discountFactor;
    //     qval += clusterSearchReward_*std::pow(discountFactor,step);
    //     std::pair<int, int> boundaryClusterPair = std::pair<int, int>(globalBoundaryIndex, clusterID);
    //     optimalQValMap_.insert(std::pair<std::pair<int,int>, float>(boundaryClusterPair, qval));

    //     qval = 0.0;
    //     step = 1;
    //     for(int x = 0; x < scorePath.size(); x++){
    //       qval += scorePath[x]*(std::pow(discountFactor, step));
    //       step++;
    //       qval += scorePath[x]*(std::pow(discountFactor, step));
    //       step++;
    //     }
    //     qval = qval/discountFactor;
    //     qval += clusterSearchReward_*std::pow(discountFactor,step);
    //     defaultQValMap_.insert(std::pair<std::pair<int, int>, float>(boundaryClusterPair, qval));
    //   }
    // }


    // double getDefaultQVal(int robotCluster, int opponentCluster){
    //   //Fetches the qval from the default Q Val matrix
    //   int globalcluster = clusters_[robotCluster];
    //   std::pair<int, int> boundaryClusterPair = std::pair<int, int>(globalcluster, opponentCluster);
    //   if(defaultQValMap_.count(boundaryClusterPair)>0){
    //     return defaultQValMap_[boundaryClusterPair];
    //   }else{
    //     return clusterSearchReward_*discountFactor_;
    //   }
    // }
    // double getOptimalQVal(int robotCluster, int opponentCluster){
    //   //Fetches the qval from the optimal Q Val matrix
    //   int globalcluster = clusters_[robotCluster];
    //   std::pair<int, int> boundaryClusterPair = std::pair<int, int>(globalcluster, opponentCluster);
    //   if(optimalQValMap_.count(boundaryClusterPair)>0){
    //     return optimalQValMap_[boundaryClusterPair];
    //   }else{
    //     return clusterSearchReward_*discountFactor_;
    //   }
    // }




    //int getOpponentMovedPos(int cluster, int action){
    //NOT IMPLEMENTED YET THIS IS FOR MOVING OPPONENT
    //}

    // int getBoundaryCluster(int cluster){
    //   //return the cluster that the boundary node belongs to.
    //   int globalcluster = clusters_[cluster];
    //   return plannerMap_->_globalClusterMap[globalcluster];
    // }

    // std::pair<float, bool> getTransitDistance(int cluster, int action){
    //   if(action > boundaryScores_[cluster].size() || action == 0){
    //     return std::pair<float, bool>(0.0, false);
    //   }else{
    //     float returnScore = boundaryScores_[cluster][action-1];
    //     return std::pair<float, bool>(returnScore, true);
    //   }
    // }

    // double getTransitSteps(int cluster, int cluster){
    //   //for ( const auto &entry : boundaryToClusterPaths_)
    //   //{
    //     //
    //     if(cluster >= 0 && cluster < nclusters_ && cluster >=0 && cluster < nClusters_){
    //       if(cluster != plannerMap_->_globalClusterMap[clusters_[cluster]]){
    //       //std::cout << (double)(boundaryToClusterPaths_[std::pair<int,int>(clusters_[cluster],cluster)].first.size()) << std::endl;
    //         return (double)(boundaryToClusterPaths_[std::pair<int,int>(clusters_[cluster],cluster)].first.size());
    //       }else{
    //         return 1.0;
    //       }
    //     }else{
    //       return 1.0;
    //     }

      //
      // int globalBoundaryIndex = clusters_[cluster];
      // int clusterID = cluster;
      // std::pair<int, int> mapPair = std::pair<int, int>(globalBoundaryIndex, clusterID);
      // std::pair<std::vector<int>, std::vector<float>> result = boundaryToClusterPaths_[mapPair];
      // std::vector<int> boundaryPath = result.first;
      // std::vector<float> scorePath = result.second;
    //}

    
};
    } /* namespace multisearch */
  }
}
#endif /* NANOMAP_PLANNER_GRAPHSEARCHSTEP_GRAPHSEARCHSTEPPROBLEMDEFINITION_HPP_ */
