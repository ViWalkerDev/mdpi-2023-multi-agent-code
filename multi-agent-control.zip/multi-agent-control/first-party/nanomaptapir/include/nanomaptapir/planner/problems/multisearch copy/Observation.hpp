/** @file Observation.hpp
 *
 * Defines the Observation class, which represents an observation in the  POMDP.
 */
#ifndef MULTISEARCH_OBSERVATION_HPP_
#define MULTISEARCH_OBSERVATION_HPP_

#include <cstddef>                      // for size_t

#include <ostream>                      // for ostream
#include <vector>                       // for vector

#include "tapirsolver/global.hpp"                     // for RandomGenerator

//#include "tapirsolver/problems/shared/GridPosition.hpp"
#include "tapirsolver/solver/abstract-problem/DiscretizedPoint.hpp"
#include "tapirsolver/solver/abstract-problem/Observation.hpp"
namespace nanomaptapir{
  namespace planner{
    namespace multisearch{
class Model;

/** A class representing an observation in the  POMDP.
 *
 * This includes an observation of the robot's own position, and a boolean flag representing
 * whether or not the robot sees the opponent (and hence is on the same grid square).
 */
class Observation : public solver::Point {
    friend class TextSerializer;
  public:
    /** Constructs a new Observation for the given robot position; seesOpponent should be true
     * iff the robot sees the opponent due to being on the same square.
     */
    //Observation(GridPosition myPosition, bool seesOpponent = false);
    //Observation(bool seesOpponent = false);
    Observation(int agentTurn, int agentBoundary, std::vector<int> agentClusters, 
                std::vector<int> agentActions_, std::vector<bool> foundStatus_, 
                std::vector<bool> searchStatus);

    virtual ~Observation() = default;
    _NO_COPY_OR_MOVE(Observation);

    std::unique_ptr<solver::Observation> copy() const override;
    double distanceTo(solver::Observation const &otherObs) const override;
    bool equals(solver::Observation const &otherObs) const override;
    std::size_t hash() const override;
    void print(std::ostream &os) const override;

    /** Returns the position the robot has observed itself in. */
    //GridPosition getPosition() const;
    /** Returns true iff the robot sees the opponent in the same square it is in. */
    std::vector<bool> foundStatus() const {return foundStatus_;}
    //Agents broadcast their current action
    std::vector<int> agentActions() const {return agentActions_;}
    //
    std::vector<bool> searchStatus() const {return searchStatus_;}
    
    std::vector<int> agentClusters() const {return agentClusters_;}
    //We need to constantly observe the boundary of the agent
    int agentBoundary() const {return agentBoundary_;}
    int agentTurn() const {return agentTurn_;}
    // int clusterBoundary() const;
    // int robotCluster() const;

  private:
  //Can only be true for an agent if they complete a search in a cluster
  int agentTurn_;
  int agentBoundary_; 
  std::vector<bool> foundStatus_;
  std::vector<bool> searchStatus_;
  std::vector<int> agentActions_;
  std::vector<int> agentClusters_;
    /** The position the robot sees itself in. */
    //GridPosition position_;
    /** True iff the robot sees the opponent in the same square it is in. */

    // int robotCluster_;
    // int clusterBoundary_;
};
} /* namespace singleSearch */
}
}
#endif /* GRAPHSEARCHSTEP_OBSERVATION_HPP_ */
