/** @file State.hpp
 *
 * Defines the State class, which represents a state of the  problem.
 */
#ifndef MULTISEARCH_STATE_HPP_
#define MULTISEARCH_STATE_HPP_

#include <cstddef>                      // for size_t

#include <memory>
#include <ostream>                      // for ostream
#include <vector>

#include "tapirsolver/solver/abstract-problem/State.hpp"
#include "tapirsolver/solver/abstract-problem/VectorState.hpp"
namespace nanomaptapir{
namespace planner{
namespace multisearch{
/** A class representing a state in the  POMDP.
 *
 * The state contains the positions of the robot and the opponent, the past position of the robot, and the past action, as well as a boolean flag for
 * whether or not the opponent has been singleSearchged; singleSearchged => terminal state.
 *
 * This class also implements solver::VectorState in order to allow the state to be easily
 * converted to a vector<double>, which can then be used inside the standard R*-tree implementation
 * of StateIndex to allow spatial lookup of states.
 */
class State : public solver::VectorState {
    friend class TextSerializer;
  public:
    /** Constructs a new State with the given positions of the robot and opponent, and the
     * given singleSearchged state.
     */
    State(int agentTurn, int agentBoundary, std::vector<int> agentClusters, std::vector<int> agentActions, 
            std::vector<int> opponentClusters, std::vector<bool> foundStatus, std::vector<bool> searchStatus);

    virtual ~State() = default;
    /** A copy constructor, for convenience. */
    State(State const &);
    /** The move constructor for State is forbidden. */
    //State(State &&) = delete;
    /** The copy assignment operator for State is forbidden. */
    //virtual State &operator=(State const &) = delete;
    /** The move assignment operator for State is forbidden. */
    //virtual State &operator=(State &&) = delete;

    std::unique_ptr<solver::State> copy() const override;

    double distanceTo(solver::State const &otherState) const override;
    bool equals(solver::State const &otherState) const override;
    std::size_t hash() const;

    std::vector<double> asVector() const override;
    void print(std::ostream &os) const override;

    /** Returns the agent clusters. */
    int getAgentTurn() const;
    std::vector<int> getAgentClusters() const;
    int getAgentBoundary() const;
    /** Returns the position of the opponents. */
    std::vector<int> getOpponentClusters() const;
    //returns the current actions for each agent as completion order for the actions between
    //agents is not deterministic
    std::vector<int> getAgentActions() const;
    /** element is true iff the opponent has been seen. */
    //bool isSearched() const;
    std::vector<bool> getFoundStatus() const;
    std::vector<bool> getSearchStatus() const;
  private:
    /** The current Cluster of the robot in the grid. */
    int agentTurn_;
    int agentBoundary_;
    std::vector<int> agentClusters_;
    std::vector<int> agentActions_;
    /** The position of the opponent in the grid. */
    std::vector<int> opponentClusters_;
    /** A flag that is true iff the opponent has been found. */
    //bool isSearched_;

    std::vector<bool> foundStatus_;
    std::vector<bool> searchStatus_;
    //int currentAction_;
};
    } /* namespace singleSearch */
  }
}
// We define a hash function directly in the std namespace.
namespace std {
/** A struct in the std namespace to define a standard hash function for the State class. */
template<> struct hash<nanomaptapir::planner::multisearch::State> {
    /** Returns the hash value for the given State. */
    std::size_t operator()(nanomaptapir::planner::multisearch::State const &state) const {
        return state.hash();
    }
};
} /* namespace std */
#endif /* GRAPHSEARCHSTEPSTATE_HPP_ */
