/** @file TextSerializer.hpp
 *
 * Contains text-based serialization methods for the core classes implementing , that is:
 * Change, State, Action, and Observation.
 */
#ifndef MULTISEARCH_TEXTSERIALIZER_HPP_
#define MULTISEARCH_TEXTSERIALIZER_HPP_

#include <iosfwd>                       // for istream, ostream
#include <memory>                       // for unique_ptr

#include "tapirsolver/global.hpp"

#include "tapirsolver/solver/abstract-problem/Action.hpp"
#include "tapirsolver/solver/abstract-problem/ModelChange.hpp"
#include "tapirsolver/solver/abstract-problem/Observation.hpp"
#include "tapirsolver/solver/abstract-problem/State.hpp"

#include "tapirsolver/solver/mappings/actions/enumerated_actions.hpp"
#include "tapirsolver/solver/mappings/observations/discrete_observations.hpp"

#include "tapirsolver/solver/serialization/TextSerializer.hpp"    // for TextSerializer


namespace solver {
class Solver;
}  /* namespace solver */
namespace nanomaptapir{
  namespace planner{
    namespace multisearch{

/** A simple method to serialize a vector of longs to an output stream. */
void saveVector(std::vector<long> values, std::ostream &os);
/** A simple method to de-serialize a vector of longs from an input stream. */
std::vector<long> loadVector(std::istream &is);

/** A serialization class for the  problem.
 *
 * This contains serialization methods for Change, State, Action, and Observation;
 * this class also inherits from solver::EnumeratedActionTextSerializer in order to serialize
 * the action mappings, and from solver::DiscreteObservationTextSerializer in order to serialize
 * the observation mappings.
 */
class TextSerializer: virtual public solver::TextSerializer,
        virtual public solver::EnumeratedActionTextSerializer,
        virtual public solver::DiscreteObservationTextSerializer {
  public:
    /** Creates a new TextSerializer instance, associated with the given solver. */
    TextSerializer(solver::Solver *solver);

    virtual ~TextSerializer() = default;
    _NO_COPY_OR_MOVE(TextSerializer);

    /* ------------------ Saving change sequences -------------------- */
    virtual void saveModelChange(solver::ModelChange const &change, std::ostream &os) override;
    virtual std::unique_ptr<solver::ModelChange> loadModelChange(std::istream &is) override;


    void saveState(solver::State const *state, std::ostream &os) override;
    std::unique_ptr<solver::State> loadState(std::istream &is) override;

    void saveObservation(solver::Observation const *obs,
            std::ostream &os) override;
    std::unique_ptr<solver::Observation> loadObservation(
            std::istream &is) override;

    void saveAction(solver::Action const *action, std::ostream &os) override;
    std::unique_ptr<solver::Action> loadAction(std::istream &is) override;


    virtual int getActionColumnWidth() override;
    virtual int getTPColumnWidth() override;
    virtual int getObservationColumnWidth() override;
};
} /* namespace singleSearch */
}
}
#endif /* GRAPHSEARCHSTEPTEXTSERIALIZER_HPP_ */
