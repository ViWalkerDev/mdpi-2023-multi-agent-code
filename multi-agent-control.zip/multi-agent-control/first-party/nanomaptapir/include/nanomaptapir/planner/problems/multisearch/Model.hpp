/** @file Model.hpp
 *
 * Contains Model, which implements the core Model interface for the  POMDP.
 */
#ifndef MULTISEARCH_MODEL_HPP_
#define MULTISEARCH_MODEL_HPP_

#include <memory>                       // for unique_ptr
#include <ostream>                      // for ostream
#include <string>                       // for string
#include <utility>                      // for pair
#include <vector>                       // for vector

#include "tapirsolver/global.hpp"                     // for RandomGenerator

#include "tapirsolver/problems/shared/GridPosition.hpp"  // for GridPosition
#include "tapirsolver/problems/shared/ModelWithProgramOptions.hpp"  // for ModelWithProgramOptions

#include "tapirsolver/solver/abstract-problem/Model.hpp"             // for Model::StepResult, Model
#include "tapirsolver/solver/abstract-problem/ModelChange.hpp"             // for ModelChange
#include "tapirsolver/solver/abstract-problem/TransitionParameters.hpp"
#include "tapirsolver/solver/abstract-problem/Action.hpp"            // for Action
#include "tapirsolver/solver/abstract-problem/Observation.hpp"       // for Observation
#include "tapirsolver/solver/abstract-problem/State.hpp"

#include "tapirsolver/solver/mappings/actions/enumerated_actions.hpp"
#include "tapirsolver/solver/mappings/observations/discrete_observations.hpp"

#include "nanomaptapir/planner/problems/multisearch/Action.hpp"
#include "nanomaptapir/planner/problems/multisearch/Options.hpp"
#include "nanomaptapir/planner/problems/multisearch/Definition.hpp"
#include "nanomaptapir/planner/problems/multisearch/smart_history.hpp"
//#include "nanomap/planner/problems/multiSearch/Definition.hpp"

namespace solver {
class StatePool;
} /* namespace solver */

/** A namespace to hold the various classes used for the  POMDP model. */
namespace nanomaptapir{
  namespace planner{
    namespace multisearch{
class Obervation;
class State;
class Model;

/** Represents a change in the  model. */
struct Change : public solver::ModelChange {
    /** The change type for this change - this should be one of:
     * - "Change Graph Connection" - to edit distances between two nodes within  problem.
     */
     //NOT YET IMPLEMENTED
};

/** A parser for a simple upper bound heuristic for .
 *
 * The actual function is defined in Model::getUpperBoundHeuristicValue; this parser allows
 * that heuristic to be selected by using the string "upper()" in the configuration file.
 */
class UBParser : public shared::Parser<solver::HeuristicFunction> {
public:
    /** Creates a new UBParser associated with the given Model instance. */
    UBParser(Model *model);
    virtual ~UBParser() = default;
    _NO_COPY_OR_MOVE(UBParser);

    virtual solver::HeuristicFunction parse(solver::Solver *solver, std::vector<std::string> args);

private:
    /** The Model instance this heuristic parser is associated with. */
    Model *model_;
};

/** The implementation of the Model interface for the  POMDP.
 *
 * See this paper http://www.cs.cmu.edu/~ggordon/jpineau-ggordon-thrun.ijcai03.pdf
 * for a description of the  problem.
 *
 * This class inherits from shared::ModelWithProgramOptions in order to use custom text-parsing
 * functionality to select many of the core ABT parameters, allowing the configuration options
 * to be changed easily via the configuration interface without having to recompile the code.
 */
class Model: public shared::ModelWithProgramOptions {
    friend class Observation;
    //friend class MdpSolver;

  public:
    /** Constructs a new Model instance with the given random number engine, and the given set
     * of configuration options.
     */
    Model(RandomGenerator *randGen, std::unique_ptr<Options> options, std::shared_ptr<Definition> definition);

    ~Model() = default;
    _NO_COPY_OR_MOVE(Model);

    /******************** Added by Josh **************************/

    /** Get 2D vector representing the current environment graph */
    // inline const std::vector<std::vector<float>>& getEnvMap() {
    //     return nodeDistances_;
    // }

    /**
     * Returns proportion of belief particles about the target's
     * position for each grid position in the map
     */
    std::vector<std::vector<float>> getAgentBeliefProportions(solver::BeliefNode const *belief);
    std::vector<std::vector<float>> getBeliefProportions(solver::BeliefNode const *belief);
    /************************************************************/
    /** Generates a new opponent position based on the current positions of the robot and the
     * opponent.
     */
    // GridPosition sampleNextOpponentPosition(GridPosition const &robotPos,
    //         GridPosition const &opponentPos);

    /* ---------- Custom getters for extra functionality  ---------- */
    /** Returns the number of rows in the map for this Model instance. */
    int getClusterCount() const {
        return nClusters_;
    }
    int getAgentId() const {
        return agentId_;
    }
    int agentId() const {
        return agentId_;
    }

    int getNeighbourCount(int cluster){
        return definition_->getNeighbourCount(cluster);
    }
//     std::vector<int> getMoveData(){
//       return definition_->getMoveData();
//     }
    // /** Returns the number of columns in the map for this Model instance. */
    // long getNCols() const {
    //     return nCols_;
    // }
    //
    // /** Initializes a MdpSolver for this Model, which can then be used to return heuristic
    //  * values for each state.
    //  */
    // void makeMdpSolver() {
    //     mdpSolver_ = std::make_unique<MdpSolver>(this);
    //     mdpSolver_->solve();
    // }
    //
    // /** Returns the MdpSolver solver (if any) owned by this model. */
    // MdpSolver *getMdpSolver() {
    //     return mdpSolver_.get();
    // }

    /** Returns the distance within the map between the two given positions. */
    std::pair<float, bool> getTransitDistance(int node, int action);
    int getSearchCost(int node);

    /* --------------- The model interface proper ----------------- */
    std::unique_ptr<solver::State> sampleAnInitState() override;
    std::unique_ptr<solver::State> sampleStateUninformed() override;
    std::unique_ptr<solver::State> sampleStateInformed(std::vector<int> agentClusters,std::vector<std::vector<bool>> searchStatus, std::vector<int> oppNode,  std::vector<bool> found);
    std::unique_ptr<solver::State> sampleStateKnownRobotNode(std::vector<int> agentClusters);
    int randomEmptyBoundaryNode();
    int randomEmptyCluster();
    int randomEmptyInitCluster();
    int randomUnsearchedCluster(std::set<int> searchedClusters);
    //void sampleInitialStates();
    bool isTerminal(solver::State const &state) override;
    bool isValid(solver::State const &state) override;
    bool isRobotValid(int const & position);
    bool isOpponentValid(int const & position);
    std::pair<int, bool> sampleRobotMovedNode(int robotBoundaryNode, int action);
    //bool sampleSearchedOutcome();
    std::pair<int, bool> getRobotMovedNode(int robotBoundaryNode, int action);
    /* -------------------- Black box dynamics ---------------------- */
    virtual std::unique_ptr<solver::State> generateNextState(
            solver::State const &state,
            solver::Action const &action,
            solver::TransitionParameters const */*tp*/) override;
    virtual std::unique_ptr<solver::Observation> generateObservation(
            solver::State const */*state*/,
            solver::Action const &action,
            solver::TransitionParameters const */*tp*/,
            solver::State const &nextState) override;
    virtual double generateReward(
                solver::State const &state,
                solver::Action const &action,
                solver::TransitionParameters const */*tp*/,
                solver::State const */*nextState*/) override;
    virtual Model::StepResult generateStep(solver::State const &state,
            solver::Action const &action) override;


    /* -------------- Methods for handling model changes ---------------- */
    virtual void applyChanges(std::vector<std::unique_ptr<solver::ModelChange>> const &changes,
             solver::Solver *solver) override;


    /* ------------ Methods for handling particle depletion -------------- */
    /** Generates particles for  using a particle filter from the previous belief.
      *
      * For each previous particle, possible next states are calculated based on consistency with
      * the given action and observation. These next states are then added to the output vector
      * in accordance with their probability of having been generated.
      */
    virtual std::vector<std::unique_ptr<solver::State>> generateParticles(
            solver::BeliefNode *previousBelief,
            solver::Action const &action,
            solver::Observation const &obs,
            long nParticles,
            std::vector<solver::State const *> const &previousParticles) override;

    /** Generates particles for  according to an uninformed prior.
     *
     * Previous states are sampled uniformly at random, a single step is generated, and only states
     * consistent with the action and observation are kept.
     */
    virtual std::vector<std::unique_ptr<solver::State>> generateParticles(
            solver::BeliefNode *previousBelief,
            solver::Action const &action,
            solver::Observation const &obs,
            long nParticles) override;


    /* --------------- Pretty printing methods ----------------- */
    /** Prints a single cell of the map out to the given output stream. */
    virtual void dispCell(std::ostream &os);
    virtual void drawEnv(std::ostream &os) override;
    virtual void drawSimulationState(solver::BeliefNode const *belief,
            solver::State const &state,
            std::ostream &os) override;


    /* ---------------------- Basic customizations  ---------------------- */
    virtual double getDefaultHeuristicValue(solver::HistoryEntry const *entry,
                solver::State const *state, solver::HistoricalData const *data) override;

    /** Returns an upper bound heuristic value for the given state.
     *
     * This upper bound assumes that the opponent will not move, and hence the heuristic value
     * simply calculates the discounted total reward, including the cost of moving one square at a
     * time until the robot reaches the opponent's current square, and then the reward for multiSearchging
     * the opponent at that time.
     */
     // /** Returns a random action */
     // std::unique_ptr<RockSampleAction> getRandomAction();
     //
     // /** Returns a random action from one of the given bins. */
     std::unique_ptr<Action> getRandomAction(std::vector<long> binNumbers);
    virtual double getUpperBoundHeuristicValue(solver::State const &state);

    virtual std::unique_ptr<solver::Action> getRolloutAction(solver::HistoryEntry const *entry,
            solver::State const *state, solver::HistoricalData const *data) override;

    /* ------- Customization of more complex solver functionality  --------- */
    /** Returns all of the actions available for the  POMDP, in the order of their enumeration
     * (as specified by multiSearch::ActionType).
     */
    virtual std::vector<std::unique_ptr<solver::DiscretizedPoint>> getAllActionsInOrder();
    virtual std::unique_ptr<solver::ActionPool> createActionPool(solver::Solver *solver) override;
    virtual std::unique_ptr<solver::HistoricalData> createRootHistoricalData() override;

    virtual std::unique_ptr<solver::Serializer> createSerializer(solver::Solver *solver) override;

  private:
    /** Initialises the required data structures and variables for this model. */
    void initialize();

    /** Generates a next state for the given state and action, as well as a boolean flag that will
     * be true if the action moved into a wall, and false otherwise.
     *
     * Moving into a wall in  simply means nothing happens - there is no associated penalty;
     * as such, this flag is mostly not used in the  problem.
     */
    std::pair<std::unique_ptr<State>, bool> makeNextState(
            solver::State const &state, solver::Action const &action);

    /** Generates an observation given the resulting next state, after the  robot has made its
     * action.
     */
    std::unique_ptr<solver::Observation> makeObservation(State const &nextState);

    // /** Generates a distribution of possible actions the opponent may choose to take, based on the
    //  * current position of the robot and the opponent.
    //  *
    //  * This distribution is represented by a vector of four elements, because the opponent's
    //  * actions are always evenly distributed between four possibilities (some of which can be the
    //  * same).
    //  */
    // std::vector<ActionType> makeOpponentActions(GridPosition const &robotPos,
    //         GridPosition const &opponentPos);
    // //
    // /** Generates a proper distribution for the possible positions the opponent could be in
    //  * after the current state.
    //  */
    // std::unordered_map<GridPosition, double> getNextOpponentPositionDistribution(
    //         GridPosition const &robotPos, GridPosition const &opponentPos);

    /** The Options instance associated with this model. */
    Options *options_;
    std::shared_ptr<Definition> definition_;

    //Move Cost is calculated as a factor of distance and the current occupancy of nodes

    /** The reward for successfully multiSearchging the opponent. */
    float clusterSearchReward_;
    float clusterSearchScale_;
    float clusterMoveScale_;
    float clusterClashCost_;
    float clusterWaitCost_;
    float stepCost_;
    float maxMovePenalty_;
    /** The number of possible actions in the  POMDP. */
    int nActions_;
    int agentId_;
    int nAgents_;
    int nTargets_;
    int nClusters_;
    //int maxNodeOccupancy_;
    //int maxNode_;
    int totalClusterOccupancy_;
    int currentInitCluster_;
    bool balanceInitFinished_;

    //int particleCount_;
    //std::vector<int> initialClusterOccupancy_;
    /* The number of unsearched cells in each node */
    //std::vector<int> nodeSize_;
    std::vector<int> initialAgentClusters_;
    std::vector<float> targetParticleProportions_;
    std::vector<int> targetParticleCounts_;
    std::vector<int> currentParticleCounts_;
    //int nextParticle_;
    std::vector<int> initialOccupancy_;

};
} /* namespace multiSearch */
}
}
#endif /* BOUNDARYSEARCHMULTIMODEL_HPP_ */
