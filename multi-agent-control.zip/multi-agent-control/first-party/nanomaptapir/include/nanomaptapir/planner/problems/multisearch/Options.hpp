/** @file Options.hpp
 *
 * Defines the Options class, which specifies the configuration settings available for the
 *  problem.
 */
#ifndef MULTISEARCH_OPTIONS_HPP_
#define MULTISEARCH_OPTIONS_HPP_

#include <string>                       // for string

#include "tapirsolver/problems/shared/SharedOptions.hpp"
namespace nanomaptapir{
  namespace planner{
    namespace multisearch{
/** A class defining the configuration settings for the  problem. */
struct Options : public shared::SharedOptions {
    Options() = default;
    virtual ~Options() = default;

    /* -------- Settings specific to the  POMDP -------- */
    /** Path to the map file (relative to SharedOptions::baseConfigPath) */
    //std::string mapPath = "";
    //int initialNode_ = 0;
    //int nNodes_ = 0;
    //float maxMovePenalty_ = 0.0;
    //std::vector<int> initialOccupancy_;
    //std::vector<int> maxOccupancy_;
    //std::vector<std::vector<float>> nodeDistances_;
    //double multiSearchReward_ = 0.0;
    /** Cost per move. */
    //double moveCost = 0.0;
    /** Reward for multiSearchging. */
    /** Penalty for a failed multiSearch attempt. */
    //double failedPenalty = 0.0;
    /** Probability the opponent will stay in place. */
    //double opponentStayProbability = 0.0;
    /** Path to vrep scene multiSearch.ttt */
    //std::string vrepScenePath = "";
    //std::shared_ptr<nanomap::planner::multisearch::Definition> problemDefinition_;
    // void setVars(std::shared_ptr<nanomap::planner::multisearch::Definition> problemDefinition){
    //   cfg_ = problemDefinition->cfgPath_;
    //   initialNode_ = problemDefinition->initialNode_;
    //   nNodes_ = problemDefinition->nNodes_;
    //   maxMovePenalty_ = problemDefinition->maxMovePenalty_;
    //   initialOccupancy_ = problemDefinition->initialOccupancy_;
    //   maxOccupancy_ = problemDefinition->maxOccupancy_;
    //   nodeDistances_ = problemDefinition->nodeDistances_;
    //   multiSearchReward_ = problemDefinition->multiSearchReward_;
    // }
    // std::string cfg_;
    // int initialNode_ = 0;
    // int nNodes_ = 0;
    // float maxMovePenalty_ = 0.0;
    double clusterSearchCost_ = 0.0;
    double clusterSearchReward_ = 0.0;
    double clusterMoveCost_ = 0.0;
    double clusterWaitCost_ = 0.0;
    double clusterClashCost_ = 0.0;
    double stepCost_ = 0.0;
    int nAgents_ = 0;
    int nTargets_ = 0;
    // std::vector<int> initialOccupancy_;
    // std::vector<int> maxOccupancy_;
    // std::vector<std::vector<float>> nodeDistances_;
    // double multiSearchReward_ = 0.0;

    // static void addRuntimeVars(int initialNode,
    //                            int nNodes,
    //                            float maxMovePenalty,
    //                            std::vector<int> initialOccupancy,
    //                            std::vector<int> maxOccupancy,
    //                            std::vector<std::vector<float>> nodeDistances,
    //                            double multiSearchReward){
    //     initialNode_ = initialNode;
    //     nNodes_ = nNodes;
    //     maxMoveCost_ = maxMoveCost;
    //     initialOccupancy_ = initialOccupancy;
    //     maxOccupancy_ = maxOccupancy;
    //     nodeDistances_ = nodeDistances;
    //     multiSearchReward_ = multiSearchReward;
    // }

    /** Constructs an OptionParser instance that will parse configuration settings for the 
     * problem into an instance of Options.
     */
    static std::unique_ptr<options::OptionParser> makeParser(bool simulating, std::string cfg) {
        std::unique_ptr<options::OptionParser> parser = SharedOptions::makeParser(simulating,
              cfg);
        addOptions(parser.get());
        return std::move(parser);
    }
    //
    /** Adds the core configuration settings for the  problem to the given parser. */
    static void addOptions(options::OptionParser *parser) {
        parser->addOption<double>("problem", "clusterMoveCost", &Options::clusterMoveCost_);
        parser->addOption<double>("problem", "clusterSearchReward", &Options::clusterSearchReward_);
        parser->addOption<double>("problem", "clusterSearchCost", &Options::clusterSearchCost_);
        parser->addOption<double>("problem", "clusterWaitCost", &Options::clusterWaitCost_);
        parser->addOption<double>("problem", "clusterClashCost", &Options::clusterClashCost_);
        parser->addOption<double>("problem", "stepCost", &Options::stepCost_);
        parser->addOption<int>("problem", "nTargets", &Options::nTargets_);
        parser->addOption<int>("problem", "nAgents", &Options::nAgents_);
        // parser->addOption<double>("problem", "opponentStayProbability",
//                &Options::opponentStayProbability);
    }

  };
} /* namespace multiSearch */
}
}
#endif /* BOUNDARYSEARCHMULTIOPTIONS_HPP_ */
