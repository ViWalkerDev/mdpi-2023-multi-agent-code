/** @file State.hpp
 *
 * Defines the State class, which represents a state of the  problem.
 */
#ifndef MULTISEARCH_STATE_HPP_
#define MULTISEARCH_STATE_HPP_

#include <cstddef>                      // for size_t

#include <memory>
#include <ostream>                      // for ostream
#include <vector>

#include "tapirsolver/solver/abstract-problem/State.hpp"
#include "tapirsolver/solver/abstract-problem/VectorState.hpp"
namespace nanomaptapir{
namespace planner{
namespace multisearch{
/** A class representing a state in the  POMDP.
 *
 * The state contains the positions of the robot and the opponent, as well as a boolean flag for
 * whether or not the opponent has been multiSearchged; multiSearchged => terminal state.
 *
 * This class also implements solver::VectorState in order to allow the state to be easily
 * converted to a vector<double>, which can then be used inside the standard R*-tree implementation
 * of StateIndex to allow spatial lookup of states.
 */
class State : public solver::VectorState {
    friend class TextSerializer;
  public:
    /** Constructs a new State with the given positions of the robot and opponent, and the
     * given multiSearchged state.
     */
    State(std::vector<int> agentClusters, std::vector<std::vector<bool>> searchStatus, std::vector<int> opponentClusters, std::vector<bool> foundStatus);

    virtual ~State() = default;
    /** A copy constructor, for convenience. */
    State(State const &);
    /** The move constructor for State is forbidden. */
    //State(State &&) = delete;
    /** The copy assignment operator for State is forbidden. */
    //virtual State &operator=(State const &) = delete;
    /** The move assignment operator for State is forbidden. */
    //virtual State &operator=(State &&) = delete;

    std::unique_ptr<solver::State> copy() const override;

    double distanceTo(solver::State const &otherState) const override;
    bool equals(solver::State const &otherState) const override;
    std::size_t hash() const;

    std::vector<double> asVector() const override;
    void print(std::ostream &os) const override;

    /** Returns the position of the robot. */
    //int getAgentPosition(int index) const;
    /** Returns the position of the robot. */
    // int getAgentAction(int index) const;

    std::vector<int> getAgentClusters() const;
    //
    // std::vector<int> getAgentActions() const;
    /** Returns the position of the opponent. */
    std::vector<int> getOpponentClusters() const;
    /** Returns true iff the opponent has already been multiSearchged. */
    std::vector<std::vector<bool>> getSearchStatus() const;
    // std::vector<bool> getSearchStatus(int index) const;
    std::vector<bool> getFoundStatus() const;
    bool isFound() const;
  private:
    /** The current Node of the robot in the grid. */
    std::vector<int> agentClusters_;
    /** The current Node of the robot in the grid. */
    // std::vector<int> agentActions;
    // /** The position of the opponent in the grid. */
    std::vector<int> opponentClusters_;
    /** A flag that is true iff the opponent has been found. */
    std::vector<std::vector<bool>> searchStatus_;

    std::vector<bool> foundStatus_;
    //int currentAction_;
};
    } /* namespace multiSearch */
  }
}
// We define a hash function directly in the std namespace.
namespace std {
/** A struct in the std namespace to define a standard hash function for the State class. */
template<> struct hash<nanomaptapir::planner::multisearch::State> {
    /** Returns the hash value for the given State. */
    std::size_t operator()(nanomaptapir::planner::multisearch::State const &state) const {
        return state.hash();
    }
};
} /* namespace std */
#endif /* BOUNDARYSEARCHMULTISTATE_HPP_ */
