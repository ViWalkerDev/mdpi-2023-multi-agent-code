/** @file Action.hpp
 *
 * Defines the Action class, which represents an action for the  problem, and also the
 * ActionType enumeration, which enumerates the different types of actions for .
 */
#ifndef SINGLESEARCH_ACTION_HPP_
#define SINGLESEARCH_ACTION_HPP_

#include <cstddef>                      // for size_t

#include <ostream>                      // for ostream
#include <vector>                       // for vector

#include "tapirsolver/solver/abstract-problem/Action.hpp"
#include "tapirsolver/solver/abstract-problem/DiscretizedPoint.hpp"             // for DiscretizedPoint
namespace nanomaptapir{
  namespace planner{
    namespace singlesearch {

//VARIABLE ACTION QTY. NUM ACTIONS = NUM ENVIRONMENT CLUSTERS
// /** An . */
// enum class ActionType : long {
//
// };

/** A class representing an action in the  POMDP.
 *
 * This class also implements solver::DiscretizedPoint so that the solver can use a simplistic
 * enumerated action mapping approach (EnumeratedActionPool) to store the available actions from
 * each belief node.
 */
class Action : public solver::DiscretizedPoint {
    friend class TextSerializer;
  public:
    /** Constructs a new action from the given ActionType. */
    //Action(ActionType actionType);
    /** Constructs a new action from the given integer code. */
    Action(int node);

    virtual ~Action() = default;
    _NO_COPY_OR_MOVE(Action);

    std::unique_ptr<solver::Action> copy() const override;
    double distanceTo(solver::Action const &otherAction) const override;
    void print(std::ostream &os) const override;

    long getBinNumber() const override;
    /** Returns the action. */
    int getAction() const;

  private:
    /** The ActionType for this action in the  POMDP. */
    //ActionType actionType_;
    int action_;
};
} /* namespace singleSearch */
}
}
#endif /* GRAPHSEARCHSTEP_ACTION_HPP_ */
