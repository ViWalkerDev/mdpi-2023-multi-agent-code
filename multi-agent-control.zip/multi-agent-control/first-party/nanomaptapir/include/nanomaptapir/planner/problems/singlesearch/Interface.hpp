/** @file TagNode.hpp
 *
 * Contains TagNode, which implements the TapirNode interface and acts as a ROS node.
 */
#ifndef SINGLESEARCH_INTERFACE_HPP_
#define SINGLESEARCH_INTERFACE_HPP_

#include <memory>                   // For unique_ptr
#include <vector>
#include <string>

#include "nanomaptapir/planner/base/Interface.hpp"

#include "nanomaptapir/planner/problems/singlesearch/Action.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Observation.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Options.hpp"
#include "nanomaptapir/planner/problems/singlesearch/State.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Model.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Definition.hpp"

namespace nanomaptapir{
	namespace planner{
		namespace singlesearch{

class Interface : public base::Interface<Options, Model, Observation,
		Action, Definition> {

public:

	Interface(){}
	~Interface(){}

	virtual void addObservation(std::vector<int> obsVector){
		observationQueue_.push_back(std::make_shared<Observation>(obsVector[0]));
	}

	// void stepThroughPolicy(){
	//
	// }
	// virtual int getPhantomAction() override {
	// 	std::unique_ptr<solver::Action> solverAction = phantomBelief_->getRecommendedAction();
	// 	Action* action = static_cast<Action *>(solverAction, solverAction.get());
	// 	return action->getAction();
	// }

};
		} /* namespace singlesearch */
	} /* namespace planner */
} /* namespace nanomap */

#endif /* GRAPHSEARCHSTEP_INTERFACE_HPP_ */
