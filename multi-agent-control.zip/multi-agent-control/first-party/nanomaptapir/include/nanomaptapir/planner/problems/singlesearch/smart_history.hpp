/** @file smart_history.hpp
 *
 * Defines a class to keep track of the position of the robot in , as well as explicitly
 * calculated probabilities for the goodness of each rock.
 */
#ifndef SINGLESEARCH_SMART_HISTORY_HPP_
#define SINGLESEARCH_SMART_HISTORY_HPP_

#include "tapirsolver/solver/abstract-problem/HistoricalData.hpp"

#include "tapirsolver/solver/serialization/TextSerializer.hpp"

#include "nanomaptapir/planner/problems/singlesearch/Action.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Observation.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Model.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Definition.hpp"
namespace nanomaptapir{
  namespace planner{
    namespace singlesearch {
class Action;
class Observation;
class Model;

/** Stores data about each rock.
 */
// struct RockData {
//     /** The number of times this rock has been checked. */
//     //long checkCount = 0;
//     /** The "goodness number"; +1 for each good observation of this rock, and -1 for each bad
//      * observation of this rock.
//      */
//     //long goodnessNumber = 0;
//     /** The calculated probability that this rock is good. */
//     //double chanceGood = 0.5;
// };

class Data : public solver::HistoricalData {
    friend class PreferredActionsMap;
    friend class DataTextSerializer;
public:
    /** Constructs a new Data instance for the given model, in the given position,
     * with default data values for each rock.
     */
    Data(Model *model, int cluster, int boundary, std::shared_ptr<Definition> definition);
    virtual ~Data() = default;

    /** We define a copy constructor for this class, for convenience. */
    Data(Data const &other);
    /** Deleted move constructor. */
    //Data(Data &&other) = delete;
    /** Deleted copy assignment operator. */
    //Data &operator=(Data const &other) = delete;
    /** Deleted move assignment operator. */
    //Data &operator=(Data &&other) = delete;

    std::unique_ptr<solver::HistoricalData> copy() const;

    std::unique_ptr<solver::HistoricalData> createChild(
            solver::Action const &action,
            solver::Observation const &observation) const override;

    /** Generates the legal actions that are available from this position. */
    std::vector<long> generateLegalActions() const;
    /** Generates a set of preferred actions, based on the knowledge stored in this
     * instance.
     */
    //std::vector<long> generatePreferredActions() const;
    void print(std::ostream &os) const override;
    int getNode() const {return cluster_;}
private:
    /** The associated model instance. */
    Model *model_;
    /** The agents cluster. */
    int cluster_;
    int boundary_;
    //Problem definition shared_ptr
    std::shared_ptr<Definition> definition_;
    /** The data for each rock, in order of rock number. */
    //std::vector<int> moveData_;
};

/** An implementation of the serialization methods for the
 * DataTextSerializer class.
 */
class DataTextSerializer : virtual public solver::TextSerializer {
public:
    void saveHistoricalData(solver::HistoricalData const *data, std::ostream &os) override;
    std::unique_ptr<solver::HistoricalData> loadHistoricalData(std::istream &is) override;
};
} /* namespace singlesearch */
}
}
#endif /* BOUNDARYSEARCH_SMART_HISTORY_HPP_ */
