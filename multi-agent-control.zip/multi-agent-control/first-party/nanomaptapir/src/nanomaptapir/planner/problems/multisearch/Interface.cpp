/** @file Interface.cpp
 *
 * Contains Interface.
 */
#include "nanomaptapir/planner/problems/multisearch/Interface.hpp"

#include <iostream>
#include <sstream>

namespace nanomaptapir{
	namespace planner {
		namespace multisearch {



		} /* namespace tag */
	}
}
