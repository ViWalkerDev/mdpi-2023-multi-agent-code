/** @file LegalActionsPool.cpp
 *
 * Contains the implementation of the mapping classes for dealing with legal actions in the
 *  problem.
 */
#include "nanomaptapir/planner/problems/multisearch/LegalActionsPool.hpp"

#include <iostream>
#include <memory>

#include "tapirsolver/solver/Solver.hpp"

#include "nanomaptapir/planner/problems/multisearch/Model.hpp"
#include "nanomaptapir/planner/problems/multisearch/smart_history.hpp"
namespace nanomaptapir{
  namespace planner{
    namespace multisearch {
LegalActionsPool::LegalActionsPool(Model *model) :
        EnumeratedActionPool(model, model->getAllActionsInOrder()),
        model_(model),
        mappings_() {
}

std::vector<long> LegalActionsPool::createBinSequence(solver::BeliefNode *node) {
    solver::HistoricalData const *data = node->getHistoricalData();
    //Model::RSActionCategory category = model_->getSearchActionCategory();
    //if (category == Model::RSActionCategory::LEGAL) {
        std::vector<long> bins = static_cast<Data const *>(data)->generateLegalActions();
        std::shuffle(bins.begin(), bins.end(), *model_->getRandomGenerator());
        return std::move(bins);
    //} else {
    //    return EnumeratedActionPool::createBinSequence(node);
    //}
}

std::unique_ptr<solver::ActionMapping> LegalActionsPool::createActionMapping(
        solver::BeliefNode *node) {
    return std::make_unique<LegalActionsMap>(node, this, createBinSequence(node));
}

void LegalActionsPool::addMapping(std::size_t dataHash, LegalActionsMap *map) {
    mappings_[dataHash].insert(map);
}

void LegalActionsPool::removeMapping(std::size_t dataHash, LegalActionsMap *map) {
    mappings_[dataHash].erase(mappings_[dataHash].find(map));
}

void LegalActionsPool::setLegal(bool isLegal, std::size_t dataHash,
        Action const &action, solver::Solver *solver) {
    for (solver::DiscretizedActionMap *discMap : mappings_[dataHash]) {
        // Only change affected belief nodes.
        if (solver == nullptr || solver->isAffected(discMap->getOwner())) {
            discMap->getEntry(action)->setLegal(isLegal);
        }
    }
}

/* ------------------- LegalActionsMap ------------------- */
LegalActionsMap::LegalActionsMap(solver::BeliefNode *owner, LegalActionsPool *pool,
        std::vector<long> binSequence) :
        solver::DiscretizedActionMap(owner, pool, binSequence) {
    Data const &data = static_cast<Data const &>(*owner->getHistoricalData());
    pool->addMapping(data.getActionHash(), this);
}

LegalActionsMap::~LegalActionsMap() {
    Data const &data = static_cast<Data const &>(*getOwner()->getHistoricalData());
    static_cast<LegalActionsPool &>(*pool_).removeMapping(data.getActionHash(), this);
}

/* ------------------- LegalActionsPoolTextSerializer ------------------- */
std::unique_ptr<solver::ActionMapping>
LegalActionsPoolTextSerializer::loadActionMapping(solver::BeliefNode *owner, std::istream &is) {
    std::unique_ptr<LegalActionsMap> map = std::make_unique<LegalActionsMap>(owner,
            static_cast<LegalActionsPool *>(getSolver()->getActionPool()),
            std::vector<long> { });
    DiscretizedActionTextSerializer::loadActionMapping(*map, is);
    return std::move(map);
}
} /* namespace multisearch */
}
}
