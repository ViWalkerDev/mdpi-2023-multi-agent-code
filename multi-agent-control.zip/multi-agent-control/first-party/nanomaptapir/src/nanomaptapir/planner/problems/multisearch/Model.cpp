/** @file Model.cpp
 *
 * Contains the implementations for the core functionality of the  POMDP.
 */
#include "nanomaptapir/planner/problems/multisearch/Model.hpp"

#include <cmath>                        // for floor, pow
#include <cstddef>                      // for size_t
#include <cstdlib>                      // for exit

#include <memory>
#include <fstream>                      // for ifstream, basic_istream, basic_istream<>::__istream_type
#include <iomanip>                      // for operator<<, setw
#include <iostream>                     // for cout
#include <random>                       // for uniform_int_distribution, bernoulli_distribution
#include <unordered_map>                // for _Node_iterator, operator!=, unordered_map<>::iterator, _Node_iterator_base, unordered_map
#include <utility>                      // for make_pair, move, pair

#include "tapirsolver/global.hpp"                     // for RandomGenerator, make_unique
//#include "tapirsolver/problems/shared/GridPosition.hpp"  // for GridPosition, operator==, operator!=, operator<<
#include "tapirsolver/problems/shared/ModelWithProgramOptions.hpp"  // for ModelWithProgramOptions

#include "tapirsolver/solver/abstract-problem/Action.hpp"            // for Action
#include "tapirsolver/solver/abstract-problem/Model.hpp"             // for Model::StepResult, Model
#include "tapirsolver/solver/abstract-problem/Observation.hpp"       // for Observation
#include "tapirsolver/solver/abstract-problem/State.hpp"             // for State, operator<<, operator==

#include "tapirsolver/solver/changes/ChangeFlags.hpp"        // for ChangeFlags

#include "tapirsolver/solver/indexing/FlaggingVisitor.hpp"
#include "tapirsolver/solver/indexing/RTree.hpp"
#include "tapirsolver/solver/indexing/SpatialIndexVisitor.hpp"             // for State, operator<<, operator==

#include "tapirsolver/solver/mappings/actions/enumerated_actions.hpp"
#include "tapirsolver/solver/mappings/observations/discrete_observations.hpp"

#include "tapirsolver/solver/ActionNode.hpp"
#include "tapirsolver/solver/BeliefNode.hpp"
#include "tapirsolver/solver/StatePool.hpp"

//PROBLEM SPECIFIC INCLUDES
#include "nanomaptapir/planner/problems/multisearch/Action.hpp"
#include "nanomaptapir/planner/problems/multisearch/Observation.hpp"
#include "nanomaptapir/planner/problems/multisearch/Options.hpp"
#include "nanomaptapir/planner/problems/multisearch/State.hpp"                 // for State
#include "nanomaptapir/planner/problems/multisearch/TextSerializer.hpp"
#include "nanomaptapir/planner/problems/multisearch/Definition.hpp"
//#include "position_history.hpp"
#include "nanomaptapir/planner/problems/multisearch/smart_history.hpp"
#include "nanomaptapir/planner/problems/multisearch/LegalActionsPool.hpp"

using std::cout;
using std::endl;
namespace nanomaptapir{
  namespace planner{
    namespace multisearch{
UBParser::UBParser(Model *model) :
        model_(model) {
}
solver::HeuristicFunction UBParser::parse(solver::Solver */*solver*/, std::vector<std::string> /*args*/) {
    return [this] (solver::HistoryEntry const *, solver::State const *state,
            solver::HistoricalData const *) {
        return model_->getUpperBoundHeuristicValue(*state);
    };
}

Model::Model(RandomGenerator *randGen, std::unique_ptr<Options> options, std::shared_ptr<Definition> definition) :
            ModelWithProgramOptions("", randGen, std::move(options)),
            options_(const_cast<Options *>(static_cast<Options const *>(getOptions()))),
            definition_(definition),
            clusterSearchReward_(options_->clusterSearchReward_),
            clusterSearchScale_(options_->clusterSearchCost_),
            clusterMoveScale_(options_->clusterMoveCost_),
            clusterClashCost_(options_->clusterClashCost_),
            clusterWaitCost_(options_->clusterWaitCost_),
            stepCost_(options_->stepCost_),
            agentId_(definition_->agentId_),
            nAgents_(options_->nAgents_),
            nTargets_(options_->nTargets_)
            {
              //
              nClusters_ = definition->nClusters_;
              definition_->setOptions(options_);
              definition_->initialiseQVals();
              initialAgentClusters_ = definition_->initialAgentClusters_;
              initialOccupancy_ = definition_->initialOccupancy_;
              options_->numberOfStateVariables = nAgents_+nAgents_*(nTargets_+1)+nTargets_*2;
              double minClash = -(definition_->clusterClashCost_)/(1 - options_->discountFactor);
              //double minMove =  -(definition_->maxMoveCost()*clusterMoveScale_)/(1 - options_->discountFactor);
              //double minSearch = -(definition_->maxSearchCost()*clusterSearchScale_)/(1 - options_->discountFactor);
              double minMove =  -(definition_->clusterMoveScale_)/(1 - options_->discountFactor);
              double minSearch = -(definition_->clusterSearchScale_)/(1 - options_->discountFactor);
              
              double minVal = DBL_MAX;
              if(minVal > minClash){
                minVal = minClash;
              }
              if(minVal > minMove){
                minVal = minMove;
              }
              if(minVal > minSearch){
                minVal = minSearch;
              }
              options_->minVal = minVal;
              options_->maxVal = clusterSearchReward_;
              nActions_ = definition_->maxConnections_+2;
              // options_->minVal = -maxMovePenalty_ / (1 - options_->discountFactor);
              // options_->maxVal = clusterSearchReward_;
              //definition_->generateQVals(options_->discountFactor);

    // Register the upper bound heuristic parser.
    registerHeuristicParser("upper", std::make_unique<UBParser>(this));
    // // Register the exact MDP heuristic parser.
    // registerHeuristicParser("exactMdp", std::make_unique<MdpParser>(this));
        cout << "nActions: " << nActions_ << endl;
    initialize();
    if (options_->hasVerboseOutput) {
        cout << "Constructed the Model" << endl;
        cout << "Discount: " << options_->discountFactor << endl;
        cout << "ClusterSize: " << nClusters_ << endl;
        cout << "nActions: " << nActions_ << endl;
        cout << "nStVars: " << options_->numberOfStateVariables << endl;
        cout << "minParticleCount: " << options_->minParticleCount << endl;
        cout << "Environment:" << endl << endl;
        //drawEnv(cout);
    }
}

// std::pair<float, bool> Model::getTransitDistance(int robotBoundaryNode, int action) {
//     return definition_->getTransitDistance(robotBoundaryNode, action);
// }

// int Model::getSearchCost(int node){
//   return maxOccupancy_[node];
// }

void Model::initialize() {
  std::cout << "initializing model" << std::endl;
  balanceInitFinished_ = false;
  // currentOccupancy_.resize(nClusters_);
  // for(int x = 0; x < nClusters_; x++){
  //   currentOccupancy_[x] = 0;
  // }
  targetParticleProportions_.resize(nClusters_);
  targetParticleCounts_.resize(nClusters_);
  currentParticleCounts_.resize(nClusters_);
  currentInitCluster_ = 0;
  // maxNodeOccupancy_ = 0;
  // for(int x = 0; x < nClusters_; x++){
  //   if(initialOccupancy_[x] > maxNodeOccupancy_){
  //     maxNodeOccupancy_ = initialOccupancy_[x];
  //   }
  // }
  totalClusterOccupancy_ = 0;
  for(int x = 0; x < nClusters_; x++){
    totalClusterOccupancy_ += initialOccupancy_[x];
    //targetParticleProportions_[x] = (float)initialOccupancy_[x]/(float)maxNodeOccupancy_;
  }
  for(int x = 0; x < nClusters_; x++){
    targetParticleProportions_[x] = (float)initialOccupancy_[x]/(float)totalClusterOccupancy_;
    targetParticleCounts_[x] = std::floor((targetParticleProportions_[x]*((float)(options_->minParticleCount))));
    currentParticleCounts_[x] = 0;
  }
  for(int x = 0; x < nClusters_; x++){
    std::cout << "targetPartCounts = " << targetParticleCounts_[x] << std::endl;
  }
  return;
}

// int Model::randomEmptyBoundaryNode() {
//     int node;
//     //while (true) {
//     node = std::uniform_int_distribution<int>(0, nBoundaryNodes_ - 1)(
//             *getRandomGenerator());
//         //if (envMap_[pos.i][pos.j] == CellType::EMPTY) {
//         //    break;
//         //}
//     //}
//     return node;
// }
int Model::randomEmptyCluster() {
    int cluster;
    //while (true) {
    cluster = std::uniform_int_distribution<int>(0, nClusters_ - 1)(
            *getRandomGenerator());
        //if (envMap_[pos.i][pos.j] == CellType::EMPTY) {
        //    break;
        //}
    //}
    return cluster;
}



int Model::randomEmptyInitCluster() {
    int cluster;
    while (true) {
    cluster = std::uniform_int_distribution<int>(0, nClusters_ - 1)(
            *getRandomGenerator());
        //if (envMap_[pos.i][pos.j] == CellType::EMPTY) {
        //    break;
        //}
        if(initialOccupancy_[cluster]>0){
          break;
        }
    }
    return cluster;
}

int Model::randomUnsearchedCluster(std::set<int> searchedClusters) {
    int cluster;
    while (true) {
    cluster = std::uniform_int_distribution<int>(0, nClusters_ - 1)(
            *getRandomGenerator());
        //if (envMap_[pos.i][pos.j] == CellType::EMPTY) {
        //    break;
        //}
        if(!(searchedClusters.find(cluster) != searchedClusters.end())){
          //cluster isn't in serached clusters, break;
          break;
        }
    }
    return cluster;
}


/* --------------- The model interface proper ----------------- */
std::unique_ptr<solver::State> Model::sampleAnInitState(){
  std::vector<int> opponentClusters;
  //opponentClusters.resize(nTargets_, -1);
  for(int x = 0; x < nTargets_; x++){
    opponentClusters.push_back(randomEmptyInitCluster());
  }
  std::vector<std::vector<bool>> searchStatus;
  for(int x = 0; x < nAgents_; x++){
    std::vector<bool> targetSearchStatus;
    targetSearchStatus.resize(nTargets_+1, false);
    searchStatus.push_back(targetSearchStatus);
  }

  std::vector<bool> foundStatus;
  foundStatus.resize(nTargets_, false);
  return sampleStateInformed(initialAgentClusters_, searchStatus, opponentClusters, foundStatus);
}


std::unique_ptr<solver::State> Model::sampleStateInformed(std::vector<int> agentClusters, std::vector<std::vector<bool>> searchStatus, std::vector<int> opponentClusters, std::vector<bool> foundStatus){
  return std::make_unique<State>(agentClusters, searchStatus, opponentClusters, foundStatus);
}
std::unique_ptr<solver::State> Model::sampleStateKnownRobotNode(std::vector<int>  agentClusters){
    //init random clusters
    std::vector<int> opponentClusters;
    //opponentClusters.resize(nTargets_, -1);
    for(int x = 0; x < nTargets_; x++){
      opponentClusters.push_back(randomEmptyCluster());
    }
    //init empty search status
    std::vector<std::vector<bool>> searchStatus;
    for(int x = 0; x < nAgents_; x++){
      std::vector<bool> targetSearchStatus;
      targetSearchStatus.resize(nTargets_+1, false);
      searchStatus.push_back(targetSearchStatus);
    }

    //init empty found status
    std::vector<bool> foundStatus;
    foundStatus.resize(nTargets_, false);
  return std::make_unique<State>(agentClusters, searchStatus, opponentClusters, foundStatus);
}

std::unique_ptr<solver::State> Model::sampleStateUninformed() {
    //init random agent clusters
    std::vector<int> agentClusters;
    for(int x = 0;x < nAgents_; x++){
      agentClusters.push_back(randomEmptyCluster());
    }
    //init empty search status
    std::vector<std::vector<bool>> searchStatus;
    for(int x = 0; x < nAgents_; x++){
      std::vector<bool> targetSearchStatus;
      targetSearchStatus.resize(nTargets_+1, false);
      searchStatus.push_back(targetSearchStatus);
    }
    std::vector<bool> foundStatus;
    foundStatus.resize(nTargets_, false);
    // for(int x = 0; x < nAgents_; x++){
    //   agentClusters.push_back(randomEmptyCluster());
    // }
    std::vector<int> opponentClusters;
    //opponentClusters.resize(nTargets_, -1);
    for(int x = 0; x < nTargets_; x++){
      opponentClusters.push_back(randomEmptyCluster());
    }
    return std::make_unique<State>(agentClusters, searchStatus, opponentClusters, foundStatus);
}

bool Model::isTerminal(solver::State const &state) {
    return static_cast<State const &>(state).isFound();
}

bool Model::isValid(solver::State const &state) {
    State const multiSearchState = static_cast<State const &>(state);
  for(int x = 0; x < nAgents_; x++){
    if(!(definition_->isOpponentValid(multiSearchState.getAgentClusters()[x]))){
      return false;
    }
  }
  for(int x = 0; x < nTargets_; x++){
    if(!definition_->isOpponentValid(multiSearchState.getOpponentClusters()[x])){
      return false;
    }
  }
    return true;
}


/* -------------------- Black box dynamics ---------------------- */
std::pair<std::unique_ptr<State>, bool> Model::makeNextState(
        solver::State const &state, solver::Action const &action) {
    State const &searchState = static_cast<State const &>(state);
    if (isTerminal(searchState)) {
        return std::make_pair(std::make_unique<State>(searchState), false);
    }

    Action const &searchAction = static_cast<Action const &>(action);
    int actionInt = searchAction.getAction();
    std::vector<int> agentClusters = searchState.getAgentClusters();
    std::vector<std::vector<bool>> searchStatus = searchState.getSearchStatus();
    std::vector<std::vector<bool>> newSearchStatus;
    for(int x = 0; x < nAgents_; x++){
      std::vector<bool> agentSearchStatus;
      agentSearchStatus.resize(nTargets_+1, false);
      newSearchStatus.push_back(agentSearchStatus);
    }
    // int agentBoundary = searchState.getAgentBoundary();
    std::vector<bool> foundStatus = searchState.getFoundStatus();
    std::vector<int> opponentClusters = searchState.getOpponentClusters();
    bool isValid;
//    int newRobotNode = multiSearchAction.getAction();
    //Handle main agent actions
    //whatever action we pick, there is it isn't completed in time. This chance is inversely proportional to the number of agents. 
    double actionChance = 1.0/(double)nAgents_;
    if(std::bernoulli_distribution(actionChance)(*getRandomGenerator())){
      if(actionInt == 0){
        newSearchStatus[agentId_][0] = true;
        int opponentIndex = 0;
        for(int opponentCluster : opponentClusters){
          if(agentClusters[agentId_] == opponentCluster){
            newSearchStatus[agentId_][opponentIndex+1] = true;
            foundStatus[opponentIndex] = true;
          }
          opponentIndex++;
        }
      }else if(actionInt > 1){
        //agent is moving.
          //agent moved
          
        int destCluster;
        int destBoundary;
        std::tie(destCluster, destBoundary) = definition_->getRobotMovedCluster(agentClusters[agentId_], 0, actionInt).first;
        agentClusters[agentId_] = destCluster;
      }
    }
        

    //iterate over other agents. have them randomly perform actions.
    for(int x = 0; x < nAgents_; x++){
        if(x != agentId_){
          int numActions = definition_->getNeighbourCount(agentClusters[x]);
          int otherActionInt;
          if(searchStatus[x][0]==false){
            otherActionInt = std::uniform_int_distribution<long>(0, numActions+1)(*getRandomGenerator());
          }else{
            //They just performed a search, so they won't pick that action again. 
            otherActionInt = std::uniform_int_distribution<long>(1, numActions+1)(*getRandomGenerator());
          }
          if(std::bernoulli_distribution(actionChance)(*getRandomGenerator())){
            //the other agent performed the action it 'selected'! otherwise it fails to perform an action.
            if(otherActionInt == 0){
              newSearchStatus[x][0] = true;
              int opponentIndex = 0;
              for(int opponentCluster : opponentClusters){
                if(agentClusters[x] == opponentCluster){
                  newSearchStatus[x][opponentIndex+1] = true;
                  foundStatus[opponentIndex] = true;
                }
                opponentIndex++;
              }
            }else if(otherActionInt > 1){
              //other agent succeeded in moving
              int destCluster;
              int destBoundary;
              std::tie(destCluster, destBoundary) = definition_->getRobotMovedCluster(agentClusters[x], 0, otherActionInt).first;
              agentClusters[x] = destCluster;
            }
          }
        }
    }
      return std::make_pair(
              std::make_unique<State>(agentClusters, newSearchStatus, opponentClusters, foundStatus),
              true);

  }
//     if(robotBoundaryNode == actionInt){
//       return std::make_pair(
//               std::make_unique<State>(robotBoundaryNode, opponentCluster, true, false), true);
//     }
//     std::tie(newRobotNode, isValid) = sampleRobotMovedNode(robotBoundaryNode, actionInt);
//     //
//     // if (newRobotNode == opponentCluster && newRobotNode == robotBoundaryNode) {
//     //     return std::make_pair(
//     //             std::make_unique<State>(newRobotNode, opponentCluster, true), true);
//     // }
//
//     //GridPosition newOpponentPos = sampleNextOpponentPosition(robotPos, opponentPos);
//     //GridPosition newRobotPos;
//     //bool wasValid;
//     //std::tie(newRobotPos, wasValid) = getMovedPos(robotPos, multiSearchAction.getActionType());
//     return std::make_pair(std::make_unique<State>(newRobotNode, opponentCluster, false, false), true);
// }

// std::vector<ActionType> Model::makeOpponentActions(
//         GridPosition const &robotPos, GridPosition const &opponentPos) {
//     std::vector<ActionType> actions;
//     if (robotPos.i > opponentPos.i) {
//         actions.push_back(ActionType::NORTH);
//         actions.push_back(ActionType::NORTH);
//     } else if (robotPos.i < opponentPos.i) {
//         actions.push_back(ActionType::SOUTH);
//         actions.push_back(ActionType::SOUTH);
//     } else {
//         actions.push_back(ActionType::NORTH);
//         actions.push_back(ActionType::SOUTH);
//     }
//     if (robotPos.j > opponentPos.j) {
//         actions.push_back(ActionType::WEST);
//         actions.push_back(ActionType::WEST);
//     } else if (robotPos.j < opponentPos.j) {
//         actions.push_back(ActionType::EAST);
//         actions.push_back(ActionType::EAST);
//     } else {
//         actions.push_back(ActionType::EAST);
//         actions.push_back(ActionType::WEST);
//     }
//     return actions;
// }

/** Generates a proper distribution for next opponent positions. */
// std::unordered_map<GridPosition, double> Model::getNextOpponentPositionDistribution(
//         GridPosition const &robotPos, GridPosition const &opponentPos) {
//     std::vector<ActionType> actions = makeOpponentActions(robotPos, opponentPos);
//     std::unordered_map<GridPosition, double> distribution;
//     double actionProb = (1 - opponentStayProbability_) / actions.size();
//     for (ActionType action : actions) {
//         distribution[getMovedPos(opponentPos, action).first] += actionProb;
//     }
//     distribution[opponentPos] += opponentStayProbability_;
//     return std::move(distribution);
// }

// GridPosition Model::sampleNextOpponentPosition(GridPosition const &robotPos,
//         GridPosition const &opponentPos) {
//     // Randomize to see if the opponent stays still.
//     if (std::bernoulli_distribution(opponentStayProbability_)(
//             *getRandomGenerator())) {
//         return opponentPos;
//     }
//     std::vector<ActionType> actions(makeOpponentActions(robotPos, opponentPos));
//     ActionType action = actions[std::uniform_int_distribution<long>(0,
//             actions.size() - 1)(*getRandomGenerator())];
//     return getMovedPos(opponentPos, action).first;
// }

// std::pair<GridPosition, bool> Model::getMovedPos(GridPosition const &position,
//         ActionType action) {
//     GridPosition movedPos = position;
//     switch (action) {
//     case ActionType::NORTH:
//         movedPos.i -= 1;
//         break;
//     case ActionType::EAST:
//         movedPos.j += 1;
//         break;
//     case ActionType::SOUTH:
//         movedPos.i += 1;
//         break;
//     case ActionType::WEST:
//         movedPos.j -= 1;
//         break;
//     case ActionType::GRAPHSEARCH:
//         break;
//     default:
//         std::ostringstream message;
//         message << "Invalid action: " << (long) action;
//         debug::show_message(message.str());
//         break;
//     }
//     bool wasValid = isValid(movedPos);
//     if (!wasValid) {
//         movedPos = position;
//     }
//     return std::make_pair(movedPos, wasValid);
// }

bool Model::isRobotValid(int const &cluster) {
  return definition_->isOpponentValid(cluster);
}

bool Model::isOpponentValid(int const &cluster) {
  return definition_->isOpponentValid(cluster);
}

// std::pair<int, bool> Model::getRobotMovedNode(int robotBoundaryNode, int action){
//   int newRobotNode;
//   bool valid;
//   std::tie(newRobotNode, valid) = definition_->getRobotMovedNode(robotBoundaryNode, action);
//   return std::make_pair(newRobotNode, valid);
// }

// std::pair<int, bool> Model::sampleRobotMovedNode(int robotBoundaryNode, int action){
//   if(action == 0){
//     return std::pair<int, bool>(robotBoundaryNode, true);
//   }
//   if (std::bernoulli_distribution(0.1)(*getRandomGenerator())) {
//        return std::pair<int, bool>(robotBoundaryNode, true);
//   }
//   return getRobotMovedNode(robotBoundaryNode, action);
// }



std::unique_ptr<solver::Observation> Model::makeObservation(State const &nextState) {
    return std::make_unique<Observation>(nextState.getAgentClusters(),
                                                        nextState.getSearchStatus());
}
double Model::generateReward(solver::State const &state,
        solver::Action const &action,
        solver::TransitionParameters const */*tp*/,
        solver::State const * nextState) {
    float nextReward = 0.0;
    Action const &multiSearchAction = static_cast<Action const &>(action);
    if(multiSearchAction.getAction() == 1){
      nextReward -= clusterWaitCost_;  
    }else if(multiSearchAction.getAction() == 0){      
      nextReward -= clusterSearchScale_;
    }else{
      nextReward -= clusterMoveScale_;
    }

    if(nextState){
       State const *ns = static_cast<State const *>(nextState);
      bool allFound = true;
      std::vector<bool> nextFoundStatus = ns->getFoundStatus();
      for(bool status : nextFoundStatus){
        if(!status){
          allFound = false;
        }
      }
      if(allFound){
        nextReward+=clusterSearchReward_;
      }
    std::vector<int> nextAgentClusters = ns->getAgentClusters();
    int agentIndex = 0;
    for(int nextCluster : nextAgentClusters){
      if(agentId_!=agentIndex){
        if(nextCluster == nextAgentClusters[agentId_]){
          //We are now occupying the same space as another agent. this is bad news
          nextReward -= clusterClashCost_;
        }
      }
      agentIndex++;
    }
    }
    
  return nextReward;
}
                                              // double Model::generateReward(solver::State const &state,
                                              //         solver::Action const &action,
                                              //         solver::TransitionParameters const */*tp*/,
                                              //         solver::State const * nextState) {
                                              //     float nextReward = 0.0;
                                              //     nextReward -= stepCost_;
                                              //     State const &multiSearchState = static_cast<State const &>(state);
                                              //     Action const &multiSearchAction = static_cast<Action const &>(action);

                                              //     // if(multiSearchAction.getAction() != multiSearchState.currentAction()){
                                              //     //   if(multiSearchAction.getAction() == multiSearchState.getRobotNode()){
                                              //     //     //nextReward -= changePenalty_/2;
                                              //     //   }else{
                                              //     //     //nextReward -= changePenalty_;
                                              //     //   }
                                              //     // }
                                              //     //std::cout << "are we even getting here" << std::endl;
                                              //     if(nextState){
                                              //             State const *ns = static_cast<State const *>(nextState);
                                              //         std::vector<int> pastAgentClusters = multiSearchState.getAgentClusters();
                                              //         std::vector<int> nextAgentClusters = ns->getAgentClusters();
                                              //         std::vector<int> nextOpponentClusters = ns->getOpponentClusters();
                                              //         std::vector<std::vector<bool>> nextSearchStatus = ns->getSearchStatus();  
                                              //         std::vector<bool> currentFoundStatus = multiSearchState.getFoundStatus();
                                              //         int actionInt = multiSearchAction.getAction();
                                              //         //std::cout << "are we even getting here1" << std::flush;
                                              //         if(actionInt == 0){
                                              //           if(nextSearchStatus[agentId_][0] == true){
                                              //             //We performed a search!
                                              //             //Lets see if we discovered any opponents
                                              //             int count = 0;
                                              //             int searchIndex = 0;
                                              //             for(bool searchStatus : nextSearchStatus[agentId_]){
                                              //               if(searchIndex != 0){
                                              //                 if(searchStatus && currentFoundStatus[searchIndex-1] == false){
                                              //                   count++;
                                              //                 }
                                              //               }
                                              //               searchIndex++;
                                              //             }
                                              //             //std::cout << "are we even getting here2" << std::flush;
                                              //             if(count > 0){
                                              //               //We found undiscovered opponents
                                              //               nextReward += (count)*clusterSearchReward_;
                                              //             }else{
                                              //               //We didn't discover any undiscovered opponents. 
                                              //               nextReward -= clusterSearchScale_*definition_->getSearchCost(nextAgentClusters[agentId_]);
                                              //             }
                                              //           }
                                              //         }
                                              //       if(actionInt == 1){
                                              //         //This always incurs a cost (albeit small cost)
                                              //         nextReward -= clusterWaitCost_;
                                              //       }else{
                                              //         //std::cout << "are we even getting here3" << std::flush;
                                              //         //We want to perform a move action.  
                                              //         if(pastAgentClusters[agentId_] != nextAgentClusters[agentId_]){
                                              //           //We managed to perform a move
                                              //           nextReward -= clusterMoveScale_*definition_->getAverageMoveCost(pastAgentClusters[agentId_], nextAgentClusters[agentId_]);
                                              //           int agentIndex = 0;
                                              //           for(int nextCluster : nextAgentClusters){
                                              //             if(agentId_!=agentIndex){
                                              //               if(nextCluster == nextAgentClusters[agentId_]){
                                              //                 //We are now occupying the same space as another agent. this is bad news
                                              //                 nextReward -= clusterClashCost_;
                                              //               }
                                              //             }
                                              //             agentIndex++;
                                              //           } 
                                              //         }
                                              //         //We didn't perform any kind of move, we are still in the attempt, no reward given. 
                                              //       }
                                              //     }
                                              //   return nextReward;
                                              // }
    //std::cout << definition_->boundaryMap_[robotNode].size() << std::endl;
    //std::cout << actionInt << std::endl;
    // if((actionInt) > (definition_->boundaryMap_[robotNode].size()+1)){
    //   //std::cout << "reward  = -500" << std::endl;
    //   return -100;
  //   // }
  //   if(actionInt == 0){
  //     nextReward -= clusterSearchCost_;

  //     if(opponentCluster == definition_->getBoundaryCluster(robotNode)){
  //       nextReward += clusterSearchReward_;
  //      }else{
  //        nextReward -= clusterSearchCost_;
  //      }
  //   }else{
  //     // float step = definition_->getTransitDistance(robotNode, actionInt).first;
  //     // if(step < clusterSearchCost_){
  //     //   step = clusterSearchCost_+1.0;
  //     // }
  //     nextReward -= clusterMoveCost_;
  //   }
  //   if(multiSearchState.isFound()){
  //     nextReward += clusterSearchReward_;
  //   }
  //   //std::cout << "reward = " << nextReward << std::endl;
  //   return nextReward;
  // }
    //


    // if(multiSearchState.isSearched()){
    //   if((multiSearchAction.getAction() == multiSearchState.currentAction())){
    //     nextReward -= searchPenalty_*3;
    //   }else{
    //     nextReward -= (float)getTransitDistance(multiSearchState.getRobotNode(), multiSearchAction.getAction());
    //   }
    // }else{
    //   if(multiSearchAction.getAction() == multiSearchState.currentAction()){
    //     if(multiSearchState.getRobotNode() == multiSearchAction.getAction()){
    //       nextReward -= searchPenalty_;
    //     }else{
    //       nextReward -= 1.0;
    //     }
    //     //nextReward -= (float)getTransitDistance(multiSearchState.getRobotNode(),getMovedPos(multiSearchState.getRobotNode(), multiSearchAction.getAction()).first);
    //   }else{
    //     nextReward -= (float)getTransitDistance(multiSearchState.getRobotNode(), multiSearchAction.getAction());
    //   }
    // }
    // //nextReward -= (float)getTransitDistance(multiSearchState.getRobotNode(), multiSearchAction.getAction());
    // //if(multiSearchState.getOpponentNode() == multiSearchAction.getAction()){
    // if(multiSearchState.getOpponentNode() == multiSearchState.getRobotNode() && multiSearchState.isSearched()){
    //   nextReward += multiSearchReward_;
    // }

//}

std::unique_ptr<solver::State> Model::generateNextState(
        solver::State const &state, solver::Action const &action,
        solver::TransitionParameters const */*tp*/) {
    return makeNextState(static_cast<State const &>(state), action).first;
}

std::unique_ptr<solver::Observation> Model::generateObservation(
        solver::State const */*state*/, solver::Action const &/*action*/,
        solver::TransitionParameters const */*tp*/,
        solver::State const &nextState) {
    return makeObservation(static_cast<State const &>(nextState));
}

solver::Model::StepResult Model::generateStep(solver::State const &state,
        solver::Action const &action) {
    solver::Model::StepResult result;
    result.action = action.copy();
    std::unique_ptr<State> nextState = makeNextState(state, action).first;

    result.observation = makeObservation(*nextState);
    result.reward = generateReward(state, action, nullptr, nextState.get());
    result.isTerminal = isTerminal(*nextState);
    result.nextState = std::move(nextState);
    return result;
}


/* -------------- Methods for handling model changes ---------------- */
void Model::applyChanges(std::vector<std::unique_ptr<solver::ModelChange>> const &changes,
        solver::Solver *solver) {
    // solver::StatePool *pool = nullptr;
    // if (solver != nullptr) {
    //     pool = solver->getStatePool();
    // }
    //
    // solver::HeuristicFunction heuristic = getHeuristicFunction();
    // std::vector<double> allHeuristicValues;
    // if (pool != nullptr) {
    //     long nStates = pool->getNumberOfStates();
    //     allHeuristicValues.resize(nStates);
    //     for (long index = 0; index < nStates; index++) {
    //         allHeuristicValues[index] = heuristic(nullptr, pool->getInfoById(index)->getState(),
    //                 nullptr);
    //     }
    // }
    //
    // for (auto const &change : changes) {
    //     Change const &multiSearchChange = static_cast<Change const &>(*change);
    //     if (options_->hasVerboseOutput) {
    //         cout << multiSearchChange.changeType << " " << multiSearchChange.i0 << " "
    //                 << multiSearchChange.j0;
    //         cout << " " << multiSearchChange.i1 << " " << multiSearchChange.j1 << endl;
    //     }
    //
    //     CellType newCellType;
    //     if (multiSearchChange.changeType == "Add Obstacles") {
    //         newCellType = CellType::WALL;
    //     } else if (multiSearchChange.changeType == "Remove Obstacles") {
    //         newCellType = CellType::EMPTY;
    //     } else {
    //         cout << "Invalid change type: " << multiSearchChange.changeType;
    //         continue;
    //     }
    //
    //     for (long i = multiSearchChange.i0; i <= multiSearchChange.i1; i++) {
    //         for (long j = multiSearchChange.j0; j <= multiSearchChange.j1; j++) {
    //             envMap_[i][j] = newCellType;
    //         }
    //     }
    //
    //     if (pool == nullptr) {
    //         continue;
    //     }
    //
    //     solver::RTree *tree = static_cast<solver::RTree *>(pool->getStateIndex());
    //     if (tree == nullptr) {
    //         debug::show_message("ERROR: state index must be enabled to handle changes in !");
    //         std::exit(4);
    //     }
    //
    //     double iLo = multiSearchChange.i0;
    //     double iHi = multiSearchChange.i1;
    //     double iMx = nRows_ - 1.0;
    //
    //     double jLo = multiSearchChange.j0;
    //     double jHi = multiSearchChange.j1;
    //     double jMx = nCols_ - 1.0;
    //
    //     // Adding walls => any states where the robot or the opponent are in a wall must
    //     // be deleted.
    //     if (newCellType == CellType::WALL) {
    //         solver::FlaggingVisitor visitor(pool, solver::ChangeFlags::DELETED);
    //         // Robot is in a wall.
    //         tree->boxQuery(visitor,
    //                 {iLo, jLo, 0.0, 0.0, 0.0},
    //                 {iHi, jHi, iMx, jMx, 1.0});
    //         // Opponent is in a wall.
    //         tree->boxQuery(visitor,
    //                 {0.0, 0.0, iLo, jLo, 0.0},
    //                 {iMx, jMx, iHi, jHi, 1.0});
    //
    //     }
    //
    //     // Also, state transitions around the edges of the new / former obstacle must be revised.
    //     solver::FlaggingVisitor visitor(pool, solver::ChangeFlags::TRANSITION);
    //     tree->boxQuery(visitor,
    //             {iLo - 1, jLo - 1, 0.0, 0.0, 0.0},
    //             {iHi + 1, jHi + 1, iMx, jMx, 1.0});
    //     tree->boxQuery(visitor,
    //             {0.0, 0.0, iLo - 1, jLo - 1, 0.0},
    //             {iMx, jMx, iHi + 1, jHi + 1, 1.0});
    // }
    //
    // if (mdpSolver_ != nullptr) {
    //     mdpSolver_->solve();
    //}

    // calculatePairwiseDistances();
    //
    // // Check for heuristic changes.
    // if (pool != nullptr) {
    //     long nStates = pool->getNumberOfStates();
    //     for (long index = 0; index < nStates; index++) {
    //         double oldValue = allHeuristicValues[index];
    //         solver::StateInfo *info = pool->getInfoById(index);
    //         double newValue = heuristic(nullptr, info->getState(), nullptr);
    //         if (std::abs(newValue - oldValue) > 1e-5) {
    //             pool->setChangeFlags(info, solver::ChangeFlags::HEURISTIC);
    //         }
    //     }
    // }
}


/* ------------ Methods for handling particle depletion -------------- */
std::vector<std::unique_ptr<solver::State>> Model::generateParticles(
        solver::BeliefNode */*previousBelief*/, solver::Action const &action,
        solver::Observation const &obs,
        long nParticles,
        std::vector<solver::State const *> const &previousParticles) {
    std::vector<std::unique_ptr<solver::State>> newParticles;
    Observation const &observation =
            (static_cast<Observation const &>(obs));
    int actionInt =
            (static_cast<Action const &>(action).getAction());

    typedef std::unordered_map<State, double> WeightMap;
    WeightMap weights;
    double weightTotal = 0;
    std::vector<int> newAgentClusters = observation.agentClusters();
    std::vector<std::vector<bool>> newSearchStatus = observation.searchStatus();
    std::vector<std::set<int>> possiblePastAgentClusters;
    std::vector<int> opponentClusters;
    std::set<int> searchedClusters;
    possiblePastAgentClusters.resize(nAgents_);
    opponentClusters.resize(nTargets_,-1);
    for(int x = 0; x < nAgents_; x++){
      //for each agent, check if the agent searched, if they didn't complete a search, their past position could be the observed cluster,
      //Or it could be a neighbouring one. 
      if(newSearchStatus[x][0] == true){
        possiblePastAgentClusters[x].insert(newAgentClusters[x]);
        searchedClusters.insert(newAgentClusters[x]);
        //check for opponent exclusions
        int index = 0;
        for(bool searchStatus : newSearchStatus[x]){
          if(index != 0){
            if(searchStatus){
              //We found an opponent (at index-1) at agent x's cluster. 
              opponentClusters[index-1] = newAgentClusters[x];
            }
          }
        }
      }else{
        possiblePastAgentClusters[x].insert(newAgentClusters[x]);
        std::vector<int> neighbours = definition_->getClusterNeighbours(newAgentClusters[x]);
        for(int neighbour : neighbours){
          possiblePastAgentClusters[x].insert(neighbour);
        }
      }
    }
    
    //int newRobotNode = observation.robotBoundaryNode();
    //int newRobotCluster = definition_->getBoundaryCluster(newAgentPositions[agentId_]);//actionInt;
    //std::cout << "generatingParticles" << std::endl;
    // if (observation.seesOpponent()){
    //     // If we saw the opponent, we must be in the same place and have performed a search.
    //     newParticles.push_back(
    //             std::make_unique<State>(newAgentPositions, newSearchStatus , newRobotCluster, true));
    // } else {
        // We didn't see the opponent, so any agents that performed a search must be in different places.
      for (solver::State const *state : previousParticles) {
          State const *multiSearchState = static_cast<State const *>(state);
          std::vector<int> oldAgentClusters = multiSearchState->getAgentClusters();
          std::vector<int> oldOpponentClusters = multiSearchState->getOpponentClusters();
          std::vector<bool> newFoundStatus = multiSearchState->getFoundStatus();
          //SANITY CHECKING
          // std::cout << "state particle: " <<std::endl;
          // std::cout << "agent Clusters: " ;
          // for(int cluster : oldAgentClusters){
          //   std::cout << " " << cluster;
          // }
          // std::cout << std::endl;
          // std::cout << "opponentClusters: ";
          // for(int cluster : oldOpponentClusters){
          //   std::cout << " " << cluster;
          // }
          // std::cout << std::endl;
          // std::cout << "foundStatus: ";
          // for(bool status : newFoundStatus){
          //   std::cout << " " << (status ? 1 : 0);
          // }
          // std::cout << std::endl;
          //Check agent cluster validity;
          int agentIndex = 0;
          bool validClusters = true;
          for(int oldAgentCluster : oldAgentClusters){
            if(!(possiblePastAgentClusters[agentIndex].find(oldAgentCluster) != possiblePastAgentClusters[agentIndex].end())){
              //old cluster isn't in the possible set of past clusters given the current observations. 
              validClusters = false;
              break;
            }
            agentIndex++;
          }
          if(!validClusters){
            continue;
          }

          //Check opponent cluster validity. 
          int opponentIndex = 0;
          bool validOpponents = true;
          for(int opponentCluster : oldOpponentClusters){
            if(opponentClusters[opponentIndex] != -1){
              //we found this opponent
              if(opponentClusters[opponentIndex] != opponentCluster){
                validOpponents = false;
              }
              //If we know we found this opponnet, we can update the found status
              newFoundStatus[opponentIndex] = true;
            }else{
              //we haven't found this opponent at its cluster, but it cannot exist in the searched cluster set, or it is invalid.
              if(searchedClusters.find(opponentCluster) != searchedClusters.end()){
                //Opponentcluster == one of the searched clusters, meaning it is invalid
                validOpponents = false;
              }
            }
            opponentIndex++;
          }
          if(!validOpponents){
            continue;
          }
          
          State newState(newAgentClusters, newSearchStatus, oldOpponentClusters, newFoundStatus);
          weights[newState] += 1.0;
          weightTotal += 1.0;
      }
                                                                                          // std::set<int> invalidOpponentClusters;
                                                                                          // //For each agent, check if new position is possible from old position.
                                                                                          // bool invalidState = false;
                                                                                          // for(int x = 0; x < nAgents_; x++){
                                                                                          //   if(newSearchStatus[x]==true){
                                                                                          //     //oldAgentPosition must = newAgentPosition;
                                                                                          //     if(oldAgentPositions[x] != newAgentPositions[x]){
                                                                                          //       invalidState = true;
                                                                                          //       continue;
                                                                                          //     }else{
                                                                                          //       invalidOpponentClusters.insert(definition_->getBoundaryCluster(newAgentPositions[x]));
                                                                                          //     }
                                                                                          //   }else{
                                                                                          //     //If new agent position is not reachable from old agent position.
                                                                                          //     if(definition_->isAccessible(newAgentPositions[x], oldAgentPositions[x])){
                                                                                          //       invalidState = true;
                                                                                          //       continue;
                                                                                          //     }
                                                                                          //   }
                                                                                          // }
                                                                                          // if(invalidState){
                                                                                          //   continue;
                                                                                          // }
                                                                                          // bool opponentClusterValid = true;
                                                                                          // if(invalidOpponentClusters.count(oldOpponentCluster) != 0){
                                                                                          //   opponentClusterValid = false;
                                                                                          // }
                                                                                          // // Ignore states that do not match knowledge of the robot's position.
                                                                                          // //if (newRobotNode != getRobotMovedNode(oldRobotNode, actionInt).first) {
                                                                                          // //  continue;
                                                                                          // //}
                                                                                          // // std::vector<int>
                                                                                          // // if(newSearchStatus[agentId_]){
                                                                                          // //   if(newRobotNode != getRobotMovedNode()){
                                                                                          // //     continue;
                                                                                          // //   }
                                                                                          // // }
                                                                                          // // Get the probability distribution for opponent moves.
                                                                                          // //GridPosition oldOpponentPos(multiSearchState->getOpponentPosition());
                                                                                          // // std::unordered_map<GridPosition, double> opponentPosDistribution = (
                                                                                          // //         getNextOpponentPositionDistribution(oldRobotPos, oldOpponentPos));
                                                                                          // //
                                                                                          // // for (auto const &entry : opponentPosDistribution) {
                                                                                          // if(opponentClusterValid) {

              //}
            //}
      //}
    double scale = nParticles / weightTotal;
    for (WeightMap::iterator it = weights.begin(); it != weights.end();
            it++) {
        double proportion = it->second * scale;
        long numToAdd = static_cast<long>(proportion);
        if (std::bernoulli_distribution(proportion - numToAdd)(
                *getRandomGenerator())) {
            numToAdd += 1;
        }
        for (int i = 0; i < numToAdd; i++) {
            newParticles.push_back(std::make_unique<State>(it->first));
        }
    }
    //std::cout << "particles generated " << std::endl;
    return newParticles;
}

std::vector<std::unique_ptr<solver::State>> Model::generateParticles(
        solver::BeliefNode */*previousBelief*/, solver::Action const &action,
        solver::Observation const &obs, long nParticles) {
    std::vector<std::unique_ptr<solver::State>> newParticles;
    Observation const &observation =
            (static_cast<Observation const &>(obs));
    int actionInt =
            (static_cast<Action const &>(action).getAction());
    std::vector<int> agentClusters = observation.agentClusters();
    std::vector<std::vector<bool>> searchStatus = observation.searchStatus();


    std::vector<int> opponentClusters;
    std::set<int> searchedClusters;
    opponentClusters.resize(nTargets_,-1);
    for(int x = 0; x < nAgents_; x++){
      //for each agent, check if the agent searched, if they didn't complete a search, their past position could be the observed cluster,
      //Or it could be a neighbouring one. 
      if(searchStatus[x][0] == true){
        searchedClusters.insert(agentClusters[x]);
        //check for opponent exclusions
        int index = 0;
        for(bool status : searchStatus[x]){
          if(index != 0){
            if(status){
              //We found an opponent (at index-1) at agent x's cluster. 
              opponentClusters[index-1] = agentClusters[x];
            }
          }
        }
      }
    }

    while ((long)newParticles.size() < nParticles) {
      std::vector<int> newOpponentClusters;
      std::vector<bool> foundStatus;
      foundStatus.resize(nTargets_);
      newOpponentClusters.resize(nTargets_);
      int opponentIndex = 0;
      for(int opponentCluster : opponentClusters){
        if(opponentCluster == -1){
          //opponent not found by last actions
          newOpponentClusters[opponentIndex] = randomUnsearchedCluster(searchedClusters);
        }else{
          newOpponentClusters[opponentIndex] = opponentCluster;
          foundStatus[opponentIndex] = true;
        }
        opponentIndex++;
      }
      newParticles.push_back(
        std::make_unique<State>(agentClusters, searchStatus, newOpponentClusters, foundStatus)
      );
    }

    // int newRobotNode = observation.robotBoundaryNode();
    // int newRobotCluster = definition_->getBoundaryCluster(newRobotNode);//actionInt;
    // if (observation.seesOpponent()) {
    //     // If we saw the opponent, we must be in the same place.
    //     while ((long)newParticles.size() < nParticles) {
    //         newParticles.push_back(
    //             std::make_unique<State>(newRobotNode, newRobotCluster, true, true)
    //           );
    //     }
    // } else {
    //     while ((long)newParticles.size() < nParticles) {
    //         std::unique_ptr<solver::State> state = sampleStateUninformed();
    //         solver::Model::StepResult result = generateStep(*state, action);
    //         if (obs == *result.observation) {
    //             newParticles.push_back(std::move(result.nextState));
    //         }
    //     }
    // }
    return newParticles;
}


/* --------------- Pretty printing methods ----------------- */
void Model::dispCell(std::ostream &os) {
    // switch (cellType) {
    // case CellType::EMPTY:
    //     os << " 0";
    //     break;
    // case CellType::WALL:
    //     os << "XX";
    //     break;
    // default:
    //     os << "ER";
    //     break;
    // }
}

void Model::drawEnv(std::ostream &os) {
    // for (std::vector<CellType> &row : envMap_) {
    //     for (CellType cellType : row) {
    //         dispCell(cellType, os);
    //         os << " ";
    //     }
    //     os << endl;
    // }
}


void Model::drawSimulationState(solver::BeliefNode const *belief,
        solver::State const &state, std::ostream &os) {
                          // State const &multiSearchState = static_cast<State const &>(state);
                          // std::vector<solver::State const *> particles = belief->getStates();
                          // std::vector<long> particleCounts(nClusters_);
                          // std::vector<long> positionCounts(nClusters_);
                          // std::vector<long> boundaryCounts(nBoundaryNodes_);
                          // int invalidCounts = 0;
                          // int particleCount = 0;
                          // for (solver::State const *particle : particles) {
                          //       particleCount++;
                          //       int opponentCluster =
                          //               static_cast<State const &>(*particle).getOpponentCluster();
                          //       if(opponentCluster < 0 || opponentCluster >= nClusters_){
                          //         invalidCounts++;
                          //       }
                          //       particleCounts[opponentCluster] += 1;
                          //       int robotPosition =
                          //               static_cast<State const &>(*particle).getAgentPosition(agentId_);
                          //       //if(definition_->getBoundaryCluster(robotPosition) != 7){
                          //       //  os << definition_->getBoundaryCluster(robotPosition) << endl;
                          //       //}
                          //       positionCounts[definition_->getBoundaryCluster(robotPosition)] += 1;
                          //       boundaryCounts[robotPosition] += 1;
                          // }

                          // // int robotBoundaryNode = multiSearchState.getRobotNode();
                          // // int opponentCluster = multiSearchState.getOpponentCluster();
                          // os << "particleCount = " << particleCount << endl;
                          // os << "invalidCounts = " << invalidCounts << endl;
                          // for(int x = 0; x < nClusters_; x++){
                          //   os << "Cluster "<< x << "(" << particleCounts[x]<<")" << "(" << positionCounts[x]<<")" ;
                          //   //if(opponentCluster == x){
                          //   //   os << "(Op)";
                          //   // }else{
                          //   //   os << "(--)";
                          //   // }
                          //   // if(robotBoundaryNode == x){
                          // //     os << "(Rb)";
                          // //   }else{
                          // //     os << "(--)";
                          // //   }
                          //   os << endl;
                          // }

                          //   for(int x = 0; x < nBoundaryNodes_; x++){
                          //     os << "BoundaryNode "<< x << "(" << boundaryCounts[x]<<")";
                          //     //if(opponentCluster == x){
                          //   //   os << "(Op)";
                          //   // }else{
                          //   //   os << "(--)";
                          //   // }
                          //   // if(robotBoundaryNode == x){
                          // //     os << "(Rb)";
                          // //   }else{
                          // //     os << "(--)";
                          // //   }
                          //     os << endl;
                          //   }
    //
    // std::vector<int> colors { 196, 161, 126, 91, 56, 21, 26, 31, 36, 41, 46 };
    // if (options_->hasColorOutput) {
    //     os << "Color map: ";
    //     for (int color : colors) {
    //         os << "\033[38;5;" << color << "m";
    //         os << '*';
    //         os << "\033[0m";
    //     }
    //     os << endl;
    // }
    // for (std::size_t i = 0; i < envMap_.size(); i++) {
    //     for (std::size_t j = 0; j < envMap_[0].size(); j++) {
    //         double proportion = (double) particleCounts[i][j]
    //                 / particles.size();
    //         if (options_->hasColorOutput) {
    //             if (proportion > 0) {
    //                 int color = colors[proportion * (colors.size() - 1)];
    //                 os << "\033[38;5;" << color << "m";
    //             }
    //         }
    //         GridPosition pos(i, j);
    //         bool hasRobot = (pos == multiSearchState.getRobotPosition());
    //         bool hasOpponent = (pos == multiSearchState.getOpponentPosition());
    //         if (hasRobot) {
    //             if (hasOpponent) {
    //                 os << "#";
    //             } else {
    //                 os << "r";
    //             }
    //         } else if (hasOpponent) {
    //             os << "o";
    //         } else {
    //             if (envMap_[i][j] == CellType::WALL) {
    //                 os << "X";
    //             } else {
    //                 os << ".";
    //             }
    //         }
    //         if (options_->hasColorOutput) {
    //             os << "\033[0m";
    //         }
    //     }
    //     os << endl;
    // }
}


/* ---------------------- Basic customizations  ---------------------- */
double Model::getDefaultHeuristicValue(solver::HistoryEntry const */*entry*/,
            solver::State const *state, solver::HistoricalData const */*data*/) {
    State const &multiSearchState = static_cast<State const &>(*state);
    if (isTerminal(multiSearchState)) {
        return 0;
    }
    std::vector<int> agentClusters = multiSearchState.getAgentClusters();
    std::vector<int> opponentClusters = multiSearchState.getOpponentClusters();
    return definition_->getDefaultQVal(agentClusters[agentId_], 0, opponentClusters[0]);
}

double Model::getUpperBoundHeuristicValue(solver::State const &state) {
    State const &multiSearchState = static_cast<State const &>(state);
    // if (isTerminal(multiSearchState)) {
    //     return 0;
    // }
    // int robotBoundaryNode = multiSearchState.getAgentPosition(agentId_);
    // int opponentCluster = multiSearchState.getOpponentCluster();
    // //double qVal = (definition_->getOptimalQVal(robotBoundaryNode, opponentCluster));
    // //long dist = getTransitDistance(robotBoundaryNode, opponentCluster);
    // //double nSteps = dist / opponentStayProbability_;
    // double nSteps =  definition_->getTransitSteps(robotBoundaryNode, opponentCluster);
    // //std::cout << "upper " << nSteps << std::endl;
    // double finalDiscount = std::pow(options_->discountFactor, nSteps);
    // double qVal = -clusterMoveCost_ * (1 - finalDiscount) / (1 - options_->discountFactor);
    // qVal += finalDiscount * clusterSearchReward_;
    // return qVal;
    // State const &multiSearchState = static_cast<State const &>(*state);
    if (isTerminal(multiSearchState)) {
        return 0;
    }
    std::vector<int> agentClusters = multiSearchState.getAgentClusters();
    std::vector<int> opponentClusters = multiSearchState.getOpponentClusters();
    //return definition_->getMultiQVal(agentClusters, opponentClusters);
    return definition_->getUpperQVal(agentClusters[agentId_], 0, opponentClusters[0]);
}

//
// std::unique_ptr<RockSampleAction> RockSampleModel::getRandomAction() {
//     long binNumber = std::uniform_int_distribution<int>(0, 4 + nRocks_)(*getRandomGenerator());
//     return std::make_unique<RockSampleAction>(binNumber);
// }
std::unique_ptr<Action> Model::getRandomAction(std::vector<long> binNumbers) {
    if (binNumbers.empty()) {
        return nullptr;
    }
    long index = std::uniform_int_distribution<int>(0, binNumbers.size() - 1)(
            *getRandomGenerator());
    return std::make_unique<Action>(binNumbers[index]);
}

std::unique_ptr<solver::Action> Model::getRolloutAction(
        solver::HistoryEntry const */*entry*/, solver::State const * /*state*/,
        solver::HistoricalData const *data) {

    return getRandomAction(static_cast<Data const &>(*data).generateLegalActions());
    // if (rolloutCategory_ == RSActionCategory::ALL) {
    //     return getRandomAction();
    // } else if (rolloutCategory_ == RSActionCategory::LEGAL) {
    //     if (heuristicType_ == RSActionCategory::LEGAL) {
    //         return getRandomAction(static_cast<PositionData const &>(*data).generateLegalActions());
    //     } else if (heuristicType_ == RSActionCategory::PREFERRED) {
    //         return getRandomAction(
    //                 static_cast<PositionAndRockData const &>(*data).generateLegalActions());
    //     }
    // } else {
    //     return getRandomAction(
    //             static_cast<PositionAndRockData const &>(*data).generatePreferredActions());
    // }
    // return nullptr;
}

std::unique_ptr<solver::HistoricalData> Model::createRootHistoricalData() {
    //switch (heuristicType_) {
    //case RSActionCategory::LEGAL:
        return std::make_unique<Data>(this, initialAgentClusters_, definition_->clusterSearchStatus_);
    //case RSActionCategory::PREFERRED:
    //    return std::make_unique<PositionAndRockData>(this, getStartPosition());
    //default:
    //    return nullptr;
    //}
}

/* ------- Customization of more complex solver functionality  --------- */
std::vector<std::unique_ptr<solver::DiscretizedPoint>> Model::getAllActionsInOrder() {
    std::vector<std::unique_ptr<solver::DiscretizedPoint>> allActions;
    for (long code = 0; code < nActions_; code++) {
        allActions.push_back(std::make_unique<Action>(code));
    }
    return allActions;
}

std::vector<std::vector<float>> Model::getAgentBeliefProportions(solver::BeliefNode const *belief){
  std::vector<solver::State const *> particles = belief->getStates();
  std::vector<std::vector<float>> particleCounts;
  for(int x = 0; x < nAgents_; x++){
    std::vector<float> agentCounts(nClusters_);
    particleCounts.push_back(agentCounts);
  }
  for (solver::State const *particle : particles) {
        int agentIndex = 0;
        for(int agentCluster : static_cast<State const &>(*particle).getAgentClusters()){
        // int targetNode = static_cast<State const &>(*particle).getOpponentClusters();
          particleCounts[agentIndex][agentCluster] += 1;
          agentIndex++;
        }
    }

    std::vector<std::vector<float>> result;
    for(int x = 0; x < nAgents_; x++){
      std::vector<float> oppResult;
      for (std::size_t i = 0; i < nClusters_; i++) {
          //result.push_back(std::vector<float>());
          //for (std::size_t j = 0; j < envMap_[0].size(); j++) {
          oppResult.push_back(particleCounts[x][i]/((float)particles.size()));
          //}
      }
      result.push_back(oppResult);
    }
    return result;
}

std::vector<std::vector<float>> Model::getBeliefProportions(solver::BeliefNode const *belief) {
    std::vector<solver::State const *> particles = belief->getStates();
    std::vector<std::vector<float>> particleCounts;
    for(int x = 0; x < nTargets_; x++){
      std::vector<float> clusterCounts(nClusters_);
      particleCounts.push_back(clusterCounts);
    }
    for (solver::State const *particle : particles) {
        int opponentIndex = 0;
        for(int opponentCluster : static_cast<State const &>(*particle).getOpponentClusters()){
        // int targetNode = static_cast<State const &>(*particle).getOpponentClusters();
          particleCounts[opponentIndex][opponentCluster] += 1;
          opponentIndex++;
        }
    }

    std::vector<std::vector<float>> result;
    for(int x = 0; x < nTargets_; x++){
      std::vector<float> oppResult;
      for (std::size_t i = 0; i < nClusters_; i++) {
          //result.push_back(std::vector<float>());
          //for (std::size_t j = 0; j < envMap_[0].size(); j++) {
          oppResult.push_back(particleCounts[x][i]/((float)particles.size()));
          //}
      }
      result.push_back(oppResult);
    }
    return result;
}

std::unique_ptr<solver::ActionPool> Model::createActionPool(solver::Solver */*solver*/) {
  return std::make_unique<LegalActionsPool>(this);
    //return std::make_unique<solver::EnumeratedActionPool>(this, getAllActionsInOrder());
}
std::unique_ptr<solver::Serializer> Model::createSerializer(solver::Solver *solver) {
    return std::make_unique<TextSerializer>(solver);
}
} /* namespace multiSearch */
}
}
