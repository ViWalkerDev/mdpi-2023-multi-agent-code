/** @file Observation.cpp
 *
 * Contains the implementations for the methods of Observation.
 */
#include "nanomaptapir/planner/problems/multisearch/Observation.hpp"

#include <cstddef>                      // for size_t

#include <algorithm>                    // for copy
#include <iterator>                     // for ostream_iterator
#include <ostream>                      // for operator<<, ostream
#include <vector>                       // for vector, operator==, _Bit_const_iterator, _Bit_iterator_base, hash, vector<>::const_iterator

#include "tapirsolver/global.hpp"

#include "tapirsolver/problems/shared/GridPosition.hpp"  // for GridPosition, operator==, operator<<
#include "tapirsolver/solver/abstract-problem/Observation.hpp"             // for Observation

#include "nanomaptapir/planner/problems/multisearch/Model.hpp"
namespace nanomaptapir{
  namespace planner{
    namespace multisearch{
Observation::Observation(std::vector<int> _agentClusters, std::vector<std::vector<bool>> _searchStatus) :
                    agentClusters_(_agentClusters),
                    //agentActions_(_agentActions),
                    searchStatus_(_searchStatus){
}
std::unique_ptr<solver::Observation>
Observation::copy() const {
    return std::make_unique<Observation>(agentClusters_, searchStatus_);
}

double Observation::distanceTo(
        solver::Observation const &otherObs) const {
    Observation const &other = static_cast<Observation const &>(otherObs);
    double distance = 0.0;
    for(int x = 0; x < agentClusters_.size(); x++){
      distance += (agentClusters_[x] == other.agentClusters_[x]) ? 0 : 1;
    }
    for(int x = 0;x < searchStatus_.size(); x++){
      for(int y = 0; y < searchStatus_[x].size(); y++){
        distance += (searchStatus_[x][y] == other.searchStatus_[x][y]) ? 0 : 1;
      }
    }
    return distance;
}

bool Observation::equals(
        solver::Observation const &otherObs) const {
    Observation const &other = static_cast<Observation const &>(otherObs);
    return (agentClusters_ == other.agentClusters_
            && searchStatus_ == other.searchStatus_);
}

std::size_t Observation::hash() const {
    std::size_t hashValue = 0;
    for(int x = 0; x < agentClusters_.size(); x++){
      tapir::hash_combine(hashValue, agentClusters_[x]);
    }
    for(int x = 0; x < searchStatus_.size(); x++){
      for(int y = 0; y < searchStatus_[x].size(); y++){
        tapir::hash_combine(hashValue, searchStatus_[x][y]);
      }
    }
    return hashValue;
}

void Observation::print(std::ostream &os) const {
    for(int x = 0; x < agentClusters_.size(); x++){
      os << "Clusters: ";
      os << agentClusters_[x] << " / ";
    }
    os << std::endl;
    // for(int x = 0; x < agentActions_.size(); x++){
    //   os << "Actions: ";
    //   os << agentActions_[x] << " / ";
    // }
    for(int x = 0; x < searchStatus_.size(); x++){
      os << "SearchStatus: ";
      for(int y = 0; y < searchStatus_[x].size(); y++){
        os << std::endl;
        os << searchStatus_[x][y] << " / ";
    
      }
    }
    os << std::endl;
}

// GridPosition Observation::getPosition() const {
//     return position_;
// }



  std::vector<std::vector<bool>> Observation::searchStatus() const {
    return searchStatus_;
  }

  std::vector<int> Observation::agentClusters() const {
    return agentClusters_;
  }

    }
  }
}
/* namespace multiSearch */
