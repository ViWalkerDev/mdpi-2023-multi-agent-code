/** @file State.cpp
 *
 * Contains the implementation for the methods of State.
 */
#include "nanomaptapir/planner/problems/multisearch/State.hpp"

#include <cstddef>                      // for size_t

#include <functional>   // for hash
#include <ostream>                      // for operator<<, ostream, basic_ostream>
#include <vector>

#include "tapirsolver/global.hpp"
//#include "tapirsolver/problems/shared/GridPosition.hpp"  // for GridPosition, operator==, operator<<
#include "tapirsolver/solver/abstract-problem/State.hpp"             // for State

namespace nanomaptapir{
  namespace planner{
    namespace multisearch{
State::State(std::vector<int> agentClusters, std::vector<std::vector<bool>> searchStatus,
                                            std::vector<int> opponentClusters, std::vector<bool> foundStatus/*, int _currentAction*/) :
    solver::Vector(),
    agentClusters_(agentClusters),
    //agentActions_(agentActions),
    searchStatus_(searchStatus),
    opponentClusters_(opponentClusters),//{//,
    foundStatus_(foundStatus){
    // currentAction_(_currentAction) {
}

State::State(State const &other) :
        State(other.agentClusters_, other.searchStatus_, other.opponentClusters_, other.foundStatus_){///*, other.currentAction_*/) {
}

std::unique_ptr<solver::State> State::copy() const {
    return std::make_unique<State>(agentClusters_, searchStatus_, opponentClusters_, foundStatus_/*, currentAction_*/);
}

double State::distanceTo(solver::State const &otherState) const {
    State const &other = static_cast<State const &>(otherState);
    double distance = 0.0;
    for(int x = 0; x < agentClusters_.size(); x++){
      distance += (agentClusters_[x] == other.agentClusters_[x]) ? 0 : 1;
    }
    for(int x = 0;x < searchStatus_.size(); x++){
      for(int y = 0; y < searchStatus_[x].size(); y++){
        distance += (searchStatus_[x][y] == other.searchStatus_[x][y]) ? 0 : 1;
      }
    }
    for(int x = 0; x < opponentClusters_.size(); x++){
      distance += (opponentClusters_[x] == other.opponentClusters_[x]) ? 0 : 1;
      distance += (foundStatus_[x] == other.foundStatus_[x]) ? 0 : 1;
    }
    return distance;
}

bool State::equals(solver::State const &otherState) const {
    State const &other = static_cast<State const &>(otherState);
    return (agentClusters_ == other.agentClusters_
            && searchStatus_ == other.searchStatus_
            && opponentClusters_ == other.opponentClusters_//);
            && foundStatus_ == other.foundStatus_);

            // && currentAction_ == otherState.currentAction_);
}

std::size_t State::hash() const {
    std::size_t hashValue = 0;
    for(int x = 0; x < agentClusters_.size(); x++){
      tapir::hash_combine(hashValue, agentClusters_[x]);
    }
    for(int x = 0; x < searchStatus_.size(); x++){
      for(int y = 0; y < searchStatus_[x].size(); y++){
        tapir::hash_combine(hashValue, searchStatus_[x][y]);
      }
    }
    for(int x = 0; x < opponentClusters_.size(); x++){
      tapir::hash_combine(hashValue, opponentClusters_[x]);
    }
    for(int x = 0; x < foundStatus_.size(); x++){
      tapir::hash_combine(hashValue, foundStatus_[x]);
    }
    return hashValue;
}

std::vector<double> State::asVector() const {
    std::vector<double> vec(agentClusters_.size() + (searchStatus_.size()*searchStatus_[0].size())+ opponentClusters_.size()*2);
    int index = 0;
    for(int x = 0; x < agentClusters_.size(); x++){
      vec[index] = agentClusters_[x];
      index++;
    }

    for(int x = 0; x < searchStatus_.size(); x++){
      for(int y = 0; y < searchStatus_[x].size(); y++){
        vec[index] = searchStatus_[x][y];
        index++;
      }
    }

    for(int x = 0; x < opponentClusters_.size(); x++){
      vec[index] = opponentClusters_[x];
      index++;
    }

    for(int x = 0; x < opponentClusters_.size(); x++){
      vec[index] = foundStatus_[x];
      index++;
    }
    return vec;
}

void State::print(std::ostream &os) const {
    for(int x = 0; x < agentClusters_.size(); x++){
      os << "Clusters: ";
      os << agentClusters_[x] << " / ";
    }
    os << std::endl;
    // for(int x = 0; x < agentActions_.size(); x++){
    //   os << "Actions: ";
    //   os << agentActions_[x] << " / ";
    // }
    for(int x = 0; x < searchStatus_.size(); x++){
      os << "SearchStatus: ";
      for(int y = 0; y < searchStatus_[x].size(); y++){
        os << std::endl;
        os << searchStatus_[x][y] << " / ";
    
      }
    }
    os << std::endl;
    for(int x = 0; x < opponentClusters_.size(); x++){
      os << "Opponent Clusters: ";
      os << opponentClusters_[x] << " / ";
    }
    os << std::endl;
    for(int x = 0; x < foundStatus_.size(); x++){
      os << "Opponent found status: ";
      os << foundStatus_[x] << " / ";
    }
    os << std::endl;
    // os << "CURRENT ACTION: " << currentAction_ ;
}


// int State::getAgentPosition(int index) const {
//     return agentClusters_[index];
// }
// int State::getAgentAction(int index) const {
//     return agentActions_[index];
// }
std::vector<int> State::getAgentClusters() const {
    return agentClusters_;
}
// std::vector<int> State::getAgentPositions() const {
//     return agentActions_;
// }



std::vector<int> State::getOpponentClusters() const {
    return opponentClusters_;
}

// int State::currentAction() const {
//     return currentAction_;
// }
//
std::vector<std::vector<bool>> State::getSearchStatus() const {
  return searchStatus_;
}
// bool State::getSearchStatus(int index) const {
//     return searchStatus_[index];
// }

std::vector<bool> State::getFoundStatus() const {
  return foundStatus_;
}
bool State::isFound() const {
    for(bool found : foundStatus_){
      if(!found){
        return false;
      }
    }
    return true;
}
    } /* namespace multiSearch */
  }
}
