/** @file TextSerializer.cpp
 *
 * Contains the implementations of the serialization methods for .
 */
#include "nanomaptapir/planner/problems/multisearch/TextSerializer.hpp"

#include <iostream>                     // for operator<<, basic_ostream, basic_ostream<>::__ostream_type, basic_istream<>::__istream_type

#include "tapirsolver/global.hpp"                     // for make_unique
#include "tapirsolver/problems/shared/GridPosition.hpp"  // for GridPosition
#include "tapirsolver/solver/abstract-problem/Action.hpp"
#include "tapirsolver/solver/abstract-problem/Observation.hpp"
#include "tapirsolver/solver/abstract-problem/State.hpp"             // for State
#include "tapirsolver/solver/serialization/TextSerializer.hpp"    // for TextSerializer

#include "tapirsolver/solver/mappings/actions/enumerated_actions.hpp"
#include "tapirsolver/solver/mappings/observations/discrete_observations.hpp"

#include "nanomaptapir/planner/problems/multisearch/Action.hpp"
#include "nanomaptapir/planner/problems/multisearch/Model.hpp"
#include "nanomaptapir/planner/problems/multisearch/Observation.hpp"
#include "nanomaptapir/planner/problems/multisearch/State.hpp"                 // for State

namespace solver {
class Solver;
} /* namespace solver */
namespace nanomaptapir{
  namespace planner{
    namespace multisearch{
void saveVector(std::vector<long> values, std::ostream &os) {
    os << "(";
    for (auto it = values.begin(); it != values.end(); it++) {
        os << *it;
        if ((it + 1) != values.end()) {
            os << ", ";
        }
    }
    os << ")";
}

std::vector<long> loadVector(std::istream &is) {
    std::vector<long> values;
    std::string tmpStr;
    std::getline(is, tmpStr, '(');
    std::getline(is, tmpStr, ')');
    std::istringstream sstr(tmpStr);
    while (std::getline(sstr, tmpStr, ',')) {
        long value;
        std::istringstream(tmpStr) >> value;
        values.push_back(value);
    }
    return values;
}

TextSerializer::TextSerializer(solver::Solver *solver) :
    solver::Serializer(solver) {
}

/* ------------------ Saving change sequences -------------------- */
void TextSerializer::saveModelChange(solver::ModelChange const &change, std::ostream &os) {
    Change const &multiSearchChange = static_cast<Change const &>(change);
}
std::unique_ptr<solver::ModelChange> TextSerializer::loadModelChange(std::istream &is) {
    std::unique_ptr<Change> change = std::make_unique<Change>();
    return std::move(change);
}

void TextSerializer::saveState(solver::State const *state, std::ostream &os) {
    State const &multiSearchState = static_cast<State const &>(*state);
    int nAgents = multiSearchState.agentClusters_.size();
    int nTargets = multiSearchState.opponentClusters_.size();
    os << nAgents << " " << nTargets << " ";
    for(int x = 0; x < nAgents; x++){
      os << multiSearchState.agentClusters_[x] << " ";
    }
    for(int x = 0; x < nAgents; x++){
      for(int y = 0; y < nTargets+1; y++){
        os << (multiSearchState.searchStatus_[x][y] ? "1" : "0") << " ";
      }
    }
    for(int x = 0; x < nTargets; x++){
      os << multiSearchState.opponentClusters_[x]<< " ";
    }
    for(int x = 0; x < nTargets; x++){
      os << multiSearchState.foundStatus_[x] << " ";
    }
}

std::unique_ptr<solver::State> TextSerializer::loadState(std::istream &is) {
    int nAgents, nTargets, agent, opp, search, found;//, currentAction;
    is >> nAgents >> nTargets;
    std::vector<int> agentClusters;
    std::vector<std::vector<bool>> searchStatus;
    std::vector<bool> foundStatus;
    std::vector<int> opponentClusters;
    for(int x = 0; x < nAgents; x++){
      is >> agent;
      agentClusters.push_back(agent);
    }
    for(int x = 0; x < nAgents; x++){
      std::vector<bool> agentSearchStatus;
      for(int y = 0; y < nTargets+1; y++){
        is >> search;
        agentSearchStatus.push_back(search);
      }
      searchStatus.push_back(agentSearchStatus);
    }
    for(int x = 0; x < nTargets; x++){
      is >> opp;
      opponentClusters.push_back(opp);
    }
    for(int x = 0; x < nTargets; x++){
      is >> found;
      foundStatus.push_back(found);
    }
    // is >> currentAction;
    return std::make_unique<State>(agentClusters, searchStatus, opponentClusters, foundStatus);
}


void TextSerializer::saveObservation(solver::Observation const *obs,
        std::ostream &os) {
    if (obs == nullptr) {
        os << "()";
    } else {
        Observation const &observation = static_cast<Observation const &>(
                *obs);
        int nAgents = observation.agentClusters_.size();
        int nTargets = observation.searchStatus_[0].size()-1;
        os << "(" << nAgents << " " << nTargets;
        for(int x = 0; x < nAgents; x++){
          os << observation.agentClusters_[x] << " ";
        }
        for(int x = 0; x < nAgents; x++){
          for(int y = 0; y < nTargets+1; y++){
            os << observation.searchStatus_[x][y] << " ";
          }
        }
    }
}

std::unique_ptr<solver::Observation> TextSerializer::loadObservation(
        std::istream &is) {
    std::string obsString;
    std::getline(is, obsString, '(');
    std::getline(is, obsString, ')');
    if (obsString == "") {
        return nullptr;
    }
    int nAgents, nTargets;
    std::istringstream iss = std::istringstream(obsString);
    iss >> nAgents >> nTargets;
    std::vector<int> agentClusters;
    std::vector<std::vector<bool>> searchStatus;
    int robot, status;
    for(int x = 0; x < nAgents; x++){
      iss >> robot;
      agentClusters.push_back(robot);
    }
    for(int x = 0; x < nAgents; x++){
      std::vector<bool> agentSearchStatus;
      for(int y = 0; y < nTargets+1; y++){
        iss >> status;
        agentSearchStatus.push_back(status);
      }
      searchStatus.push_back(agentSearchStatus);
    }
    return std::make_unique<Observation>(agentClusters, searchStatus);
}


void TextSerializer::saveAction(solver::Action const *action,
        std::ostream &os) {
    if (action == nullptr) {
        os << "NULL";
        return;
    }
    Action const &a =
            static_cast<Action const &>(*action);
    int node = a.getAction();
    os << node;
}

std::unique_ptr<solver::Action> TextSerializer::loadAction(
        std::istream &is) {
    int node;
    is >> node;
        return std::make_unique<Action>(node);
}


int TextSerializer::getActionColumnWidth(){
    return 4;
}
int TextSerializer::getTPColumnWidth() {
    return 0;
}
int TextSerializer::getObservationColumnWidth() {
    return 30;
}
    } /* namespace multiSearch */
  }
}
