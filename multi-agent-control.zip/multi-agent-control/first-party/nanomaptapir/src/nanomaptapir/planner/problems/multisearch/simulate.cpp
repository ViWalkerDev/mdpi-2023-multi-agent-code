/** @file problems/multiSearch/simulate.cpp
 *
 * Defines the main method for the "simulate" executable for the  POMDP, which runs online
 * simulations to test the performance of the solver.
 */
#include <tapirsolver/problems/shared/simulate.hpp>

#include "nanomaptapir/planner/problems/multiSearch/Model.hpp"                 // for Model
#include "nanomaptapir/planner/problems/multiSearch/Options.hpp"               // for Options

/** The main method for the "simulate" executable for . */
int main(int argc, char const *argv[]) {
    return simulate<multiSearch::Model, multiSearch::Options>(argc, argv);
}
