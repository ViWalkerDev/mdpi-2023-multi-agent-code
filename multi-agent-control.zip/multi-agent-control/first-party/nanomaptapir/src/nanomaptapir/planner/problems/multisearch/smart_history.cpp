/** @file smart_history.cpp
 *
 * Contains the implementations for Data and DataTextSerializer.
 */
#include "nanomaptapir/planner/problems/multisearch/smart_history.hpp"

#include <iostream>
#include <sstream>

#include "nanomaptapir/planner/problems/multisearch/Action.hpp"
#include "nanomaptapir/planner/problems/multisearch/Observation.hpp"
#include "nanomaptapir/planner/problems/multisearch/Model.hpp"

#include "tapirsolver/solver/ActionNode.hpp"
#include "tapirsolver/solver/BeliefNode.hpp"

#include "tapirsolver/solver/abstract-problem/Action.hpp"
namespace nanomaptapir{
  namespace planner{
    namespace multisearch {
/* ---------------------- Data --------------------- */
Data::Data(Model *model, std::vector<int> agentClusters, std::vector<bool> clusterSearchStatus)://, std::set<int> searchedClusters) :
        model_(model),
        agentClusters_(agentClusters),
        clusterSearchStatus_(clusterSearchStatus){
        lastAction_ = 1;
        agentId_ = model_->agentId();
        lastCluster_ = agentClusters[agentId_];
        actionCompletion_ = true;
        //searchedClusters_(searchedClusters){
        //moveData_(model_->getMoveCounts()) {
}

Data::Data(Model *model, std::vector<int> agentClusters, 
                    std::vector<bool> clusterSearchStatus,
                    int lastAction,
                    int lastCluster,
                    bool actionCompletion,
                    int agentId)://, std::set<int> searchedClusters) :
        model_(model),
        agentClusters_(agentClusters),
        clusterSearchStatus_(clusterSearchStatus),
        lastAction_(lastAction),
        lastCluster_(lastCluster),
        actionCompletion_(actionCompletion),
        agentId_(agentId){
        // lastAction_ = -1;
        // agentId_ = model_->agentId();
        // lastCluster_ = agentClusters[agentId_];
        // actionCompletion_ = false;
        //searchedClusters_(searchedClusters){
        //moveData_(model_->getMoveCounts()) {
}

Data::Data(Data const &other) :
        model_(other.model_),
        agentClusters_(other.agentClusters_),
        clusterSearchStatus_(other.clusterSearchStatus_),
        //definition_(other.definition_),
        agentId_(other.agentId_),
        lastAction_(other.lastAction_),
        lastCluster_(other.lastCluster_),
        actionCompletion_(other.actionCompletion_)
        //boundaryNode_(other.boundaryNode_){
        //searchedClusters_(other.searchedClusters_){
        // moveData_(other.moveData_) {
{}

std::unique_ptr<solver::HistoricalData> Data::copy() const {
    return std::make_unique<Data>(*this);
}

std::unique_ptr<solver::HistoricalData> Data::createChild(
        solver::Action const &action, solver::Observation const &observation) const {
    Action const &bsAction = static_cast<Action const &>(action);
    Observation const &bsObservation = static_cast<Observation const &> (observation);
    std::unique_ptr<Data> nextData = (std::make_unique<Data>(*this));
    nextData->lastCluster_ = nextData->agentClusters_[agentId_];
    nextData->agentClusters_ = bsObservation.agentClusters();
    nextData->lastAction_ = bsAction.getAction();
    nextData->actionCompletion_ = false;
    if(nextData->lastAction_ == 0){
        //last action was to search
        if(bsObservation.searchStatus()[agentId_][0] == true){
            //We searched a cluster
            nextData->actionCompletion_ = true;
        }
    }else if(nextData->lastAction_ == 1){
        //We're waiting, this is always completed. 
        nextData->actionCompletion_ = true;
    }else if(nextData->lastAction_ > 1){
        //we wanted to move. Check if last cluster is not the same as new clsuter. 
        if(nextData->lastCluster_ != nextData->agentClusters_[agentId_]){
            //we have moved
            nextData->actionCompletion_ = true;
        }
    }
    // nextData->actionCompletion_ = bsObservation.actionCompletion();
    int agentIndex = 0;
    for(std::vector<bool> agentSearchStatus : bsObservation.searchStatus()){
        if(agentSearchStatus[0] == true){
            //search completed at cluster of agent (agentIndex);
            nextData->clusterSearchStatus_[agentClusters_[agentIndex]] = true;
        }
        agentIndex++;
    }
    // std::vector<bool> searchStatus = bsObservation.searchStatuses()
    // for(int x = 0; x < searchStatus.size(); x++){
    //   if(searchStatus[x] == true){
    //     nextData->searchedClusters_.insert(bsObservation.agentPosition(x));
    //   }
    // }
    // bool isLegal;
    // std::tie(nextData->position_, isLegal) = model_->getRobotMovedNode(position_,
    //         bsAction.getAction());
    // if (!isLegal) {
    //     debug::show_message("ERROR: An illegal action was taken!?");
    //     return std::move(nextData);
    // }
    //
    // if (rsAction.getActionType() == ActionType::SAMPLE) {
    //     int rockNo = model_->getCellType(position_) - Model::ROCK;
    //     nextData->allRockData_[rockNo].chanceGood = 0.0;
    //     nextData->allRockData_[rockNo].checkCount = 10;
    //     nextData->allRockData_[rockNo].goodnessNumber = -10;
    // } else if (rsAction.getActionType() == ActionType::CHECK) {
    //     int rockNo = rsAction.getRockNo();
    //
    //     GridPosition rockPos = model_->getRockPosition(rockNo);
    //     double distance = position_.euclideanDistanceTo(rockPos);
    //     double probabilityCorrect = (model_->getSensorCorrectnessProbability(distance));
    //     double probabilityIncorrect = 1 - probabilityCorrect;
    //
    //     Observation const &rsObs =
    //             (static_cast<Observation const &>(observation));
    //
    //     RockData &rockData = nextData->allRockData_[rockNo];
    //     rockData.checkCount++;
    //     double likelihoodGood = rockData.chanceGood;
    //     double likelihoodBad = 1 - rockData.chanceGood;
    //     if (rsObs.isGood()) {
    //         rockData.goodnessNumber++;
    //         likelihoodGood *= probabilityCorrect;
    //         likelihoodBad *= probabilityIncorrect;
    //     } else {
    //         rockData.goodnessNumber--;
    //         likelihoodGood *= probabilityIncorrect;
    //         likelihoodBad *= probabilityCorrect;
    //     }
    //     rockData.chanceGood = likelihoodGood / (likelihoodGood + likelihoodBad);
    // }
    return std::move(nextData);
}

std::vector<long> Data::generateLegalActions() const {
    std::vector<long> legalActions;
    for (std::unique_ptr<solver::DiscretizedPoint> const &action : model_->getAllActionsInOrder()) {
        Action const &bsAction = static_cast<Action const &>(*action);
        // if(bsAction.getAction() >= 0 && bsAction.getAction() < (model_->getNeighbourCount(agentClusters_[agentId_])+2)){
        //         legalActions.push_back(bsAction.getBinNumber());
        // }
        if(actionCompletion_ == false){
            if(bsAction.getAction() == lastAction_){
                legalActions.push_back(bsAction.getBinNumber());
            }
        }else{
            if(bsAction.getAction() == 0){
                if(clusterSearchStatus_[agentClusters_[agentId_]] == false){
                    legalActions.push_back(bsAction.getBinNumber());
                }
            }else if(bsAction.getAction() >= 1 && bsAction.getAction() < (model_->getNeighbourCount(agentClusters_[agentId_])+2)){
                legalActions.push_back(bsAction.getBinNumber());
            }
        }
    }
    return legalActions;
}

// std::vector<long> Data::generatePreferredActions() const {
//     std::vector<long> preferredActions;
//
//     int nRocks = model_->getNumberOfRocks();
//
//     // Check if we're currently on top of a rock.
//     int rockNo = model_->getCellType(position_) - Model::ROCK;
//     // If we are on top of a rock, and it has more +ve than -ve observations
//     // then we will sample it.
//     if (rockNo >= 0 && rockNo < nRocks) {
//         RockData const &rockData = allRockData_[rockNo];
//         if (rockData.chanceGood == 1.0 || rockData.goodnessNumber > 0) {
//             preferredActions.push_back(static_cast<long>(ActionType::SAMPLE));
//             return preferredActions;
//         }
//     }
//
//     bool worthwhileRockFound = false;
//     bool northWorthwhile = false;
//     bool southWorthwhile = false;
//     bool eastWorthwhile = false;
//     bool westWorthwhile = false;
//
//     // Check to see which rocks are worthwhile.
//     for (int i = 0; i < nRocks; i++) {
//         RockData const &rockData = allRockData_[i];
//         if (rockData.chanceGood != 0.0 && rockData.goodnessNumber >= 0) {
//             worthwhileRockFound = true;
//             GridPosition pos = model_->getRockPosition(i);
//             if (pos.i > position_.i) {
//                 southWorthwhile = true;
//             } else if (pos.i < position_.i) {
//                 northWorthwhile = true;
//             }
//
//             if (pos.j > position_.j) {
//                 eastWorthwhile = true;
//             } else if (pos.j < position_.j) {
//                 westWorthwhile = true;
//             }
//         }
//     }
//     // If no rocks are worthwhile head east.
//     if (!worthwhileRockFound) {
//         preferredActions.push_back(static_cast<long>(ActionType::EAST));
//         return preferredActions;
//     }
//
//     if (northWorthwhile) {
//         preferredActions.push_back(static_cast<long>(ActionType::NORTH));
//     }
//     if (southWorthwhile) {
//         preferredActions.push_back(static_cast<long>(ActionType::SOUTH));
//     }
//     if (eastWorthwhile) {
//         preferredActions.push_back(static_cast<long>(ActionType::EAST));
//     }
//     if (westWorthwhile) {
//         preferredActions.push_back(static_cast<long>(ActionType::WEST));
//     }
//
//     // See which rocks we might want to check
//     for (int i = 0; i < nRocks; i++) {
//         RockData const &rockData = allRockData_[i];
//         if (rockData.chanceGood != 0.0 && rockData.chanceGood != 1.0
//                 && std::abs(rockData.goodnessNumber) < 2) {
//             preferredActions.push_back(static_cast<long>(ActionType::CHECK) + i);
//         }
//     }
//     return preferredActions;
// }

void Data::print(std::ostream &os) const {
    // os << "Position: " << position_ << std::endl;
    // os << "Chances of goodness: ";
    // for (RockData const &rockData : allRockData_) {
    //     tapir::print_double(rockData.chanceGood, os, 6, 4);
    //     os << " ";
    // }
    // os << std::endl;
}

/* --------------------- PreferredActionsTextSerializer -------------------- */
void DataTextSerializer::saveHistoricalData(solver::HistoricalData const *data,
        std::ostream &os) {
    os << std::endl;
    os << "CUSTOM DATA:" << std::endl;
    Data const &prData = (static_cast<Data const &>(*data));
    os << prData.agentId_ << " " << prData.agentClusters_.size() << " " << prData.clusterSearchStatus_.size() 
    << " " << prData.lastAction_ << " " << (prData.actionCompletion_ ? 1 : 0) << " " << prData.lastCluster_;
    for(int x = 0; prData.agentClusters_.size(); x++){
        os << " " << prData.agentClusters_[x];
    }
    for(int x = 0; prData.clusterSearchStatus_.size(); x++){
        os << " " << (prData.clusterSearchStatus_[x] ? 1 : 0);
    }
      // //tapir::print_double(rockData.chanceGood, os, 7, 5);
      // os << " from " << rockData.checkCount << " checks ( ";
      // os << std::showpos << rockData.goodnessNumber << std::noshowpos;
      // os << " )" << std::endl;
    os << std::endl;
}
std::unique_ptr<solver::HistoricalData> DataTextSerializer::loadHistoricalData(
        std::istream &is) {

    std::string line;
    std::getline(is, line); // Blank line
    std::getline(is, line); // Header

    std::getline(is, line);
    std::istringstream iss = std::istringstream(line);
    int agentId, nAgents, nClusters, lastAction, actionCompletion, lastCluster, agentCluster, searchStatus;
    iss >> agentId >> nAgents >> nClusters >> lastAction >> actionCompletion >> lastCluster;
    std::vector<int> agentClusters;
    for(int x = 0; x < nAgents; x++){
        iss >> agentCluster;
        agentClusters.push_back(agentCluster);
    }
    std::vector<bool> clusterSearchStatus;
    for(int x = 0; x < nClusters; x++){
        iss >> searchStatus;
        clusterSearchStatus.push_back(searchStatus);
    }
    Model *model = dynamic_cast<Model *>(getModel());
    std::unique_ptr<Data> data = (std::make_unique<Data>(model, agentClusters,clusterSearchStatus, lastAction, lastCluster, actionCompletion, agentId));
    // for (RockData &rockData : data->allRockData_) {
    //     std::getline(is, line);
    //     std::istringstream sstr(line);
    //
    //     sstr >> tmpStr >> tmpStr >> rockData.chanceGood;
    //     sstr >> tmpStr >> rockData.checkCount >> tmpStr >> tmpStr;
    //     sstr >> rockData.goodnessNumber;
    // }

    std::getline(is, line); // Blank line

    return std::move(data);
}
} /* namespace multisearch */
}
}
