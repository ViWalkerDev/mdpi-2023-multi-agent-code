/** @file problems/multiSearch/solve.cpp
 *
 * Defines the main method for the "solve" executable for the  POMDP, which generates an
 * initial policy.
 */
#include <tapirsolver/problems/shared/solve.hpp>

#include "nanomap/planner/problems/multiSearch/Model.hpp"                 // for Model
#include "nanomap/planner/problems/multiSearch/Options.hpp"               // for Options

/** The main method for the "solve" executable for . */
int main(int argc, char const *argv[]) {
    return solve<multiSearch::Model, multiSearch::Options>(argc, argv);
}
