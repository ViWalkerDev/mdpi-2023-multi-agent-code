/** @file multiSearch/stest.cpp
 *
 * Defines the main method for the "stest" executable for the  POMDP, which tests the
 * serialization methods for  by deserializing and re-serializing a policy file.
 */
#include <tapirsolver/problems/shared/stest.hpp>

#include "nanomap/planner/problems/multiSearch/Model.hpp"                 // for Model
#include "nanomap/planner/problems/multiSearch/Options.hpp"               // for Options

/** The main method for the "stest" executable for . */
int main(int argc, char const *argv[]) {
    return stest<multiSearch::Model, multiSearch::Options>(argc, argv);
}
