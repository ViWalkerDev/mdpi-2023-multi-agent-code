/** @file Action.cpp
 *
 * Contains the implementations for the methods of the Action class.
 */
#include "nanomaptapir/planner/problems/singlesearch/Action.hpp"

#include <cstddef>                      // for size_t

#include <algorithm>                    // for copy
#include <iterator>                     // for ostream_iterator
#include <ostream>                      // for operator<<, ostream
#include <vector>                       // for vector, operator==, _Bit_const_iterator, _Bit_iterator_base, hash, vector<>::const_iterator

#include "tapirsolver/global.hpp"

//#include "tapirsolver/problems/shared/GridPosition.hpp"  // for GridPosition, operator==, operator<<
#include "tapirsolver/solver/abstract-problem/State.hpp"             // for State
namespace nanomaptapir{
  namespace planner{
    namespace singlesearch{

Action::Action(int neighbour) :
        action_(neighbour) {}

std::unique_ptr<solver::Action> Action::copy() const {
    return std::make_unique<Action>(action_);
}

double Action::distanceTo(solver::Action const &/*otherAction*/) const {
    return 0;
}

void Action::print(std::ostream &os) const {
    os << action_;
}

long Action::getBinNumber() const {
    return static_cast<long>(action_);
}
int Action::getAction() const {
    return action_;
}
    } /* namespace singleSearch */
  }
}
