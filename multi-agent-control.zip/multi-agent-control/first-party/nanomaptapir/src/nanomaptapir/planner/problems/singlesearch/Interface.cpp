/** @file Interface.cpp
 *
 * Contains Interface.
 */
#include "nanomaptapir/planner/problems/singlesearch/Interface.hpp"

#include <iostream>
#include <sstream>

namespace nanomaptapir {
	namespace planner {
		namespace singlesearch {



		} /* namespace tag */
	}
}
