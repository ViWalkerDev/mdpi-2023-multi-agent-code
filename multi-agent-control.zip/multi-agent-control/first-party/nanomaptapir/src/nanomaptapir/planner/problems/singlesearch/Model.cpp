/** @file Model.cpp
 *
 * Contains the implementations for the core functionality of the  POMDP.
 */
#include "nanomaptapir/planner/problems/singlesearch/Model.hpp"

#include <cmath>                        // for floor, pow
#include <cstddef>                      // for size_t
#include <cstdlib>                      // for exit

#include <memory>
#include <fstream>                      // for ifstream, basic_istream, basic_istream<>::__istream_type
#include <iomanip>                      // for operator<<, setw
#include <iostream>                     // for cout
#include <random>                       // for uniform_int_distribution, bernoulli_distribution
#include <unordered_map>                // for _Node_iterator, operator!=, unordered_map<>::iterator, _Node_iterator_base, unordered_map
#include <utility>                      // for make_pair, move, pair

#include "tapirsolver/global.hpp"                     // for RandomGenerator, make_unique
//#include "tapirsolver/problems/shared/GridPosition.hpp"  // for GridPosition, operator==, operator!=, operator<<
#include "tapirsolver/problems/shared/ModelWithProgramOptions.hpp"  // for ModelWithProgramOptions

#include "tapirsolver/solver/abstract-problem/Action.hpp"            // for Action
#include "tapirsolver/solver/abstract-problem/Model.hpp"             // for Model::StepResult, Model
#include "tapirsolver/solver/abstract-problem/Observation.hpp"       // for Observation
#include "tapirsolver/solver/abstract-problem/State.hpp"             // for State, operator<<, operator==

#include "tapirsolver/solver/changes/ChangeFlags.hpp"        // for ChangeFlags

#include "tapirsolver/solver/indexing/FlaggingVisitor.hpp"
#include "tapirsolver/solver/indexing/RTree.hpp"
#include "tapirsolver/solver/indexing/SpatialIndexVisitor.hpp"             // for State, operator<<, operator==

#include "tapirsolver/solver/mappings/actions/enumerated_actions.hpp"
#include "tapirsolver/solver/mappings/observations/discrete_observations.hpp"

#include "tapirsolver/solver/ActionNode.hpp"
#include "tapirsolver/solver/BeliefNode.hpp"
#include "tapirsolver/solver/StatePool.hpp"

//PROBLEM SPECIFIC INCLUDES
#include "nanomaptapir/planner/problems/singlesearch/Action.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Observation.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Options.hpp"
#include "nanomaptapir/planner/problems/singlesearch/State.hpp"                 // for State
#include "nanomaptapir/planner/problems/singlesearch/TextSerializer.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Definition.hpp"
//#include "position_history.hpp"
#include "nanomaptapir/planner/problems/singlesearch/smart_history.hpp"
#include "nanomaptapir/planner/problems/singlesearch/LegalActionsPool.hpp"

using std::cout;
using std::endl;
namespace nanomaptapir{
  namespace planner{
    namespace singlesearch{
UBParser::UBParser(Model *model) :
        model_(model) {
}
solver::HeuristicFunction UBParser::parse(solver::Solver */*solver*/, std::vector<std::string> /*args*/) {
    return [this] (solver::HistoryEntry const *, solver::State const *state,
            solver::HistoricalData const *) {
        return model_->getUpperBoundHeuristicValue(*state);
    };
}

Model::Model(RandomGenerator *randGen, std::unique_ptr<Options> options, std::shared_ptr<Definition> definition) :
            ModelWithProgramOptions("", randGen, std::move(options)),
            options_(const_cast<Options *>(static_cast<Options const *>(getOptions()))),
            definition_(definition),
            clusterSearchReward_(options_->clusterSearchReward_),
            clusterSearchScale_(options_->clusterSearchCost_),
            clusterMoveScale_(options_->clusterMoveCost_)
            {
              //
              options_->numberOfStateVariables = 4;
              definition_->setOptions(options_);
              definition_->initialiseQVals();
              nClusters_ = definition->nClusters_;
              initialCluster_ = definition_->initialCluster_;
              initialBoundary_ = definition_->initialBoundary_;
              initialOccupancy_ = definition_->initialOccupancy_;
              double minMove =  -(definition_->maxMoveCost()*clusterMoveScale_)/(1 - options_->discountFactor);
              double minSearch = -(definition_->maxSearchCost()*clusterSearchScale_)/(1 - options_->discountFactor);
              // double minMove =  -(definition_->maxMoveCost()*clusterSearchScale_)/(1 - options_->discountFactor);
              // double minSearch = -(definition_->maxSearchCost()*clusterMoveScale_)/(1 - options_->discountFactor);
              if(minMove <= minSearch){
                options_->minVal = minMove;
              }else{
                options_->minVal = minSearch;
              }
              options_->maxVal = clusterSearchReward_;
              nActions_ = definition_->maxConnections_+1;
              std::cout << "nActions " << nActions_ << std::endl;
              //definition_->generateQVals(options_->discountFactor);

    // Register the upper bound heuristic parser.
    registerHeuristicParser("upper", std::make_unique<UBParser>(this));
    // // Register the exact MDP heuristic parser.
    // registerHeuristicParser("exactMdp", std::make_unique<MdpParser>(this));

    initialize();
    if (options_->hasVerboseOutput) {
        cout << "Constructed the Model" << endl;
        cout << "Discount: " << options_->discountFactor << endl;
        cout << "ClusterSize: " << nClusters_ << endl;
        //cout << "move cost: " << maxMovePenalty_ << endl;
        cout << "nActions: " << nActions_ << endl;
        cout << "nStVars: " << options_->numberOfStateVariables << endl;
        cout << "minParticleCount: " << options_->minParticleCount << endl;
        cout << "Environment:" << endl << endl;
        //drawEnv(cout);
    }
}

// std::pair<float, bool> Model::getTransitDistance(int robotCluster, int action) {
//     return definition_->getTransitDistance(robotCluster, action);
// }

// int Model::getSearchCost(int node){
//   return maxOccupancy_[node];
// }

void Model::initialize() {
  std::cout << "initializing model" << std::endl;
  balanceInitFinished_ = false;
  // currentOccupancy_.resize(nClusters_);
  // for(int x = 0; x < nClusters_; x++){
  //   currentOccupancy_[x] = 0;
  // }
  targetParticleProportions_.resize(nClusters_);
  targetParticleCounts_.resize(nClusters_);
  currentParticleCounts_.resize(nClusters_);
  currentInitCluster_ = 0;
  // maxNodeOccupancy_ = 0;
  // for(int x = 0; x < nClusters_; x++){
  //   if(initialOccupancy_[x] > maxNodeOccupancy_){
  //     maxNodeOccupancy_ = initialOccupancy_[x];
  //   }
  // }
  totalClusterOccupancy_ = 0;
  for(int x = 0; x < nClusters_; x++){
    totalClusterOccupancy_ += initialOccupancy_[x];
    //targetParticleProportions_[x] = (float)initialOccupancy_[x]/(float)maxNodeOccupancy_;
  }
  for(int x = 0; x < nClusters_; x++){
    targetParticleProportions_[x] = (float)initialOccupancy_[x]/(float)totalClusterOccupancy_;
    targetParticleCounts_[x] = std::floor((targetParticleProportions_[x]*((float)(options_->minParticleCount))));
    currentParticleCounts_[x] = 0;
  }
  for(int x = 0; x < nClusters_; x++){
    std::cout << "targetPartCounts = " << targetParticleCounts_[x] << std::endl;
  }
  return;
}

int Model::randomEmptyCluster() {
    int cluster;
    //while (true) {
    cluster = std::uniform_int_distribution<int>(0, nClusters_ - 1)(
            *getRandomGenerator());
        //if (envMap_[pos.i][pos.j] == CellType::EMPTY) {
        //    break;
        //}
    //}
    return cluster;
}
// int Model::randomEmptyCluster() {
//     int cluster;
//     //while (true) {
//     cluster = std::uniform_int_distribution<int>(0, nClusters_ - 1)(
//             *getRandomGenerator());
//         //if (envMap_[pos.i][pos.j] == CellType::EMPTY) {
//         //    break;
//         //}
//     //}
//     return cluster;
// }
int Model::randomEmptyInitCluster() {
    int cluster;
    while (true) {
    cluster = std::uniform_int_distribution<int>(0, nClusters_ - 1)(
            *getRandomGenerator());
        //if (envMap_[pos.i][pos.j] == CellType::EMPTY) {
        //    break;
        //}
        if(initialOccupancy_[cluster]>0){
          break;
        }
    }
    return cluster;
}


/* --------------- The model interface proper ----------------- */
std::unique_ptr<solver::State> Model::sampleAnInitState(){
          // //return sampleStateInformed();
          // //std::cout << "test" << std::endl;
          // int opponentCluster;
          // if(balanceInitFinished_){
          //     opponentCluster = randomEmptyInitCluster();
          //     currentParticleCounts_[opponentCluster]++;
          // }else{
          //   bool valid = false;
          //   while(!valid){
          //     //std::cout << currentInitCluster_ << " / " << nClusters_<< std::endl;
          //     if(currentParticleCounts_[currentInitCluster_] >= targetParticleCounts_[currentInitCluster_]){
          //       currentInitCluster_++;
          //
          //       if(currentInitCluster_>=nClusters_){
          //         balanceInitFinished_ = true;
          //         opponentCluster = randomEmptyInitCluster();
          //         currentParticleCounts_[opponentCluster]++;
          //         valid = true;
          //       }
          //     }else{
          //       opponentCluster = currentInitCluster_;
          //       currentParticleCounts_[currentInitCluster_]++;
          //       valid = true;
          //     }
          //   }
          // }
          // //return sampleStateInformed();
          //
          // return sampleStateInformed(initialcluster_, opponentCluster, false, false);
          bool valid = false;
          int opponentCluster = 0;
          while(!valid){
            opponentCluster = std::uniform_int_distribution<int>(0, nClusters_ - 1)(
                        *getRandomGenerator());
            if(initialOccupancy_[opponentCluster]!=0){
              valid = true;
            }
          }
          return sampleStateInformed(initialCluster_, initialBoundary_, opponentCluster, false);
}

// void Model::sampleInitialStates(){
//    return;
// }
//
std::unique_ptr<solver::State> Model::sampleStateInformed(int robotCluster, int clusterBoundary, int opponentCluster, bool oppFound){
  return std::make_unique<State>(robotCluster, clusterBoundary, opponentCluster,  oppFound);
}
std::unique_ptr<solver::State> Model::sampleStateKnownRobotNode(int robotCluster, int clusterBoundary){
  int opponentCluster = randomEmptyCluster();
  //int opponentCluster = ;
  return std::make_unique<State>(robotCluster, clusterBoundary, opponentCluster, false);
}

std::unique_ptr<solver::State> Model::sampleStateUninformed() {
    //int robotCluster = definition_->randomEmptycluster();
    //int opponentCluster = definition_->randomEmptyCluster();
    int robotCluster = randomEmptyCluster();
    int randomBoundary = getRandomBoundary(robotCluster);
    int opponentCluster = randomEmptyCluster();
    return std::make_unique<State>(robotCluster, randomBoundary, opponentCluster, false);
}

int Model::getRandomBoundary(int cluster){
  int nBoundaries = definition_->getNumberOfBoundaries(cluster);
  int randomBoundary = std::uniform_int_distribution<int>(0, nBoundaries - 1)(
                        *getRandomGenerator());
  return randomBoundary;
}
// std::unique_ptr<solver::State> Model::sampleStateUninformedWithPriorClusterAndAction(int priorCluster, int actionInt) {
//     //int robotCluster = definition_->randomEmptycluster();
//     //int opponentCluster = definition_->randomEmptyCluster();
//     int robotCluster = definition_->getPotentialPriorClusters(priorCluster);
//     int opponentCluster = randomEmptyCluster();
//     return std::make_unique<State>(priorCluster, robotCluster, opponentCluster, false, false);
// }

bool Model::isTerminal(solver::State const &state) {
    return static_cast<State const &>(state).isFound();
}

bool Model::isValid(solver::State const &state) {
    State const singleSearchState = static_cast<State const &>(state);
    return definition_->isOpponentValid(singleSearchState.getOpponentCluster()) && definition_->isRobotValid(singleSearchState.getRobotCluster(), singleSearchState.getClusterBoundary());
}


/* -------------------- Black box dynamics ---------------------- */
std::pair<std::unique_ptr<State>, bool> Model::makeNextState(
        solver::State const &state, solver::Action const &action) {
    State const &singleSearchState = static_cast<State const &>(state);
    if (isTerminal(singleSearchState)) {
        return std::make_pair(std::make_unique<State>(singleSearchState), false);
    }

    Action const &singleSearchAction = static_cast<Action const &>(action);
    int robotCluster = singleSearchState.getRobotCluster();
    int clusterBoundary = singleSearchState.getClusterBoundary();
    int opponentCluster = singleSearchState.getOpponentCluster();
    int actionInt = singleSearchAction.getAction();
    int newRobotNode;
    bool isValid;
//    int newRobotNode = singleSearchAction.getAction();
    if(actionInt == 0){
      //Robot action is to search cluster
      if(robotCluster == opponentCluster){
        //Robot is searching and is in the correct cluster to find the agent.
        //However, there is a chance that another observation is required before the search is complete.
        //Thus we use a distribution to create searched and unsearched states
        //OLD CODE FROM MULTI
        // if(std::bernoulli_distribution(0.1)(*getRandomGenerator())){
        //   return std::make_pair(
        //           std::make_unique<State>(robotCluster,
        //                                                   opponentCluster,
        //                                                   false,
        //                                                   false),
        //                                                   true);
        // }else{
        //   return std::make_pair(
        return std::make_pair(
                  std::make_unique<State>(robotCluster,
                                                          clusterBoundary,
                                                            opponentCluster,
                                                            true),
                                                            true);
                    // }
      //}else{
        //Robot is searching but isn't in the correct cluster to find the agent.
        //There is still a chance that the search is incomplete at the time of another observation
        //So we still use a distribution to create searched and unsearched states.
        // return std::make_pair(
        //         std::make_unique<State>(robotCluster,
        //                                                 opponentCluster,
        //                                                 std::bernoulli_distribution(0.9)(*getRandomGenerator()),
        //                                                 false),
        //                                                 true);
      }else{
                return std::make_pair(
                  std::make_unique<State>(robotCluster,
                                                          clusterBoundary,
                                                            opponentCluster,
                                                            false),
                                                            true);
      }
    }else{
      //Robot action is to move to cluster neighbour according to action and last cluster (this informs the cost of movement)
      std::pair<int, int> newRobotClusterBoundary;
      bool valid;
      std::tie(newRobotClusterBoundary, valid) = getRobotMovedCluster(robotCluster, clusterBoundary, actionInt);
      return std::make_pair(
              std::make_unique<State>(newRobotClusterBoundary.first,
                                                      newRobotClusterBoundary.second,
                                                      opponentCluster,
                                                      false),
                                                      valid);
    }
  }
//     if(robotCluster == actionInt){
//       return std::make_pair(
//               std::make_unique<State>(robotCluster, opponentCluster, true, false), true);
//     }
//     std::tie(newRobotNode, isValid) = sampleRobotMovedNode(robotCluster, actionInt);
//     //
//     // if (newRobotNode == opponentCluster && newRobotNode == robotCluster) {
//     //     return std::make_pair(
//     //             std::make_unique<State>(newRobotNode, opponentCluster, true), true);
//     // }
//
//     //GridPosition newOpponentPos = sampleNextOpponentPosition(robotPos, opponentPos);
//     //GridPosition newRobotPos;
//     //bool wasValid;
//     //std::tie(newRobotPos, wasValid) = getMovedPos(robotPos, singleSearchAction.getActionType());
//     return std::make_pair(std::make_unique<State>(newRobotNode, opponentCluster, false, false), true);
// }

// std::vector<ActionType> Model::makeOpponentActions(
//         GridPosition const &robotPos, GridPosition const &opponentPos) {
//     std::vector<ActionType> actions;
//     if (robotPos.i > opponentPos.i) {
//         actions.push_back(ActionType::NORTH);
//         actions.push_back(ActionType::NORTH);
//     } else if (robotPos.i < opponentPos.i) {
//         actions.push_back(ActionType::SOUTH);
//         actions.push_back(ActionType::SOUTH);
//     } else {
//         actions.push_back(ActionType::NORTH);
//         actions.push_back(ActionType::SOUTH);
//     }
//     if (robotPos.j > opponentPos.j) {
//         actions.push_back(ActionType::WEST);
//         actions.push_back(ActionType::WEST);
//     } else if (robotPos.j < opponentPos.j) {
//         actions.push_back(ActionType::EAST);
//         actions.push_back(ActionType::EAST);
//     } else {
//         actions.push_back(ActionType::EAST);
//         actions.push_back(ActionType::WEST);
//     }
//     return actions;
// }

/** Generates a proper distribution for next opponent positions. */
// std::unordered_map<GridPosition, double> Model::getNextOpponentPositionDistribution(
//         GridPosition const &robotPos, GridPosition const &opponentPos) {
//     std::vector<ActionType> actions = makeOpponentActions(robotPos, opponentPos);
//     std::unordered_map<GridPosition, double> distribution;
//     double actionProb = (1 - opponentStayProbability_) / actions.size();
//     for (ActionType action : actions) {
//         distribution[getMovedPos(opponentPos, action).first] += actionProb;
//     }
//     distribution[opponentPos] += opponentStayProbability_;
//     return std::move(distribution);
// }

// GridPosition Model::sampleNextOpponentPosition(GridPosition const &robotPos,
//         GridPosition const &opponentPos) {
//     // Randomize to see if the opponent stays still.
//     if (std::bernoulli_distribution(opponentStayProbability_)(
//             *getRandomGenerator())) {
//         return opponentPos;
//     }
//     std::vector<ActionType> actions(makeOpponentActions(robotPos, opponentPos));
//     ActionType action = actions[std::uniform_int_distribution<long>(0,
//             actions.size() - 1)(*getRandomGenerator())];
//     return getMovedPos(opponentPos, action).first;
// }

// std::pair<GridPosition, bool> Model::getMovedPos(GridPosition const &position,
//         ActionType action) {
//     GridPosition movedPos = position;
//     switch (action) {
//     case ActionType::NORTH:
//         movedPos.i -= 1;
//         break;
//     case ActionType::EAST:
//         movedPos.j += 1;
//         break;
//     case ActionType::SOUTH:
//         movedPos.i += 1;
//         break;
//     case ActionType::WEST:
//         movedPos.j -= 1;
//         break;
//     case ActionType::GRAPHSEARCH:
//         break;
//     default:
//         std::ostringstream message;
//         message << "Invalid action: " << (long) action;
//         debug::show_message(message.str());
//         break;
//     }
//     bool wasValid = isValid(movedPos);
//     if (!wasValid) {
//         movedPos = position;
//     }
//     return std::make_pair(movedPos, wasValid);
// }

bool Model::isRobotValid(int const &position, int cluster) {
  return definition_->isRobotValid(position, cluster);
}

bool Model::isOpponentValid(int const &position) {
  return definition_->isOpponentValid(position);
}

std::pair<std::pair<int, int>, bool> Model::getRobotMovedCluster(int robotCluster, int boundary, int action){
  std::pair<int, int> newRobotClusterBoundary;
  bool valid;
  std::tie(newRobotClusterBoundary, valid) = definition_->getRobotMovedCluster(robotCluster, boundary, action);
  return std::make_pair(newRobotClusterBoundary, valid);
}

// std::pair<int, bool> Model::sampleRobotMovedCluster(int robotCluster, int action){
//   if(action == 0){
//     return std::pair<int, bool>(robotCluster, true);
//   }
//   if (std::bernoulli_distribution(0.1)(*getRandomGenerator())) {
//        return std::pair<int, bool>(robotCluster, true);
//   }
//   return getRobotMovedNode(robotCluster, action);
// }



std::unique_ptr<solver::Observation> Model::makeObservation(Action const &action, State const &nextState) {
    int actionInt = action.getAction();
    return std::make_unique<Observation>(nextState.getRobotCluster() == nextState.getOpponentCluster()
                                                        && actionInt == 0);
}

double Model::generateReward(solver::State const &state,
        solver::Action const &action,
        solver::TransitionParameters const */*tp*/,
        solver::State const */*nextState*/) {
    float nextReward = 0.0;
    State const &singleSearchState = static_cast<State const &>(state);
    Action const &singleSearchAction = static_cast<Action const &>(action);

    // if(singleSearchAction.getAction() != singleSearchState.currentAction()){
    //   if(singleSearchAction.getAction() == singleSearchState.getRobotNode()){
    //     //nextReward -= changePenalty_/2;
    //   }else{
    //     //nextReward -= changePenalty_;
    //   }
    // }
    int robotCluster = singleSearchState.getRobotCluster();
    int clusterBoundary = singleSearchState.getClusterBoundary();
    int actionInt = singleSearchAction.getAction();
    //std::cout << definition_->boundaryMap_[robotNode].size() << std::endl;
    //std::cout << actionInt << std::endl;
    // if((actionInt) > (definition_->boundaryMap_[robotNode].size()+1)){
    //   //std::cout << "reward  = -500" << std::endl;co
    //   return -100;
    // }
    int opponentCluster = singleSearchState.getOpponentCluster();
    if(actionInt == 0){
      nextReward -= definition_->getSearchCost(robotCluster)*clusterSearchScale_;

      if(opponentCluster == robotCluster){
        nextReward = clusterSearchReward_;
      }
      //  }else{
      //   nextReward -= clusterSearchCost_;
      //  }
    }else{
      // float step = definition_->getTransitDistance(robotNode, actionInt).first;
      // if(step < clusterSearchCost_){
      //   step = clusterSearchCost_+1.0;
      // }
      nextReward -= clusterMoveScale_*(definition_->getClusterMove(robotCluster, clusterBoundary, actionInt)).second;
    }
    //std::cout << "reward = " << nextReward << std::endl;
    return nextReward;
  }
    //


    // if(singleSearchState.isSearched()){
    //   if((singleSearchAction.getAction() == singleSearchState.currentAction())){
    //     nextReward -= searchPenalty_*3;
    //   }else{
    //     nextReward -= (float)getTransitDistance(singleSearchState.getRobotNode(), singleSearchAction.getAction());
    //   }
    // }else{
    //   if(singleSearchAction.getAction() == singleSearchState.currentAction()){
    //     if(singleSearchState.getRobotNode() == singleSearchAction.getAction()){
    //       nextReward -= searchPenalty_;
    //     }else{
    //       nextReward -= 1.0;
    //     }
    //     //nextReward -= (float)getTransitDistance(singleSearchState.getRobotNode(),getMovedPos(singleSearchState.getRobotNode(), singleSearchAction.getAction()).first);
    //   }else{
    //     nextReward -= (float)getTransitDistance(singleSearchState.getRobotNode(), singleSearchAction.getAction());
    //   }
    // }
    // //nextReward -= (float)getTransitDistance(singleSearchState.getRobotNode(), singleSearchAction.getAction());
    // //if(singleSearchState.getOpponentNode() == singleSearchAction.getAction()){
    // if(singleSearchState.getOpponentNode() == singleSearchState.getRobotNode() && singleSearchState.isSearched()){
    //   nextReward += singleSearchReward_;
    // }

//}

std::unique_ptr<solver::State> Model::generateNextState(
        solver::State const &state, solver::Action const &action,
        solver::TransitionParameters const */*tp*/) {
    return makeNextState(static_cast<State const &>(state), action).first;
}

std::unique_ptr<solver::Observation> Model::generateObservation(
        solver::State const */*state*/, solver::Action const &action,
        solver::TransitionParameters const */*tp*/,
        solver::State const &nextState) {
    return makeObservation(static_cast<Action const &>(action), static_cast<State const &>(nextState));
}

solver::Model::StepResult Model::generateStep(solver::State const &state,
        solver::Action const &action) {
    solver::Model::StepResult result;
    result.action = action.copy();
    std::unique_ptr<State> nextState = makeNextState(state, action).first;

    result.observation = makeObservation(static_cast<Action const &>(action), *nextState);
    result.reward = generateReward(state, action, nullptr, nullptr);
    result.isTerminal = isTerminal(*nextState);
    result.nextState = std::move(nextState);
    return result;
}


/* -------------- Methods for handling model changes ---------------- */
void Model::applyChanges(std::vector<std::unique_ptr<solver::ModelChange>> const &changes,
        solver::Solver *solver) {
    // solver::StatePool *pool = nullptr;
    // if (solver != nullptr) {
    //     pool = solver->getStatePool();
    // }
    //
    // solver::HeuristicFunction heuristic = getHeuristicFunction();
    // std::vector<double> allHeuristicValues;
    // if (pool != nullptr) {
    //     long nStates = pool->getNumberOfStates();
    //     allHeuristicValues.resize(nStates);
    //     for (long index = 0; index < nStates; index++) {
    //         allHeuristicValues[index] = heuristic(nullptr, pool->getInfoById(index)->getState(),
    //                 nullptr);
    //     }
    // }
    //
    // for (auto const &change : changes) {
    //     Change const &singleSearchChange = static_cast<Change const &>(*change);
    //     if (options_->hasVerboseOutput) {
    //         cout << singleSearchChange.changeType << " " << singleSearchChange.i0 << " "
    //                 << singleSearchChange.j0;
    //         cout << " " << singleSearchChange.i1 << " " << singleSearchChange.j1 << endl;
    //     }
    //
    //     CellType newCellType;
    //     if (singleSearchChange.changeType == "Add Obstacles") {
    //         newCellType = CellType::WALL;
    //     } else if (singleSearchChange.changeType == "Remove Obstacles") {
    //         newCellType = CellType::EMPTY;
    //     } else {
    //         cout << "Invalid change type: " << singleSearchChange.changeType;
    //         continue;
    //     }
    //
    //     for (long i = singleSearchChange.i0; i <= singleSearchChange.i1; i++) {
    //         for (long j = singleSearchChange.j0; j <= singleSearchChange.j1; j++) {
    //             envMap_[i][j] = newCellType;
    //         }
    //     }
    //
    //     if (pool == nullptr) {
    //         continue;
    //     }
    //
    //     solver::RTree *tree = static_cast<solver::RTree *>(pool->getStateIndex());
    //     if (tree == nullptr) {
    //         debug::show_message("ERROR: state index must be enabled to handle changes in !");
    //         std::exit(4);
    //     }
    //
    //     double iLo = singleSearchChange.i0;
    //     double iHi = singleSearchChange.i1;
    //     double iMx = nRows_ - 1.0;
    //
    //     double jLo = singleSearchChange.j0;
    //     double jHi = singleSearchChange.j1;
    //     double jMx = nCols_ - 1.0;
    //
    //     // Adding walls => any states where the robot or the opponent are in a wall must
    //     // be deleted.
    //     if (newCellType == CellType::WALL) {
    //         solver::FlaggingVisitor visitor(pool, solver::ChangeFlags::DELETED);
    //         // Robot is in a wall.
    //         tree->boxQuery(visitor,
    //                 {iLo, jLo, 0.0, 0.0, 0.0},
    //                 {iHi, jHi, iMx, jMx, 1.0});
    //         // Opponent is in a wall.
    //         tree->boxQuery(visitor,
    //                 {0.0, 0.0, iLo, jLo, 0.0},
    //                 {iMx, jMx, iHi, jHi, 1.0});
    //
    //     }
    //
    //     // Also, state transitions around the edges of the new / former obstacle must be revised.
    //     solver::FlaggingVisitor visitor(pool, solver::ChangeFlags::TRANSITION);
    //     tree->boxQuery(visitor,
    //             {iLo - 1, jLo - 1, 0.0, 0.0, 0.0},
    //             {iHi + 1, jHi + 1, iMx, jMx, 1.0});
    //     tree->boxQuery(visitor,
    //             {0.0, 0.0, iLo - 1, jLo - 1, 0.0},
    //             {iMx, jMx, iHi + 1, jHi + 1, 1.0});
    // }
    //
    // if (mdpSolver_ != nullptr) {
    //     mdpSolver_->solve();
    //}

    // calculatePairwiseDistances();
    //
    // // Check for heuristic changes.
    // if (pool != nullptr) {
    //     long nStates = pool->getNumberOfStates();
    //     for (long index = 0; index < nStates; index++) {
    //         double oldValue = allHeuristicValues[index];
    //         solver::StateInfo *info = pool->getInfoById(index);
    //         double newValue = heuristic(nullptr, info->getState(), nullptr);
    //         if (std::abs(newValue - oldValue) > 1e-5) {
    //             pool->setChangeFlags(info, solver::ChangeFlags::HEURISTIC);
    //         }
    //     }
    // }
}


/* ------------ Methods for handling particle depletion -------------- */
std::vector<std::unique_ptr<solver::State>> Model::generateParticles(
        solver::BeliefNode */*previousBelief*/, solver::Action const &action,
        solver::Observation const &obs,
        long nParticles,
        std::vector<solver::State const *> const &previousParticles) {
    std::vector<std::unique_ptr<solver::State>> newParticles;
    Observation const &observation =
            (static_cast<Observation const &>(obs));
    int actionInt =
            (static_cast<Action const &>(action).getAction());

    typedef std::unordered_map<State, double> WeightMap;
    WeightMap weights;
    double weightTotal = 0;
    //int newRobotCluster = observation.robotCluster();
    //int clusterBoundary = observation.clusterBoundary();
    //int newRobotCluster = dnewRobotNode);//actionInt;
    //std::cout << "generatingParticles" << std::endl;
    int oldRobotCluster = static_cast<State const *>(
            previousParticles[0])->getRobotCluster();
    int oldClusterBoundary = static_cast<State const *>(
            previousParticles[0])->getClusterBoundary();
    std::pair<int,int> newRobotClusterBoundary;
    bool valid; 
    std::tie(newRobotClusterBoundary, valid) = getRobotMovedCluster(oldRobotCluster, oldClusterBoundary,actionInt);
    if (observation.seesOpponent()) {
        // If we saw the opponent, we must be in the same place and have performed a search.
        newParticles.push_back(
                std::make_unique<State>(newRobotClusterBoundary.first, newRobotClusterBoundary.second, newRobotClusterBoundary.first, true));
    } else {
        // We didn't see the opponent, so we must be in different places OR we are in the same place but haven't performed a search.
        //IF we've performed a search
        if(actionInt == 0){
          for (solver::State const *state : previousParticles) {
              State const *singleSearchState = static_cast<State const *>(state);
              //int oldRobotCluster = singleSearchState->getRobotCluster();
              //int oldclusterBoundary = singleSearchState->getClusterBoundary();
              int oldOpponentCluster = singleSearchState->getOpponentCluster();
              // Ignore states that do not match knowledge of the robot's position.
              //if (newRobotNode != getRobotMovedNode(oldRobotNode, actionInt).first) {
              //  continue;
              // //}
              // if(newRobotNode != oldRobotNode || clusterBoundary != oldclusterBoundary){
              //   continue;
              // }
              // Get the probability distribution for opponent moves.
              //GridPosition oldOpponentPos(singleSearchState->getOpponentPosition());
              // std::unordered_map<GridPosition, double> opponentPosDistribution = (
              //         getNextOpponentPositionDistribution(oldRobotPos, oldOpponentPos));
              //
              // for (auto const &entry : opponentPosDistribution) {
              if(oldOpponentCluster != newRobotClusterBoundary.first) {
                State newState(newRobotClusterBoundary.first, newRobotClusterBoundary.second, oldOpponentCluster, false);
                weights[newState] += 1.0;
                weightTotal += 1.0;
              }
            }
          }else{
        //else We haven't performed a search, we've moved, so no opponent positions are removed from likelihood.
            for (solver::State const *state : previousParticles) {
                State const *singleSearchState = static_cast<State const *>(state);
                //int oldRobotCluster = singleSearchState->getRobotCluster();
                //int oldclusterBoundary = singleSearchState->getClusterBoundary();
                int oldOpponentCluster = singleSearchState->getOpponentCluster();
                // Ignore states that do not match knowledge of the robot's position.
                // if (clusterBoundary != oldRobotCluster) {
                //   continue;
                // }

                // Get the probability distribution for opponent moves.
                //GridPosition oldOpponentPos(singleSearchState->getOpponentPosition());
                // std::unordered_map<GridPosition, double> opponentPosDistribution = (
                //         getNextOpponentPositionDistribution(oldRobotPos, oldOpponentPos));
                //
                // for (auto const &entry : opponentPosDistribution) {
                //if(oldOpponentNode != newRobotNode) {
                  State newState(newRobotClusterBoundary.first, newRobotClusterBoundary.second, oldOpponentCluster, false);
                  weights[newState] += 1.0;
                  weightTotal += 1.0;
                //}
                // }
            }
          }
      }
        double scale = nParticles / weightTotal;
        for (WeightMap::iterator it = weights.begin(); it != weights.end();
                it++) {
            double proportion = it->second * scale;
            long numToAdd = static_cast<long>(proportion);
            if (std::bernoulli_distribution(proportion - numToAdd)(
                    *getRandomGenerator())) {
                numToAdd += 1;
            }
            for (int i = 0; i < numToAdd; i++) {
                newParticles.push_back(std::make_unique<State>(it->first));
            }
      }
    //std::cout << "particles generated " << std::endl;
    return newParticles;
}

std::vector<std::unique_ptr<solver::State>> Model::generateParticles(
        solver::BeliefNode *previousBelief, solver::Action const &action,
        solver::Observation const &obs, long nParticles) {
    std::vector<std::unique_ptr<solver::State>> newParticles;
    Observation const &observation =
            (static_cast<Observation const &>(obs));
    int actionInt =
            (static_cast<Action const &>(action).getAction());
    int oldRobotCluster = static_cast<State const &>(
            *previousBelief->getStates()[0]).getRobotCluster();
    int oldClusterBoundary = static_cast<State const &>(
            *previousBelief->getStates()[0]).getClusterBoundary();
    std::pair<int, int> newRobotClusterBoundary;
    bool valid;
    std::tie(newRobotClusterBoundary, valid) = getRobotMovedCluster(oldRobotCluster, oldClusterBoundary, actionInt);
    //int newRobotCluster = observation.robotCluster();
    //int newclusterBoundary = observation.clusterBoundary();
    
    if (observation.seesOpponent()) {
        // If we saw the opponent, we must be in the same place and will have performed a search and our past cluster is our current cluster
        while ((long)newParticles.size() < nParticles) {
            newParticles.push_back(
                std::make_unique<State>(newRobotClusterBoundary.first, newRobotClusterBoundary.second,newRobotClusterBoundary.first, true)
              );
        }
    } else {
      if(actionInt == 0){
        //We searched, but did not see the opponent, it could be anywhere except where we just searched
        while((long)newParticles.size()<nParticles){
          int opponent = randomEmptyCluster();
          if(opponent != newRobotClusterBoundary.first){
            newParticles.push_back(
                std::make_unique<State>(newRobotClusterBoundary.first, newRobotClusterBoundary.second, opponent, false)
              );
          }
        }
      }else{
        //We didn't search, it could be anywhere. 
      while ((long)newParticles.size() < nParticles) {
          int opponent = randomEmptyCluster();
          newParticles.push_back(
            std::make_unique<State>(newRobotClusterBoundary.first, newRobotClusterBoundary.second, opponent, false)
          );
          //solver::Model::StepResult result = generateStep(*state, action);
          //if (obs == *result.observation) {
          //    newParticles.push_back(std::move(result.nextState));
        }  //}
      }
    }
    return newParticles;
}


/* --------------- Pretty printing methods ----------------- */
void Model::dispCell(std::ostream &os) {
    // switch (cellType) {
    // case CellType::EMPTY:
    //     os << " 0";
    //     break;
    // case CellType::WALL:
    //     os << "XX";
    //     break;
    // default:
    //     os << "ER";
    //     break;
    // }
}

void Model::drawEnv(std::ostream &os) {
    // for (std::vector<CellType> &row : envMap_) {
    //     for (CellType cellType : row) {
    //         dispCell(cellType, os);
    //         os << " ";
    //     }
    //     os << endl;
    // }
}


void Model::drawSimulationState(solver::BeliefNode const *belief,
        solver::State const &state, std::ostream &os) {
             State const &singleSearchState = static_cast<State const &>(state);
             std::vector<solver::State const *> particles = belief->getStates();
             std::vector<long> particleCounts(nClusters_);
             std::vector<long> positionCounts(nClusters_);
             //std::vector<long> boundaryCounts(nClusters_);
             int invalidCounts = 0;
             int particleCount = 0;
             for (solver::State const *particle : particles) {
                  particleCount++;
                  int opponentCluster =
                          static_cast<State const &>(*particle).getOpponentCluster();
                  if(opponentCluster < 0 || opponentCluster >= nClusters_){
                    invalidCounts++;
                  }
                  particleCounts[opponentCluster] += 1;
                  int robotPosition =
                          static_cast<State const &>(*particle).getRobotCluster();
                  //if(definition_->getBoundaryCluster(robotPosition) != 7){
                  //  os << definition_->getBoundaryCluster(robotPosition) << endl;
                  //}
                  positionCounts[robotPosition] += 1;
                  //boundaryCounts[robotPosition] += 1;
             }

            // int robotCluster = singleSearchState.getRobotNode();
            // int opponentCluster = singleSearchState.getOpponentCluster();
            os << "particleCount = " << particleCount << endl;
            os << "invalidCounts = " << invalidCounts << endl;
             for(int x = 0; x < nClusters_; x++){
               os << "Cluster "<< x << "(" << particleCounts[x]<<")" << "(" << positionCounts[x]<<")" ;
               //if(opponentCluster == x){
              //   os << "(Op)";
              // }else{
              //   os << "(--)";
              // }
              // if(robotCluster == x){
            //     os << "(Rb)";
            //   }else{
            //     os << "(--)";
            //   }
               os << endl;
             }

            //   for(int x = 0; x < nclusters_; x++){
            //     os << "cluster "<< x << "(" << boundaryCounts[x]<<")";
            //     //if(opponentCluster == x){
            //    //   os << "(Op)";
            //    // }else{
            //    //   os << "(--)";
            //    // }
            //    // if(robotCluster == x){
            //  //     os << "(Rb)";
            //  //   }else{
            //  //     os << "(--)";
            //  //   }
            //     os << endl;
            //   }
    //
    // std::vector<int> colors { 196, 161, 126, 91, 56, 21, 26, 31, 36, 41, 46 };
    // if (options_->hasColorOutput) {
    //     os << "Color map: ";
    //     for (int color : colors) {
    //         os << "\033[38;5;" << color << "m";
    //         os << '*';
    //         os << "\033[0m";
    //     }
    //     os << endl;
    // }
    // for (std::size_t i = 0; i < envMap_.size(); i++) {
    //     for (std::size_t j = 0; j < envMap_[0].size(); j++) {
    //         double proportion = (double) particleCounts[i][j]
    //                 / particles.size();
    //         if (options_->hasColorOutput) {
    //             if (proportion > 0) {
    //                 int color = colors[proportion * (colors.size() - 1)];
    //                 os << "\033[38;5;" << color << "m";
    //             }
    //         }
    //         GridPosition pos(i, j);
    //         bool hasRobot = (pos == singleSearchState.getRobotPosition());
    //         bool hasOpponent = (pos == singleSearchState.getOpponentPosition());
    //         if (hasRobot) {
    //             if (hasOpponent) {
    //                 os << "#";
    //             } else {
    //                 os << "r";
    //             }
    //         } else if (hasOpponent) {
    //             os << "o";
    //         } else {
    //             if (envMap_[i][j] == CellType::WALL) {
    //                 os << "X";
    //             } else {
    //                 os << ".";
    //             }
    //         }
    //         if (options_->hasColorOutput) {
    //             os << "\033[0m";
    //         }
    //     }
    //     os << endl;
    // }
}


/* ---------------------- Basic customizations  ---------------------- */
double Model::getDefaultHeuristicValue(solver::HistoryEntry const */*entry*/,
            solver::State const *state, solver::HistoricalData const */*data*/) {
    State const &singleSearchState = static_cast<State const &>(*state);
    if (isTerminal(singleSearchState)) {
        return 0;
    }
    int robotCluster = singleSearchState.getRobotCluster();
    int clusterBoundary = singleSearchState.getClusterBoundary();
    int opponentCluster = singleSearchState.getOpponentCluster();
    //double nSteps;
    //double dist;
    //double qVal = (definition_->getDefaultQVal(robotCluster, opponentCluster));
    //std::vector<double> solutionCosts = definition_->getOptimalSolutionCosts(robotCluster, clusterBoundary, opponentCluster);
    //double nSteps = definition_->getTransitSteps(robotCluster, opponentCluster);
    //std::cout << "default "<< nSteps << std::endl;
    //double nSteps = dist / opponentStayProbability_;
    //double finalDiscount = 
    //double finalDiscount = std::pow(options_->discountFactor, nSteps);
    //double qVal = -clusterMoveCost_  * (1 - finalDiscount) / (1 - options_->discountFactor);
    //qVal += finalDiscount * clusterSearchReward_;
    return definition_->getDefaultQVal(robotCluster, clusterBoundary, opponentCluster);
}

double Model::getUpperBoundHeuristicValue(solver::State const &state) {
    State const &singleSearchState = static_cast<State const &>(state);
    if (isTerminal(singleSearchState)) {
        return 0;
    }
    int robotCluster = singleSearchState.getRobotCluster();
    int clusterBoundary = singleSearchState.getClusterBoundary();
    int opponentCluster = singleSearchState.getOpponentCluster();
    //double nSteps;
    //double dist;
    //double qVal = (definition_->getDefaultQVal(robotCluster, opponentCluster));
    //std::vector<double> solutionCosts = definition_->getOptimalSolutionCosts(robotCluster, clusterBoundary, opponentCluster);
    //double nSteps = definition_->getTransitSteps(robotCluster, opponentCluster);
    //std::cout << "default "<< nSteps << std::endl;
    //double nSteps = dist / opponentStayProbability_;
    //double finalDiscount = 
    //double finalDiscount = std::pow(options_->discountFactor, nSteps);
    //double qVal = -clusterMoveCost_  * (1 - finalDiscount) / (1 - options_->discountFactor);
    //qVal += finalDiscount * clusterSearchReward_;
    return definition_->getDefaultQVal(robotCluster, clusterBoundary, opponentCluster);
}
//
// std::unique_ptr<RockSampleAction> RockSampleModel::getRandomAction() {
//     long binNumber = std::uniform_int_distribution<int>(0, 4 + nRocks_)(*getRandomGenerator());
//     return std::make_unique<RockSampleAction>(binNumber);
// }
std::unique_ptr<Action> Model::getRandomAction(std::vector<long> binNumbers) {
    if (binNumbers.empty()) {
        return nullptr;
    }
    long index = std::uniform_int_distribution<int>(0, binNumbers.size() - 1)(
            *getRandomGenerator());
    return std::make_unique<Action>(binNumbers[index]);
}

std::unique_ptr<solver::Action> Model::getRolloutAction(
        solver::HistoryEntry const */*entry*/, solver::State const * /*state*/,
        solver::HistoricalData const *data) {

    return getRandomAction(static_cast<Data const &>(*data).generateLegalActions());
    // if (rolloutCategory_ == RSActionCategory::ALL) {
    //     return getRandomAction();
    // } else if (rolloutCategory_ == RSActionCategory::LEGAL) {
    //     if (heuristicType_ == RSActionCategory::LEGAL) {
    //         return getRandomAction(static_cast<PositionData const &>(*data).generateLegalActions());
    //     } else if (heuristicType_ == RSActionCategory::PREFERRED) {
    //         return getRandomAction(
    //                 static_cast<PositionAndRockData const &>(*data).generateLegalActions());
    //     }
    // } else {
    //     return getRandomAction(
    //             static_cast<PositionAndRockData const &>(*data).generatePreferredActions());
    // }
    // return nullptr;
}

std::unique_ptr<solver::HistoricalData> Model::createRootHistoricalData() {
    //switch (heuristicType_) {
    //case RSActionCategory::LEGAL:
        return std::make_unique<Data>(this, initialCluster_, initialBoundary_, definition_);
    //case RSActionCategory::PREFERRED:
    //    return std::make_unique<PositionAndRockData>(this, getStartPosition());
    //default:
    //    return nullptr;
    //}
}

/* ------- Customization of more complex solver functionality  --------- */
std::vector<std::unique_ptr<solver::DiscretizedPoint>> Model::getAllActionsInOrder() {
    std::vector<std::unique_ptr<solver::DiscretizedPoint>> allActions;
    //std::cout << "getALLACTIONS NUM ACTIONS " << nActions_ << std::endl;
    for (int code = 0; code < nActions_; code++) {
        allActions.push_back(std::make_unique<Action>(code));
    }
    return allActions;
}

std::vector<float> Model::getBeliefProportions(solver::BeliefNode const *belief) {
    std::vector<solver::State const *> particles = belief->getStates();
    std::vector<float> particleCounts(nClusters_);
    for (solver::State const *particle : particles) {
        int targetNode = static_cast<State const &>(*particle).getOpponentCluster();
        particleCounts[targetNode] += 1;
    }

    std::vector<float> result;
    for (std::size_t i = 0; i < nClusters_; i++) {
        //result.push_back(std::vector<float>());
        //for (std::size_t j = 0; j < envMap_[0].size(); j++) {
        result.push_back(particleCounts[i]/((float)particles.size()));
        //}
    }
    return result;
}

std::unique_ptr<solver::ActionPool> Model::createActionPool(solver::Solver */*solver*/) {
  return std::make_unique<LegalActionsPool>(this);
    //return std::make_unique<solver::EnumeratedActionPool>(this, getAllActionsInOrder());
}
std::unique_ptr<solver::Serializer> Model::createSerializer(solver::Solver *solver) {
    return std::make_unique<TextSerializer>(solver);
}
} /* namespace singleSearch */
}
}
