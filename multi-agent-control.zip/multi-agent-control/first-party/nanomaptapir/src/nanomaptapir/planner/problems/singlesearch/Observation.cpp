/** @file Observation.cpp
 *
 * Contains the implementations for the methods of Observation.
 */
#include "nanomaptapir/planner/problems/singlesearch/Observation.hpp"

#include <cstddef>                      // for size_t

#include <algorithm>                    // for copy
#include <iterator>                     // for ostream_iterator
#include <ostream>                      // for operator<<, ostream
#include <vector>                       // for vector, operator==, _Bit_const_iterator, _Bit_iterator_base, hash, vector<>::const_iterator

#include "tapirsolver/global.hpp"

#include "tapirsolver/problems/shared/GridPosition.hpp"  // for GridPosition, operator==, operator<<
#include "tapirsolver/solver/abstract-problem/Observation.hpp"             // for Observation

#include "nanomaptapir/planner/problems/singlesearch/Model.hpp"
namespace nanomaptapir{
  namespace planner{
    namespace singlesearch{
Observation::Observation(bool _seesOpponent) :
                    seesOpponent_(_seesOpponent) {
}
std::unique_ptr<solver::Observation>
Observation::copy() const {
    return std::make_unique<Observation>(seesOpponent_);
}

double Observation::distanceTo(
        solver::Observation const &otherObs) const {
    Observation const &other =
            static_cast<Observation const &>(otherObs);
    return seesOpponent_ == other.seesOpponent_ ? 0 : 1;
}

bool Observation::equals(
        solver::Observation const &otherObs) const {
    Observation const &other =
        static_cast<Observation const &>(otherObs);
    return seesOpponent_ == other.seesOpponent_;
}

std::size_t Observation::hash() const {
    std::size_t hashValue = 0;
    //tapir::hash_combine(hashValue, robotCluster_);
    //tapir::hash_combine(hashValue, clusterBoundary_);
    //tapir::hash_combine(hashValue, searched_);
    tapir::hash_combine(hashValue, seesOpponent_);
    return hashValue;
}

void Observation::print(std::ostream &os) const {
    //os << robotCluster_;
    //os << clusterBoundary_;
    // if(searched_){
    //   os << "SEARCHED";
    // } else{
    //   os << "UNSEARCHED";
    // }
    if (seesOpponent_) {
        os << "SEEN";
    } else {
        os << "UNSEEN";
    }
}

// GridPosition Observation::getPosition() const {
//     return position_;
// }

// int Observation::robotCluster() const {
//   return robotCluster_;
// }
// int Observation::clusterBoundary() const {
//   return clusterBoundary_;
// }

// bool Observation::searched() const {
//   return searched_;
// }

bool Observation::seesOpponent() const {
    return seesOpponent_;
}

    }
  }
}
/* namespace singleSearch */
