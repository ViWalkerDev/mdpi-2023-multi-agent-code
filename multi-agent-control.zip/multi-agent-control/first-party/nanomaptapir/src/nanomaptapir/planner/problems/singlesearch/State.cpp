/** @file State.cpp
 *
 * Contains the implementation for the methods of State.
 */
#include "nanomaptapir/planner/problems/singlesearch/State.hpp"

#include <cstddef>                      // for size_t

#include <functional>   // for hash
#include <ostream>                      // for operator<<, ostream, basic_ostream>
#include <vector>

#include "tapirsolver/global.hpp"
//#include "tapirsolver/problems/shared/GridPosition.hpp"  // for GridPosition, operator==, operator<<
#include "tapirsolver/solver/abstract-problem/State.hpp"             // for State

namespace nanomaptapir{
  namespace planner{
    namespace singlesearch{
State::State(int robotCluster, int clusterBoundary, int opponentCluster,
                                            bool isFound/*, int _currentAction*/) :
    solver::Vector(),
    robotCluster_(robotCluster),
    clusterBoundary_(clusterBoundary),
    opponentCluster_(opponentCluster),//{//,
    isFound_(isFound){
    // currentAction_(_currentAction) {
}

State::State(State const &other) :
        State(other.robotCluster_, other.clusterBoundary_, other.opponentCluster_,  other.isFound_){///*, other.currentAction_*/) {
}

std::unique_ptr<solver::State> State::copy() const {
    return std::make_unique<State>(robotCluster_, clusterBoundary_, opponentCluster_, isFound_/*, currentAction_*/);
}

double State::distanceTo(solver::State const &otherSolverState) const {
    State const &otherState = static_cast<State const &>(otherSolverState);
    double distance = (robotCluster_ == otherState.robotCluster_) ? 0 : 1;
    distance += (clusterBoundary_ == otherState.clusterBoundary_) ? 0 : 1;
    distance += (opponentCluster_ == otherState.opponentCluster_) ? 0 : 1;
    // distance += (isSearched_ == otherState.isSearched_) ? 0 : 1;
    distance += (isFound_ == otherState.isFound_) ? 0 : 1;
    // distance += (currentAction_ == otherState.currentAction_) ? 0 : 1;
    return distance;
}

bool State::equals(solver::State const &otherSolverState) const {
    State const &otherState = static_cast<State const &>(otherSolverState);
    return (robotCluster_ == otherState.robotCluster_
            && clusterBoundary_ == otherState.clusterBoundary_
            && opponentCluster_ == otherState.opponentCluster_//);
            && isFound_ == otherState.isFound_);
            // && currentAction_ == otherState.currentAction_);
}

std::size_t State::hash() const {
    std::size_t hashValue = 0;
    tapir::hash_combine(hashValue, robotCluster_);
    tapir::hash_combine(hashValue, clusterBoundary_);
    tapir::hash_combine(hashValue, opponentCluster_);
    tapir::hash_combine(hashValue, isFound_);
    // tapir::hash_combine(hashValue, currentAction_);
    return hashValue;
}

std::vector<double> State::asVector() const {
    std::vector<double> vec(4);
    vec[0] = robotCluster_;
    vec[1] = clusterBoundary_;
    vec[2] = opponentCluster_;
    vec[3] = isFound_ ? 1 : 0;
    // vec[3] = currentAction_;
    return vec;
}

void State::print(std::ostream &os) const {
    os << "ROBOT: " << robotCluster_ << " PREVIOUS: " << clusterBoundary_ << " OPPONENT: " << opponentCluster_;
    if (isFound_) {
        os << " FOUND!";
    }
    // os << "CURRENT ACTION: " << currentAction_ ;
}


int State::getRobotCluster() const {
    return robotCluster_;
}


int State::getClusterBoundary() const {
    return clusterBoundary_;
}

int State::getOpponentCluster() const {
    return opponentCluster_;
}

// int State::currentAction() const {
//     return currentAction_;
// }
//
// bool State::isSearched() const {
//     return isSearched_;
// }
bool State::isFound() const {
    return isFound_;
}
    } /* namespace singleSearch */
  }
}
