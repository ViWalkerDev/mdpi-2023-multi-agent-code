/** @file TextSerializer.cpp
 *
 * Contains the implementations of the serialization methods for .
 */
#include "nanomaptapir/planner/problems/singlesearch/TextSerializer.hpp"

#include <iostream>                     // for operator<<, basic_ostream, basic_ostream<>::__ostream_type, basic_istream<>::__istream_type

#include "tapirsolver/global.hpp"                     // for make_unique
#include "tapirsolver/problems/shared/GridPosition.hpp"  // for GridPosition
#include "tapirsolver/solver/abstract-problem/Action.hpp"
#include "tapirsolver/solver/abstract-problem/Observation.hpp"
#include "tapirsolver/solver/abstract-problem/State.hpp"             // for State
#include "tapirsolver/solver/serialization/TextSerializer.hpp"    // for TextSerializer

#include "tapirsolver/solver/mappings/actions/enumerated_actions.hpp"
#include "tapirsolver/solver/mappings/observations/discrete_observations.hpp"

#include "nanomaptapir/planner/problems/singlesearch/Action.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Model.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Observation.hpp"
#include "nanomaptapir/planner/problems/singlesearch/State.hpp"                 // for State

namespace solver {
class Solver;
} /* namespace solver */
namespace nanomaptapir{
  namespace planner{
    namespace singlesearch{
void saveVector(std::vector<long> values, std::ostream &os) {
    os << "(";
    for (auto it = values.begin(); it != values.end(); it++) {
        os << *it;
        if ((it + 1) != values.end()) {
            os << ", ";
        }
    }
    os << ")";
}

std::vector<long> loadVector(std::istream &is) {
    std::vector<long> values;
    std::string tmpStr;
    std::getline(is, tmpStr, '(');
    std::getline(is, tmpStr, ')');
    std::istringstream sstr(tmpStr);
    while (std::getline(sstr, tmpStr, ',')) {
        long value;
        std::istringstream(tmpStr) >> value;
        values.push_back(value);
    }
    return values;
}

TextSerializer::TextSerializer(solver::Solver *solver) :
    solver::Serializer(solver) {
}

/* ------------------ Saving change sequences -------------------- */
void TextSerializer::saveModelChange(solver::ModelChange const &change, std::ostream &os) {
    Change const &singleSearchChange = static_cast<Change const &>(change);
}
std::unique_ptr<solver::ModelChange> TextSerializer::loadModelChange(std::istream &is) {
    std::unique_ptr<Change> change = std::make_unique<Change>();
    return std::move(change);
}

void TextSerializer::saveState(solver::State const *state, std::ostream &os) {
    State const &singleSearchState = static_cast<State const &>(*state);
    os << singleSearchState.robotCluster_ << " "
       << singleSearchState.clusterBoundary_ << " "
       << singleSearchState.opponentCluster_ << " "
    //    << (singleSearchState.isSearched_ ? "S" : "_") << " "
       << (singleSearchState.isFound_ ? "F" : "_") << " ";
       // << singleSearchState.currentAction_;
}

std::unique_ptr<solver::State> TextSerializer::loadState(std::istream &is) {
    int robot, prev, opp;//, currentAction;
    is >> robot >> prev >>  opp;
    int robotCluster = robot;
    int clusterBoundary = prev;
    int oppNode = opp;
    // std::string searchedString;
    // is >> searchedString;
    // bool searched = (searchedString == "S");

    std::string opponentFoundString;
    is >> opponentFoundString;
    bool opponentFound = (opponentFoundString == "F");
    // is >> currentAction;
    return std::make_unique<State>(robotCluster, clusterBoundary, oppNode, opponentFound);
}


void TextSerializer::saveObservation(solver::Observation const *obs,
        std::ostream &os) {
    if (obs == nullptr) {
        os << "()";
    } else {
        Observation const &observation = static_cast<Observation const &>(
                *obs);
        os << "(" << (observation.seesOpponent_ ? "SEEN" : "UNSEEN") << ")";
    }
}

std::unique_ptr<solver::Observation> TextSerializer::loadObservation(
        std::istream &is) {
    std::string obsString;
    std::getline(is, obsString, '(');
    std::getline(is, obsString, ')');
    if (obsString == "") {
        return nullptr;
    }
    std::string searchStr, seenStr;
    //int robotCluster;
    //int clusterBoundary;
    std::istringstream(obsString)>> seenStr;
    //bool searched = searchStr=="SEARCHED";
    bool seesOpponent = seenStr == "SEEN";
    return std::make_unique<Observation>(seesOpponent);
}


void TextSerializer::saveAction(solver::Action const *action,
        std::ostream &os) {
    if (action == nullptr) {
        os << "NULL";
        return;
    }
    Action const &a =
            static_cast<Action const &>(*action);
    int node = a.getAction();
    os << node;
}

std::unique_ptr<solver::Action> TextSerializer::loadAction(
        std::istream &is) {
    int node;
    is >> node;
        return std::make_unique<Action>(node);
}


int TextSerializer::getActionColumnWidth(){
    return 4;
}
int TextSerializer::getTPColumnWidth() {
    return 0;
}
int TextSerializer::getObservationColumnWidth() {
    return 8;
}
    } /* namespace singleSearch */
  }
}
