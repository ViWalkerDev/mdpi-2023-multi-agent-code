/** @file smart_history.cpp
 *
 * Contains the implementations for Data and DataTextSerializer.
 */
#include "nanomaptapir/planner/problems/singlesearch/smart_history.hpp"

#include <iostream>
#include <sstream>



#include "tapirsolver/solver/ActionNode.hpp"
#include "tapirsolver/solver/BeliefNode.hpp"

#include "tapirsolver/solver/abstract-problem/Action.hpp"
namespace nanomaptapir{
  namespace planner{
    namespace singlesearch {
/* ---------------------- Data --------------------- */
Data::Data(Model *model, int cluster, int boundary, std::shared_ptr<Definition> definition) :
        model_(model),
        cluster_(cluster),
        boundary_(boundary),
        definition_(definition){
        //moveData_(model_->getMoveCounts()) {
}

Data::Data(Data const &other) :
        model_(other.model_),
        cluster_(other.cluster_),
        boundary_(other.boundary_),
        definition_(other.definition_){
        // moveData_(other.moveData_) {
}

std::unique_ptr<solver::HistoricalData> Data::copy() const {
    return std::make_unique<Data>(*this);
}

std::unique_ptr<solver::HistoricalData> Data::createChild(
        solver::Action const &action, solver::Observation const &observation) const {
    Action const &bsAction = static_cast<Action const &>(action);
    Observation const &bsObservation = static_cast<Observation const &> (observation);
    std::unique_ptr<Data> nextData = (std::make_unique<Data>(*this));
    
    std::tie(nextData->cluster_, nextData->boundary_) = 
                        definition_->getClusterMove(cluster_, boundary_, bsAction.getAction()).first;//bsObservation.robotCluster();
    //nextData->cluster_ = definition_->getClusterMove(cluster_, 0, bsAction.getAction()).first.first;//bsObservation.robotCluster();
    //nextData->boundary_ 
    // bool isLegal;
    // std::tie(nextData->position_, isLegal) = model_->getRobotMovedNode(position_,
    //         bsAction.getAction());
    // if (!isLegal) {
    //     debug::show_message("ERROR: An illegal action was taken!?");
    //     return std::move(nextData);
    // }
    //
    // if (rsAction.getActionType() == ActionType::SAMPLE) {
    //     int rockNo = model_->getCellType(position_) - Model::ROCK;
    //     nextData->allRockData_[rockNo].chanceGood = 0.0;
    //     nextData->allRockData_[rockNo].checkCount = 10;
    //     nextData->allRockData_[rockNo].goodnessNumber = -10;
    // } else if (rsAction.getActionType() == ActionType::CHECK) {
    //     int rockNo = rsAction.getRockNo();
    //
    //     GridPosition rockPos = model_->getRockPosition(rockNo);
    //     double distance = position_.euclideanDistanceTo(rockPos);
    //     double probabilityCorrect = (model_->getSensorCorrectnessProbability(distance));
    //     double probabilityIncorrect = 1 - probabilityCorrect;
    //
    //     Observation const &rsObs =
    //             (static_cast<Observation const &>(observation));
    //
    //     RockData &rockData = nextData->allRockData_[rockNo];
    //     rockData.checkCount++;
    //     double likelihoodGood = rockData.chanceGood;
    //     double likelihoodBad = 1 - rockData.chanceGood;
    //     if (rsObs.isGood()) {
    //         rockData.goodnessNumber++;
    //         likelihoodGood *= probabilityCorrect;
    //         likelihoodBad *= probabilityIncorrect;
    //     } else {
    //         rockData.goodnessNumber--;
    //         likelihoodGood *= probabilityIncorrect;
    //         likelihoodBad *= probabilityCorrect;
    //     }
    //     rockData.chanceGood = likelihoodGood / (likelihoodGood + likelihoodBad);
    // }
    return std::move(nextData);
}

std::vector<long> Data::generateLegalActions() const {
    //std::cout << "ARE WE AT LEAST TRYING TO GET LEGAL ACTIONS? " << std::endl;
    std::vector<long> legalActions;
    for (std::unique_ptr<solver::DiscretizedPoint> const &action : model_->getAllActionsInOrder()) {
        Action const &bsAction = static_cast<Action const &>(*action);
        //std::cout << model_->getMoveData()[cluster_] << std::endl;
        if(!(bsAction.getAction() > model_->getMoveData()[cluster_])){
          legalActions.push_back(bsAction.getBinNumber());
        }
    }
    return legalActions;
}

// std::vector<long> Data::generatePreferredActions() const {
//     std::vector<long> preferredActions;
//
//     int nRocks = model_->getNumberOfRocks();
//
//     // Check if we're currently on top of a rock.
//     int rockNo = model_->getCellType(position_) - Model::ROCK;
//     // If we are on top of a rock, and it has more +ve than -ve observations
//     // then we will sample it.
//     if (rockNo >= 0 && rockNo < nRocks) {
//         RockData const &rockData = allRockData_[rockNo];
//         if (rockData.chanceGood == 1.0 || rockData.goodnessNumber > 0) {
//             preferredActions.push_back(static_cast<long>(ActionType::SAMPLE));
//             return preferredActions;
//         }
//     }
//
//     bool worthwhileRockFound = false;
//     bool northWorthwhile = false;
//     bool southWorthwhile = false;
//     bool eastWorthwhile = false;
//     bool westWorthwhile = false;
//
//     // Check to see which rocks are worthwhile.
//     for (int i = 0; i < nRocks; i++) {
//         RockData const &rockData = allRockData_[i];
//         if (rockData.chanceGood != 0.0 && rockData.goodnessNumber >= 0) {
//             worthwhileRockFound = true;
//             GridPosition pos = model_->getRockPosition(i);
//             if (pos.i > position_.i) {
//                 southWorthwhile = true;
//             } else if (pos.i < position_.i) {
//                 northWorthwhile = true;
//             }
//
//             if (pos.j > position_.j) {
//                 eastWorthwhile = true;
//             } else if (pos.j < position_.j) {
//                 westWorthwhile = true;
//             }
//         }
//     }
//     // If no rocks are worthwhile head east.
//     if (!worthwhileRockFound) {
//         preferredActions.push_back(static_cast<long>(ActionType::EAST));
//         return preferredActions;
//     }
//
//     if (northWorthwhile) {
//         preferredActions.push_back(static_cast<long>(ActionType::NORTH));
//     }
//     if (southWorthwhile) {
//         preferredActions.push_back(static_cast<long>(ActionType::SOUTH));
//     }
//     if (eastWorthwhile) {
//         preferredActions.push_back(static_cast<long>(ActionType::EAST));
//     }
//     if (westWorthwhile) {
//         preferredActions.push_back(static_cast<long>(ActionType::WEST));
//     }
//
//     // See which rocks we might want to check
//     for (int i = 0; i < nRocks; i++) {
//         RockData const &rockData = allRockData_[i];
//         if (rockData.chanceGood != 0.0 && rockData.chanceGood != 1.0
//                 && std::abs(rockData.goodnessNumber) < 2) {
//             preferredActions.push_back(static_cast<long>(ActionType::CHECK) + i);
//         }
//     }
//     return preferredActions;
// }

void Data::print(std::ostream &os) const {
    os << "Cluster: " << cluster_ << std::endl;
    // os << "Position: " << position_ << std::endl;
    // os << "Chances of goodness: ";
    // for (RockData const &rockData : allRockData_) {
    //     tapir::print_double(rockData.chanceGood, os, 6, 4);
    //     os << " ";
    // }
    // os << std::endl;
}

/* --------------------- PreferredActionsTextSerializer -------------------- */
void DataTextSerializer::saveHistoricalData(solver::HistoricalData const *data,
        std::ostream &os) {
    os << std::endl;
    os << "CUSTOM DATA:" << std::endl;
    Data const &prData = (static_cast<Data const &>(*data));
    os << " " << prData.cluster_ << " " << prData.boundary_ << std::endl;
    // for (int const &moveData : prData.moveData_) {
    //   os << " " << moveData;
    //   // //tapir::print_double(rockData.chanceGood, os, 7, 5);
    //   // os << " from " << rockData.checkCount << " checks ( ";
    //   // os << std::showpos << rockData.goodnessNumber << std::noshowpos;
    //   // os << " )" << std::endl;
    // }
    os << std::endl;
}
std::unique_ptr<solver::HistoricalData> DataTextSerializer::loadHistoricalData(
        std::istream &is) {

    std::string line;
    std::getline(is, line); // Blank line
    std::getline(is, line); // Header

    std::getline(is, line);
    std::string tmpStr;
    int cluster;
    int boundary;
    std::istringstream(line) >> tmpStr >> cluster >> boundary;

    Model *model = dynamic_cast<Model *>(getModel());
    std::shared_ptr<Definition> definition = std::make_shared<Definition>();
    std::unique_ptr<Data> data = (std::make_unique<Data>(model,
            cluster, boundary, definition));

    // for (RockData &rockData : data->allRockData_) {
    //     std::getline(is, line);
    //     std::istringstream sstr(line);
    //
    //     sstr >> tmpStr >> tmpStr >> rockData.chanceGood;
    //     sstr >> tmpStr >> rockData.checkCount >> tmpStr >> tmpStr;
    //     sstr >> rockData.goodnessNumber;
    // }

    std::getline(is, line); // Blank line

    return std::move(data);
}
} /* namespace multisearch */
}
}
