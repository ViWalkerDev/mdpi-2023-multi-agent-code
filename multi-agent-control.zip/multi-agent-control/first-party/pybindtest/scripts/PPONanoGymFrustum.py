from stable_baselines3 import PPO, SAC
from datetime import datetime
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize, VecMonitor
from stable_baselines3.common.callbacks import CheckpointCallback
import nano_gym

now = datetime.now()
date_time = now.strftime("%m-%d-%Y_%H-%M-%S")
save_path = './ppo_transit_logs/'+date_time
tensorboard_log_path = './ppo_transit_logs/'+date_time + '/tensorboard_log'
checkpoint_callback = CheckpointCallback(save_freq=6000, save_path = save_path,
                                         name_prefix='rl_model')
vec_env = make_vec_env("NanoGymFrustumEnv-v0", n_envs=16, vec_env_cls=DummyVecEnv)
policy_kwargs = dict(net_arch=[128, 64])
model = PPO("MlpPolicy", vec_env, verbose=1, policy_kwargs=policy_kwargs, n_steps=600, tensorboard_log=tensorboard_log_path)
#model = SAC("MlpPolicy", vec_env, verbose=1, learning_starts = 4800,  batch_size = 256,policy_kwargs=policy_kwargs, train_freq=5)

print(model.policy)
model.learn(total_timesteps=20000000, callback=checkpoint_callback)
model.save("ppo_nano_frustum")
