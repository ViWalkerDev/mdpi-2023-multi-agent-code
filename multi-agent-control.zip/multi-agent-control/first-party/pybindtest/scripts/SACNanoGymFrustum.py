from stable_baselines3 import PPO, SAC
from datetime import datetime
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize, VecMonitor, SubprocVecEnv
from stable_baselines3.common.callbacks import CheckpointCallback
import nano_gym


if __name__ == '__main__':
    now = datetime.now()
    date_time = now.strftime("%m-%d-%Y_%H-%M-%S")
    save_path = './sac_transit_logs/'+date_time
    tensorboard_log_path = './sac_search_logs/'+date_time + '/tensorboard_log'
    checkpoint_callback = CheckpointCallback(save_freq=5000, save_path = save_path,
                                            name_prefix='rl_model')
    vec_env = make_vec_env("NanoGymFrustumEnv-v0", n_envs=8, seed=0, vec_env_cls=SubprocVecEnv)
    policy_kwargs = dict(net_arch=[128, 64])
    #model = PPO("MlpPolicy", vec_env, verbose=1, n_steps = 1024, batch_size=4, policy_kwargs=policy_kwargs)
    model = SAC("MlpPolicy", vec_env, verbose=1,buffer_size=1000000, learning_starts = 4800, batch_size = 1024,policy_kwargs=policy_kwargs, gamma = 0.99, tensorboard_log=tensorboard_log_path)

    print(model.policy)
    model.learn(total_timesteps=10000000, callback=checkpoint_callback)
    model.save("SAC_nano_frustum")
