import PyBindTest as pbt
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
import quaternion as quat
import numpy as np

# env = make_vec_env("NanoGymFrustumEnv-v0", n_envs=1)
# ##env = gym.make("NanoGymFrustumEnv-v0")
# model = PPO("MlpPolicy", env, verbose=1)
# model.learn(total_timesteps=25000)
# model.save("ppo_nano_frustum")


pbt.initOpenVDB()
#add = nm.add(1,2)
#print(add)

print("Beginning GymInstance Test")

gymInstance = pbt.GymInstance("/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/config.txt")
gymInstance.createManager()
gymInstance.createHandler()
states = np.zeros(3)
observations = np.zeros(160)
goalObs = np.zeros(11)
print("resetting agent and getting random path to travel")
gymInstance.resetAgentByIndex(0)
print("getting new pose")
pose = gymInstance.getAgentPoseAsFloatByIndex(0)
position = [pose[0], pose[1], pose[2]]
orientation = [pose[3],pose[4],pose[5],pose[6]]
gymInstance.updateAgentPose(0,pose[0],pose[1],pose[2],pose[3],pose[4],pose[5],pose[6])
print("Moving Agent Until Collision")
for x in range(20):
    yawVel = 0.2
    # = position[0]
    print(position)
    # alpha_beta_gamma = [0.0,0.0,0.0]
    # q = quat.from_euler_angles(alpha_beta_gamma)
    # qf = quat.as_float_array(q)
    #print("Updating Pose")
    gymInstance.updateAgentPoseFromVelocities(0,0.1, 0.0,0.0,0.0,0.0,0.0,yawVel)
    #print("Generating View")
    gymInstance.generateAgentViews(0)
    #print("Processing View")
    gymInstance.processAgentViews(0)
    #print("updating agent observations")
    gymInstance.updateAgentObservations()
    #print("getting state of agent")
    states = gymInstance.getAgentStateByIndex(0)
    print(states)
    observations = gymInstance.getObservationsByIndex(0)
    print(observations)
    goalObs = gymInstance.getGoalObservationsByIndex(0)
    print(goalObs)
    if states[0]==1:
        print("TERMINAL STATE REACHED!")
        break
    #position[0] += xIncrement
    gymInstance.saveAgentGridToFile(0, "testGridPython"+str(x)+".vdb")

#print("Saving Observed Grid to File")
gymInstance.saveAgentGridToFile(0, "testGridPython.vdb")


print("GymInstance Test Complete")

