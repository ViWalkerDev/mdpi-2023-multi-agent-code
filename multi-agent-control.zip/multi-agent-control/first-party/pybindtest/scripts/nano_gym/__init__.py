from gym.envs.registration import register

from .nano_gym_frustum_env import NanoGymFrustumEnv

# environments = [['NanoGymFrustumEnv', 'v0']]

# for environment in environments:
#     register(
#         id='{}-{}'.format(environment[0], environment[1]),
#         entry_point='nano_gym:{}'.format(environment[0]),
#         nondeterministic=False
#     )

register(
    id="NanoGymFrustumEnv-v0",
    entry_point = "nano_gym.nano_gym_frustum_env:NanoGymFrustumEnv",
    max_episode_steps = 200,
)