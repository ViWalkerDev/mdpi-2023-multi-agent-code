import NanomapPy as nm
import numpy as np
import gym
from gym import spaces
np.random.seed(0)
class NanoGymFrustumEnv(gym.Env):
    """Custom Environment that creates a cuda nanomap simulation instance"""
    metadata = {"render.modes": ["human"]}


    
    def __init__(self, info={}):
        super(NanoGymFrustumEnv, self).__init__()
        config = nm.Config("/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/config.txt")
        print("creating manager")
        gymManager = nm.createManager(config)
        print("solving environment")
        gymManager.solveEnvironment(0)
        print("resetting agent")
        gymManager.gymReset(0)
        #number of distance readings from agent to environment in a sphere. 
        #default is 80
        #2 readings are provided, the distance to a cell that isn't considered free space
        #and the confidence of that reading. 0 means there is no knowledge of the cells state is unknown
        #                                    1 means there is high confidence the cell is occupied
        num_dist_obs = 80*2
        max_obs_reading = 10
        min_obs_reading = 0.0
        #agent obs = velocity observations
        #(x, y, z, yaw) velocities
        num_agent_obs = 4
        agent_velocities = np.array([0.0,0.0,0.0,0.0])
        #max linear velocity = 1m/s
        max_linear_vel = 1
        #max angular velocity = 0.2 rad/s
        max_angular_vel = 0.2
        #distance to goal 
        # + distance to closest point on goal vector 
        # + yaw heading to next goal point 
        # + pitch heading to next goal 
        num_goal_obs = 11
        max_goal_dist = 20
        num_obs = num_agent_obs + num_goal_obs + num_dist_obs
            # Define action and observation space
        # They must be gym.spaces objects
        
        self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(4,), dtype=np.float32)
        # Example for using image as input (channel-first; channel-last also works):
        self.observation_space = spaces.Box(low=-1.0, high=1.0,
                                            shape=(self.num_obs,), dtype=np.float32)

    def step(self, action):
        print("step")
        assert self.action_space.contains(action), "Invalid Action"
        self.agent_velocities[0] += action[0]
        if(self.agent_velocities[0]>self.max_linear_vel):
            self.agent_velocities[0] = self.max_linear_vel
        elif(self.agent_velocities[0]<-self.max_linear_vel):
            self.agent_velocities[0] = -self.max_linear_vel
        
        self.agent_velocities[1] += action[1]
        if(self.agent_velocities[1]>self.max_linear_vel):
            self.agent_velocities[1] = self.max_linear_vel
        elif(self.agent_velocities[1]<-self.max_linear_vel):
            self.agent_velocities[1] = -self.max_linear_vel
        self.agent_velocities[2] += action[2]
        if(self.agent_velocities[2]>self.max_linear_vel):
            self.agent_velocities[2] = self.max_linear_vel
        elif(self.agent_velocities[2]<-self.max_linear_vel):
            self.agent_velocities[2] = -self.max_linear_vel
        self.agent_velocities[3] += action[3]
        if(self.agent_velocities[3]>self.max_angular_vel):
            self.agent_velocities[3] = self.max_angular_vel
        elif(self.agent_velocities[3]<-self.max_angular_vel):
            self.agent_velocities[3] = -self.max_angular_vel
        self.gymManager.updatePoseFromGym(0, self.agent_velocities[0], self.agent_velocities[1], self.agent_velocities[2], self.agent_velocities[3])
        #agentObs = np.array([agent_velocities[0], agent_velocities[1], agent_velocities[2], agent_velocities[3]])
        agentObs = self.agent_velocities
        goalObs = self.gymManager.getGoalObs()
        distObs = self.gymManager.getDistObs()
        observation = np.concatenate(agentObs, goalObs, distObs)

        reward = self.gymManager.getReward()

        done = self.gymManager.getDone()

        info = []
        return observation, reward, done, info
    
    def reset(self):
        #This forces the gymManager to clear any info it may be tracking from the
        #previous run
        self.gymManager.gymReset(0)
        ##self.gymManager.generateGymStart()
        agentObs = self.gymManager.getAgentObs(0)
        goalObs = self.gymManager.getGoalObs(0)
        distObs = self.gymManager.getDistObs(0)
        observation = np.concatenate(agentObs, goalObs, distObs)
        return observation  # reward, done, info can't be included
    def render(self, mode="human"):
        ...
    def close (self):
        #performs shutdown of gymManager object.
        self.gymManager.gymClose()



