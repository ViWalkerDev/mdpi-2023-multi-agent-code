import PyBindTest as pbt
import numpy as np
import gym
from gym import spaces
from random import randint
from math import sqrt
import random
from datetime import datetime

np.random.seed(0)
class NanoGymFrustumEnv(gym.Env):
    """Custom Environment that creates a cuda nanomap simulation instance"""
    metadata = {"render.modes": ["human"]}


    
    def __init__(self, info={}):
        super(NanoGymFrustumEnv, self).__init__()
        #config = nm.Config("/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/config.txt")
        #print("creating manager")
        pbt.initOpenVDB()
        # seed = random.seed(datetime.now().timestamp())
        intMax = 2147483647
        seed = random.randint(0,intMax)
        # if seedOffset+seed > intMax:
        #     seed = seedOffset-seed
        print(seed)
        self.gymInstance = pbt.GymInstance("/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/config.txt", seed)
        self.knowledgeRadius = 2.0
        self.environmentKnowledge = 1
        self.objectsOnPath = False
        self.currentStep = 0
        self.maxSteps = 200
        self.observationDistance = 10
        self.collisionDistance = 0.25
        self.maxProximityDistance = self.collisionDistance*3
        self.collisionDistanceNorm = self.collisionDistance/self.observationDistance
        self.maxProximityDistanceNorm = self.maxProximityDistance/self.observationDistance
        # if randint(0,1)==0:
        #     self.objectsOnPath = True
        # print("debug1")
        self.gymInstance.setObjectsOnPath(self.objectsOnPath)
        self.gymInstance.setEnvironmentKnowledge(self.environmentKnowledge, self.knowledgeRadius)
        self.gymInstance.createManager()
        self.gymInstance.createHandler()
        self.timeStep = 0.1
        #number of distance readings from agent to environment in a sphere. 
        #default is 80
        #2 readings are provided, the distance to a cell that isn't considered free space
        #and the confidence of that reading. 0 means there is no knowledge of the cells state is unknown
        #                                    1 means there is high confidence the cell is occupied
        print("debug2")
        self.num_dist_obs = 256*2
        self.max_obs_reading = 10
        self.min_obs_reading = 0.0
        self.states = np.zeros(4)
        self.observations = np.zeros(self.num_dist_obs)
        self.goalObs = np.zeros(11)

        # pose = gymInstance.getAgentPoseAsFloatByIndex(0)
        # position = [pose[0], pose[1], pose[2]]
        # orientation = [pose[3],pose[4],pose[5],pose[6]]
        self.goalReachedReward = 4.0
        self.cellDiscoveryMax = 0.1
        self.cellDiscoveryMultiplier = 0.01
        self.suddenVelChangePenalty = -0.05
        self.nodeSearchReward = 2.0
        ##collisionPenalty = -300
        #self.collisionPenalty = -25
        self.collisionPenalty = -20.0
        ##timeStepCost 0.1
        self.timeStepCost = 0.0
        ##distanceFactor = -1
        self.distanceFactor = 0.03
        self.distancePenaltyScale = 0.02
        self.maxDistanceForPenalty = 10
        self.explorationFactor = 0.02
        #agent obs = velocity observations
        #(x, y, z, yaw) velocities
        self.num_agent_obs = 4
        self.num_agent_actions = 4
        self.agent_velocities = np.array([0.0,0.0,0.0,0.0])
        self.old_agent_velocities = np.array([0.0,0.0,0.0,0.0])
        self.prior_actions = np.zeros(4)
        #max linear velocity = 1m/s
        self.max_x_vel = 2.0
        self.max_yz_vel = 0.75
        #max angular velocity = 0.2 rad/s
        self.max_angular_vel = 0.5
        #distance to goal 
        # + distance to closest point on goal vector 
        # + yaw heading to next goal point 
        # + pitch heading to next goal 
        self.num_goal_obs = 3*5
        self.goalSearchReward = 5
        self.max_goal_dist = 10
        self.last_goal_obs = np.zeros(6)
        self.num_obs = self.num_agent_actions + self.num_agent_obs*2 + self.num_goal_obs + self.num_dist_obs + 1
        print(self.num_obs)
            # Define action and observation space
        # They must be gym.spaces objects
        print("debug3")
        self.gymInstance.resetAgentByIndex(0)
        self.gymInstance.onAgentReset()
        self.pose = self.gymInstance.getAgentPoseAsFloatByIndex(0)
        self.gymInstance.updateAgentPose(0,self.pose[0], self.pose[1], self.pose[2], self.pose[3], self.pose[4], self.pose[5], self.pose[6])
        print("debug4")
        # self.gymInstance.onAgentReset()
        # print("debug5")
        # self.gymInstance.generateAgentViews(0)
        # #print("Processing View")
        # print("debug6")
        # self.gymInstance.processAgentViews(0)
        #print("updating agent observations")
        self.gymInstance.gymStep()
        self.lastDistFromGoal = 1.0
        self.continuityReward = 0.0
        #self.currentAction = np.zeros(4)
        # print("debug7")
        # self.gymInstance.updateAgentObservations()
        # print("debug7.5")
        self.maxLinearVelocityStep = 0.25
        self.maxAngularVelocityStep = 0.05
        #self.normMaxLinearStep = self.maxLinearVelocityStep/self.max_linear_vel
        #self.normMaxAngularStep = self.maxAngularVelocityStep/self.max_angular_vel
        self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(4,), dtype=np.float32)
        # Example for using image as input (channel-first; channel-last also works):
        self.observation_space = spaces.Box(low=-1.0, high=1.0,
                                            shape=(self.num_obs,), dtype=np.float32)

    def step(self, action):
        #print("step")
        done = False
        self.currentStep+=1
        assert self.action_space.contains(action), "Invalid Action"
        
        self.old_agent_velocities = self.agent_velocities
        self.continuityReward = 0.0
        self.continuityReward -= ((action[0]-self.prior_actions[0])**2)*0.0001
        self.continuityReward -= ((action[1]-self.prior_actions[1])**2)*0.0001
        self.continuityReward -= ((action[2]-self.prior_actions[2])**2)*0.0001
#        self.continuityReward -= ((action[3]-self.prior_actions[3])**2)*0.00005
        # self.continuityReward -= ((action[3])**2)*0.0001
        angleVelChange = abs(action[3]-self.prior_actions[3])-0.4
        if angleVelChange < 0.0:
            angleVelChange = 0.0
        self.continuityReward -= (angleVelChange**2)*0.0001
        # # self.continuityReward -= ((action[3])**2)*0.0002
        self.agent_velocities[0] = action[0]
        self.agent_velocities[1] = action[1]
        self.agent_velocities[2] = action[2]
        self.agent_velocities[3] = action[3]
        
        reward = self.timeStepCost
        reward += self.continuityReward
        # if abs(self.agent_velocities[0]-self.old_agent_velocities[0]) > self.normMaxLinearStep:
        #     reward += self.suddenVelChangePenalty
        #     sign = np.sign(self.agent_velocities[0]-self.old_agent_velocities[0])
        #     self.agent_velocities[0] = self.old_agent_velocities[0]+sign*self.normMaxLinearStep

        # if abs(self.agent_velocities[1]-self.old_agent_velocities[1]) > self.normMaxLinearStep:
        #     reward += self.suddenVelChangePenalty
        #     sign = np.sign(self.agent_velocities[1]-self.old_agent_velocities[1])
        #     self.agent_velocities[1] = self.old_agent_velocities[1]+sign*self.normMaxLinearStep

        # if abs(self.agent_velocities[2]-self.old_agent_velocities[2]) > self.normMaxLinearStep:
        #     reward += self.suddenVelChangePenalty
        #     sign = np.sign(self.agent_velocities[2]-self.old_agent_velocities[2])
        #     self.agent_velocities[2] = self.old_agent_velocities[2]+sign*self.normMaxLinearStep

        # if abs(self.agent_velocities[3]-self.old_agent_velocities[3]) > self.normMaxAngularStep:
        #     reward += self.suddenVelChangePenalty
        #     sign = np.sign(self.agent_velocities[3]-self.old_agent_velocities[3])
        #     self.agent_velocities[3] = self.old_agent_velocities[3]+sign*self.normMaxAngularStep


        # self.agent_velocities[0] += action[0]*self.maxLinearVelocityStep
        # if(self.agent_velocities[0]>self.max_linear_vel):
        #     self.agent_velocities[0] = self.max_linear_vel
        # elif(self.agent_velocities[0]<-self.max_linear_vel):
        #     self.agent_velocities[0] = -self.max_linear_vel
        
        # self.agent_velocities[1] += action[1]*self.maxLinearVelocityStep
        # if(self.agent_velocities[1]>self.max_linear_vel):
        #     self.agent_velocities[1] = self.max_linear_vel
        # elif(self.agent_velocities[1]<-self.max_linear_vel):
        #     self.agent_velocities[1] = -self.max_linear_vel

        # self.agent_velocities[2] += action[2]*self.maxLinearVelocityStep
        # if(self.agent_velocities[2]>self.max_linear_vel):
        #     self.agent_velocities[2] = self.max_linear_vel
        # elif(self.agent_velocities[2]<-self.max_linear_vel):
        #     self.agent_velocities[2] = -self.max_linear_vel

        # self.agent_velocities[3] += action[3]*self.maxAngularVelocityStep
        # if(self.agent_velocities[3]>self.max_angular_vel):
        #     self.agent_velocities[3] = self.max_angular_vel
        # elif(self.agent_velocities[3]<-self.max_angular_vel):
        #     self.agent_velocities[3] = -self.max_angular_vel
        

        # self.agent_velocities[0] += action[0]*self.maxLinearVelocityStep
        # if(self.agent_velocities[0]>self.max_linear_vel):
        #     self.agent_velocities[0] = self.max_linear_vel
        # elif(self.agent_velocities[0]<-self.max_linear_vel):
        #     self.agent_velocities[0] = -self.max_linear_vel
        
        # self.agent_velocities[1] += action[1]*self.maxLinearVelocityStep
        # if(self.agent_velocities[1]>self.max_linear_vel):
        #     self.agent_velocities[1] = self.max_linear_vel
        # elif(self.agent_velocities[1]<-self.max_linear_vel):
        #     self.agent_velocities[1] = -self.max_linear_vel

        # self.agent_velocities[2] += action[2]*self.maxLinearVelocityStep
        # if(self.agent_velocities[2]>self.max_linear_vel):
        #     self.agent_velocities[2] = self.max_linear_vel
        # elif(self.agent_velocities[2]<-self.max_linear_vel):
        #     self.agent_velocities[2] = -self.max_linear_vel

        # self.agent_velocities[3] += action[3]*self.maxAngularVelocityStep
        # if(self.agent_velocities[3]>self.max_angular_vel):
        #     self.agent_velocities[3] = self.max_angular_vel
        # elif(self.agent_velocities[3]<-self.max_angular_vel):
        #     self.agent_velocities[3] = -self.max_angular_vel
        # #print("debug8")
        adjusted_velocities = self.agent_velocities
        if adjusted_velocities[0] < 0.0:
            adjusted_velocities[0] = adjusted_velocities[0]*self.max_yz_vel
        else:
            adjusted_velocities[0] = adjusted_velocities[0]*self.max_x_vel
        #if adjusted_velocities[0] < -self.max_yz_vel:
        #   adjusted_velocities[0] = -self.max_yz_vel
        adjusted_velocities[1] = adjusted_velocities[1]*self.max_yz_vel
        adjusted_velocities[2] = adjusted_velocities[2]*self.max_yz_vel
        adjusted_velocities[3] = adjusted_velocities[3]*self.max_angular_vel
        self.gymInstance.updateAgentPoseFromVelocities(0, self.timeStep, adjusted_velocities[0], adjusted_velocities[1], adjusted_velocities[2], 0.0, 0.0, adjusted_velocities[3])
        #agentObs = np.array([agent_velocities[0], agent_velocities[1], agent_velocities[2], agent_velocities[3]])
        #print("debug9")


        # WE WANT TO RELEASE GIL FOR THESE STEPS AS THEY ARE THE COMPUTATIONALLY EXPENSIVE ONES DONE ON THE CPU and GPU
        #generates simulated views for agent within simulation environment
        # self.gymInstance.generateAgentViews(0)
        # #print("debug10")
        # #processes those simulated views into a map object
        # self.gymInstance.processAgentViews(0)
        # #print("debug11")
        # #Uses the newly updated map object to generate observations
        # self.gymInstance.updateAgentObservations()
        self.gymInstance.gymStep()


        agentObs = self.agent_velocities
        oldAgentObs = self.old_agent_velocities
        priorActions = self.prior_actions
        self.prior_actions = action
        #print("debug12")
        agentState = self.gymInstance.getAgentStateByIndex(0)
        goalObs = self.gymInstance.getGoalObservationsByIndex(0)
        #goalObs = np.array([bigGoalObs[0],bigGoalObs[1],bigGoalObs[2], bigGoalObs[3], bigGoalObs[4],bigGoalObs[5],bigGoalObs[6], bigGoalObs[7], bigGoalObs[8], bigGoalObs[9]])
        proximityCost = 0.0
        closestHazard = 1.0
        distObs = self.gymInstance.getObservationsByIndex(0)
        for x in range(int(self.num_dist_obs/2)):
            #closestHazard = 1.0
            #if distObs[x] < closestHazard:
            closestHazard = distObs[int(self.num_dist_obs/2)+x]
            #if closestHazard < self.collisionDistanceNorm:
            if closestHazard < self.maxProximityDistanceNorm:
                closestHazard -= self.collisionDistanceNorm
                if closestHazard < 0.0:
                   closestHazard = 0.0
                   reward += self.collisionPenalty
                   done = True
                   print("we crashed")
                   break
                else:
                    proximityCost -= ((((self.maxProximityDistanceNorm-self.collisionDistanceNorm)-closestHazard)/(self.maxProximityDistanceNorm-self.collisionDistanceNorm))**2)*0.002
                
        if proximityCost < -0.02:
            proximityCost = -0.02
        #print(proximityCost)
        reward += proximityCost
        stepObs = np.array([(self.maxSteps-self.currentStep)/self.maxSteps])
        observation = np.concatenate((priorActions, oldAgentObs, agentObs, goalObs, distObs, stepObs))
        # reward = self.timeStepCost
        # #reward = 0.0

        # if abs(goalObs[0]) < 0.1 and abs(goalObs[1]) < 0.1 and abs(goalObs[2]) < 0.1:
        #     print("goal dist satisfies goal reached")
        #     print(agentState)
        #     print(goalObs)
        #if agentState[2] == 1:
        #    print(agentState[2])
        exploreReward = 0.0
        if agentState[0] == 1:
            #IS TERMINAL
            done = True
            if agentState[1] == 1:
                #WE CRASHED :(
                print("we crashed")
                reward += self.collisionPenalty
            # else:
            #     #We can't find anymore search goals, so we reset the search
            #     self.gymInstance.resetAgentByIndex(0)
            #     self.gymInstance.setObjectsOnPath(self.objectsOnPath)
            #     self.gymInstance.setEnvironmentKnowledge(self.environmentKnowledge, self.knowledgeRadius)
            #     self.pose = self.gymInstance.getAgentPoseAsFloatByIndex(0)
            #     #print(self.pose)
            #     self.gymInstance.updateAgentPose(0,self.pose[0], self.pose[1], self.pose[2], self.pose[3], self.pose[4], self.pose[5], self.pose[6])
            #     self.gymInstance.onAgentReset()
            #     self.gymInstance.gymStep()
            #     agentState = self.gymInstance.getAgentStateByIndex(0)
            #     bigGoalObs = self.gymInstance.getGoalObservationsByIndex(0)
            #     goalObs = np.array([bigGoalObs[0],bigGoalObs[1],bigGoalObs[2]])
        else:
            exploreReward = agentState[3]*self.cellDiscoveryMultiplier
            if exploreReward>self.cellDiscoveryMax:
                exploreReward = self.cellDiscoveryMax
                #print("goal searched, finding new search goal")
        reward += self.nodeSearchReward*agentState[2]
        if agentState[2] > 0:
            print("we observed " + str(agentState[2]) +" goalNodes")
        reward+=exploreReward
        #print(exploreReward)
            # elif agentState[2] == 1:
            #     #WE DIDNT CRASH AND REACHED THE FINAL GOAL!
            #     #print("terminalGoal?")
            #     reward += self.goalReachedReward*2
        #elif agentState[2] == 1:
            #print("intermediate goal reached")
            #WE REACHED AN INTERMEDIATE GOAL
            #reward += self.goalReachedReward

        # forwardVector = np.array([1.0,0.0,0.0])
        # goalVector = np.array([goalObs[0], goalObs[1], goalObs[2]])
        # goalVector = goalVector/np.linalg.norm(goalVector)
        # dotProduct = np.dot(forwardVector, goalVector)
        #print("dotProduct")
        #print(dotProduct)
        # distFromGoal = sqrt(goalObs[0]**2 + goalObs[1]**2 + goalObs[2]**2)
        # reward -= distFromGoal*self.distancePenaltyScale
            #if distFromGoal < self.lastDistFromGoal:
            # if agentState[2] == 1:
                #reward+= (self.lastDistFromGoal - distFromGoal)*0.1
                # self.lastDistFromGoal = distFromGoal
            # else:
                # reward+= (self.lastDistFromGoal - distFromGoal)*0.001
                # if goalObs[0]>0:
                    #print("dotProduct")
                    #print(dotProduct)
                 # reward-= ((1.0-dotProduct)*0.001)
                # else:
                    # reward -= 0.001
                    #reward+= (self.last_goal_obs[1]-goalObs[1])*0.05
                #reward+= (self.last_goal_obs[0]-goalObs[0])*0.05
                # self.lastDistFromGoal = distFromGoal


        # self.last_goal_obs = goalObs
            # else:
            # self.lastDistFromGoal = 1.0
        #print("debug13")
        # exploration_reward = self.explorationFactor*agentState[3]
        # if exploration_reward > 2:
        #     exploration_reward = 2
        #reward+= self.explorationFactor*agentState[3]
        #reward+=exploration_reward
        # if agentState[0]!=1:
        #     distFromGoal = sqrt(goalObs[0]**2 + goalObs[1]**2 + goalObs[2]**2)
        #     if distFromGoal < self.lastDistFromGoal:
        #         reward+= self.lastDistFromGoal - distFromGoal
        #     # else:
        #     #     reward-=self.distanceFactor
        #     self.lastDistFromGoal = distFromGoal
        #print(agentState)
        #print(agentObs)
        #print(goalObs)
        # if agentState[2]==1:
        #     print("goalReached")
        #done = agentState[0]
        #print(agentState[3])
        info = {}
        return observation, reward, done, info
    
    def reset(self):
        #This forces the gymManager to clear any info it may be tracking from the
        #previous run
        self.currentStep = 0
        self.gymInstance.resetAgentByIndex(0)
        self.knowledgeRadius = 2.0
        # if randint(0,1)==0:
        #     self.objectsOnPath = True
        # else:
        #     self.objectsOnPath = False
        # if self.objectsOnPath == False:
        #     if randint(0,4) == 0:
        #         self.knowledgeRadius = 0.0
        self.gymInstance.setObjectsOnPath(self.objectsOnPath)
        self.gymInstance.setEnvironmentKnowledge(self.environmentKnowledge, self.knowledgeRadius)
        self.pose = self.gymInstance.getAgentPoseAsFloatByIndex(0)
        #print(self.pose)
        self.gymInstance.updateAgentPose(0,self.pose[0], self.pose[1], self.pose[2], self.pose[3], self.pose[4], self.pose[5], self.pose[6])
        self.gymInstance.onAgentReset()
        self.gymInstance.gymStep()
        # self.gymInstance.generateAgentViews(0)
        # #print("Processing View")
        # self.gymInstance.processAgentViews(0)
        # #print("updating agent observations")
        # self.gymInstance.updateAgentObservations()
        self.agent_velocities = np.zeros(4)
        self.old_agent_velocities = np.zeros(4)
        self.prior_actions = np.zeros(4)
        ##self.gymManager.generateGymStart()
        self.lastDistFromGoal = 1.0
        oldAgentObs = self.old_agent_velocities
        priorActions = self.prior_actions
        agentObs = self.agent_velocities
        goalObs = self.gymInstance.getGoalObservationsByIndex(0)
        # goalObs = np.array([bigGoalObs[0],bigGoalObs[1],bigGoalObs[2],bigGoalObs[3], bigGoalObs[4], bigGoalObs[5]])
        #goalObs = np.array([bigGoalObs[0],bigGoalObs[1],bigGoalObs[2]])
        self.lastDistFromGoal = sqrt(goalObs[0]**2 + goalObs[1]**2 + goalObs[2]**2)
        distObs = self.gymInstance.getObservationsByIndex(0)
        #print("distObsSize")
        #print(distObs.shape)
        stepObs = np.array([(self.maxSteps-self.currentStep)/self.maxSteps])
        observation = np.concatenate((priorActions,oldAgentObs, agentObs, goalObs, distObs, stepObs))
        #print(observation.shape)
        return observation  # reward, done, info can't be included
    
    def render(self, mode="human"):
        ...
    def close (self):
        ...
        #performs shutdown of gymManager object.
        

