import PyBindTest as pbt
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
import quaternion as quat

# env = make_vec_env("NanoGymFrustumEnv-v0", n_envs=1)
# ##env = gym.make("NanoGymFrustumEnv-v0")
# model = PPO("MlpPolicy", env, verbose=1)
# model.learn(total_timesteps=25000)
# model.save("ppo_nano_frustum")


pbt.initOpenVDB()
#add = nm.add(1,2)
#print(add)

print("Beginning PlannerInstance Test")

plannerInstance = pbt.PlannerInstance("/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/config.txt")
plannerInstance.createManager()
plannerInstance.createHandler()
plannerInstance.loadPlannerGrid("/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/simGrid.vdb")
plannerInstance.solvePlannerGrid()

print("PlannerInstance Test Complete")

