import NanomapPy as nm
import nano_gym
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env

env = make_vec_env("NanoGymFrustumEnv-v0", n_envs=1)
##env = gym.make("NanoGymFrustumEnv-v0")
model = PPO("MlpPolicy", env, verbose=1)
model.learn(total_timesteps=25000)
model.save("ppo_nano_frustum")



#add = nm.add(1,2)
#print(add)

#config = nm.Config("/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/config.txt")
#gymManager = nm.createManager(config)
#dist = 0.0
#minDist = 10.0
##gymManager.generateStartingState(minDist)
    ##METHOD FOR THIS
    ##DO THIS IN C++ AND EXPOSE THE METHOD
        ##While dist < minDist:
            ##Get a valid pose for the target
            ##targetPos = gymManager.getRandomValidPosition()
            ##Get a valid pose for the agent
            ##agentPos = gymManager.getRandomValidPosition()
            ##dist = gymManager.getDistanceBetween(agentPos, targetPos)
##agentPose = gymManager.getAgentPose()
##distObs = gymManager.getDistObs()
##goalObs = gymManager.getGoalObs()
##velObs = gymManager.getVelObs()

##while doing training
##