import PyBindTest as pbt
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
import quaternion as quat

# env = make_vec_env("NanoGymFrustumEnv-v0", n_envs=1)
# ##env = gym.make("NanoGymFrustumEnv-v0")
# model = PPO("MlpPolicy", env, verbose=1)
# model.learn(total_timesteps=25000)
# model.save("ppo_nano_frustum")


pbt.initOpenVDB()
#add = nm.add(1,2)
#print(add)

print("Beginning SimInstance Test")
print("Creating Instance")
instance = pbt.SimInstance("/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/config.txt")
print("Creating Manager")
instance.createManager()
print("Creating Handler")
instance.createHandler() 
radianIncrement = 6.28/20.0
position = [0.0,0.0,0.0]
print("Updating and Generating Views 0->20")
for x in range(20):
    yaw = x*radianIncrement
    print("Yaw = " + str(yaw))
    alpha_beta_gamma = [0.0,0.0,yaw]
    q = quat.from_euler_angles(alpha_beta_gamma)
    qf = quat.as_float_array(q)
    print("Updating Pose")
    instance.updateAgentPose(0,position[0], position[1], position[2], qf[0], qf[1], qf[2], qf[3])
    print("Generating View")
    instance.generateAgentViews(0)
    print("Processing View")
    instance.processAgentViews(0)
print("Saving Observed Grid to File")
instance.saveAgentGridToFile(0, "testGridPython.vdb")

print("SimInstance Test Complete")
