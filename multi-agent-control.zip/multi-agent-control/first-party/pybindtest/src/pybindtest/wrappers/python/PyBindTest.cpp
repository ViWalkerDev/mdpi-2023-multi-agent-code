#include <pybind11/pybind11.h>
#include <pybind11/eigen.h>
#include <nanomap/instance/SimInstance.h>
#include <nanomap/instance/PlannerInstance.h>
#include <nanomap/instance/GymInstance.h>
#include <openvdb/openvdb.h>
namespace py = pybind11;

int add(int i, int j){
    return i+j;
}

void initOpenVDB(){
    openvdb::initialize();
}

// std::shared_ptr<nanomap::config::GymConfig> createConfig(std::string config){
//     return std::make_shared<nanomap::config::GymConfig>(nanomap::config::GymConfig(config));
// }

// nanomap::manager::GymManager createManager(nanomap::config::GymConfig config){
//     return nanomap::manager::GymManager(config);
// }

PYBIND11_MODULE(PyBindTest, m){
    m.doc() = "pybind11 example plugin"; //optional module docstring
    m.def("add", &add, "a function that adds two numbers");
    m.def("initOpenVDB", &initOpenVDB, "initOpenVDB");
//}
//     m.def("createConfig", &createConfig, "a function that gets a sharedPtr to a config object");
//     m.def("createManager", &createManager, "a function that creates a Gym Manager from a sharedPtr to a config object");



//    py::class_<nanomap::Pose>(m, "Pose")
//     .def(py::init<>())
//     .def("setOrientationFromFloat", &nanomap::Pose::setOrientationFromFloat)
//     .def("setPositionFromFloat", &nanomap::Pose::setPositionFromFloat)
//     .def("getOrientationAsFloat", &nanomap::Pose::getOrientationAsFloat)
//     .def("getPositionAsFloat", &nanomap::Pose::getPositionAsFloat);


    py::class_<nanomap::instance::SimInstance>(m, "SimInstance")
    .def(py::init<std::string>())
    .def("createManager", &nanomap::instance::SimInstance::createManager)
    .def("createHandler", &nanomap::instance::SimInstance::createHandler)
    .def("updateAgentPose", &nanomap::instance::SimInstance::updateAgentPoseFromFloat)
    .def("generateAgentViews", static_cast<void (nanomap::instance::SimInstance::*)(int)>(&nanomap::instance::SimInstance::generateAgentViews))
    //.def("processAgentViews", &nanomap::instance::SimInstance::processAgentViews)
    .def("processAgentViews", static_cast<void (nanomap::instance::SimInstance::*)(int)>(&nanomap::instance::SimInstance::processAgentViews))
    .def("saveAgentGridToFile", &nanomap::instance::SimInstance::saveAgentGridToFile);
    

    py::class_<nanomap::instance::PlannerInstance>(m, "PlannerInstance")
    .def(py::init<std::string>())
    .def("createManager", &nanomap::instance::PlannerInstance::createManager)
    .def("createHandler", &nanomap::instance::PlannerInstance::createHandler)
    .def("loadPlannerGrid", &nanomap::instance::PlannerInstance::loadPlannerGrid)
    //.def("processAgentViews", &nanomap::instance::SimInstance::processAgentViews)
    .def("solvePlannerGrid", &nanomap::instance::PlannerInstance::solvePlannerGrid);
    


    // py::class_<nanomap::instance::GymInstance>(m, "GymInstance")
    // .def(py::init<std::string>())
    // .def("createManager", &nanomap::instance::GymInstance::createManager)
    // .def("createHandler", &nanomap::instance::GymInstance::createHandler)
    // .def("updateAgentPose", &nanomap::instance::GymInstance::updateAgentPoseFromFloat)
    // .def("updateAgentPoseFromVelocities", &nanomap::instance::GymInstance::updateAgentPoseFromVelocities)
    // //.def("generateAgentViews", &nanomap::instance::GymInstance::generateAgentViews)
    // .def("getAgentPoseAsFloat", static_cast<Eigen::Array<float,7,1> (nanomap::instance::GymInstance::*)(int)>(&nanomap::instance::GymInstance::getAgentPoseAsFloat))
    // .def("getAgentPoseAsFloatByIndex", &nanomap::instance::GymInstance::getAgentPoseAsFloatByIndex)
    // //.def("processAgentViews", &nanomap::instance::GymInstance::processAgentViews)
    // //.def("processAgentViews", static_cast<void (nanomap::instance::GymInstance::*)(int)>(&nanomap::instance::GymInstance::processAgentViews))
    // .def("saveAgentGridToFile", &nanomap::instance::GymInstance::saveAgentGridToFile)
    // //.def("updateAgentObservations", &nanomap::instance::GymInstance::updateAgentObservations)
    // .def("resetAgentByIndex", &nanomap::instance::GymInstance::resetAgentByIndex)
    // .def("getAgentStateByIndex", &nanomap::instance::GymInstance::getAgentStateByIndex)
    // .def("getObservationsByIndex", &nanomap::instance::GymInstance::getObservationsByIndex)
    // .def("getGoalObservationsByIndex", &nanomap::instance::GymInstance::getGoalObservationsByIndex)
    // .def("onAgentReset", &nanomap::instance::GymInstance::onAgentReset)
    // .def("setEnvironmentKnowledge", &nanomap::instance::GymInstance::setEnvironmentKnowledge)
    // .def("setObjectsOnPath", &nanomap::instance::GymInstance::setObjectsOnPath)
    // //.def("gymStep", &nanomap::instance::GymInstance::gymStep, py::call_guard<py::gil_scoped_release>());
    // .def("gymStep", &nanomap::instance::GymInstance::gymStep);
    py::class_<nanomap::instance::GymInstance>(m, "GymInstance")
    .def(py::init<std::string>())
    .def(py::init<std::string, int>())
    .def("createManager", &nanomap::instance::GymInstance::createManager)
    .def("createHandler", &nanomap::instance::GymInstance::createHandler)
    .def("updateAgentPose", &nanomap::instance::GymInstance::updateAgentPoseFromFloat)
    .def("updateAgentPoseFromVelocities", &nanomap::instance::GymInstance::updateAgentPoseFromVelocities)
    //.def("generateAgentViews", &nanomap::instance::GymInstance::generateAgentViews)
    .def("getAgentPoseAsFloat", static_cast<Eigen::Array<float,7,1> (nanomap::instance::GymInstance::*)(int)>(&nanomap::instance::GymInstance::getAgentPoseAsFloat))
    .def("getAgentPoseAsFloatByIndex", &nanomap::instance::GymInstance::getAgentPoseAsFloatByIndex)
    //.def("processAgentViews", &nanomap::instance::GymInstance::processAgentViews)
    //.def("processAgentViews", static_cast<void (nanomap::instance::GymInstance::*)(int)>(&nanomap::instance::GymInstance::processAgentViews))
    .def("saveAgentGridToFile", &nanomap::instance::GymInstance::saveAgentGridToFile)
    //.def("updateAgentObservations", &nanomap::instance::GymInstance::updateAgentObservations)
    .def("resetAgentByIndex", &nanomap::instance::GymInstance::resetAgentByIndex)
    .def("getAgentStateByIndex", &nanomap::instance::GymInstance::getAgentStateByIndex)
    .def("getObservationsByIndex", &nanomap::instance::GymInstance::getObservationsByIndex)
    .def("getGoalObservationsByIndex", &nanomap::instance::GymInstance::getGoalObservationsByIndex)
    .def("onAgentReset", &nanomap::instance::GymInstance::onAgentReset)
    .def("setEnvironmentKnowledge", &nanomap::instance::GymInstance::setEnvironmentKnowledge)
    .def("setObjectsOnPath", &nanomap::instance::GymInstance::setObjectsOnPath)
    //.def("setSearchGoal", &nanomap::instance::GymInstance::setSearchGoal)
    //.def("gymStep", &nanomap::instance::GymInstance::gymStep, py::call_guard<py::gil_scoped_release>());
    .def("gymStep", &nanomap::instance::GymInstance::gymStep);

    

    // .def("gymReset", &nanomap::manager::GymManager::gymReset)
    // .def("gymClose", &nanomap::manager::GymManager::gymClose)
    // .def("updatePoseFromGym", &nanomap::manager::GymManager::updatePoseFromGym)
    // //.def("getAgentObs", &nanomap::manager::GymManager::getAgentObs);
    // .def("getGoalObs", &nanomap::manager::GymManager::getGoalObs)
    // .def("getDistObs", &nanomap::manager::GymManager::getDistObs)
    // .def("getReward", &nanomap::manager::GymManager::getReward)
    // .def("getDone", &nanomap::manager::GymManager::getDone);

    // .def("solveEnvironment", &nanomap::manager::GymManager::solveEnvironment)
    // .def("generateGymStart", &nanomap::manager::GymManager::generateGymStart)
    // .def("gymReset", &nanomap::manager::GymManager::gymReset)
    // .def("gymClose", &nanomap::manager::GymManager::gymClose)
    // .def("updatePoseFromGym", &nanomap::manager::GymManager::updatePoseFromGym)
    // //.def("getAgentObs", &nanomap::manager::GymManager::getAgentObs);
    // .def("getGoalObs", &nanomap::manager::GymManager::getGoalObs)
    // .def("getDistObs", &nanomap::manager::GymManager::getDistObs)
    // .def("getReward", &nanomap::manager::GymManager::getReward)
    // .def("getDone", &nanomap::manager::GymManager::getDone);


    //py::class_<nanomap::config::GymConfig>(m, "Config")
    //.def(py::init<std::string>());
    //.def("loadConfig", &nanomap::config::GymConfig::loadConfig);
    // py::class_<nanomap::manager::GymManager>(m, "Manager")
    // .def(py::init<nanomap::config::GymConfig>());
    // // .def("solveEnvironment", &nanomap::manager::GymManager::solveEnvironment)
    // // .def("generateGymStart", &nanomap::manager::GymManager::generateGymStart)
    // // .def("gymReset", &nanomap::manager::GymManager::gymReset)
    // // .def("gymClose", &nanomap::manager::GymManager::gymClose)
    // // .def("updatePoseFromGym", &nanomap::manager::GymManager::updatePoseFromGym)
    // // //.def("getAgentObs", &nanomap::manager::GymManager::getAgentObs);
    // // .def("getGoalObs", &nanomap::manager::GymManager::getGoalObs)
    // // .def("getDistObs", &nanomap::manager::GymManager::getDistObs)
    // // .def("getReward", &nanomap::manager::GymManager::getReward)
    // // .def("getDone", &nanomap::manager::GymManager::getDone);



    // py::class_<nanomap::config::GymConfig>(m, "Config")
    // .def(py::init<std::string>());
    // //.def("loadConfig", &nanomap::config::GymConfig::loadConfig);
}
