#ifndef NANOMAP_ROS_CONTROL_NODES_HPP_
#define NANOMAP_ROS_CONTROL_NODES_HPP_


#include "rclcpp/rclcpp.hpp"
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <thread>
#include <array>
#include <regex>
#include "openvdb/openvdb.h"
#include <openvdb/io/Stream.h>
#include "std_msgs/msg/string.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/point_stamped.hpp"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include "nanomap_msgs/msg/openvdb_grid.hpp"
#include "nanomap_msgs/msg/policy_observations.hpp"
#include "nanomap_msgs/msg/multi_agent_info.hpp"
#include "nanomap_msgs/srv/policy_query.hpp"

#include "nanomap/instance/GymInstance.h"
#include "nanomap/map/Map.h"
#include "nanomap/agent/Agent.h"
#include "nanomap/config/Config.h"
#include "nanomap/nanomap.h"
#include "nanomap/sensor/SensorData.h"

#include <Eigen/Geometry>
#include <Eigen/Core>
#include <Eigen/Dense>
#include "visualization_msgs/msg/marker.hpp"
#include "visualization_msgs/msg/marker_array.hpp"

#include "nanomaptapir/planner/problems/singlesearch/Definition.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Observation.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Action.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Interface.hpp"

namespace nanomap_ros{
    namespace control{
using Pose = nanomap::Pose;
using namespace std::chrono_literals;


  class ViewSimLoop : public rclcpp::Node
  {
  public:
    ViewSimLoop(nanomap::instance::GymInstance& gymInstance, std::string node_name);

  private:
    nanomap::instance::GymInstance* gymInstance_;
    rclcpp::TimerBase::SharedPtr timer_;
    size_t count_;
  };

class PoseSimLoop : public rclcpp::Node
{
public:
  PoseSimLoop(nanomap::instance::GymInstance& gymInstance, Eigen::Vector3f &xyz, Eigen::Vector3f &rpy, std::string node_name);

private:
  nanomap::instance::GymInstance* gymInstance_;
  Eigen::Vector3f* xyz_;
  Eigen::Vector3f* rpy_;
  rclcpp::TimerBase::SharedPtr timer_;
  size_t count_;
};


class TransitPolicyClient : public rclcpp::Node
{
public:
  TransitPolicyClient(std::string queryTopic_,nanomap::instance::GymInstance& gymInstance, Eigen::Vector3f &xyz, Eigen::Vector3f &rpy, bool &transitMode, std::vector<Eigen::Vector3f>& currentGoals, float goalDist, std::vector<float> maxVelocities);
  std::vector<float> normalizedGoalObservations(std::vector<float> goalData);
  std::vector<float> normalizedVelocityObservations();
private:
  std::string queryTopic_;
  nanomap::instance::GymInstance* gymInstance_;
  std::promise<std::shared_ptr<nanomap_msgs::srv::PolicyQuery::Response>> promise_;
  std::shared_future<std::shared_ptr<nanomap_msgs::srv::PolicyQuery::Response>> future_;
  //nanomap_msgs::srv::PolicyQuery::Request request_;
  //nanomap_msgs::srv::PolicyQuery::Response result_;
  Eigen::Vector3f* xyz_;
  Eigen::Vector3f* rpy_;
  bool* transitMode_;
  //Used to determine normalization for the goal observations;
  float goalDist_;
  //Used to determine normalized velocity observations;
  std::vector<float> maxVelocities_;
  std::vector<Eigen::Vector3f>* currentGoals_;
  //nanomap_msgs::msg::PolicyObservations msg_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Client<nanomap_msgs::srv::PolicyQuery>::SharedPtr client_;
  size_t count_;
};

class SearchPolicyClient : public rclcpp::Node
{
public:
  SearchPolicyClient(std::string queryTopic, nanomap::instance::GymInstance& gymInstance, Eigen::Vector3f &xyz, Eigen::Vector3f &rpy, 
                    bool &searchMode, std::vector<Eigen::Vector3f>& currentGoals, 
                    float goalDist, std::vector<float> maxVelocities);
  std::vector<float> normalizedGoalObservations(std::vector<float> goalData);
  std::vector<float> normalizedVelocityObservations();
private:
  std::string queryTopic_;
  nanomap::instance::GymInstance* gymInstance_;
  std::promise<std::shared_ptr<nanomap_msgs::srv::PolicyQuery::Response>> promise_;
  std::shared_future<std::shared_ptr<nanomap_msgs::srv::PolicyQuery::Response>> future_;
  //nanomap_msgs::srv::PolicyQuery::Request request_;
  //nanomap_msgs::srv::PolicyQuery::Response result_;
  Eigen::Vector3f* xyz_;
  Eigen::Vector3f* rpy_;
  bool* searchMode_;
  //Used to determine normalization for the goal observations;
  float goalDist_;
  //Used to determine normalized velocity observations;
  std::vector<float> maxVelocities_;
  std::vector<Eigen::Vector3f>* currentGoals_;
  //nanomap_msgs::msg::PolicyObservations msg_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Client<nanomap_msgs::srv::PolicyQuery>::SharedPtr client_;
  size_t count_;
};




class SingleMacroManagerNode : public rclcpp::Node
{
public:
  SingleMacroManagerNode(int simType, int searchType,
                nanomap::instance::GymInstance& gymInstance,
                std::tuple<int, int, int, std::vector<Eigen::Vector3f>>& searchGoals,
                std::tuple<int, int, int, std::vector<Eigen::Vector3f>>& transitGoals,
                Eigen::Vector3f &xyz, Eigen::Vector3f &rpy, bool& transitMode, bool& searchMode, std::vector<Eigen::Vector3f>& currentGoals);
  void populateSearchTargets(std::vector<int> replaceIndex);
  std::vector<bool> areTargetsSeen();
  std::vector<int>  checkSearchTargets();
  void stepSearchRoutine();
  void startSearchRoutine();
  void stepTransitRoutine();
  void startTransitRoutine();
  std::map<float, Eigen::Vector3f> sortSearchTargetsMap(std::vector<int> searchCompletion);
private:
  int targetCluster_ = 0;
  nanomap::instance::GymInstance* gymInstance_;
  std::tuple<int, int, int, std::vector<Eigen::Vector3f>>* transitGoals_;
  std::tuple<int, int, int, std::vector<Eigen::Vector3f>>* searchGoals_;
  std::map<float, Eigen::Vector3f> searchTargetsMap_;
  int currentCluster_; //This is the true cluster, used for some path calculations
  // int currentTargetCluster_; //this is the cluster the agent is supposed to be in. 
  //Sometimes the current Cluster and currentTargetCluster are not aligned because
  //Because the agent may be just outside the target cluster, and the planner shits the bed.
  //This was a problem for the transit calcs until the use of a target cluster variable. 
  std::shared_ptr<nanomap::map::Map> agentMap_;
  int currentBoundary_;
  int currentGoalIndex_;
  bool isSearchGoal_;
  bool isGoalComplete_;
  bool targetFoundThisSearch_ = false;
  std::pair<bool, int> foundDuringTransit_ = std::make_pair(false, -1);
  bool isSubGoalComplete_;
  int currentTargetCluster_;
  int currentPlannerCluster_;
  int currentPlannerBoundary_;
  int currentTargetBoundary_;
  bool nearBoundary_;
  bool goalExists_;
  bool* searchMode_;
  bool* transitMode_;
  int numTargets_;
  int simType_;
  int searchType_;
  std::vector<bool> targetsFoundThisSearch_;
  std::vector<bool> areTargetsFound_;

  int testCounter_ = 0;
  Eigen::Vector3f* xyz_;
  Eigen::Vector3f* rpy_;
  Eigen::Array<float, 7, 1> poseAsFloat_;
  nanomap::Pose pose_;
  std::vector<Eigen::Vector3f>* currentGoals_;
  std::map<float, Eigen::Vector3f> searchTargets_;
  rclcpp::TimerBase::SharedPtr timer_;
  size_t count_;
};

//TODO integrate observations into a specific planner manager object maybe? or a specific nanomaptapir object that we update with planner manager?
//For now we are on time crunch, keep it simple.
//Might need gymInstance for ease of data retrieval later, maybe just work with the observations stuff for now and keep tapir interface isolated 
//observation sequences is a vector of observations. with observations being a pair with an int-id, and a vector of int based observations.
class ActionObservationNode : public rclcpp::Node
{
public:
  ActionObservationNode(nanomap::instance::GymInstance& gymInstance,
                        nanomaptapir::planner::singlesearch::Definition* definition,
                  std::vector<std::pair<int, std::vector<int>>>&            observationsSequence,
                std::vector<std::pair<int, int>>&                                                actionSequence,
                std::tuple<int, int, int, std::vector<Eigen::Vector3f>>& searchGoals,
                std::tuple<int, int, int, std::vector<Eigen::Vector3f>>& transitGoals);
private:
  int targetCluster_ = 0;
  nanomap::instance::GymInstance* gymInstance_;
  nanomaptapir::planner::singlesearch::Definition* definition_;
  std::tuple<int, int, int, std::vector<Eigen::Vector3f>>* transitGoals_;
  std::tuple<int, int, int, std::vector<Eigen::Vector3f>>* searchGoals_;
  bool actionComplete_;
  bool actionPending_;
  int currentTargetCluster_;
  int currentRealCluster_;
  int currentPlannerCluster_;
  int currentPlannerBoundary_;
  int currentTargetBoundary_;
  int currentBoundary_;
  int mode_ = -1;
  int isFound_ = 0;
  int actionId_ = 0;
  std::vector<std::pair<int,std::vector<int>>>* observationsSequence_;
  int currentObservation_;
  std::vector<std::pair<int, int>>* actionSequence_;
  rclcpp::TimerBase::SharedPtr timer_;
  size_t count_;
};




class SingleAgentTapirNode : public rclcpp::Node
{
public:
  SingleAgentTapirNode(nanomaptapir::planner::singlesearch::Interface& tapirInterface, 
                std::vector<std::pair<int, std::vector<int>>>&            observationsSequence,
                std::vector<std::pair<int,int>>&                                                actionSequence,
                std::vector<nanomaptapir::planner::singlesearch::Observation>& observations);
private:
  //nanomap::instance::GymInstance* gymInstance_;
  nanomaptapir::planner::singlesearch::Interface* tapirInterface_;
  std::vector<std::pair<int,std::vector<int>>>* observationsSequence_;
  std::vector<nanomaptapir::planner::singlesearch::Observation>* observations_;
  int actionId_;
  int currentObservation_;
  std::vector<std::pair<int,int>>* actionSequence_;

  rclcpp::TimerBase::SharedPtr timer_;
  size_t count_;
};


class CompletionCheck : public rclcpp::Node
{
  public:
    CompletionCheck(
    nanomaptapir::planner::singlesearch::Definition* definition,
    std::vector<std::pair<int, std::vector<int>>>& observationsSequence,
    std::vector<std::pair<int, int>>& actionSequence);
  private:
    int agentCluster_;
    bool targetFound_;
    nanomaptapir::planner::singlesearch::Definition* definition_;
    std::vector<std::pair<int, std::vector<int>>>* observationsSequence_;
    std::vector<std::pair<int, int>>* actionSequence_;
    std::chrono::time_point<std::chrono::high_resolution_clock> startTime_;
    int targetFoundStatus_ = false;
    int actionId_;
    int observationId_;
    bool waitingOnSearch_ = false;
    std::vector<bool> clusterSearchStatus_;
    rclcpp::TimerBase::SharedPtr timer_;
};


    }
}

#endif