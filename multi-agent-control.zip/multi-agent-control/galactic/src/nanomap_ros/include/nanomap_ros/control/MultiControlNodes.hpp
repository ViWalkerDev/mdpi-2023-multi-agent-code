#ifndef NANOMAP_ROS_MULTI_CONTROL_NODES_HPP_
#define NANOMAP_ROS_MULTI_CONTROL_NODES_HPP_


#include "rclcpp/rclcpp.hpp"
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <thread>
#include <array>
#include <regex>
#include "openvdb/openvdb.h"
#include <openvdb/io/Stream.h>
#include "std_msgs/msg/string.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/point_stamped.hpp"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include "nanomap_msgs/msg/openvdb_grid.hpp"
#include "nanomap_msgs/msg/policy_observations.hpp"
#include "nanomap_msgs/msg/multi_agent_info.hpp"
#include "nanomap_msgs/srv/policy_query.hpp"

#include "nanomap/instance/GymInstance.h"
#include "nanomap/map/Map.h"
#include "nanomap/agent/Agent.h"
#include "nanomap/config/Config.h"
#include "nanomap/nanomap.h"
#include "nanomap/sensor/SensorData.h"

#include <Eigen/Geometry>
#include <Eigen/Core>
#include <Eigen/Dense>
#include "visualization_msgs/msg/marker.hpp"
#include "visualization_msgs/msg/marker_array.hpp"

#include "nanomaptapir/planner/problems/multisearch/Definition.hpp"
#include "nanomaptapir/planner/problems/multisearch/Observation.hpp"
#include "nanomaptapir/planner/problems/multisearch/Action.hpp"
#include "nanomaptapir/planner/problems/multisearch/Interface.hpp"
#define SIMPLE_SIM 1

namespace nanomap_ros{
    namespace multi_control{
using Pose = nanomap::Pose;
using namespace std::chrono_literals;


struct MultiAgentInfo
{
  rclcpp::Time timeStamp_;
  int infoId_;
  int agentId_;
  //The current cluster that the agent planner considers occupied
  int currentCluster_;
  bool actionCompletion_;
  //Size of nTargets+1 details if it has completed a search of the cluster it resides in, and which targets were found
  std::vector<bool> searchStatus_;
};

class LatestObservationInfo
{
public:
  LatestObservationInfo(nanomaptapir::planner::multisearch::Definition* definition); 
  void processLatestInfo(std::vector<nanomap_ros::multi_control::MultiAgentInfo> agentInfo);
  std::vector<int> agentClusters(){return agentClusters_;}
  std::vector<std::vector<bool>> searchStatus(){return searchStatus_;}
  bool actionCompletion(){return actionCompletion_;}
private:
  int nAgents_;
  int nTargets_;
  bool actionCompletion_;
  std::vector<int> agentClusters_;
  std::vector<std::vector<bool>> searchStatus_;
  nanomaptapir::planner::multisearch::Definition* definition_;
};

class MultiMacroManagerNode : public rclcpp::Node
{
public:
  MultiMacroManagerNode(int nTargets,int simType, int searchType, 
                nanomap::instance::GymInstance& gymInstance,
                std::tuple<int, std::vector<bool>, int, std::vector<Eigen::Vector3f>>& searchGoals,
                std::tuple<int, int, int, std::vector<Eigen::Vector3f>>& transitGoals,
                Eigen::Vector3f &xyz, Eigen::Vector3f &rpy, bool& transitMode, bool& searchMode, std::vector<Eigen::Vector3f>& currentGoals);
  void populateSearchTargets(std::vector<int> replaceIndex);
  std::vector<bool> areTargetsSeen();
  std::vector<int>  checkSearchTargets();
  void stepSearchRoutine();
  void startSearchRoutine();
  void stepTransitRoutine();
  void startTransitRoutine();
  std::map<float, Eigen::Vector3f> sortSearchTargetsMap(std::vector<int> searchCompletion);
private:
  int targetCluster_ = 0;
  int nTargets_;
  nanomap::instance::GymInstance* gymInstance_;
  std::tuple<int, int, int, std::vector<Eigen::Vector3f>>* transitGoals_;
  std::tuple<int, std::vector<bool>, int, std::vector<Eigen::Vector3f>>* searchGoals_;
  std::map<float, Eigen::Vector3f> searchTargetsMap_;
  int currentCluster_; //This is the true cluster, used for some path calculations
  int currentTargetCluster_; //this is the cluster the agent is supposed to be in. 
  //Sometimes the current Cluster and currentTargetCluster are not aligned because
  //Because the agent may be just outside the target cluster, and the planner shits the bed.
  //This was a problem for the transit calcs until the use of a target cluster variable. 
  std::shared_ptr<nanomap::map::Map> agentMap_;
  int currentPlannerCluster_;
  int currentBoundary_;
  int currentGoalIndex_;
  int simType_ = 0;
  int searchType_ = 0;
  bool isSearchGoal_;
  bool isGoalComplete_;
  bool isSubGoalComplete_;
  bool goalExists_;
  bool* searchMode_;
  bool* transitMode_;
  std::vector<bool> searchStatus_;
  std::vector<bool> targetsFoundThisSearch_;
  std::vector<bool> areTargetsFound_;
  std::vector<std::pair<bool, int>> foundDuringTransit_;
  int testCounter_ = 0;
  Eigen::Vector3f* xyz_;
  Eigen::Vector3f* rpy_;
  Eigen::Array<float, 7, 1> poseAsFloat_;
  nanomap::Pose pose_;
  std::vector<Eigen::Vector3f>* currentGoals_;
  std::map<float, Eigen::Vector3f> searchTargets_;
  rclcpp::TimerBase::SharedPtr timer_;
  size_t count_;
  bool nearBoundary_;
};


//Manages the actions for a single agent. produces an observation when appropriate
class MultiActionManager : public rclcpp::Node
{
public:
  MultiActionManager(nanomap::instance::GymInstance& gymInstance,
                  nanomaptapir::planner::multisearch::Definition* definition,
                  std::vector<nanomap_ros::multi_control::MultiAgentInfo>&  agentInfoSequence,
                std::vector<std::pair<int, int>>&                              actionSequence,
                std::tuple<int, std::vector<bool>, int, std::vector<Eigen::Vector3f>>& searchGoals,
                std::tuple<int, int, int, std::vector<Eigen::Vector3f>>& transitGoals
                );
private:
  int agentId_;
  int infoId_;
  int nTargets_;
  int targetCluster_ = 0;
  nanomap::instance::GymInstance* gymInstance_;
  nanomaptapir::planner::multisearch::Definition* definition_;
  std::tuple<int, int, int, std::vector<Eigen::Vector3f>>* transitGoals_;
  std::tuple<int, std::vector<bool>, int, std::vector<Eigen::Vector3f>>* searchGoals_;
  bool actionComplete_;
  bool actionPending_;
  int currentTargetCluster_;
  int currentRealCluster_;
  int currentPlannerCluster_;
  int currentBoundary_;
  std::vector<bool> searchStatus_;
  int mode_ = -1;
  int isFound_ = 0;
  int actionId_ = 0;
  std::vector<nanomap_ros::multi_control::MultiAgentInfo>* agentInfoSequence_;
  std::vector<std::pair<int, int>>* actionSequence_;
  rclcpp::TimerBase::SharedPtr timer_;
  size_t count_;
};



//Each agent has one of these
class MultiObservationPublisher : public rclcpp::Node
{
public:
  MultiObservationPublisher(int agentId_, std::string topicName, std::vector<nanomap_ros::multi_control::MultiAgentInfo>& agentStampedInfo);
private:
  int agentId_;
  std::string topicName_;
  std::vector<nanomap_ros::multi_control::MultiAgentInfo>* agentStampedInfo_;
  //When the last entry in agentStampedInfo_ differs from the latestInfo_ we update lastest info. 

  nanomap_ros::multi_control::MultiAgentInfo latestInfo_;
  //this is the msg that is used to publish latestInfo_;
  nanomap_msgs::msg::MultiAgentInfo msg_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<nanomap_msgs::msg::MultiAgentInfo>::SharedPtr publisher_;
};

//And numAgents-1 of these. (one for each other agent)
class MultiObservationSubscriber : public rclcpp::Node
{
public:
  MultiObservationSubscriber(int agentId_, std::string topicName, std::vector<nanomap_ros::multi_control::MultiAgentInfo>& agentStampedInfo);

private:
  int agentId_;
  std::string topicName_;
  //This is the vector that new info gets place if the latest msg is not the same as the last msg received. 
  std::vector<nanomap_ros::multi_control::MultiAgentInfo>* agentStampedInfo_;
  //When the latest info from msg_ differs from the latestInfo_ we update agentStampedInfo with this new latest info.  
  nanomap_ros::multi_control::MultiAgentInfo latestInfo_;
  
  void topic_callback(const nanomap_msgs::msg::MultiAgentInfo::SharedPtr msg){
    int infoId = msg->info_id;
    if(infoId != latestInfo_.infoId_){
      latestInfo_.timeStamp_ = msg->info_stamp;
      latestInfo_.infoId_ = msg->info_id;
      latestInfo_.agentId_ = msg->agent_id;
      latestInfo_.currentCluster_ = msg->current_cluster;
      latestInfo_.searchStatus_ = msg->search_status;
      agentStampedInfo_->push_back(latestInfo_);
    }
  }
  
  //this is the msg that is used to publish latestInfo_;
  rclcpp::Subscription<nanomap_msgs::msg::MultiAgentInfo>::SharedPtr subscription_;
};


//Organizes the agent info according to age and creates the necessary observations for the planner.
class MultiObservationManager : public rclcpp::Node
{
public:
  MultiObservationManager(nanomap::instance::GymInstance& gymInstance,
                        nanomaptapir::planner::multisearch::Definition* definition,
                  std::vector<std::vector<nanomap_ros::multi_control::MultiAgentInfo>>& agentStampedInfo,
                  std::vector<std::pair<bool,std::pair<std::vector<int>, std::vector<std::vector<bool>>>>>& plannerObservations);
private:
  nanomap::instance::GymInstance* gymInstance_;
  nanomaptapir::planner::multisearch::Definition* definition_;

  //This is the observation sequence shared with the action observation manager. These are all this agents observations
  std::vector<std::vector<nanomap_ros::multi_control::MultiAgentInfo>>* agentStampedInfo_;
  std::vector<nanomap_ros::multi_control::MultiAgentInfo> newInfo_;
  //std::map<rclcpp::Time, nanomap_ros::multi_control::MultiAgentInfo> newInfo_;
  std::vector<std::pair<bool, std::pair<std::vector<int>, std::vector<std::vector<bool>>>>>* plannerObservations_;
  int currentObservation_;
  int nAgents_;
  nanomap_ros::multi_control::LatestObservationInfo latestObservationInfo_;
  std::vector<int> infoIds_;
  std::vector<std::pair<int, int>>* actionSequence_;
  rclcpp::TimerBase::SharedPtr timer_;
  int isTimed_;


  size_t count_;
};


class CompletionCheck : public rclcpp::Node
{
  public:
    CompletionCheck(
    nanomaptapir::planner::multisearch::Definition* definition,
    std::vector<std::vector<nanomap_ros::multi_control::MultiAgentInfo>>& agentStampedInfo);
  private:
    nanomaptapir::planner::multisearch::Definition* definition_;
    std::vector<std::vector<nanomap_ros::multi_control::MultiAgentInfo>>* agentStampedInfo_;
    std::chrono::time_point<std::chrono::high_resolution_clock> startTime_;
    std::vector<bool> targetFoundStatus_;
    std::vector<bool> clusterSearchStatus_;
    std::vector<int> infoIds_;
    int nAgents_;
    int nTargets_;
    rclcpp::TimerBase::SharedPtr timer_;
};


class MultiAgentTapirNode : public rclcpp::Node
{
public:
  MultiAgentTapirNode(int agentId,
                nanomaptapir::planner::multisearch::Interface& tapirInterface, 
                std::vector<std::pair<bool, std::pair<std::vector<int>, std::vector<std::vector<bool>>>>>&           plannerObservations,
                std::vector<std::pair<int,int>>&                                                actionSequence);
private:
  //nanomap::instance::GymInstance* gymInstance_;
  int agentId_;
  nanomaptapir::planner::multisearch::Interface* tapirInterface_;
  std::vector<std::pair<bool, std::pair<std::vector<int>, std::vector<std::vector<bool>>>>>* plannerObservations_;
  int actionId_;
  int lastAction_;
  int currentObservation_;
  std::vector<std::pair<int,int>>* actionSequence_;
  bool* actionCompletion_;
  rclcpp::TimerBase::SharedPtr timer_;
  size_t count_;
};



    }
}

#endif