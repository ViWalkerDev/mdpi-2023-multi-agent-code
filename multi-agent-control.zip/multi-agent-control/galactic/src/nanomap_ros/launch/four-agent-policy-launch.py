
from launch_ros.actions import Node

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, TimerAction, Shutdown
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration, PythonExpression

def generate_launch_description():
    # spawn_agent_0 = ExecuteProcess(
    # cmd=[[
    #     'ros2 run nanomap_ros multiTest 0 2 1 1'
    # ]],
    # required=True,
    # output="screen",
    # shell=True
    # )
    # //agent_0_node = 
    # spawn_agent_1 = ExecuteProcess(
    # cmd=[[
    #     'ros2 run nanomap_ros multiTest 1 2 1 1'
    # ]],
    # shell=True
    # )

    return LaunchDescription([
        ##Agent 0
        Node(
        package='nanomap_ros',
        executable='multiTest',
        arguments=["0", "4", "0", "1"],
        name='agent_0_control',
        output="screen",
        on_exit=Shutdown(),
        ),
        Node(
        package='py_nanomap_ros',
        executable='SearchPolicyServer',
        arguments=["0"],
        name='agent_0_search_policy_server',
        ),
        Node(
        package='py_nanomap_ros',
        executable='TransitPolicyServer',
        arguments=["0"],
        name='agent_0_transit_policy_server',
        ),

        ##Agent 1

        Node(
        package='nanomap_ros',
        executable='multiTest',
        arguments=["1", "4", "0", "1"],
        name='agent_1_control',
        ),
        Node(
        package='py_nanomap_ros',
        executable='SearchPolicyServer',
        arguments=["1"],
        name='agent_1_search_policy_server',
        ),
        Node(
        package='py_nanomap_ros',
        executable='TransitPolicyServer',
        arguments=["1"],
        name='agent_1_transit_policy_server',
        ),

        ##Agent 2

        Node(
        package='nanomap_ros',
        executable='multiTest',
        arguments=["2", "4", "0", "1"],
        name='agent_2_control',
        ),
        Node(
        package='py_nanomap_ros',
        executable='SearchPolicyServer',
        arguments=["2"],
        name='agent_2_search_policy_server',
        ),
        Node(
        package='py_nanomap_ros',
        executable='TransitPolicyServer',
        arguments=["2"],
        name='agent_2_transit_policy_server',
        ),
                
        ##Agent 2

        Node(
        package='nanomap_ros',
        executable='multiTest',
        arguments=["3", "4", "0", "1"],
        name='agent_3_control',
        ),
        Node(
        package='py_nanomap_ros',
        executable='SearchPolicyServer',
        arguments=["3"],
        name='agent_3_search_policy_server',
        ),
        Node(
        package='py_nanomap_ros',
        executable='TransitPolicyServer',
        arguments=["3"],
        name='agent_3_transit_policy_server',
        ),
    ])
