
from launch_ros.actions import Node

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, TimerAction, Shutdown
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration, PythonExpression

def generate_launch_description():
    # spawn_agent_0 = ExecuteProcess(
    # cmd=[[
    #     'ros2 run nanomap_ros multiTest 0 2 1 1'
    # ]],
    # required=True,
    # output="screen",
    # shell=True
    # )
    # //agent_0_node = 
    # spawn_agent_1 = ExecuteProcess(
    # cmd=[[
    #     'ros2 run nanomap_ros multiTest 1 2 1 1'
    # ]],
    # shell=True
    # )

    return LaunchDescription([
        Node(
        package='nanomap_ros',
        executable='multiTest',
        arguments=["0", "2", "1", "1"],
        name='agent_0_control',
        output="screen",
        on_exit=Shutdown(),
        ),
        Node(
        package='nanomap_ros',
        executable='multiTest',
        arguments=["1", "2", "1", "1"],
        name='agent_1_control',
        ),
    ])
