#include <openvdb/openvdb.h>
#include "nanomap/mapgen/procedural/MapGen.h"



int main(int argc, char **argv){
    if(!(argc == 3)){
    std::cout << "please provide map gen config file and desired save file" << std::endl;
    return 0;
    }

    std::string mapGenConfig = argv[1];
    std::string saveString = argv[2];
    openvdb::initialize();
    int count = 0;
    int seed = time(0);
    srand(seed);
    nanomap::mapgen::MapGen generator;

    openvdb::FloatGrid::Ptr simGrid = generator.generateAndReturnMap(mapGenConfig); 
    openvdb::GridPtrVec Grids;
    Grids.push_back(simGrid);
    // Write out the contents of the container
    openvdb::io::File savefile(saveString);
    savefile.write(Grids);
    savefile.close();
}