#include <openvdb/openvdb.h>
#include "nanomap/mapgen/procedural/MapGen.h"
#include "nanomap/instance/GymInstance.h"
#include "nanomap/map/Map.h"
#include "nanomap/agent/Agent.h"
#include "nanomap/config/Config.h"
#include "nanomap/nanomap.h"
#include "nanomap/sensor/SensorData.h"
#include "rclcpp/rclcpp.hpp"

#include <ament_index_cpp/get_package_share_directory.hpp>

int main(int argc, char **argv){
    if(!(argc == 2)){
    std::cout << "please provide desired save file" << std::endl;
    return 0;
    }

    std::string saveString = argv[1];
    openvdb::initialize();
    int count = 0;
    int seed = time(0);
    srand(seed);

    std::string package_share_directory = ament_index_cpp::get_package_share_directory("nanomap_ros");
    std::string gymConfig = package_share_directory + "/config/gym/frustumSim/config.txt";

    //CREATE GYM INSTANCE
    
    nanomap::instance::GymInstance gymInstance(gymConfig);
    int environmentKnowledge = 1;
    float knowledgeRadius = 2.0;
    gymInstance.setEnvironmentKnowledge(environmentKnowledge, knowledgeRadius);
    gymInstance.createManager();
    gymInstance.createHandler();
    float obstacleOdds = 0.0075;
    gymInstance.generateObstaclesInSimGrid(saveString, obstacleOdds);

    return 1;
}