#include "rclcpp/rclcpp.hpp"
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <thread>
#include "openvdb/openvdb.h"
#include <openvdb/io/Stream.h>
#include "std_msgs/msg/string.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/point_stamped.hpp"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include "nanomap_msgs/msg/openvdb_grid.hpp"

#include "nanomap/instance/GymInstance.h"
#include "nanomap/map/Map.h"
#include "nanomap/agent/Agent.h"
#include "nanomap/config/Config.h"
#include "nanomap/nanomap.h"
#include "nanomap/sensor/SensorData.h"

#include <Eigen/Geometry>
#include <Eigen/Core>
#include <Eigen/Dense>
using namespace std::chrono_literals;
static rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr occupied_point_cloud;

std::string string_thread_id()
{
  auto hashed = std::hash<std::thread::id>()(std::this_thread::get_id());
  return std::to_string(hashed);
}

  using GridType = openvdb::FloatGrid;
  using TreeType = GridType::TreeType;
  using IterType = TreeType::ValueOnIter;
  using SensorData = nanomap::sensor::SensorData;

class LeafPublisherNode : public rclcpp::Node
{
public:
  LeafPublisherNode(openvdb::FloatGrid::Ptr grid, std::string node_name)
  : Node(node_name), count_(0) , grid_(grid)
  {
    std::string topic = grid_->getName();
    publisher_ = this->create_publisher<nanomap_msgs::msg::OpenvdbGrid>(topic, 10);
    auto timer_callback =
      [this]() -> void {
        auto curr_thread = string_thread_id();
        msg_.header.frame_id = "world";
        msg_.header.stamp = now();
        std::ostringstream ostr(std::ios_base::binary);
        openvdb::GridPtrVecPtr grids(new openvdb::GridPtrVec);
        gridCopy_ = grid_->deepCopy();
        grids->push_back(gridCopy_);
        openvdb::io::Stream(ostr).write(*grids);
        int size = ostr.str().size();
        msg_.size = size;
        msg_.data.resize(size);
        std::memcpy(msg_.data.data(), reinterpret_cast<unsigned char*>(const_cast<char*>(ostr.str().c_str())), size);
        gridCopy_->clear();
        this->publisher_->publish(msg_);
      };
    timer_ = this->create_wall_timer(500ms, timer_callback);
  }


private:
  nanomap_msgs::msg::OpenvdbGrid msg_;
  openvdb::FloatGrid::Ptr grid_;
  openvdb::FloatGrid::Ptr gridCopy_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<nanomap_msgs::msg::OpenvdbGrid>::SharedPtr publisher_;
  size_t count_;
};

class SensorPublisher : public rclcpp::Node
{
public:
  SensorPublisher(nanomap::instance::GymInstance& gymInstance)
  : Node("sensor_publisher"), count_(0) , gymInstance_(&gymInstance)
  {
    std::string topic = "sensor_publisher";
    publisher_ = this->create_publisher<sensor_msgs::msg::PointCloud2>(topic, 10);

    auto timer_callback =
      [this]() -> void {
        int sensorIndex = 0;
        //0.0 -1.0 0.0 0.0 0.0 1.0 1.0 0.0 0.0
        Eigen::Vector3f vec1(0.0,-1.0,0.0);
        Eigen::Vector3f vec2(0.0,0.0,1.0);
        Eigen::Vector3f vec3(1.0,0.0,0.0);
        
        Eigen::Matrix<float,3,3> rotation;
        rotation.row(0) = vec1;
        rotation.row(1) = vec2;
        rotation.row(2) = vec3;

        pcl::PointCloud<pcl::PointXYZ>::Ptr cloud =
          boost::make_shared<pcl::PointCloud<pcl::PointXYZ>>();
        for (int x = 0; x < gymInstance_->agentManager()->getAgent(0)->sensor(sensorIndex)->sensorData()->sharedParameters()._pclSize; x++) {
          Eigen::Vector3f point(gymInstance_->agentManager()->getAgent(0)->sensor(sensorIndex)->publishCloud().col(x)(0),
                    gymInstance_->agentManager()->getAgent(0)->sensor(sensorIndex)->publishCloud().col(x)(1),
                    gymInstance_->agentManager()->getAgent(0)->sensor(sensorIndex)->publishCloud().col(x)(2));
          Eigen::Vector3f rotatedPoint(rotation(0,0)*point(0)+rotation(0,1)*point(1)+rotation(0,2)*point(2),
                          rotation(1,0)*point(0)+rotation(1,1)*point(1)+rotation(1,2)*point(2),
                          rotation(2,0)*point(0)+rotation(2,1)*point(1)+rotation(2,2)*point(2));
          cloud->push_back(pcl::PointXYZ(rotatedPoint(0),
                                          rotatedPoint(1),
                                          rotatedPoint(2)));

        }
        pcl::toROSMsg(*cloud, msg_);
        auto curr_thread = string_thread_id();
        msg_.header.frame_id = "agent";
        msg_.header.stamp = now();
        this->publisher_->publish(msg_);
      };
    timer_ = this->create_wall_timer(100ms, timer_callback);
  }

private:
  sensor_msgs::msg::PointCloud2 msg_;
  nanomap::instance::GymInstance* gymInstance_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr publisher_;
  size_t count_;
};

class UnknownPublisher : public rclcpp::Node
{
public:
  UnknownPublisher(nanomap::instance::GymInstance& gymInstance)
  : Node("unknown_publisher"), count_(0), gymInstance_(&gymInstance)
  {
    std::string topic1 = "unknown_publisher";
    publisher_ = this->create_publisher<sensor_msgs::msg::PointCloud2>(topic1, 10);
    auto timer_callback =
      [this]() -> void {
        Eigen::ArrayXf obsCloud = gymInstance_->getObservationCloudByIndex(0);
  
        pcl::PointCloud<pcl::PointXYZ>::Ptr cloud1 =
          boost::make_shared<pcl::PointCloud<pcl::PointXYZ>>();

         int numObs = obsCloud.size()/6;
         for (int x = 0; x < numObs; x++) {
          if(sqrt(obsCloud(x*3+0)*obsCloud(x*3+0) + 
              obsCloud(x*3+1)*obsCloud(x*3+1) + 
              obsCloud(x*3+2)*obsCloud(x*3+2)) < 10){
               cloud1->push_back(pcl::PointXYZ(obsCloud(x*3+0),
                                           obsCloud(x*3+1),
                                           obsCloud(x*3+2)));
          }

        }

        pcl::toROSMsg(*cloud1, msg_);
        auto curr_thread = string_thread_id();
        msg_.header.frame_id = "agent";
        msg_.header.stamp = now();
        this->publisher_->publish(msg_);
      };
    timer_ = this->create_wall_timer(100ms, timer_callback);
  }

private:
  nanomap::instance::GymInstance* gymInstance_;
  sensor_msgs::msg::PointCloud2 msg_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr publisher_;
  
  size_t count_;
};

class HazardPublisher : public rclcpp::Node
{
public:
  HazardPublisher(nanomap::instance::GymInstance& gymInstance)
  : Node("hazard_publisher"), count_(0), gymInstance_(&gymInstance)
  {
    std::string topic2 = "hazard_publisher";
    publisher2_ = this->create_publisher<sensor_msgs::msg::PointCloud2>(topic2, 10);
    auto timer_callback =
      [this]() -> void {
        Eigen::ArrayXf obsCloud = gymInstance_->getObservationCloudByIndex(0);

        pcl::PointCloud<pcl::PointXYZ>::Ptr cloud2 =
          boost::make_shared<pcl::PointCloud<pcl::PointXYZ>>();
          int numObs = obsCloud.size()/6;
        for (int y = 0; y < numObs; y++) {
          if(sqrt(obsCloud(numObs*3+(y*3+0))*obsCloud(numObs*3+(y*3+0)) + 
              obsCloud(numObs*3+(y*3+1))*obsCloud(numObs*3+(y*3+1)) + 
              obsCloud(numObs*3+(y*3+2))*obsCloud(numObs*3+(y*3+2))) < 10){
                cloud2->push_back(pcl::PointXYZ(obsCloud(numObs*3+(y*3+0)),
                                           obsCloud(numObs*3+(y*3+1)),
                                           obsCloud(numObs*3+(y*3+2))));

              }
           
        }

        pcl::toROSMsg(*cloud2, msg2_);
        auto curr_thread2 = string_thread_id();
        msg2_.header.frame_id = "agent";
        msg2_.header.stamp = now();
        this->publisher2_->publish(msg2_);
      };
    timer_ = this->create_wall_timer(100ms, timer_callback);
  }

private:
  nanomap::instance::GymInstance* gymInstance_;
  sensor_msgs::msg::PointCloud2 msg2_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr publisher2_;
  
  size_t count_;
};

// class ObservationPublisher : public rclcpp::Node
// {
// public:
//   ObservationPublisher(nanomap::instance::GymInstance& gymInstance)
//   : Node("observation_publisher"), count_(0), gymInstance_(&gymInstance)
//   {
//     std::string topic = "observation_publisher";
//     publisher_ = this->create_publisher<sensor_msgs::msg::PointCloud2>(topic, 10);

//     auto timer_callback =
//       [this]() -> void {
//         pcl::PointCloud<pcl::PointXYZ>::Ptr cloud =
//           boost::make_shared<pcl::PointCloud<pcl::PointXYZ>>();
//         Eigen::ArrayXf obsCloud = gymInstance_->getObservationCloudByIndex(0);
//          for (int x = 0; x < obsCloud.size()/3; x++) {
//            cloud->push_back(pcl::PointXYZ(obsCloud(x*3+0),
//                                            obsCloud(x*3+1),
//                                            obsCloud(x*3+2)));

//         }
//         pcl::toROSMsg(*cloud, msg_);
//         auto curr_thread = string_thread_id();
//         msg_.header.frame_id = "agent";
//         msg_.header.stamp = now();
//         this->publisher_->publish(msg_);
//       };
//     timer_ = this->create_wall_timer(100ms, timer_callback);
//   }

// private:
//   nanomap::instance::GymInstance* gymInstance_;
//   sensor_msgs::msg::PointCloud2 msg_;
//   rclcpp::TimerBase::SharedPtr timer_;
//   rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr publisher_;
//   size_t count_;
// };


class GoalPublisher : public rclcpp::Node
{
public:
  GoalPublisher(nanomap::instance::GymInstance& gymInstance)
  : Node("goal_publisher"),count_(0), gymInstance_(&gymInstance)
  {
    std::string topic = "goal_publisher";
    publisher_ = this->create_publisher<geometry_msgs::msg::PointStamped>(topic, 10);

    auto timer_callback =
    [this]() -> void {
      Eigen::Array<float, 11, 1> goalObs = gymInstance_->getGoalObservationsByIndex(0);
      rclcpp::Time now = this->get_clock()->now();
      
      msg_.header.stamp = now;
      msg_.header.frame_id = "agent";
      //std::cout << "goalObs " << goalObs(0) << " / " << goalObs(1) << " / " << goalObs(2) << std::endl;
      msg_.point.x = goalObs(0)*10;
      msg_.point.y =  goalObs(1)*10;
      msg_.point.z =  goalObs(2)*10;

      // msg_.pose.orientation.x = (double)sensorData->sharedParameters()._pose.orientation.x();
      // msg_.pose.orientation.y = (double)sensorData->sharedParameters()._pose.orientation.y();
      // msg_.pose.orientation.z = (double)sensorData->sharedParameters()._pose.orientation.z();
      // msg_.pose.orientation.w = (double)sensorData->sharedParameters()._pose.orientation.w();

      // Send the transformation
      this->publisher_->publish(msg_);
    };
    timer_ = this->create_wall_timer(10ms, timer_callback);
  }

private:
  geometry_msgs::msg::PointStamped msg_;

  nanomap::instance::GymInstance* gymInstance_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<geometry_msgs::msg::PointStamped>::SharedPtr publisher_;
  size_t count_;
};

class GoalTwoPublisher : public rclcpp::Node
{
public:
  GoalTwoPublisher(nanomap::instance::GymInstance& gymInstance)
  : Node("goal_two_publisher"),count_(0), gymInstance_(&gymInstance)
  {
    std::string topic = "goal_two_publisher";
    publisher_ = this->create_publisher<geometry_msgs::msg::PointStamped>(topic, 10);

    auto timer_callback =
    [this]() -> void {
      Eigen::Array<float, 11, 1> goalObs = gymInstance_->getGoalObservationsByIndex(0);
      rclcpp::Time now = this->get_clock()->now();
      
      msg_.header.stamp = now;
      msg_.header.frame_id = "agent";

      msg_.point.x = goalObs(3)*10;
      msg_.point.y =  goalObs(4)*10;
      msg_.point.z =  goalObs(5)*10;

      // msg_.pose.orientation.x = (double)sensorData->sharedParameters()._pose.orientation.x();
      // msg_.pose.orientation.y = (double)sensorData->sharedParameters()._pose.orientation.y();
      // msg_.pose.orientation.z = (double)sensorData->sharedParameters()._pose.orientation.z();
      // msg_.pose.orientation.w = (double)sensorData->sharedParameters()._pose.orientation.w();

      // Send the transformation
      this->publisher_->publish(msg_);
    };
    timer_ = this->create_wall_timer(10ms, timer_callback);
  }

private:
  geometry_msgs::msg::PointStamped msg_;

  nanomap::instance::GymInstance* gymInstance_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<geometry_msgs::msg::PointStamped>::SharedPtr publisher_;
  size_t count_;
};



class PosePublisher : public rclcpp::Node
{
public:
  PosePublisher(nanomap::instance::GymInstance& gymInstance, int agentIndex, int sensorIndex)
  : Node("agent_pose_publisher"), gymInstance_(&gymInstance), agentIndex_(agentIndex), sensorIndex_(sensorIndex)
  {
    std::string topic = "Agent_" + std::to_string(agentIndex_) + "PoseStamped";
    publisher_ = this->create_publisher<geometry_msgs::msg::PoseStamped>(topic, 10);

    auto timer_callback =
    [this]() -> void {
      rclcpp::Time now = this->get_clock()->now();
      std::shared_ptr<SensorData> sensorData = gymInstance_->agentManager()->getAgent(agentIndex_)->sensor(sensorIndex_)->sensorData();
      msg_.header.stamp = now;
      msg_.header.frame_id = "world";

      msg_.pose.position.x = sensorData->sharedParameters()._pose.position(0);
      msg_.pose.position.y = sensorData->sharedParameters()._pose.position(1);
      msg_.pose.position.z = sensorData->sharedParameters()._pose.position(2);

      msg_.pose.orientation.x = (double)sensorData->sharedParameters()._pose.orientation.x();
      msg_.pose.orientation.y = (double)sensorData->sharedParameters()._pose.orientation.y();
      msg_.pose.orientation.z = (double)sensorData->sharedParameters()._pose.orientation.z();
      msg_.pose.orientation.w = (double)sensorData->sharedParameters()._pose.orientation.w();

      // Send the transformation
      this->publisher_->publish(msg_);
    };

      timer_ = this->create_wall_timer(20ms, timer_callback);
  }

  private:
    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr publisher_;
    nanomap::instance::GymInstance* gymInstance_;
    std::string agentname_;
    int agentIndex_;
    int sensorIndex_;
    geometry_msgs::msg::PoseStamped msg_;
  };
//
class FramePublisher : public rclcpp::Node
{
public:
  FramePublisher(nanomap::instance::GymInstance& gymInstance, std::string agentName)
  : Node("agent_frame_publisher"), gymInstance_(&gymInstance), agentname_(agentName)
  {
    this->declare_parameter<std::string>("agentname", "agent");
    this->get_parameter("agentname", agentname_);

    // Initialize the transform broadcaster
    tf_broadcaster_ =
      std::make_unique<tf2_ros::TransformBroadcaster>(*this);

    auto timer_callback =
    [this]() -> void {
      rclcpp::Time now = this->get_clock()->now();
      geometry_msgs::msg::TransformStamped t;
      //std::vector<nanomap::Pose> poses = manager_->agentPoses();
      //std::shared_ptr<SensorData> sensorData = gymInstance_->agentManager()->getAgent(0)->sensor(sensorIndex_)->sensorData();
      //nanomap::Pose* agentPose = gymInstance_->agentManager()->getAgent(0)->agentData()->pose();
      t.header.stamp = now;
      t.header.frame_id = "world";
      t.child_frame_id = agentname_.c_str();

      // t.transform.translation.x = sensorData->sharedParameters()._pose.position(0);
      // t.transform.translation.y = sensorData->sharedParameters()._pose.position(1);
      // t.transform.translation.z = sensorData->sharedParameters()._pose.position(2);

      // t.transform.rotation.x = (double)sensorData->sharedParameters()._pose.orientation.x();
      // t.transform.rotation.y = (double)sensorData->sharedParameters()._pose.orientation.y();
      // t.transform.rotation.z = (double)sensorData->sharedParameters()._pose.orientation.z();
      // t.transform.rotation.w = (double)sensorData->sharedParameters()._pose.orientation.w();

      t.transform.translation.x = gymInstance_->agentManager()->getAgent(0)->agentData()->pose().position(0);
      t.transform.translation.y = gymInstance_->agentManager()->getAgent(0)->agentData()->pose().position(1);
      t.transform.translation.z = gymInstance_->agentManager()->getAgent(0)->agentData()->pose().position(2);

      t.transform.rotation.x = (double)(gymInstance_->agentManager()->getAgent(0)->agentData()->pose().orientation.x());
      t.transform.rotation.y = (double)(gymInstance_->agentManager()->getAgent(0)->agentData()->pose().orientation.y());
      t.transform.rotation.z = (double)(gymInstance_->agentManager()->getAgent(0)->agentData()->pose().orientation.z());
      t.transform.rotation.w = (double)(gymInstance_->agentManager()->getAgent(0)->agentData()->pose().orientation.w());

      tf_broadcaster_->sendTransform(t);

    };

      timer_ = this->create_wall_timer(20ms, timer_callback);
  }

  private:
    rclcpp::TimerBase::SharedPtr timer_;
    std::unique_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;
    nanomap::instance::GymInstance* gymInstance_;
    std::string agentname_;

  };
  class ViewLoopNode : public rclcpp::Node
  {
  public:
    ViewLoopNode(nanomap::instance::GymInstance& gymInstance, std::string node_name)
    : Node(node_name), count_(0) , gymInstance_(&gymInstance)
    {
      auto timer_callback =
        [this]() -> void {
            gymInstance_->gymStep();
          };
      timer_ = this->create_wall_timer(50ms, timer_callback);
    }

  private:
    nanomap::instance::GymInstance* gymInstance_;
    rclcpp::TimerBase::SharedPtr timer_;
    size_t count_;
  };


class PoseLoopNode : public rclcpp::Node
{
public:
  PoseLoopNode(nanomap::instance::GymInstance& gymInstance, Eigen::Vector3f &xyz, Eigen::Vector3f &rpy, std::string node_name)
  : Node(node_name), count_(0) , gymInstance_(&gymInstance),xyz_(&xyz), rpy_(&rpy)
  {
    auto timer_callback =
      [this]() -> void {
          nanomap::Pose pose;
          nanomap::Pose old_pose;
          Eigen::Array<float, 7, 1> poseAsFloat = gymInstance_->getAgentPoseAsFloatByIndex(0);
          old_pose.position.x() = poseAsFloat(0);
          old_pose.position.y() = poseAsFloat(1);
          old_pose.position.z() = poseAsFloat(2);
          old_pose.orientation.w() = poseAsFloat(3);
          old_pose.orientation.x() = poseAsFloat(4);
          old_pose.orientation.y() = poseAsFloat(5);
          old_pose.orientation.z()= poseAsFloat(6);
          //std::cout << (*xyz_).x() << " / " << (*xyz_).y() << " / " << (*xyz_).z() << std::endl;
          // std::cout << poseAsFloat(0) << " / " 
          //   << poseAsFloat(1) << " / " 
          //   << poseAsFloat(2) << " / " 
          //   << poseAsFloat(3) << " / " 
          //   << poseAsFloat(4) << " / " 
          //   << poseAsFloat(5) << " / " 
          //   << poseAsFloat(6) << " / " << std::endl;
          float timeStep = 0.01; 
          Eigen::Vector3f updated_vec = old_pose.orientation.toRotationMatrix()*(*xyz_);
          updated_vec(0) = updated_vec(0)*timeStep;
          updated_vec(1) = updated_vec(1)*timeStep;
          updated_vec(2) = updated_vec(2)*timeStep;
          if(!gymInstance_->agentManager()->getAgent(0)->getAgentCollision(updated_vec)){
            gymInstance_->updateAgentPoseFromVelocities(0,timeStep, (*xyz_).x(), (*xyz_).y(), (*xyz_).z(), (*rpy_).x(), (*rpy_).y(), (*rpy_).z());
            // pose.position = old_pose.position+updated_vec;
            // Eigen::Quaternionf q = Eigen::AngleAxisf((*rpy_)(0), Eigen::Vector3f::UnitX())
            //       * Eigen::AngleAxisf((*rpy_)(1), Eigen::Vector3f::UnitY())
            //       * Eigen::AngleAxisf((*rpy_)(2), Eigen::Vector3f::UnitZ());
            // pose.orientation = q.normalized()*(old_pose.orientation.normalized());
            // //poses.push_back(pose);
            // gymInstance_->updateAgentPose(0,pose);
          }else{
            std::cout<< "Agent Collided with Sim Environment!" << std::endl;
          }
        };
    timer_ = this->create_wall_timer(10ms, timer_callback);
  }

private:
  nanomap::instance::GymInstance* gymInstance_;
  Eigen::Vector3f* xyz_;
  Eigen::Vector3f* rpy_;
  rclcpp::TimerBase::SharedPtr timer_;
  size_t count_;
};


class JoyListenerNode : public rclcpp::Node
{
public:
  JoyListenerNode(Eigen::Vector3f &xyz, Eigen::Vector3f &rpy, std::string node_name)
  : Node(node_name), count_(0) , xyz_(&xyz), rpy_(&rpy)
  {
  subscription_ = this->create_subscription<geometry_msgs::msg::Twist>(
         "/cmd_vel", 10, std::bind(&JoyListenerNode::topic_callback, this, std::placeholders::_1));
  }

private:
  void topic_callback(const geometry_msgs::msg::Twist::ConstSharedPtr msg) {
    (*xyz_)(0)=msg->linear.x;
    (*xyz_)(1)=msg->linear.y;
    (*xyz_)(2)=msg->linear.z;
    (*rpy_)(0) = msg->angular.x;
    (*rpy_)(1) = msg->angular.y;
    (*rpy_)(2) = msg->angular.z;
  }
  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr subscription_;
  Eigen::Vector3f* xyz_;
  Eigen::Vector3f* rpy_;
  rclcpp::TimerBase::SharedPtr timer_;
  size_t count_;
};


int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  openvdb::initialize();

  if(!(argc == 2  || argc ==3)){
    std::cout << "please provide only the path to main config file for joystick Gym" << std::endl;
    return 0;
  }



  std::string gymConfig = argv[1];
  openvdb::initialize();
  nanomap::instance::GymInstance instance(gymConfig);
  int seed = time(0);
  srand(seed);
  int environmentKnowledge = 1;
  float knowledgeRadius = 2.0;
  instance.setObjectsOnPath(true);
  instance.setEnvironmentKnowledge(environmentKnowledge, knowledgeRadius);
        
  instance.createManager();
  instance.createHandler();
  instance.resetAgentByIndex(0);
  instance.onAgentReset();
  //Perform more initialisation here



  Eigen::Vector3f rpy(0,0,0);
  Eigen::Vector3f xyz(0,0,0);

  Eigen::Array<float, 7, 1> poseAsFloat = instance.getAgentPoseAsFloatByIndex(0);
  nanomap::Pose pose;
  std::cout << poseAsFloat(0) << " / " 
            << poseAsFloat(1) << " / " 
            << poseAsFloat(2) << " / " 
            << poseAsFloat(3) << " / " 
            << poseAsFloat(4) << " / " 
            << poseAsFloat(5) << " / " 
            << poseAsFloat(6) << " / " << std::endl; 
  pose.position.x() = poseAsFloat(0);
  pose.position.y() = poseAsFloat(1);
  pose.position.z() = poseAsFloat(2);
  pose.orientation.w() = poseAsFloat(3);
  pose.orientation.x() = poseAsFloat(4);
  pose.orientation.y() = poseAsFloat(5);
  pose.orientation.z()= poseAsFloat(6);

  //std::vector<nanomap::Pose> poses;
  instance.updateAgentPose(0, pose);
  instance.gymStep();
  //instance.generateAgentViews();
  //instance.processAgentViews();
  //poses.push_back(pose);
  //simManager.updateAgentPoses(poses);
  //simManager.updateAgentViews(map_ptr);
  std::cout << "finished updating agent views" << std::endl;
  rclcpp::executors::MultiThreadedExecutor executor;
  auto occupiedVoxelPubNode = std::make_shared<LeafPublisherNode>(instance.agentManager()->getAgent(0)->map()->occupiedGrid(),"occupiedGridVoxels");
  int mode;
  if(argc==2){
    mode = 0;
  }else{
    mode = 1;
  }
  nanomap::Pose sub_pose;
  auto poseLoop = std::make_shared<PoseLoopNode>(instance, xyz, rpy, "poseLoop");
  auto viewLoop = std::make_shared<ViewLoopNode>(instance, "viewLoop");
  auto framePublisher = std::make_shared<FramePublisher>(instance, instance.agentManager()->getAgent(0)->agentData()->agentName());
  auto sensorPublisher = std::make_shared<SensorPublisher>(instance);
  auto goalPublisher = std::make_shared<GoalPublisher>(instance);
  auto goalTwoPublisher = std::make_shared<GoalTwoPublisher>(instance);
  //auto observationPublisher = std::make_shared<ObservationPublisher>(instance);
  auto hazardPublisher = std::make_shared<HazardPublisher>(instance);
  auto unknownPublisher = std::make_shared<UnknownPublisher>(instance);
  auto joyListener = std::make_shared<JoyListenerNode>(xyz, rpy, "joyListener");
  executor.add_node(joyListener);
  executor.add_node(poseLoop);
  executor.add_node(viewLoop);
  executor.add_node(occupiedVoxelPubNode);
  executor.add_node(framePublisher);
  executor.add_node(sensorPublisher);
  executor.add_node(goalPublisher);
  executor.add_node(goalTwoPublisher);
  //executor.add_node(observationPublisher);
  executor.add_node(hazardPublisher);
  executor.add_node(unknownPublisher);
  executor.spin();
  rclcpp::shutdown();


  //simManager.closeHandler();
  return 0;
}
