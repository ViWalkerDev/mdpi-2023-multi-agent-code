#include "rclcpp/rclcpp.hpp"
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <thread>
#include <array>
#include <regex>
#include "openvdb/openvdb.h"
#include <openvdb/io/Stream.h>
#include "std_msgs/msg/string.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/point_stamped.hpp"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include "nanomap_msgs/msg/openvdb_grid.hpp"
#include "nanomap_msgs/msg/policy_observations.hpp"
#include "nanomap_msgs/srv/policy_query.hpp"

#include "nanomap/instance/GymInstance.h"
#include "nanomap/map/Map.h"
#include "nanomap/agent/Agent.h"
#include "nanomap/config/Config.h"
#include "nanomap/nanomap.h"
#include "nanomap/sensor/SensorData.h"

#include <Eigen/Geometry>
#include <Eigen/Core>
#include <Eigen/Dense>
#include "visualization_msgs/msg/marker.hpp"
#include "visualization_msgs/msg/marker_array.hpp"
#include "nanomap_ros/control/MultiControlNodes.hpp"

#include "nanomap_ros/visualization/VisualizerNodes.hpp"
#include "nanomap_ros/control/ControlNodes.hpp"


#include "nanomaptapir/planner/problems/multisearch/Definition.hpp"
#include "nanomaptapir/planner/problems/multisearch/Observation.hpp"
#include "nanomaptapir/planner/problems/multisearch/Action.hpp"
#include "nanomaptapir/planner/problems/multisearch/Interface.hpp"

#include "rclcpp/utilities.hpp" 

#include <ament_index_cpp/get_package_share_directory.hpp>

using Pose = nanomap::Pose;
using namespace std::chrono_literals;

std::string string_thread_id()
{
  auto hashed = std::hash<std::thread::id>()(std::this_thread::get_id());
  return std::to_string(hashed);
}

void readMultiAgentConfig(std::string agentConfig, std::vector<nanomap::Pose>& agentStartPositions, std::vector<Eigen::Vector3f>& targetStartPositions){
  std::cout <<"reading in multiAgentConfig file: " << agentConfig << std::endl;
      std::ifstream *input = new std::ifstream(agentConfig.c_str(), std::ios::in | std::ios::binary);
      //bool end = false;
      std::string file, line;
      int nAgents, nTargets;
      float x,y,z, w, qx, qy, qz;
      *input >> line; // NumAgents
      *input >> nAgents;
      *input >> line; // Agent Positions
      for(int i = 0; i < nAgents; i++){
        *input >> x >> y >> z >> w >> qx >> qy >> qz;
        agentStartPositions.push_back(nanomap::Pose(Eigen::Vector3f(x,y,z),Eigen::Quaternionf(w, qx, qy, qz)));
      }
      *input >> line; // numTargets
      *input >> nTargets;
      *input >> line; //targetPositions
      for(int i = 0; i < nTargets; i++){
        *input >> x >> y >> z;
        targetStartPositions.push_back(Eigen::Vector3f(x,y,z));
      }
      //std::cout << line << std::endl;
}

void printClusterGraph(std::vector<std::vector<std::pair<int,std::vector<std::pair<int,int>>>>> clusterGraph){
  int clusterIndex = 0;
  std::cout << "Cluster graph has " << clusterGraph.size() << " clusters." << std::endl;
  for(auto clusterEntry : clusterGraph){
    std::cout << "Cluster " << clusterIndex << " has " << clusterEntry.size() << " neighbours:";
    for(auto neighbourEntry : clusterEntry){
      std::cout << " " << neighbourEntry.first;
    }
    std::cout << std::endl;
    clusterIndex++;
  }
}

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  openvdb::initialize();
  int seed = time(0);
  srand(seed);
  std::cout << seed << std::endl;
  std::vector<std::string> nonRosArgs = rclcpp::remove_ros_arguments(argc, argv);
  if(!(nonRosArgs.size() >= 5)){
    std::cout << "please provide agent Id and num agents, sim type, and search type" << std::endl;
    //std::cout << "instead received ";
    // for(int x = 1; x < argc; x++){
    //   std::cout << " " << argv[x];
    // }
    return 0;
  }
  int agentId_ = std::stoi(argv[1]);
  std::cout << agentId_ << std::endl;
  int nAgents_ = std::stoi(argv[2]);
  int simType_ = std::stoi(argv[3]);
  int searchType_ = std::stoi(argv[4]);

  
  nanomap_ros::visualization::VisualizerColors colorsObject;
  std::string package_share_directory = ament_index_cpp::get_package_share_directory("nanomap_ros");
  // std::string gymConfig = "/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/config.txt";
  // std::string plannerProblemPath = "/home/vi/github/first-party/src/nanomaptapir/problems/singlesearch/config";
  // std::string plannerConfig = "/home/vi/github/first-party/src/nanomaptapir/problems/singlesearch/config/default.cfg";
  std::string multiConfig = package_share_directory + "/config/planner/multisearch/"+std::to_string(nAgents_)+"/agentConfig.cfg";
  std::string gymConfig = package_share_directory + "/config/gym/frustumSim/config.txt";
  std::string plannerProblemPath = package_share_directory + "/config/planner/multisearch/"+std::to_string(nAgents_);
  std::string plannerConfig = package_share_directory + "/config/planner/multisearch/"+std::to_string(nAgents_) +"/default.cfg";
  //CREATE GYM INSTANCE
  
  nanomap::instance::GymInstance gymInstance(gymConfig);
  int environmentKnowledge = 1;
  float knowledgeRadius = 2.0;
  gymInstance.setEnvironmentKnowledge(environmentKnowledge, knowledgeRadius);
  gymInstance.createManager();
  gymInstance.createHandler();
  auto clusterGraph_ = gymInstance.plannerInstance()->plannerManager()->returnClusterGraph();
  //printClusterGraph(clusterGraph_);
  std::vector<nanomap::Pose> agentStartPoses;
  std::vector<int> agentStartClusters;
  std::vector<Eigen::Vector3f> targetPositions;
  readMultiAgentConfig(multiConfig, agentStartPoses, targetPositions);
  for(auto pose : agentStartPoses){
    int cluster = gymInstance.plannerInstance()->plannerManager()->getClusterFromPosition(pose.position);
    agentStartClusters.push_back(cluster);
  }
  // for(Eigen::Vector3f position : agentStartPositions){
  //   std::cout << position.x() << " / " << position.y() << " / " <<position.z() << std::endl;
  // }
  // for(Eigen::Vector3f position : targetPositions){
  //   std::cout << position.x() << " / " << position.y() << " / " <<position.z() << std::endl;
  // }
  //gymInstance.resetAgentByIndexToPosition(0, agentCluster);
  // nanomap::Pose pose;
  // pose.position.x() = agentStartPositions[agentId_].x();
  // pose.position.y() = agentStartPositions[agentId_].y();
  // pose.position.z() = agentStartPositions[agentId_].z();
  // pose.orientation.w() = 1.0;
  // pose.orientation.x() = 0.0;
  // pose.orientation.y() = 0.0;
  // pose.orientation.z() = 0.0;
 // gymInstance.resetAgentByIndex(0); 
  // gymInstance.updateAgentPose(0, pose)  

//std::vector<nanomap::Pose> poses;


  // Eigen::Array<float, 7, 1> poseAsFloat = gymInstance.getAgentPoseAsFloatByIndex(0);
  // nanomap::Pose pose;
  // std::cout << poseAsFloat(0) << " / " 
  //           << poseAsFloat(1) << " / " 
  //           << poseAsFloat(2) << " / " 
  //           << poseAsFloat(3) << " / " 
  //           << poseAsFloat(4) << " / " 
  //           << poseAsFloat(5) << " / " 
  //           << poseAsFloat(6) << " / " << std::endl; 
  // pose.position.x() = poseAsFloat(0);
  // pose.position.y() = poseAsFloat(1);
  // pose.position.z() = poseAsFloat(2);
  // pose.orientation.w() = poseAsFloat(3);
  // pose.orientation.x() = poseAsFloat(4);
  // pose.orientation.y() = poseAsFloat(5);
  // pose.orientation.z()= poseAsFloat(6);

  // std::cout << "cluster: " << gymInstance.plannerInstance()->plannerManager()->getClusterFromPosition(pose.position) << std::endl;

  // gymInstance.generateRandomTargetPositions(4);
  // std::vector<Eigen::Vector3f> targetPosition = gymInstance.targetPositions();
  // for(auto position : targetPosition){
  //   std::cout << position.x() << " / " << position.y() << " / " <<position.z() << std::endl;
  //     std::cout << "cluster: " << gymInstance.plannerInstance()->plannerManager()->getClusterFromPosition(position) << std::endl;
  // }
//return 1;
    gymInstance.updateAgentPose(0, agentStartPoses[agentId_]);
    gymInstance.onAgentReset();
    // //DEFINE GRAPH SEARCH DEFINITION
    std::cout << "FinishedMapLoad and Solve, Beginning Planning" << std::endl;
    //   //Initialising tapir planner definition using planner info from nanomap plannermanager
    std::shared_ptr<nanomaptapir::planner::multisearch::Definition> plannerDefinition
                      = std::make_shared<nanomaptapir::planner::multisearch::Definition>();

    gymInstance.setTargetPositions(targetPositions);
    //   //gymInstance.generateRandomTargetPositions(1);
    //   //std::vector<Eigen::Vector3f> targetPositions = gymInstance.targetPositions();
    //   //int targetCluster =  gymInstance.plannerInstance()->plannerManager()->getClusterFromPosition(targetPositions[0]); 
    //   //occupancy[targetCluster] = std::floor(std::sqrt(gymInstance.plannerInstance()->plannerManager()->getSafeCountForCluster(targetCluster)));
    plannerDefinition->setPlannerManager(gymInstance.plannerInstance()->plannerManager());
    plannerDefinition->setCfgPath(plannerConfig);
    plannerDefinition->getClusterInfoFromManager();
    //plannerDefinition->setInitialOccupancy(occupancy);
    plannerDefinition->setUniformOccupancy();
    plannerDefinition->setInitialPositions(agentStartClusters, agentId_);
    //   //std::pair<int, int> initialPosition = gymInstance.plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose.position);
    //   //plannerDefinition->setInitialPosition(initialPosition);

    printClusterGraph(clusterGraph_);

    nanomaptapir::planner::multisearch::Interface  tapirInterface;
    std::vector<std::pair<bool, std::pair<std::vector<int>, std::vector<std::vector<bool>>>>> plannerObservations;
    std::vector<std::pair<int,int>> actionSequence;
    std::vector<std::vector<nanomap_ros::multi_control::MultiAgentInfo>> agentStampedInfo;
    for(int x = 0; x < nAgents_; x++){
      std::vector<nanomap_ros::multi_control::MultiAgentInfo> agentInfo;
      agentStampedInfo.push_back(agentInfo);
    }
    //   //Creating the shared objects that ferry information between nodes. 
      std::tuple<int, std::vector<bool>, int, std::vector<Eigen::Vector3f>> searchGoals;
      std::tuple<int, int, int, std::vector<Eigen::Vector3f>> transitGoals;
      std::vector<Eigen::Vector3f> currentGoals;
      currentGoals.resize(5);
      bool transitMode = false;
      bool searchMode = false;
      float maxGoalObsDist = 10.0;
      std::vector<float> maxVelocities;
      //Xforward
      maxVelocities.push_back(2.0);
      //Xbackward
      maxVelocities.push_back(0.75);
      //Yforward
      maxVelocities.push_back(0.75);
      //Ybackward
      maxVelocities.push_back(0.75);
      //Zforward
      maxVelocities.push_back(0.75);
      //Zbackward
      maxVelocities.push_back(0.75);
      //yaw right
      maxVelocities.push_back(1.0);
      //yaw left
      maxVelocities.push_back(1.0);

  Eigen::Vector3f rpy(0,0,0);
  Eigen::Vector3f xyz(0,0,0);
    //   //Initializing the tapir interface using the tapirDefinition we created earlier.
      tapirInterface.initialisePlanner(plannerDefinition, plannerProblemPath);

    //   //CREATE THE MULTITHREADED EXECUTOR
    std::cout << "creating multithreaded executor " << std::endl;
    rclcpp::executors::MultiThreadedExecutor executor;

    
// //VISUALIZATION NODES
          


          //PUBLISHED BY ONLY AGENT 0
            auto graphVisualizer = std::make_shared<nanomap_ros::visualization::GraphVisualizer>(gymInstance);
            auto boundaryVisualizer = std::make_shared<nanomap_ros::visualization::BoundaryVisualizer>(gymInstance, colorsObject);
            //auto simGridPubNode = std::make_shared<nanomap_ros::visualization::OpenVDBGridPublisher>(gymInstance.getSimGrid(),"SimulatedGrid");
            auto targetPublisher = std::make_shared<nanomap_ros::visualization::TargetPublisher>(gymInstance);
            auto completionCheck = std::make_shared<nanomap_ros::multi_control::CompletionCheck>(plannerDefinition.get(),
                                                                                                agentStampedInfo);
            auto searchGridPubNode = std::make_shared<nanomap_ros::visualization::OpenVDBGridPublisher>(
                                                              gymInstance.agentManager()->getAgentByIndex(0)->map()->searchGrid(),
                                                              "Agent_"+std::to_string(agentId_)+"_SearchGrid", 
                                                              "Agent_"+std::to_string(agentId_)+"_SearchGrid");

            if(agentId_ == 0){
              executor.add_node(boundaryVisualizer);
              executor.add_node(graphVisualizer);
              executor.add_node(targetPublisher);
              executor.add_node(completionCheck);
              executor.add_node(searchGridPubNode);
              //executor.add_node(simGridPubNode);
            }
          // auto searchNodeVisualizer = std::make_shared<nanomap_ros::visualization::ClusterSearchNodeVisualizer>(gymInstance, colorsObject);
          // auto targetPublisher = std::make_shared<nanomap_ros::visualization::TargetPublisher>(gymInstance);

          //PUBLISHED BY ALL AGENTS
          auto framePublisher = std::make_shared<nanomap_ros::visualization::FramePublisher>(gymInstance, "agent_"+std::to_string(agentId_));
          auto transitGoalVisualizer = std::make_shared<nanomap_ros::visualization::TransitGoalVisualizer>(agentId_, gymInstance, currentGoals);
          auto searchGoalVisualizer = std::make_shared<nanomap_ros::visualization::SearchGoalVisualizer>(agentId_, gymInstance, currentGoals);
          auto occupiedVoxelPubNode = std::make_shared<nanomap_ros::visualization::OpenVDBGridPublisher>(
                                                                        gymInstance.agentManager()->getAgentByIndex(0)->map()->occupiedGrid(),
                                                                        "Agent_"+std::to_string(agentId_)+"_OccupiedGrid", 
                                                                        "Agent_"+std::to_string(agentId_)+"_OccupiedGrid");
          
          
          
          

          // //CONTROL NODES
          // //Adding the tapir interface to a ros node for looping. 
          auto tapirLoop = std::make_shared<nanomap_ros::multi_control::MultiAgentTapirNode>(agentId_, tapirInterface, plannerObservations, actionSequence);
          auto multiActionManager = std::make_shared<nanomap_ros::multi_control::MultiActionManager>(gymInstance,plannerDefinition.get(),agentStampedInfo[agentId_], actionSequence, searchGoals, transitGoals);
          auto macroManagerNode = std::make_shared<nanomap_ros::multi_control::MultiMacroManagerNode>(plannerDefinition->nTargets_,simType_, searchType_,  gymInstance, searchGoals, transitGoals, xyz, rpy, transitMode, searchMode, currentGoals);
          auto multiObservationManager = std::make_shared<nanomap_ros::multi_control::MultiObservationManager>( gymInstance, plannerDefinition.get(), agentStampedInfo,plannerObservations);
          auto multiObservationPublisher = std::make_shared<nanomap_ros::multi_control::MultiObservationPublisher>(agentId_, "agent_" + std::to_string(agentId_) + "_info", agentStampedInfo[agentId_]);
          std::vector<std::shared_ptr<nanomap_ros::multi_control::MultiObservationSubscriber>> subscribers;
          for(int x = 0; x < nAgents_; x++){
            if(x == agentId_){
              continue;
            }
            subscribers.push_back(std::make_shared<nanomap_ros::multi_control::MultiObservationSubscriber>(x, 
                                                                        "agent_" + std::to_string(x) + "_info",
                                                                        agentStampedInfo[x]));
          }
          for(auto subscriber : subscribers){
            executor.add_node(subscriber);
          }
          std::string searchQueryTopic = "agent_" + std::to_string(agentId_) + "_search_policy_query";
          std::string transitQueryTopic = "agent_" + std::to_string(agentId_) + "_transit_policy_query";
          
          auto searchPolicyClient = std::make_shared<nanomap_ros::control::SearchPolicyClient>(searchQueryTopic,
                                                                                                gymInstance,
                                                                                                xyz,
                                                                                                rpy,
                                                                                                searchMode,
                                                                                                currentGoals,
                                                                                                maxGoalObsDist,
                                                                                                maxVelocities);
          auto transitPolicyClient = std::make_shared<nanomap_ros::control::TransitPolicyClient>(transitQueryTopic,
                                                                                                gymInstance,
                                                                                                xyz,
                                                                                                rpy,
                                                                                                transitMode,
                                                                                                currentGoals,
                                                                                                maxGoalObsDist,
                                                                                                maxVelocities);
          auto viewSimLoop = std::make_shared<nanomap_ros::control::ViewSimLoop>(gymInstance, "agent_"+std::to_string(agentId_)+"view_loop");
          auto poseSimLoop = std::make_shared<nanomap_ros::control::PoseSimLoop>(gymInstance, xyz, rpy, "agent_"+std::to_string(agentId_)+"pose_loop");

          // //ADDING NODES TO EXECUTOR
          // VISUALIZERS
          executor.add_node(framePublisher);
          executor.add_node(occupiedVoxelPubNode);
          executor.add_node(transitGoalVisualizer);
          executor.add_node(searchGoalVisualizer);
          executor.add_node(tapirLoop);
          executor.add_node(multiActionManager);
          executor.add_node(macroManagerNode);
          executor.add_node(multiObservationManager);
          executor.add_node(multiObservationPublisher);
          if(simType_ == 0){
            executor.add_node(searchPolicyClient);
            executor.add_node(transitPolicyClient);
            executor.add_node(viewSimLoop);
            executor.add_node(poseSimLoop);
          }

          // executor.add_node(agentPublisher);
          // executor.add_node(targetPublisher);
          // executor.add_node(occupiedVoxelPubNode);
          // executor.add_node(simGridPubNode);
          // executor.add_node(macroManagerNode);
          // executor.add_node(searchNodeVisualizer);

          // executor.add_node(tapirLoop);
          // executor.add_node(actionObservationNode);
          // std::cout << "spinning nodes" << std::endl;
          executor.spin();
          rclcpp::shutdown();




























  //Random map created, solved and agent spawned in with views calculated. 
  // int clusterCount = gymInstance.plannerInstance()->plannerManager()->getClusterCount();
  // std::vector<int> occupancy;
  // occupancy.resize(clusterCount);
  // int numRandomOccupiedClusters = 5;
  // std::set<int> randomOccupiedClusters;
  // while(randomOccupiedClusters.size() < 5){
  //   randomOccupiedClusters.insert(rand()%clusterCount);
  // }
  // //occupancy[rand()%clusterCount] = ;
  // for(int occupiedCluster : randomOccupiedClusters){
  //   occupancy[occupiedCluster] = std::floor(std::sqrt(gymInstance.plannerInstance()->plannerManager()->getSafeCountForCluster(occupiedCluster)));
  // }

          // gymInstance.setObjectsOnPath(false);


          
          // gymInstance.onAgentReset();

          // Eigen::Vector3f rpy(0,0,0);
          // Eigen::Vector3f xyz(0,0,0);

          // Eigen::Array<float, 7, 1> poseAsFloat = gymInstance.getAgentPoseAsFloatByIndex(0);
          // nanomap::Pose pose;
          // std::cout << poseAsFloat(0) << " / " 
          //           << poseAsFloat(1) << " / " 
          //           << poseAsFloat(2) << " / " 
          //           << poseAsFloat(3) << " / " 
          //           << poseAsFloat(4) << " / " 
          //           << poseAsFloat(5) << " / " 
          //           << poseAsFloat(6) << " / " << std::endl; 
          // pose.position.x() = poseAsFloat(0);
          // pose.position.y() = poseAsFloat(1);
          // pose.position.z() = poseAsFloat(2);
          // pose.orientation.w() = poseAsFloat(3);
          // pose.orientation.x() = poseAsFloat(4);
          // pose.orientation.y() = poseAsFloat(5);
          // pose.orientation.z()= poseAsFloat(6);

          // //std::vector<nanomap::Pose> poses;
          // gymInstance.updateAgentPose(0, pose);
          // //Random map created, solved and agent spawned in with views calculated. 
          // int clusterCount = gymInstance.plannerInstance()->plannerManager()->getClusterCount();
          // std::vector<int> occupancy;
          // occupancy.resize(clusterCount);
          // int numRandomOccupiedClusters = 5;
          // std::set<int> randomOccupiedClusters;
          // while(randomOccupiedClusters.size() < 5){
          //   randomOccupiedClusters.insert(rand()%clusterCount);
          // }
          // //occupancy[rand()%clusterCount] = ;
          // for(int occupiedCluster : randomOccupiedClusters){
          //   occupancy[occupiedCluster] = std::floor(std::sqrt(gymInstance.plannerInstance()->plannerManager()->getSafeCountForCluster(occupiedCluster)));
          // }
          // //DEFINE GRAPH SEARCH DEFINITION
          // std::cout << "FinishedMapSolve, Beginning Planning" << std::endl;
          // //Initialising tapir planner definition using planner info from nanomap plannermanager
          // std::shared_ptr<nanomaptapir::planner::singlesearch::Definition> plannerDefinition
          //                 = std::make_shared<nanomaptapir::planner::singlesearch::Definition>();


          // gymInstance.generateRandomTargetPositions(1);
          // std::vector<Eigen::Vector3f> targetPositions = gymInstance.targetPositions();
          // int targetCluster =  gymInstance.plannerInstance()->plannerManager()->getClusterFromPosition(targetPositions[0]); 
          // occupancy[targetCluster] = std::floor(std::sqrt(gymInstance.plannerInstance()->plannerManager()->getSafeCountForCluster(targetCluster)));
          // plannerDefinition->setPlannerManager(gymInstance.plannerInstance()->plannerManager());
          // plannerDefinition->setCfgPath(plannerConfig);
          // plannerDefinition->getClusterInfoFromManager();
          // plannerDefinition->setInitialOccupancy(occupancy);
          // //plannerDefinition->setUniformOccupancy();
          // std::pair<int, int> initialPosition = gymInstance.plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose.position);
          // plannerDefinition->setInitialPosition(initialPosition);

          // nanomaptapir::planner::singlesearch::Interface  tapirInterface;
          // std::vector<std::pair<int, std::vector<int>>> observationsSequence;
          // std::vector<nanomaptapir::planner::singlesearch::Observation> observations;
          // std::vector<std::pair<int,int>> actionSequence;

          // //Creating the shared objects that ferry information between nodes. 
          // std::tuple<int, std::vector<bool>, int, std::vector<Eigen::Vector3f>> searchGoals;
          // std::tuple<int, int, int, std::vector<Eigen::Vector3f>> transitGoals;
          // std::vector<Eigen::Vector3f> currentGoals;
          // currentGoals.resize(5);
          // bool transitMode = false;
          // bool searchMode = false;

          // //Initializing the tapir interface using the tapirDefinition we created earlier.
          // tapirInterface.initialisePlanner(plannerDefinition, plannerProblemPath);

          // //CREATE THE MULTITHREADED EXECUTOR
          // rclcpp::executors::MultiThreadedExecutor executor;

          // //VISUALIZATION NODES
          // auto occupiedVoxelPubNode = std::make_shared<nanomap_ros::visualization::OpenVDBGridPublisher>(gymInstance.agentManager()->getAgentByIndex(0)->map()->occupiedGrid(),"OccupiedGrid");
          // auto simGridPubNode = std::make_shared<nanomap_ros::visualization::OpenVDBGridPublisher>(gymInstance.getSimGrid(),"SimulatedGrid");
          // auto graphVisualizer = std::make_shared<nanomap_ros::visualization::GraphVisualizer>(gymInstance);
          // auto boundaryVisualizer = std::make_shared<nanomap_ros::visualization::BoundaryVisualizer>(gymInstance, colorsObject);
          // auto searchNodeVisualizer = std::make_shared<nanomap_ros::visualization::ClusterSearchNodeVisualizer>(gymInstance, colorsObject);
          // auto agentPublisher = std::make_shared<nanomap_ros::visualization::AgentPublisher>(gymInstance);
          // auto targetPublisher = std::make_shared<nanomap_ros::visualization::TargetPublisher>(gymInstance);

          // //CONTROL NODES
          // //Adding the tapir interface to a ros node for looping. 
          // auto tapirLoop = std::make_shared<nanomap_ros::control::SingleAgentTapirNode>(tapirInterface, observationsSequence, actionSequence, observations);
          // auto actionObservationNode = std::make_shared<nanomap_ros::control::ActionObservationNode>(gymInstance,plannerDefinition.get(),observationsSequence, actionSequence, searchGoals, transitGoals);
          // auto macroManagerNode = std::make_shared<nanomap_ros::control::SingleMacroManagerNode>(gymInstance, searchGoals, transitGoals, xyz, rpy, transitMode, searchMode, currentGoals);


          // //ADDING NODES TO EXECUTOR
          // executor.add_node(agentPublisher);
          // executor.add_node(targetPublisher);
          // executor.add_node(occupiedVoxelPubNode);
          // executor.add_node(simGridPubNode);
          // executor.add_node(macroManagerNode);
          // executor.add_node(searchNodeVisualizer);
          // executor.add_node(boundaryVisualizer);
          // executor.add_node(graphVisualizer);
          // executor.add_node(tapirLoop);
          // executor.add_node(actionObservationNode);
          // std::cout << "spinning nodes" << std::endl;
          // executor.spin();
          // rclcpp::shutdown();
}
