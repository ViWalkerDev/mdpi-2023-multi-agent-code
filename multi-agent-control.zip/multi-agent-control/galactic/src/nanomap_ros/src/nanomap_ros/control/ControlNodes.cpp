#include "nanomap_ros/control/ControlNodes.hpp"


namespace nanomap_ros{
  namespace control{

    ViewSimLoop::ViewSimLoop(nanomap::instance::GymInstance& gymInstance, std::string node_name)
    : Node(node_name), count_(0) , gymInstance_(&gymInstance)
    {
      auto timer_callback =
        [this]() -> void {
            gymInstance_->generateAgentViews();
            gymInstance_->processAgentViews();
            gymInstance_->updateAgentEnvironmentObservations();
          };
      timer_ = this->create_wall_timer(50ms, timer_callback);
    }

  PoseSimLoop::PoseSimLoop(nanomap::instance::GymInstance& gymInstance, Eigen::Vector3f &xyz, Eigen::Vector3f &rpy, std::string node_name)
  : Node(node_name), count_(0) , gymInstance_(&gymInstance),xyz_(&xyz), rpy_(&rpy)
  {
    auto timer_callback =
      [this]() -> void {
          nanomap::Pose pose;
          nanomap::Pose old_pose;
          Eigen::Array<float, 7, 1> poseAsFloat = gymInstance_->getAgentPoseAsFloatByIndex(0);
          old_pose.position.x() = poseAsFloat(0);
          old_pose.position.y() = poseAsFloat(1);
          old_pose.position.z() = poseAsFloat(2);
          old_pose.orientation.w() = poseAsFloat(3);
          old_pose.orientation.x() = poseAsFloat(4);
          old_pose.orientation.y() = poseAsFloat(5);
          old_pose.orientation.z()= poseAsFloat(6);


          float timeStep = 0.01; 
          Eigen::Vector3f updated_vec = old_pose.orientation.toRotationMatrix()*(*xyz_);
          updated_vec(0) = updated_vec(0)*timeStep;
          updated_vec(1) = updated_vec(1)*timeStep;
          updated_vec(2) = updated_vec(2)*timeStep;
          if(!gymInstance_->agentManager()->getAgent(0)->getAgentCollision(updated_vec)){
            gymInstance_->updateAgentPoseFromVelocities(0,timeStep, (*xyz_).x(), (*xyz_).y(), (*xyz_).z(), (*rpy_).x(), (*rpy_).y(), (*rpy_).z());
            //std::cout << "vels = " << (*xyz_).x() << "/ "<<  (*xyz_).y()<< "/ "<< (*xyz_).z() << "/ "<< (*rpy_).z() << std::endl;
          }else{
            //std::cout<< "Agent Collided with Sim Environment!" << std::endl;
          }
        };
    timer_ = this->create_wall_timer(10ms, timer_callback);
  }



  TransitPolicyClient::TransitPolicyClient(std::string queryTopic, nanomap::instance::GymInstance& gymInstance, Eigen::Vector3f &xyz, Eigen::Vector3f &rpy, 
                                            bool &transitMode, std::vector<Eigen::Vector3f> &currentGoals, 
                                            float goalDist, std::vector<float> maxVelocities)
  : Node(queryTopic),  queryTopic_(queryTopic), count_(0), gymInstance_(&gymInstance), 
                                  xyz_(&xyz), rpy_(&rpy), transitMode_(&transitMode), 
                                  currentGoals_(&currentGoals), goalDist_(goalDist),
                                  maxVelocities_(maxVelocities)
  {

    client_ = this->create_client<nanomap_msgs::srv::PolicyQuery>(queryTopic_);
    future_ = promise_.get_future().share();
    auto timer_callback =
      [this]() -> void {
      
      if(*transitMode_){
        //std::cout << "transit MoDE" << std::endl;
        if(future_.wait_for(std::chrono::seconds(0)) == std::future_status::ready){
          (*xyz_).x() = future_.get()->actions[0];
          (*xyz_).y() = future_.get()->actions[1];
          (*xyz_).z() = future_.get()->actions[2];
          (*rpy_).z() = future_.get()->actions[3];
        }
        
        std::vector<float> normalizedVelocities = normalizedVelocityObservations();
        //GOAL DATA CALCULATIONS
        std::vector<Eigen::Vector3f> worldGoals;
        //for(int x = 0; x < 2; x++){
          worldGoals.push_back((*currentGoals_)[0]);
        //}
        std::vector<Eigen::Vector3f> localGoals = gymInstance_->getLocalGoalsFromWorldGoals(0,worldGoals);
        std::vector<float> goalData;
        for(auto goal : localGoals){
          for(int x = 0; x < 3; x++){
            goalData.push_back(goal(x));
          }
        }
        std::vector<float> normalizedGoals = normalizedGoalObservations(goalData);

        //DISTANCE DATA CALCS/FETCHING, distance data is already normalized when we get it.
        Eigen::ArrayXf distanceArray = gymInstance_->getObservationsByIndex(0);
        std::vector<float> distanceData;
        for(int x = 0; x<distanceArray.size(); x++){
          distanceData.push_back(distanceArray(x));
        }
        auto request_ = std::make_shared<nanomap_msgs::srv::PolicyQuery::Request>();
        //response_ = std::make_shared<nanomap_msgs::srv::PolicyQuery::Response>();

        request_->goalobservations = normalizedGoals;
        request_->distanceobservations = distanceData;
        request_->agentvelocities = normalizedVelocities;
        future_ = this->client_->async_send_request(request_);
        //if (rclcpp::spin_until_future_complete(this->get_node_base_interface(), result_) ==
        //        rclcpp::FutureReturnCode::SUCCESS)
        //{
      }
        //}else {
        //  RCLCPP_ERROR(rclcpp::get_logger("rclcpp"), "Failed to call policy query service");
        //}
    };
    timer_ = this->create_wall_timer(50ms, timer_callback);
  }

std::vector<float> TransitPolicyClient::normalizedGoalObservations(std::vector<float> goalData){
  std::vector<float> normalizedGoals;
  normalizedGoals.resize(goalData.size());
  for(int x = 0; x < (int)(goalData.size()/3); x++){
    //divide every value in each point by max goal dist
    normalizedGoals[x*3+0] = goalData[x*3+0];///20.0;
    normalizedGoals[x*3+1] = goalData[x*3+1];///20.0;
    normalizedGoals[x*3+2] = goalData[x*3+2];///20.0;

    //if there are any vectors still longer than 1 unit, then normalize them so they are the max they can be. 
    Eigen::Vector3f vec = Eigen::Vector3f(normalizedGoals[x*3+0],normalizedGoals[x*3+1],normalizedGoals[x*3+2]);
    if(vec.norm()>0.0){
      vec.normalize();
      normalizedGoals[x*3+0] = vec(0)*0.4;
      normalizedGoals[x*3+1] = vec(1)*0.4;
      normalizedGoals[x*3+2] = vec(2)*0.4;
    }
  }
  return normalizedGoals;
}

std::vector<float> TransitPolicyClient::normalizedVelocityObservations(){
  //normalize x vel
  std::vector<float> normalizedVelocities;
  normalizedVelocities.resize(4,0.0);
  if((*xyz_).x()>0.0){
    normalizedVelocities[0] = (*xyz_).x()/maxVelocities_[0];
  }else{
    normalizedVelocities[0] = (*xyz_).x()/maxVelocities_[1];
  }
  if((*xyz_).y()>0.0){
    normalizedVelocities[1] = (*xyz_).y()/maxVelocities_[2];
  }else{
    normalizedVelocities[1] = (*xyz_).y()/maxVelocities_[3];
  }
  if((*xyz_).z()>0.0){
    normalizedVelocities[2] = (*xyz_).z()/maxVelocities_[4];
  }else{
    normalizedVelocities[2] = (*xyz_).z()/maxVelocities_[5];
  }
  if((*rpy_).z()>0.0){
    normalizedVelocities[3] = (*rpy_).z()/maxVelocities_[6];
  }else{
    normalizedVelocities[3] = (*rpy_).z()/maxVelocities_[7];
  }
  
  for(int x =0; x < normalizedVelocities.size(); x++){
    if(normalizedVelocities[x]>1.0){
      normalizedVelocities[x] = 1.0;
    }else if(normalizedVelocities[x] < -1.0){
      normalizedVelocities[x] = -1.0;
    }
  }
  return normalizedVelocities;
}

SearchPolicyClient::SearchPolicyClient(std::string queryTopic, nanomap::instance::GymInstance& gymInstance, Eigen::Vector3f &xyz, Eigen::Vector3f &rpy, 
                                            bool &searchMode, std::vector<Eigen::Vector3f> &currentGoals, 
                                            float goalDist, std::vector<float> maxVelocities)
  : Node(queryTopic), queryTopic_(queryTopic), count_(0), gymInstance_(&gymInstance), 
    xyz_(&xyz), rpy_(&rpy), searchMode_(&searchMode), 
    currentGoals_(&currentGoals), goalDist_(goalDist), maxVelocities_(maxVelocities)
  {

    client_ = this->create_client<nanomap_msgs::srv::PolicyQuery>(queryTopic);
    future_ = promise_.get_future().share();
    auto timer_callback =
      [this]() -> void {
      
      if(*searchMode_){
        //std::cout << "search Mode " << std::endl;
        if(future_.wait_for(std::chrono::seconds(0)) == std::future_status::ready){
          (*xyz_).x() = future_.get()->actions[0];
          (*xyz_).y() = future_.get()->actions[1];
          (*xyz_).z() = future_.get()->actions[2];
          (*rpy_).z() = future_.get()->actions[3];
        }
        std::vector<float> normalizedVelocities = normalizedVelocityObservations();
        //GOAL DATA CALCULATIONS
        std::vector<Eigen::Vector3f> worldGoals;
        for(int x = 0; x < 5; x++){
          worldGoals.push_back((*currentGoals_)[x]);
        }
        std::vector<Eigen::Vector3f> localGoals = gymInstance_->getLocalGoalsFromWorldGoals(0,worldGoals);
        std::vector<float> goalData;
        for(auto goal : localGoals){
          for(int x = 0; x < 3; x++){
            goalData.push_back(goal(x));
          }
        }
        std::vector<float> normalizedGoals = normalizedGoalObservations(goalData);

        //DISTANCE DATA CALCS/FETCHING, distance data is already normalized when we get it.
        Eigen::ArrayXf distanceArray = gymInstance_->getObservationsByIndex(0);
        std::vector<float> distanceData;
        for(int x = 0; x<distanceArray.size(); x++){
          distanceData.push_back(distanceArray(x));
        }
        auto request_ = std::make_shared<nanomap_msgs::srv::PolicyQuery::Request>();
        //response_ = std::make_shared<nanomap_msgs::srv::PolicyQuery::Response>();

        request_->goalobservations = normalizedGoals;
        request_->distanceobservations = distanceData;
        request_->agentvelocities = normalizedVelocities;
        future_ = this->client_->async_send_request(request_);
        //if (rclcpp::spin_until_future_complete(this->get_node_base_interface(), result_) ==
        //        rclcpp::FutureReturnCode::SUCCESS)
        //{
      }
        //}else {
        //  RCLCPP_ERROR(rclcpp::get_logger("rclcpp"), "Failed to call policy query service");
        //}
    };
    timer_ = this->create_wall_timer(50ms, timer_callback);
  }

std::vector<float> SearchPolicyClient::normalizedGoalObservations(std::vector<float> goalData){
  std::vector<float> normalizedGoals;
  normalizedGoals.resize(goalData.size());
  for(int x = 0; x < (int)(goalData.size()/3); x++){
    //divide every value in each point by max goal dist
    normalizedGoals[x*3+0] = goalData[x*3+0]/goalDist_;
    normalizedGoals[x*3+1] = goalData[x*3+1]/goalDist_;
    normalizedGoals[x*3+2] = goalData[x*3+2]/goalDist_;

    //if there are any vectors still longer than 1 unit, then normalize them so they are the max they can be. 
    Eigen::Vector3f vec = Eigen::Vector3f(normalizedGoals[x*3+0],normalizedGoals[x*3+1],normalizedGoals[x*3+2]);
    if(vec.norm()>1.0){
      vec.normalize();
      normalizedGoals[x*3+0] = vec(0);
      normalizedGoals[x*3+1] = vec(1);
      normalizedGoals[x*3+2] = vec(2);
    }
  }
  return normalizedGoals;
}

std::vector<float> SearchPolicyClient::normalizedVelocityObservations(){
  //normalize x vel
  std::vector<float> normalizedVelocities;
  normalizedVelocities.resize(4,0.0);
  if((*xyz_).x()>0.0){
    normalizedVelocities[0] = (*xyz_).x()/maxVelocities_[0];
  }else{
    normalizedVelocities[0] = (*xyz_).x()/maxVelocities_[1];
  }
  if((*xyz_).y()>0.0){
    normalizedVelocities[1] = (*xyz_).y()/maxVelocities_[2];
  }else{
    normalizedVelocities[1] = (*xyz_).y()/maxVelocities_[3];
  }
  if((*xyz_).z()>0.0){
    normalizedVelocities[2] = (*xyz_).z()/maxVelocities_[4];
  }else{
    normalizedVelocities[2] = (*xyz_).z()/maxVelocities_[5];
  }
  if((*rpy_).z()>0.0){
    normalizedVelocities[3] = (*rpy_).z()/(maxVelocities_[6]);
  }else{
    normalizedVelocities[3] = (*rpy_).z()/(maxVelocities_[7]);
  }
  
  for(int x =0; x < normalizedVelocities.size(); x++){
    if(normalizedVelocities[x]>1.0){
      normalizedVelocities[x] = 1.0;
    }else if(normalizedVelocities[x] < -1.0){
      normalizedVelocities[x] = -1.0;
    }
  }
  return normalizedVelocities;
}

  SingleMacroManagerNode::SingleMacroManagerNode(int simType, int searchType,
                nanomap::instance::GymInstance& gymInstance,
                std::tuple<int, int, int, std::vector<Eigen::Vector3f>>& searchGoals,
                std::tuple<int, int, int, std::vector<Eigen::Vector3f>>& transitGoals,
                Eigen::Vector3f &xyz, Eigen::Vector3f &rpy, bool& transitMode, bool& searchMode, std::vector<Eigen::Vector3f>& currentGoals)
  : Node("SingleMacroManagerNode"), count_(0), simType_(simType), searchType_(searchType), gymInstance_(&gymInstance),
        searchGoals_(&searchGoals), transitGoals_(&transitGoals), xyz_(&xyz), rpy_(&rpy), 
        searchMode_(&searchMode), transitMode_(&transitMode), currentGoals_(&currentGoals), 
        agentMap_(NULL)
  {
    agentMap_ = gymInstance_->agentManager()->getAgentByIndex(0)->map();
    poseAsFloat_ = gymInstance_->getAgentPoseAsFloatByIndex(0);
    pose_.position.x() = poseAsFloat_(0);
    pose_.position.y() = poseAsFloat_(1);
    pose_.position.z() = poseAsFloat_(2);
    numTargets_ = gymInstance_->targetPositions().size();
    // areTargetsFound_.resize(numTargets_,false);
    // foundDuringTransit_.resize(numTargets_,std::pair<bool, int>(false, -1));
    // targetsFoundThisSearch_.resize(numTargets_,false);
    std::tie(currentCluster_, currentBoundary_) = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose_.position);
    goalExists_ = false;
    isSearchGoal_ = false;
    isGoalComplete_ = false;
    currentGoalIndex_ = 0;
    std::string topic = "MacroManagerNode";
    auto timer_callback =
      [this]() -> void {
        //Always get the agent reported pose first!
        poseAsFloat_ = gymInstance_->getAgentPoseAsFloatByIndex(0);
        pose_.position.x() = poseAsFloat_(0);
        pose_.position.y() = poseAsFloat_(1);
        pose_.position.z() = poseAsFloat_(2);
        std::tie(currentCluster_, currentBoundary_) = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose_.position);
        
        // if(searchMode_ == 0 && transitMode_ == 0){
        //     (*xyz_).x() = 0.0;
        //     (*xyz_).y() = 0.0;
        //     (*xyz_).z() = 0.0;
        //     (*rpy_).x() = 0.0;
        //     (*rpy_).y() = 0.0;
        //     (*rpy_).z() = 0.0;
        // }

        if(!goalExists_){
          if(std::get<0>(*searchGoals_)>0){
          //We are performing search routine
            startSearchRoutine();
            
          }else if(std::get<0>(*transitGoals_)>0){
            startTransitRoutine();
          }
        }

        if(goalExists_){
          if(isSearchGoal_){
            //We step the search routine!
            //Only used to approximate the performance when not using full system.
            if(simType_ == 1){
              if(testCounter_ > 10){
                pose_.position = std::get<3>(*searchGoals_)[currentGoalIndex_];
                gymInstance_->updateAgentPose(0, pose_);
                gymInstance_->simulateAgentSearch(0, std::get<3>(*searchGoals_)[currentGoalIndex_]);
                testCounter_ = 0;
              }
              testCounter_++;
            }
            stepSearchRoutine();
            
            //Used for testing the tapir planner and interfaces without running the policy clients
            //stepSearchRoutineApproximated();
          }else{

            //Only used to approximate the performance when not using full system.
            if(simType_ == 1){
              if(testCounter_>10){
                pose_.position = (*currentGoals_)[0];
                gymInstance_->updateAgentPose(0, pose_);
                testCounter_ = 0;
              }
              testCounter_++;
            
            }
            //We step the transit routine!
            stepTransitRoutine();
          }
          //testCounter_++;
          //isGoalComplete_ = false;
        }
        
      };
    timer_ = this->create_wall_timer(50ms, timer_callback);
  }

  std::vector<bool> SingleMacroManagerNode::areTargetsSeen(){
    //During vision generation checks, nanomap checks to see if the simulated and known target positions lie within the FOV of the agent.  
    return gymInstance_->targetObservedStatus(0);
  }

  std::map<float, Eigen::Vector3f> SingleMacroManagerNode::sortSearchTargetsMap(std::vector<int> searchCompletion){
    return gymInstance_->plannerInstance()->plannerManager()->sortSearchClusterTargetsByDistance(pose_.position, 
                                                                                            searchTargetsMap_, 
                                                                                            searchCompletion, *currentGoals_);
  }
void SingleMacroManagerNode::stepSearchRoutine(){
              //We already have a goal. first check if that goal is completed
          //If it isn't completed command the agent to complete the goal. 
            std::vector<bool> areTargetsFound = areTargetsSeen();
            if(areTargetsFound[0]){
              targetFoundThisSearch_ = true;
            }
            // int index = 0;
            //for(bool found : areTargetsFound){
              // if(found){
              //   areTargetsFound_[index] = true;
              //   targetsFoundThisSearch_[index] = true;
              // }
              // index++;
            //}

            //std::cout << "searchTargetsMap_.size() " << searchTargetsMap_.size() << std::endl;
            //First we see if the target has been observed
            //and we add the value to our target found matrix.
            //If all the targets have been found, we can finish the search, else
            //we keep searching. 
            
            // std::cout << "searchTargetsMap.size() " << searchTargetsMap_.size() << std::endl;
            //!(std::all_of(areTargetsFound_.begin(), areTargetsFound_.end(), [](bool found) { return found; }))
            if(true){
              //If it hasn't we continue the search as normal. 
              //std::cout << "search incomplete " << std::endl;
              //we check to see if any of intermediate search goals are complete. 
              //searchTargetsMap_ = gymInstance_->plannerInstance()->plannerManager()->getSearchClusterTargetsByDistance(pose_.position, currentTargetCluster_,  gymInstance_->agentManager()->getAgentByIndex(0)->map());
              if(searchTargetsMap_.size() < 200){
                searchTargetsMap_ = gymInstance_->plannerInstance()->plannerManager()->getSearchClusterTargetsByDistance(pose_.position, currentTargetCluster_,  gymInstance_->agentManager()->getAgentByIndex(0)->map());
              } 
              std::vector<int> searchCompletion = checkSearchTargets(); //gymInstance_->plannerInstance()->plannerManager()->checkSearchtargets(currentGoals_, )
              if(searchCompletion.size() > 0){
                //then we've completed some of the search!
                if(searchCompletion.size() <= searchTargetsMap_.size()){
                  //We still have enough search targets to populate more without considering the search complete. 
                  //However, we do need to resort the map according to new distances based on our position. 
                  searchTargetsMap_ = sortSearchTargetsMap(searchCompletion);
                }
                populateSearchTargets(searchCompletion);
              }
                //Then with a valid searchTargetsMap (or not, it might be too small) we populate the search targets.
                //If the searchTargetsMap is too small, then we create duplicate entries. 
              //HOWEVER!
              //If the searchTargetsMap is too small, it's a good time to fetch a new search goal,
              //Giving us new search targets to explore.
              //std::cout << "searchTargetsMap_.size() " << searchTargetsMap_.size() << std::endl;

              if(gymInstance_->plannerInstance()->plannerManager()->isClusterSearchComplete( currentTargetCluster_, gymInstance_->agentManager()->getAgentByIndex(0)->map())){
                
                //time to move on. 
                // std::get<0>(*searchGoals_) -= 1;
                // //Update the list of search goals, removing the one just completed.
                // std::get<3>(*searchGoals_).erase(std::get<3>(*searchGoals_).begin()+currentGoalIndex_);
                // if(std::get<0>(*searchGoals_) > 0){
                //   //Then we still have search goals to go!
                //   std::vector<Eigen::Vector3f> goals = std::get<3>(*searchGoals_);
                //   //Get the closest major search goal and populate it with targets. 
                //   float dist = FLT_MAX;
                //   int closestGoalIndex = -1;
                //   int goalIndex = 0;
                //   for(auto goalPos : goals){
                //     float goalDist = gymInstance_->plannerInstance()->plannerManager()->getDistanceBetweenPositions(pose_.position, goalPos);
                //     if(goalDist < dist){
                //       dist = goalDist;
                //       closestGoalIndex = goalIndex;
                //     }
                //     goalIndex++;
                //   }
                //   currentGoalIndex_ = closestGoalIndex;
                //   //searchTargetsMap_ = gymInstance_->plannerInstance()->plannerManager()->getSearchClusterTargetsByDistanceAndGoal(pose_.position, currentTargetCluster_, goals[closestGoalIndex], agentMap_);
                //   searchTargetsMap_ = gymInstance_->plannerInstance()->plannerManager()->getSearchClusterTargetsByDistanceAndGoal(pose_.position, currentTargetCluster_, goals[closestGoalIndex], agentMap_);
                //   std::vector<int> replaceIndex = {0,1,2,3,4};
                //   populateSearchTargets(replaceIndex);
                  
                // }else{
                  //Search of this cluster is complete!
                
                  // if(gymInstance_->isTargetLocalToAgentCluster(0,0)){
                  //   isTargetFound = true;
                  // }
                  //int foundCount = 0;
                  std::cout << "search complete " << std::endl;
                  bool isFound = false;
                  //SearchType_ determines if we recognise found targets. 
                  //If == 0, then we do, and the search can end once all targets found.
                  //If == 1, then we perform a "full search"
                  if(simType_ == 0 && searchType_ == 0){
                    if(targetFoundThisSearch_){
                      isFound = true;
                    }
                  }
                
                  if(simType_ == 1 && searchType_ == 0){
                    if(gymInstance_->isTargetLocalToAgentCluster(0,0)){
                      isFound = true;
                    }
                    // if(gymInstance_->isTargetLocalToAgentCluster(0,0)){
                    //   foundCount++;
                    // }
                  }
                  std::get<0>(*searchGoals_) = 0;
                  std::get<1>(*searchGoals_) = isFound;
                  goalExists_ = false;
                  currentGoalIndex_ = 0;
                  //std::cout << "search complete, setting agent info" << std::endl;
                  //We now have to wait for the next action. so lets set out velocity to 0
                  *searchMode_=false;
                  (*xyz_).x() = 0.0;
                  (*xyz_).y() = 0.0;
                  (*xyz_).z() = 0.0;
                  (*rpy_).x() = 0.0;
                  (*rpy_).y() = 0.0;
                  (*rpy_).z() = 0.0;
                  
                }
              // }
              
            // }else{
            //   //deprecrated logic I think. 
            //   //all targets are found! we can finish the search if all targets are found.
            //   // 
            //   //std::cout << "all targets are found, we can finish the search" << std::endl;
            //   //int foundCount = 0;
            //   searchStatus_[0] = true;
            //   for(int x = 0; x < nTargets_; x++){
            //     if(targetsFoundThisSearch_[x] == true){
            //       //foundCount++;
            //       searchStatus_[x+1] = true;
            //     }
            //   }
            //   std::get<0>(*searchGoals_) = 0;
              //TO FIX std::get<1>(*searchGoals_) = foundCount;
            }
  }
  // void SingleMacroManagerNode::stepSearchRoutine(){
  //             //We already have a goal. first check if that goal is completed
  //         //If it isn't completed command the agent to complete the goal. 
  //           std::vector<bool> areTargetsFound = areTargetsSeen();
  //           int index = 0;
  //           for(bool found : areTargetsFound){
  //             if(found){
  //               areTargetsFound_[index] = true;
  //               targetsFoundThisSearch_[index] = true;
  //             }
  //             index++;
  //           }
  //           //First we see if the target has been observed
  //           //and we add the value to our target found matrix.
  //           //If all the targets have been found, we can finish the search, else
  //           //we keep searching. 
  //           //std::cout << "searchTargetsMap.size() " << searchTargetsMap_.size() << std::endl;
  //           if(!(std::all_of(areTargetsFound_.begin(), areTargetsFound_.end(), [](bool found) { return found; }))){
  //             //If it hasn't we continue the search as normal. 
  //             //we check to see if any of intermediate search goals are complete. 
  //             std::vector<int> searchCompletion = checkSearchTargets(); //gymInstance_->plannerInstance()->plannerManager()->checkSearchtargets(currentGoals_, )
  //             if(searchCompletion.size() > 0){
  //               //then we've completed some of the search!
  //               if(searchCompletion.size() <= searchTargetsMap_.size()){
  //                 //We still have enough search targets to populate more without considering the search complete. 
  //                 //However, we do need to resort the map according to new distances based on our position. 
  //                 searchTargetsMap_ = sortSearchTargetsMap(searchCompletion);
  //               }
  //               populateSearchTargets(searchCompletion);
  //             }
  //               //Then with a valid searchTargetsMap (or not, it might be too small) we populate the search targets.
  //               //If the searchTargetsMap is too small, then we create duplicate entries. 
  //             //HOWEVER!
  //             //If the searchTargetsMap is too small, it's a good time to fetch a new search goal,
  //             //Giving us new search targets to explore.
  //             if(searchTargetsMap_.size() <= 4){
                
  //               //We only have a single node we haven't seen, time to move on. 
  //               std::get<0>(*searchGoals_) -= 1;
  //               //Update the list of search goals, removing the one just completed.
  //               std::get<3>(*searchGoals_).erase(std::get<3>(*searchGoals_).begin()+currentGoalIndex_);
  //               if(std::get<0>(*searchGoals_) > 0){
  //                 //Then we still have search goals to go!
  //                 std::vector<Eigen::Vector3f> goals = std::get<3>(*searchGoals_);
  //                 //Get the closest major search goal and populate it with targets. 
  //                 float dist = FLT_MAX;
  //                 int closestGoalIndex = -1;
  //                 int goalIndex = 0;
  //                 for(auto goalPos : goals){
  //                   float goalDist = gymInstance_->plannerInstance()->plannerManager()->getDistanceBetweenPositions(pose_.position, goalPos);
  //                   if(goalDist < dist){
  //                     dist = goalDist;
  //                     closestGoalIndex = goalIndex;
  //                   }
  //                   goalIndex++;
  //                 }
  //                 currentGoalIndex_ = closestGoalIndex;
  //                 searchTargetsMap_ = gymInstance_->plannerInstance()->plannerManager()->getSearchClusterTargetsByDistanceAndGoal(pose_.position, currentTargetCluster_, goals[closestGoalIndex], agentMap_);
  //                 std::vector<int> replaceIndex = {0,1,2,3,4};
  //                 populateSearchTargets(replaceIndex);
                  
  //               }else{
  //                 //Search of this cluster is complete!
                
  //                 // if(gymInstance_->isTargetLocalToAgentCluster(0,0)){
  //                 //   isTargetFound = true;
  //                 // }
  //                 int foundCount = 0;
  //                 if(simType_ == 0 && searchType_ == 0)
  //                 for(int x = 0; x < numTargets_; x++){
  //                   if(targetsFoundThisSearch_[x] == true){
  //                     foundCount++;
  //                   }
  //                 }

  //                 if(simType_ == 1 && searchType_ == 0){
  //                   if(gymInstance_->isTargetLocalToAgentCluster(0,0)){
  //                     foundCount++;
  //                   }
  //                 }

  //                 std::get<1>(*searchGoals_) = foundCount;
  //                 goalExists_ = false;
  //                 currentGoalIndex_ = 0;
  //                 //std::cout << "search complete, setting observation " << std::endl;
  //                 //We now have to wait for the next action. so lets set out velocity to 0
  //                 // (*xyz_).x() = 0.0;
  //                 // (*xyz_).y() = 0.0;
  //                 // (*xyz_).z() = 0.0;
  //                 // (*rpy_).x() = 0.0;
  //                 // (*rpy_).y() = 0.0;
  //                 // (*rpy_).z() = 0.0;
  //               }
  //             }
              
  //           }else{
  //             //all targets are found! we can finish the search if all targets are found.
  //             // 
  //             //std::cout << "all targets are found, we can finish the search" << std::endl;
  //             int foundCount = 0;
  //             for(int x = 0; x < numTargets_; x++){
  //               if(targetsFoundThisSearch_[x] == true){
  //                 foundCount++;
  //               }
  //             }
  //             std::get<0>(*searchGoals_) = 0;
  //             std::get<1>(*searchGoals_) = foundCount;
  //           }
  // }
  void SingleMacroManagerNode::startSearchRoutine(){

    // for(int x = 0; x < nTargets_; x++){
    //   if(foundDuringTransit_[x].first == true && foundDuringTransit_[x].second == std::get<2>(*searchGoals_)){
    //     targetsFoundThisSearch_[x] = true;
    //   }else{
    //     targetsFoundThisSearch_[x] = false;
    //   }
    // }
    targetFoundThisSearch_ = false;
    goalExists_ = true;
    currentTargetCluster_ = std::get<2>(*searchGoals_);
    currentPlannerCluster_ = currentTargetCluster_;
    if(foundDuringTransit_.first == true){
      if(currentTargetCluster_ == foundDuringTransit_.second){
        targetFoundThisSearch_ = true;
      }
    }
    //std::vector<Eigen::Vector3f> goals = std::get<3>(*searchGoals_);
    //float dist = FLT_MAX;
    //int closestGoalIndex = -1;
    //int goalIndex = 0;
    // for(auto goalPos : goals){
    //   float goalDist = gymInstance_->plannerInstance()->plannerManager()->getDistanceBetweenPositions(pose_.position, goalPos);
    //   if(goalDist < dist){
    //     dist = goalDist;
    //     closestGoalIndex = goalIndex;
    //   }
    //   goalIndex++;
    // }
    //searchTargetsMap_ = gymInstance_->plannerInstance()->plannerManager()->getSearchClusterTargetsByDistanceAndGoal(pose_.position, currentTargetCluster_, goals[closestGoalIndex], gymInstance_->agentManager()->getAgentByIndex(0)->map());
    searchTargetsMap_ = gymInstance_->plannerInstance()->plannerManager()->getSearchClusterTargetsByDistance(pose_.position, currentTargetCluster_, gymInstance_->agentManager()->getAgentByIndex(0)->map());
    //currentGoalIndex_ = closestGoalIndex;
    std::vector<int> replaceIndex = {0,1,2,3,4};
    populateSearchTargets(replaceIndex);
    isSearchGoal_ = true;
    *searchMode_ = true;
    *transitMode_ = false;
    }
  // void SingleMacroManagerNode::startSearchRoutine(){
  //   for(int x = 0; x < numTargets_; x++){
  //     if(foundDuringTransit_[x].first == true && foundDuringTransit_[x].second == std::get<2>(*searchGoals_)){
  //       targetsFoundThisSearch_[x] = true;
  //     }else{
  //       targetsFoundThisSearch_[x] = false;
  //     }
  //   }
  //   goalExists_ = true;
  //   currentTargetCluster_ = std::get<2>(*searchGoals_);
  //   std::vector<Eigen::Vector3f> goals = std::get<3>(*searchGoals_);
  //   float dist = FLT_MAX;
  //   int closestGoalIndex = -1;
  //   int goalIndex = 0;
  //   for(auto goalPos : goals){
  //     float goalDist = gymInstance_->plannerInstance()->plannerManager()->getDistanceBetweenPositions(pose_.position, goalPos);
  //     if(goalDist < dist){
  //       dist = goalDist;
  //       closestGoalIndex = goalIndex;
  //     }
  //     goalIndex++;
  //   }
  //   searchTargetsMap_ = gymInstance_->plannerInstance()->plannerManager()->getSearchClusterTargetsByDistanceAndGoal(pose_.position, currentTargetCluster_, goals[closestGoalIndex], agentMap_);
  //   currentGoalIndex_ = closestGoalIndex;
  //   std::vector<int> replaceIndex = {0,1,2,3,4};
  //   populateSearchTargets(replaceIndex);
  //   isSearchGoal_ = true;
  //   *searchMode_ = true;
  //   *transitMode_ = false;
  // }

  void SingleMacroManagerNode::stepTransitRoutine(){
    isGoalComplete_ = false;
    std::vector<bool> areTargetsFound = areTargetsSeen();
            //int index = 0;
    //for(bool found : areTargetsFound){
      if(areTargetsFound[0]){
        foundDuringTransit_ = std::make_pair(true, gymInstance_->getTargetCluster(0));
        //areTargetsFound_[index] = true;
        //targetsFoundThisSearch_[index] = true;
      }
      // index++;
    //}
    // Eigen::Vector3f positionDelta = pose_.position - (*currentGoals_)[0];
    // if(std::abs(positionDelta(0)) < 1.2 && 
    //       std::abs(positionDelta(1)) < 1.2 &&
    //           std::abs(positionDelta(2)) < 1.2){
    //   isGoalComplete_ = true;
    // }
    //if(isGoalComplete_){
      // std::vector<Eigen::Vector3f> goals = gymInstance_->getTransitGoalsVec(0,currentTargetCluster_);
      // int goalIndex = 0;
      // bool validGoal = false;
      // for(Eigen::Vector3f goal : goals){

      //   if((pose_.position-goal).norm()>0.8 && (pose_.position-goal).norm() < 10.0 && goal != Eigen::Vector3f(0.0,0.0,0.0)){
      //     validGoal = true;
      //     break;
          
      //   }
      //   goalIndex++;
      // }
      //if(validGoal){
      //(*currentGoals_)[0] = goals[goalIndex];
      // (*currentGoals_)[1] = goals[goalIndex];
      // }else{
      //   std::cout << "invalid GOAL!" << std::endl;
      // }//The current transit goal has been met.
      //std::get<1>(*transitGoals_)+=1;
      //currentGoalIndex_+=1;
      if(gymInstance_->plannerInstance()->plannerManager()->getClusterFromPosition(pose_.position) != currentTargetCluster_){
        Eigen::Vector3f boundaryPoint = gymInstance_->plannerInstance()->plannerManager()->getDestinationBoundaryPoint(currentPlannerCluster_, currentTargetCluster_);
      
        if(!nearBoundary_){
          if((pose_.position - boundaryPoint).norm() < 1.0){
            (*currentGoals_)[0] = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryAverage(currentTargetCluster_);
            nearBoundary_ = true;
          }else{
            (*currentGoals_)[0] = boundaryPoint;
          }
        }else{
          if((pose_.position - boundaryPoint).norm() < 2.0){
            (*currentGoals_)[0] = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryAverage(currentTargetCluster_);
          }else{
            (*currentGoals_)[0] = boundaryPoint;
            nearBoundary_ = false;
          }
        }
      }else{
        (*currentGoals_)[0] = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryAverage(currentTargetCluster_);
        Eigen::Vector3f boundaryPoint = gymInstance_->plannerInstance()->plannerManager()->getDestinationBoundaryPoint(currentPlannerCluster_, currentTargetCluster_);
        if((pose_.position - boundaryPoint).norm() > 1.5 || (pose_.position - (*currentGoals_)[0]).norm() < 1.0){
      //if(){
        //we reached the last goal in the series.
        //Set first entry to 0 to signal planner to get new action. 
          std::get<0>(*transitGoals_) = 0;
          goalExists_ = false;
          currentGoalIndex_ = 0;
          *transitMode_=false;
          (*xyz_).x() = 0.0;
          (*xyz_).y() = 0.0;
          (*xyz_).z() = 0.0;
          (*rpy_).x() = 0.0;
          (*rpy_).y() = 0.0;
          (*rpy_).z() = 0.0;
        }
      // }else{
      //   (*currentGoals_)[0] = goals[currentGoalIndex_];
      //   if(std::get<0>(*transitGoals_)-2 <=std::get<1>(*transitGoals_)){
      //     //We are on the last goal in teh series
      //     (*currentGoals_)[1] = goals[currentGoalIndex_];
      //   }// }else{
        //   (*currentGoals_)[1] = goals[currentGoalIndex_+1];
        // }

      }
    // isGoalComplete_ = false;
    // std::vector<bool> areTargetsFound = areTargetsSeen();
    //         int index = 0;
    // for(bool found : areTargetsFound){
    //   if(found){
    //     foundDuringTransit_[index] = std::make_pair(found, gymInstance_->getTargetCluster(index));
    //     //areTargetsFound_[index] = true;
    //     //targetsFoundThisSearch_[index] = true;
    //   }
    //   index++;
    // }
    // Eigen::Vector3f positionDelta = pose_.position - (*currentGoals_)[0];
    // if(std::abs(positionDelta(0)) < 1.25 && 
    //       std::abs(positionDelta(1)) < 1.25 &&
    //           std::abs(positionDelta(2)) < 1.25){
    //   isGoalComplete_ = true;
    // }
    // if(isGoalComplete_){
    //   std::vector<Eigen::Vector3f> goals = std::get<3>(*transitGoals_);
    //   //The current transit goal has been met.
    //   std::get<1>(*transitGoals_)+=1;
    //   currentGoalIndex_+=1;
    //   if(std::get<1>(*transitGoals_)>=std::get<0>(*transitGoals_)){
    //     //we reached the last goal in the series.
    //     //Set first entry to 0 to signal planner to get new action. 
    //     std::get<0>(*transitGoals_) = 0;
    //     goalExists_ = false;
    //     currentGoalIndex_ = 0;
    //   }else{
    //     (*currentGoals_)[0] = goals[currentGoalIndex_];
    //     if(std::get<0>(*transitGoals_)-2 <=std::get<1>(*transitGoals_)){
    //       //We are on the last goal in teh series
    //       (*currentGoals_)[1] = goals[currentGoalIndex_];
    //     }else{
    //       (*currentGoals_)[1] = goals[currentGoalIndex_+1];
    //     }
    //   }
    // }
  }

  void SingleMacroManagerNode::startTransitRoutine(){
          currentGoalIndex_ = 0;
          //We are performing transit routine.
           goalExists_ = true; 
      //     //std::vector<Eigen::Vector3f> goals= std::get<3>(*transitGoals_);
          currentPlannerCluster_ = std::get<1>(*transitGoals_);
          currentTargetCluster_ = std::get<2>(*transitGoals_);
          nearBoundary_ = false;
      if(gymInstance_->plannerInstance()->plannerManager()->getClusterFromPosition(pose_.position) != currentTargetCluster_){
        Eigen::Vector3f boundaryPoint = gymInstance_->plannerInstance()->plannerManager()->getDestinationBoundaryPoint(currentPlannerCluster_, currentTargetCluster_);
        if(!nearBoundary_){
          if((pose_.position - boundaryPoint).norm() < 1.5){
            (*currentGoals_)[0] = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryAverage(currentTargetCluster_);
            nearBoundary_ = true;
          }else{
            (*currentGoals_)[0] = boundaryPoint;
          }
        }else{
          if((pose_.position - boundaryPoint).norm() < 2.5){
            (*currentGoals_)[0] = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryAverage(currentTargetCluster_);
          }else{
            (*currentGoals_)[0] = boundaryPoint;
            nearBoundary_ = false;
            }
          }
        //(*currentGoals_)[0] = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryAverage(currentTargetCluster_);
            isSearchGoal_ = false;
            *transitMode_ = true;
            *searchMode_ = false;
      }else{
        (*currentGoals_)[0] = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryAverage(currentTargetCluster_);
        Eigen::Vector3f boundaryPoint = gymInstance_->plannerInstance()->plannerManager()->getDestinationBoundaryPoint(currentPlannerCluster_, currentTargetCluster_);
        if((pose_.position - boundaryPoint).norm() > 1.5 || (pose_.position - (*currentGoals_)[0]).norm() < 1.0){
          *transitMode_ = false;
          *searchMode_ = false;
          isSearchGoal_ = false;
          std::get<0>(*transitGoals_) = 0;
          goalExists_ = false;
          currentGoalIndex_ = 0;
          (*xyz_).x() = 0.0;
          (*xyz_).y() = 0.0;
          (*xyz_).z() = 0.0;
          (*rpy_).x() = 0.0;
          (*rpy_).y() = 0.0;
          (*rpy_).z() = 0.0;
        }
      }
          // std::vector<Eigen::Vector3f> goals= std::get<3>(*transitGoals_);
          // currentTargetCluster_ = std::get<2>(*transitGoals_);
          // (*currentGoals_)[0] = goals[0];
          // if(std::get<0>(*transitGoals_)>1){
          //   (*currentGoals_)[1] = goals[1];
          // }else{
          //   (*currentGoals_)[1] = goals[1]; 
          // }
          // isSearchGoal_ = false;
          // *transitMode_ = true;
          // *searchMode_ = false;
  }

  void SingleMacroManagerNode::populateSearchTargets(std::vector<int> replaceIndex){
     if(searchTargetsMap_.size() >= replaceIndex.size()){
           //Then we can populate search targets
           int targetIndex = 0;
            //std::cout << "stepping through targets? " << std::endl;
           for(auto it = searchTargetsMap_.begin(); it != std::next(searchTargetsMap_.begin(),replaceIndex.size()); ++it){

            //std::cout << "targetIndex = " << replaceIndex[targetIndex] << std::endl;
            //std::cout << "target point = " << (*it).second.x() << " / " << (*it).second.y() << " / "<< (*it).second.z() << std::endl;

            (*currentGoals_)[replaceIndex[targetIndex]] = (*it).second;
            targetIndex++;
           } 
      }else if (searchTargetsMap_.size() >= 0){
        //Populate search targets with what we can, and then duplicate the existing ones. 
        int targetIndex = 0;
        for(auto it = searchTargetsMap_.begin(); it != searchTargetsMap_.end(); ++it){
          (*currentGoals_)[replaceIndex[targetIndex]] = (*it).second;
          replaceIndex[targetIndex] = -1;
          targetIndex++;
        }
        //get a valid search target from the current search targets to double up on. 
        int duplicateIndex = 0;
        for(int index = 0; index < replaceIndex.size(); index++){
            if(duplicateIndex == replaceIndex[index]){
              duplicateIndex++;
            }else{
              break;
            }
          }
        for(int x = targetIndex; x < replaceIndex.size(); x++){
          //For the remainder, just add the current unsearched duplicate. 
          (*currentGoals_)[replaceIndex[targetIndex]] = (*currentGoals_)[duplicateIndex];
          targetIndex++;
        }
      }
      // }else/*searchTargetsMap_.size == 0*/{
      //   //Do nothing for the current goals. 
      // }
  }

  std::vector<int> SingleMacroManagerNode::checkSearchTargets(){
    return gymInstance_->plannerInstance()->plannerManager()->checkSearchTargets((*currentGoals_), agentMap_);
  }


//TODO integrate observations into a specific planner manager object maybe? or a specific nanomaptapir object that we update with planner manager?
//For now we are on time crunch, keep it simple.
//Might need gymInstance for ease of data retrieval later, maybe just work with the observations stuff for now and keep tapir interface isolated 
//observation sequences is a vector of observations. with observations being a pair with an int-id, and a vector of int based observations.
  ActionObservationNode::ActionObservationNode(nanomap::instance::GymInstance& gymInstance,
                        nanomaptapir::planner::singlesearch::Definition* definition,
                  std::vector<std::pair<int, std::vector<int>>>&            observationsSequence,
                std::vector<std::pair<int, int>>&                                                actionSequence,
                std::tuple<int, int, int, std::vector<Eigen::Vector3f>>& searchGoals,
                std::tuple<int, int, int, std::vector<Eigen::Vector3f>>& transitGoals)
  : Node("actionObsNode"), count_(0), gymInstance_(&gymInstance), definition_(definition), 
        observationsSequence_(&observationsSequence), actionSequence_(&actionSequence),
        searchGoals_(&searchGoals), transitGoals_(&transitGoals)
  {
    Eigen::Array<float, 7, 1> poseAsFloat = gymInstance_->getAgentPoseAsFloatByIndex(0);
              nanomap::Pose pose;
              pose.position.x() = poseAsFloat(0);
              pose.position.y() = poseAsFloat(1);
              pose.position.z() = poseAsFloat(2);
              std::tie(currentRealCluster_, currentBoundary_) = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose.position);
              //std::cout << "current Real, Planner and Target Cluster =  " << currentRealCluster_  << std::endl;
    currentTargetCluster_ = currentRealCluster_;
    currentPlannerCluster_ = currentRealCluster_;   
    currentPlannerBoundary_ = currentBoundary_;      
    currentObservation_ = 0;
    actionPending_ = false;
    actionComplete_ = false;
    actionId_ = 0;
    std::string topic = "actionObsNode";
    auto timer_callback =
      [this]() -> void {
        std::vector<int> obsVec;
        if(actionSequence_->size() > 0){
          std::pair<int, int> latestAction = actionSequence_->back();

          if(latestAction.first >= actionId_){
                      //std::cout << "latestActionId = " << latestAction.first << "actionId = " << actionId_ << std::endl;
            //New action
            if(latestAction.second == 0){
              
              //getsearchgoal gets the search goals for the current agent in its current cluster. 
              currentTargetCluster_ = currentPlannerCluster_;
              currentTargetBoundary_ = currentPlannerBoundary_;
              //*searchGoals_ = gymInstance_->getSearchGoalsForAgentByIndex(0, currentTargetCluster_);
                              //currentTargetCluster_ = currentPlannerCluster_;
                std::vector<Eigen::Vector3f> searchGoals  = gymInstance_->getSearchGoalsVec(0, currentTargetCluster_);
                // searchStatus_.clear();
                // searchStatus_.resize(nTargets_+1,false);

                std::get<1>(*searchGoals_) = 0;
                std::get<2>(*searchGoals_) = currentTargetCluster_;
                std::get<3>(*searchGoals_) = searchGoals;
                std::get<0>(*searchGoals_) = searchGoals.size();
              mode_ = 0;
            }else{
               Eigen::Array<float, 7, 1> poseAsFloat = gymInstance_->getAgentPoseAsFloatByIndex(0);
              nanomap::Pose pose;
              pose.position.x() = poseAsFloat(0);
              pose.position.y() = poseAsFloat(1);
              pose.position.z() = poseAsFloat(2);
              // std::tie(currentRealCluster_, currentBoundary_) = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose.position);
              // //std::cout << "current real Cluster " << currentRealCluster_  << std::endl;
              // //std::cout << "current planner cluster " << currentPlannerCluster_ << std::endl;
              // //getTransitGoalForindexAndtargetCluster
              // //gets the goal locations for the transit from the agents current position to the provided cluster
              // currentTargetCluster_ = definition_->getClusterMove(currentPlannerCluster_, 0, latestAction.second).first.first;
              // //std::cout << " targetCluster after move action = " << currentTargetCluster_ << std::endl;
              // //*transitGoals_ = gymInstance_->getTransitGoalsForClusterByIndex(0,currentTargetCluster_);
              // mode_ = 1;
              std::tie(currentRealCluster_, currentBoundary_) = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose.position);
              //std::cout << "current real Cluster " << currentRealCluster_  << std::endl;
              //std::cout << "current planner cluster " << currentPlannerCluster_ << std::endl;
              //getTransitGoalForindexAndtargetCluster
              //gets the goal locations for the transit from the agents current position to the provided cluster
              std::tie(currentTargetCluster_, currentTargetBoundary_) = definition_->getClusterMove(currentPlannerCluster_, currentPlannerBoundary_, latestAction.second).first;
              //std::cout << " targetCluster after move action = " << currentTargetCluster_ << std::endl;
              
              std::vector<Eigen::Vector3f> transitGoals = gymInstance_->getTransitGoalsVec(0,currentTargetCluster_);

              std::get<1>(*transitGoals_) = currentPlannerCluster_;
              std::get<2>(*transitGoals_) = currentTargetCluster_;
              std::get<3>(*transitGoals_) = transitGoals;
              std::get<0>(*transitGoals_) = transitGoals.size();
              mode_ = 1;
              // actionPending_ = true;
            }
            actionId_++;
            actionPending_ = true;
            actionComplete_ = false;
          }
        }
        if(actionPending_){
          if(mode_ == 0){
            if(std::get<0>(*searchGoals_) == 0){
              //search complete.
              if(std::get<1>(*searchGoals_) > 0){
                //search successful!
                isFound_ = 1;
              }else{
                isFound_ = 0;
              }
              actionComplete_ = true;
            }
          }else if(mode_ == 1){
            if(std::get<0>(*transitGoals_) == 0){
              //transit complete
              isFound_ = 0;
              actionComplete_ = true;
            }
          }
          if(actionComplete_){
            currentPlannerCluster_ = currentTargetCluster_;
            currentPlannerBoundary_ = currentTargetBoundary_;
            //std::cout << "action completed, creating observation: (" << currentObservation_ << ", "<< isFound_ << ")"<< std::endl;
            //generate observation.
            std::vector<int> obsVec;
            obsVec.push_back(isFound_);
            observationsSequence_->push_back(std::make_pair(currentObservation_, obsVec));
            currentObservation_++;
            actionPending_ = false;
            actionComplete_ = false;
          }
        }
      };
    timer_ = this->create_wall_timer(100ms, timer_callback);
  }




  SingleAgentTapirNode::SingleAgentTapirNode(nanomaptapir::planner::singlesearch::Interface& tapirInterface, 
                std::vector<std::pair<int, std::vector<int>>>&            observationsSequence,
                std::vector<std::pair<int,int>>&                                                actionSequence,
                std::vector<nanomaptapir::planner::singlesearch::Observation>& observations)
  : Node("TapirNode"), count_(0), tapirInterface_(&tapirInterface), observationsSequence_(&observationsSequence), actionSequence_(&actionSequence), observations_(&observations)
  {

    currentObservation_ = 0;
    actionId_ = 0;
    actionSequence_->push_back(std::make_pair(actionId_, tapirInterface_->getPreferredAction()));
     //std::cout << "ACTION FROM POLICY = " << tapirInterface_->getPreferredAction() << std::endl;
    actionId_++;
    auto timer_callback =
      [this]() -> void {

          //PLANNER LOOP HERE
        if(observationsSequence_->size()>currentObservation_){

          tapirInterface_->addObservation((*observationsSequence_)[currentObservation_].second);
          
          //tapirInterface_->addObservation(&((*observations_)[currentObservation_]));
          tapirInterface_->stepSolver();
          //std::cout << "ACTION FROM POLICY = " << tapirInterface_->lastAction_->getAction() << std::endl;
          actionSequence_->push_back(std::make_pair(actionId_, tapirInterface_->getPreferredAction()));      
          currentObservation_++;
          actionId_++;
        }
      };
    timer_ = this->create_wall_timer(1000ms, timer_callback);
  }




CompletionCheck::CompletionCheck(nanomaptapir::planner::singlesearch::Definition* definition,
                            std::vector<std::pair<int, std::vector<int>>>& observationsSequence,
                              std::vector<std::pair<int, int>>& actionSequence)
: Node("completion_check_node"), definition_(definition), observationsSequence_(&observationsSequence), actionSequence_(&actionSequence)                              
{
    clusterSearchStatus_ = definition_->clusterSearchStatus_;
    agentCluster_ = definition_->initialCluster_;
    targetFound_ = false;
    startTime_ = std::chrono::high_resolution_clock::now();
    actionId_ = 0;
    observationId_ = 0;
    startTime_ = std::chrono::high_resolution_clock::now();
      auto timer_callback =
      [this]() -> void {
        if(actionSequence_->size() > actionId_){
          //process action
          waitingOnSearch_ = false;
          int actionInt = (*actionSequence_)[actionId_].second;
          if(actionInt == 0){
            waitingOnSearch_ = true;
          }else{
            agentCluster_ = definition_->getRobotMovedCluster(agentCluster_, 0, actionInt).first.first;
          }
          actionId_++;
        }

        if(observationsSequence_->size() > observationId_){
          if(waitingOnSearch_){
            //We were waiting on a search action. 
            clusterSearchStatus_[agentCluster_] = true;
            waitingOnSearch_ = false;
          }
          if((*observationsSequence_)[observationId_].second[0] == 1){
            targetFoundStatus_ = true;
          }
          observationId_++;
        }

        bool isSearchComplete = true;
        for(bool status : clusterSearchStatus_){
          if(!status){
            isSearchComplete = false;
            break;
          }
        }
        if(isSearchComplete == false){
          if(targetFoundStatus_){
            isSearchComplete = true;
          }
        }
        if(isSearchComplete){
          auto endTime = std::chrono::high_resolution_clock::now();
          std::cout << "Search took "
          << std::chrono::duration_cast<std::chrono::seconds>(endTime-startTime_).count()
          << " seconds\n";
          exit(1);
        }
        // for(int x = 0; x < nAgents_; x++){
        //   while((*agentStampedInfo_)[x].size() > infoIds_[x]){                   
        //     if((*agentStampedInfo_)[x][infoIds_[x]].searchStatus_[0] == true){
        //       //Search of cluster was completed;
        //       clusterSearchStatus_[(*agentStampedInfo_)[x][infoIds_[x]].agentCluster_] = true;
        //       for(int target = 0; target < nTargets_; x++){
        //         if((*agentStampedInfo_)[x][infoIds_[x]].searchStatus[1+target] == true){
        //           targetFoundStatus_[target] = true;
        //         }
        //       }
        //     }
        //     infoIds_[x]++; 
        //   }
        // }
        // bool isSearchComplete = true;
        // for(bool status : clusterSearchStatus){
        //   if(!status){
        //     isSearchComplete = false;
        //     break;
        //   }
        // }
        // if(isSearchComplete == false){
        //   bool isFoundStatusTrue = true;
        //   for(bool foundStatus : targetFoundStatus_){
        //     if(!foundStatus){
        //       isFoundStatusTrue == false;
        //       break;
        //     }
        //   }
        //   if(isFoundStatusTrue){
        //     isSearchComplete = true;
        //   }
        // }
        // if(isSearchComplete){
        //   auto endTime = std::chrono::high_resolution_clock::now();
        //   std::cout << "Search took "
        //   << std::chrono::duration_cast<std::chrono::seconds>(endTime-startTime_).count()
        //   << " seconds\n";
        //   exit();
        // }
        
      };
    timer_ = this->create_wall_timer(50ms, timer_callback);
}


  }
}