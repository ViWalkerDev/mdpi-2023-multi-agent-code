#include "nanomap_ros/control/MultiControlNodes.hpp"


namespace nanomap_ros{
  namespace multi_control{


  MultiMacroManagerNode::MultiMacroManagerNode(int nTargets,
                                                int simType,
                                              int searchType,
                  nanomap::instance::GymInstance& gymInstance,
                std::tuple<int, std::vector<bool>, int, std::vector<Eigen::Vector3f>>& searchGoals,
                std::tuple<int, int, int, std::vector<Eigen::Vector3f>>& transitGoals,
                Eigen::Vector3f &xyz, Eigen::Vector3f &rpy, bool& transitMode, bool& searchMode, std::vector<Eigen::Vector3f>& currentGoals)
  : Node("MultiMacroManagerNode"), nTargets_(nTargets), gymInstance_(&gymInstance),
        searchGoals_(&searchGoals), transitGoals_(&transitGoals), xyz_(&xyz), rpy_(&rpy), 
        searchMode_(&searchMode), transitMode_(&transitMode), currentGoals_(&currentGoals), 
        agentMap_(NULL), simType_(simType), searchType_(searchType)
  {
    agentMap_ = gymInstance_->agentManager()->getAgentByIndex(0)->map();
    poseAsFloat_ = gymInstance_->getAgentPoseAsFloatByIndex(0);
    pose_.position.x() = poseAsFloat_(0);
    pose_.position.y() = poseAsFloat_(1);
    pose_.position.z() = poseAsFloat_(2);
    areTargetsFound_.resize(nTargets_,false);
    foundDuringTransit_.resize(nTargets_,std::pair<bool, int>(false, -1));
    targetsFoundThisSearch_.resize(nTargets_,false);
    searchStatus_.resize(nTargets+1, false);
    std::tie(currentCluster_, currentBoundary_) = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose_.position);
    goalExists_ = false;
    isSearchGoal_ = false;
    isGoalComplete_ = false;
    currentGoalIndex_ = 0;
    std::string topic = "MacroManagerNode";
    auto timer_callback =
      [this]() -> void {
        //Always get the agent reported pose first!
        poseAsFloat_ = gymInstance_->getAgentPoseAsFloatByIndex(0);
        pose_.position.x() = poseAsFloat_(0);
        pose_.position.y() = poseAsFloat_(1);
        pose_.position.z() = poseAsFloat_(2);
        std::tie(currentCluster_, currentBoundary_) = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose_.position);
        
        // if(searchMode_ == 0 && transitMode_ == 0){
        //     (*xyz_).x() = 0.0;
        //     (*xyz_).y() = 0.0;
        //     (*xyz_).z() = 0.0;
        //     (*rpy_).x() = 0.0;
        //     (*rpy_).y() = 0.0;
        //     (*rpy_).z() = 0.0;
        // }

        if(!goalExists_){
          if(std::get<0>(*searchGoals_)>0){
          //We are performing search routine
            //clear search status
            for(int x = 0; x < searchStatus_.size(); x++){
              searchStatus_[x] = false;
            }
            startSearchRoutine();
            
          }else if(std::get<0>(*transitGoals_)>0){
            startTransitRoutine();
          }
        }

        if(goalExists_){
          if(isSearchGoal_){
            //We step the search routine!
            //Only used to approximate the performance when not using full system.
            if(simType_ == 1){
              if(testCounter_ > 30){
                  pose_.position = std::get<3>(*searchGoals_)[currentGoalIndex_];
                  gymInstance_->updateAgentPose(0, pose_);
                  gymInstance_->simulateAgentSearch(0, std::get<2>(*searchGoals_));
                  testCounter_ = 0;
              }
              testCounter_++;
            }


            stepSearchRoutine();
            
            //Used for testing the tapir planner and interfaces without running the policy clients
            //stepSearchRoutineApproximated();
          }else{

            //Only used to approximate the performance when not using full system.
            if(simType_ == 1){
              if(testCounter_>30){
                  pose_.position = (*currentGoals_)[0];
                  gymInstance_->updateAgentPose(0, pose_);
                  testCounter_ = 0;
              }
              testCounter_++;
            
            }
            //We step the transit routine!
            stepTransitRoutine();
          }
          //testCounter_++;
          //isGoalComplete_ = false;
        }
        
      };
    timer_ = this->create_wall_timer(50ms, timer_callback);
  }

  std::vector<bool> MultiMacroManagerNode::areTargetsSeen(){
    //During vision generation checks, nanomap checks to see if the simulated and known target positions lie within the FOV of the agent.  
    return gymInstance_->targetObservedStatus(0);
  }

  std::map<float, Eigen::Vector3f> MultiMacroManagerNode::sortSearchTargetsMap(std::vector<int> searchCompletion){
    return gymInstance_->plannerInstance()->plannerManager()->sortSearchClusterTargetsByDistance(pose_.position, 
                                                                                            searchTargetsMap_, 
                                                                                            searchCompletion, *currentGoals_);
  }

  void MultiMacroManagerNode::stepSearchRoutine(){
              //We already have a goal. first check if that goal is completed
          //If it isn't completed command the agent to complete the goal. 
            std::vector<bool> areTargetsFound = areTargetsSeen();
            int index = 0;
            for(bool found : areTargetsFound){
              if(found){
                areTargetsFound_[index] = true;
                targetsFoundThisSearch_[index] = true;
              }
              index++;
            }

            //std::cout << "searchTargetsMap_.size() " << searchTargetsMap_.size() << std::endl;
            //First we see if the target has been observed
            //and we add the value to our target found matrix.
            //If all the targets have been found, we can finish the search, else
            //we keep searching. 
            
            // std::cout << "searchTargetsMap.size() " << searchTargetsMap_.size() << std::endl;
            //!(std::all_of(areTargetsFound_.begin(), areTargetsFound_.end(), [](bool found) { return found; }))
            if(true){
              //If it hasn't we continue the search as normal. 
              //std::cout << "search incomplete " << std::endl;
              //we check to see if any of intermediate search goals are complete. 
              //searchTargetsMap_ = gymInstance_->plannerInstance()->plannerManager()->getSearchClusterTargetsByDistance(pose_.position, currentTargetCluster_,  gymInstance_->agentManager()->getAgentByIndex(0)->map());
              if(searchTargetsMap_.size() < 200){
                searchTargetsMap_ = gymInstance_->plannerInstance()->plannerManager()->getSearchClusterTargetsByDistance(pose_.position, currentTargetCluster_,  gymInstance_->agentManager()->getAgentByIndex(0)->map());
              } 
              std::vector<int> searchCompletion = checkSearchTargets(); //gymInstance_->plannerInstance()->plannerManager()->checkSearchtargets(currentGoals_, )
              if(searchCompletion.size() > 0){
                //then we've completed some of the search!
                if(searchCompletion.size() <= searchTargetsMap_.size()){
                  //We still have enough search targets to populate more without considering the search complete. 
                  //However, we do need to resort the map according to new distances based on our position. 
                  searchTargetsMap_ = sortSearchTargetsMap(searchCompletion);
                }
                populateSearchTargets(searchCompletion);
              }
                //Then with a valid searchTargetsMap (or not, it might be too small) we populate the search targets.
                //If the searchTargetsMap is too small, then we create duplicate entries. 
              //HOWEVER!
              //If the searchTargetsMap is too small, it's a good time to fetch a new search goal,
              //Giving us new search targets to explore.
              //std::cout << "searchTargetsMap_.size() " << searchTargetsMap_.size() << std::endl;

              if(gymInstance_->plannerInstance()->plannerManager()->isClusterSearchComplete( currentTargetCluster_, gymInstance_->agentManager()->getAgentByIndex(0)->map())){
                
                //time to move on. 
                // std::get<0>(*searchGoals_) -= 1;
                // //Update the list of search goals, removing the one just completed.
                // std::get<3>(*searchGoals_).erase(std::get<3>(*searchGoals_).begin()+currentGoalIndex_);
                // if(std::get<0>(*searchGoals_) > 0){
                //   //Then we still have search goals to go!
                //   std::vector<Eigen::Vector3f> goals = std::get<3>(*searchGoals_);
                //   //Get the closest major search goal and populate it with targets. 
                //   float dist = FLT_MAX;
                //   int closestGoalIndex = -1;
                //   int goalIndex = 0;
                //   for(auto goalPos : goals){
                //     float goalDist = gymInstance_->plannerInstance()->plannerManager()->getDistanceBetweenPositions(pose_.position, goalPos);
                //     if(goalDist < dist){
                //       dist = goalDist;
                //       closestGoalIndex = goalIndex;
                //     }
                //     goalIndex++;
                //   }
                //   currentGoalIndex_ = closestGoalIndex;
                //   //searchTargetsMap_ = gymInstance_->plannerInstance()->plannerManager()->getSearchClusterTargetsByDistanceAndGoal(pose_.position, currentTargetCluster_, goals[closestGoalIndex], agentMap_);
                //   searchTargetsMap_ = gymInstance_->plannerInstance()->plannerManager()->getSearchClusterTargetsByDistanceAndGoal(pose_.position, currentTargetCluster_, goals[closestGoalIndex], agentMap_);
                //   std::vector<int> replaceIndex = {0,1,2,3,4};
                //   populateSearchTargets(replaceIndex);
                  
                // }else{
                  //Search of this cluster is complete!
                
                  // if(gymInstance_->isTargetLocalToAgentCluster(0,0)){
                  //   isTargetFound = true;
                  // }
                  //int foundCount = 0;
                  std::cout << "search complete " << std::endl;
                  searchStatus_[0] = true;
                  //SearchType_ determines if we recognise found targets. 
                  //If == 0, then we do, and the search can end once all targets found.
                  //If == 1, then we perform a "full search"
                  if(simType_ == 0 && searchType_ == 0){
                    for(int x = 0; x < nTargets_; x++){
                      if(targetsFoundThisSearch_[x] == true){
                        //foundCount++;
                        searchStatus_[x+1] = true;
                      }
                    }
                  }

                  if(simType_ == 1 && searchType_ == 0){
                    for(int x = 0; x < nTargets_; x++){
                      if(gymInstance_->isTargetLocalToAgentCluster(0,x)){
                        searchStatus_[x+1] = true;
                      }
                    }
                    // if(gymInstance_->isTargetLocalToAgentCluster(0,0)){
                    //   foundCount++;
                    // }
                  }
                  std::get<0>(*searchGoals_) = 0;
                  std::get<1>(*searchGoals_) = searchStatus_;
                  goalExists_ = false;
                  currentGoalIndex_ = 0;
                  //std::cout << "search complete, setting agent info" << std::endl;
                  //We now have to wait for the next action. so lets set out velocity to 0
                  *searchMode_=false;
                  (*xyz_).x() = 0.0;
                  (*xyz_).y() = 0.0;
                  (*xyz_).z() = 0.0;
                  (*rpy_).x() = 0.0;
                  (*rpy_).y() = 0.0;
                  (*rpy_).z() = 0.0;
                  
                }
              // }
              
            }else{
              //deprecrated logic I think. 
              //all targets are found! we can finish the search if all targets are found.
              // 
              //std::cout << "all targets are found, we can finish the search" << std::endl;
              //int foundCount = 0;
              searchStatus_[0] = true;
              for(int x = 0; x < nTargets_; x++){
                if(targetsFoundThisSearch_[x] == true){
                  //foundCount++;
                  searchStatus_[x+1] = true;
                }
              }
              std::get<0>(*searchGoals_) = 0;
              //TO FIX std::get<1>(*searchGoals_) = foundCount;
            }
  }

  void MultiMacroManagerNode::startSearchRoutine(){
    for(int x = 0; x < nTargets_; x++){
      if(foundDuringTransit_[x].first == true && foundDuringTransit_[x].second == std::get<2>(*searchGoals_)){
        targetsFoundThisSearch_[x] = true;
      }else{
        targetsFoundThisSearch_[x] = false;
      }
    }
    goalExists_ = true;
    currentTargetCluster_ = std::get<2>(*searchGoals_);
    std::vector<Eigen::Vector3f> goals = std::get<3>(*searchGoals_);
    //float dist = FLT_MAX;
    //int closestGoalIndex = -1;
    //int goalIndex = 0;
    // for(auto goalPos : goals){
    //   float goalDist = gymInstance_->plannerInstance()->plannerManager()->getDistanceBetweenPositions(pose_.position, goalPos);
    //   if(goalDist < dist){
    //     dist = goalDist;
    //     closestGoalIndex = goalIndex;
    //   }
    //   goalIndex++;
    // }
    //searchTargetsMap_ = gymInstance_->plannerInstance()->plannerManager()->getSearchClusterTargetsByDistanceAndGoal(pose_.position, currentTargetCluster_, goals[closestGoalIndex], gymInstance_->agentManager()->getAgentByIndex(0)->map());
    searchTargetsMap_ = gymInstance_->plannerInstance()->plannerManager()->getSearchClusterTargetsByDistance(pose_.position, currentTargetCluster_, gymInstance_->agentManager()->getAgentByIndex(0)->map());
    //currentGoalIndex_ = closestGoalIndex;
    std::vector<int> replaceIndex = {0,1,2,3,4};
    populateSearchTargets(replaceIndex);
    isSearchGoal_ = true;
    *searchMode_ = true;
    *transitMode_ = false;
    }

  void MultiMacroManagerNode::stepTransitRoutine(){
    isGoalComplete_ = false;
    std::vector<bool> areTargetsFound = areTargetsSeen();
            int index = 0;
    for(bool found : areTargetsFound){
      if(found){
        foundDuringTransit_[index] = std::make_pair(found, gymInstance_->getTargetCluster(index));
        //areTargetsFound_[index] = true;
        //targetsFoundThisSearch_[index] = true;
      }
      index++;
    }
    // Eigen::Vector3f positionDelta = pose_.position - (*currentGoals_)[0];
    // if(std::abs(positionDelta(0)) < 1.2 && 
    //       std::abs(positionDelta(1)) < 1.2 &&
    //           std::abs(positionDelta(2)) < 1.2){
    //   isGoalComplete_ = true;
    // }
    //if(isGoalComplete_){
      // std::vector<Eigen::Vector3f> goals = gymInstance_->getTransitGoalsVec(0,currentTargetCluster_);
      // int goalIndex = 0;
      // bool validGoal = false;
      // for(Eigen::Vector3f goal : goals){

      //   if((pose_.position-goal).norm()>0.8 && (pose_.position-goal).norm() < 10.0 && goal != Eigen::Vector3f(0.0,0.0,0.0)){
      //     validGoal = true;
      //     break;
          
      //   }
      //   goalIndex++;
      // }
      //if(validGoal){
      //(*currentGoals_)[0] = goals[goalIndex];
      // (*currentGoals_)[1] = goals[goalIndex];
      // }else{
      //   std::cout << "invalid GOAL!" << std::endl;
      // }//The current transit goal has been met.
      //std::get<1>(*transitGoals_)+=1;
      //currentGoalIndex_+=1;
      if(gymInstance_->plannerInstance()->plannerManager()->getClusterFromPosition(pose_.position) != currentTargetCluster_){
        Eigen::Vector3f boundaryPoint = gymInstance_->plannerInstance()->plannerManager()->getDestinationBoundaryPoint(currentPlannerCluster_, currentTargetCluster_);
      
        if(!nearBoundary_){
          if((pose_.position - boundaryPoint).norm() < 1.0){
            (*currentGoals_)[0] = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryAverage(currentTargetCluster_);
            nearBoundary_ = true;
          }else{
            (*currentGoals_)[0] = boundaryPoint;
          }
        }else{
          if((pose_.position - boundaryPoint).norm() < 2.0){
            (*currentGoals_)[0] = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryAverage(currentTargetCluster_);
          }else{
            (*currentGoals_)[0] = boundaryPoint;
            nearBoundary_ = false;
          }
        }
      }else{
        (*currentGoals_)[0] = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryAverage(currentTargetCluster_);
        Eigen::Vector3f boundaryPoint = gymInstance_->plannerInstance()->plannerManager()->getDestinationBoundaryPoint(currentPlannerCluster_, currentTargetCluster_);
        if((pose_.position - boundaryPoint).norm() > 1.5 || (pose_.position - (*currentGoals_)[0]).norm() < 1.0){
      //if(){
        //we reached the last goal in the series.
        //Set first entry to 0 to signal planner to get new action. 
          std::get<0>(*transitGoals_) = 0;
          goalExists_ = false;
          currentGoalIndex_ = 0;
          *transitMode_=false;
          (*xyz_).x() = 0.0;
          (*xyz_).y() = 0.0;
          (*xyz_).z() = 0.0;
          (*rpy_).x() = 0.0;
          (*rpy_).y() = 0.0;
          (*rpy_).z() = 0.0;
        }
      // }else{
      //   (*currentGoals_)[0] = goals[currentGoalIndex_];
      //   if(std::get<0>(*transitGoals_)-2 <=std::get<1>(*transitGoals_)){
      //     //We are on the last goal in teh series
      //     (*currentGoals_)[1] = goals[currentGoalIndex_];
      //   }// }else{
        //   (*currentGoals_)[1] = goals[currentGoalIndex_+1];
        // }

      }
    //}
  }

  void MultiMacroManagerNode::startTransitRoutine(){
          currentGoalIndex_ = 0;
          //We are performing transit routine.
           goalExists_ = true; 
      //     //std::vector<Eigen::Vector3f> goals= std::get<3>(*transitGoals_);
          currentPlannerCluster_ = std::get<1>(*transitGoals_);
          currentTargetCluster_ = std::get<2>(*transitGoals_);
      //     //(*currentGoals_)[0] = goals[0];
      //     std::vector<Eigen::Vector3f> goals = gymInstance_->getTransitGoalsVec(0,currentTargetCluster_);
      //     int goalIndex = 0;
      // bool validGoal = false;
      // for(Eigen::Vector3f goal : goals){

      //   if((pose_.position-goal).norm()>0.8 && (pose_.position-goal).norm() < 10.0 && goal != Eigen::Vector3f(0.0,0.0,0.0)){
      //     validGoal = true;
      //     break;
          
      //   }
      //   goalIndex++;
      // }
      // if(validGoal){
      // (*currentGoals_)[0] = goals[goalIndex];
      // (*currentGoals_)[1] = goals[goalIndex];
      // }else{
      //   std::cout << "invalid GOAL!" << std::endl;
      // }
      nearBoundary_ = false;
      if(gymInstance_->plannerInstance()->plannerManager()->getClusterFromPosition(pose_.position) != currentTargetCluster_){
        Eigen::Vector3f boundaryPoint = gymInstance_->plannerInstance()->plannerManager()->getDestinationBoundaryPoint(currentPlannerCluster_, currentTargetCluster_);
        if(!nearBoundary_){
          if((pose_.position - boundaryPoint).norm() < 1.5){
            (*currentGoals_)[0] = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryAverage(currentTargetCluster_);
            nearBoundary_ = true;
          }else{
            (*currentGoals_)[0] = boundaryPoint;
          }
        }else{
          if((pose_.position - boundaryPoint).norm() < 2.5){
            (*currentGoals_)[0] = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryAverage(currentTargetCluster_);
          }else{
            (*currentGoals_)[0] = boundaryPoint;
            nearBoundary_ = false;
            }
          }
        //(*currentGoals_)[0] = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryAverage(currentTargetCluster_);
            isSearchGoal_ = false;
            *transitMode_ = true;
            *searchMode_ = false;
      }else{
        (*currentGoals_)[0] = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryAverage(currentTargetCluster_);
        Eigen::Vector3f boundaryPoint = gymInstance_->plannerInstance()->plannerManager()->getDestinationBoundaryPoint(currentPlannerCluster_, currentTargetCluster_);
        if((pose_.position - boundaryPoint).norm() > 1.5 || (pose_.position - (*currentGoals_)[0]).norm() < 1.0){
          *transitMode_ = false;
          *searchMode_ = false;
          isSearchGoal_ = false;
          std::get<0>(*transitGoals_) = 0;
          goalExists_ = false;
          currentGoalIndex_ = 0;
          (*xyz_).x() = 0.0;
          (*xyz_).y() = 0.0;
          (*xyz_).z() = 0.0;
          (*rpy_).x() = 0.0;
          (*rpy_).y() = 0.0;
          (*rpy_).z() = 0.0;
        }
      }
  }

  void MultiMacroManagerNode::populateSearchTargets(std::vector<int> replaceIndex){
     if(searchTargetsMap_.size() >= replaceIndex.size()){
           //Then we can populate search targets
           int targetIndex = 0;
            //std::cout << "stepping through targets? " << std::endl;
           for(auto it = searchTargetsMap_.begin(); it != std::next(searchTargetsMap_.begin(),replaceIndex.size()); ++it){

            //std::cout << "targetIndex = " << replaceIndex[targetIndex] << std::endl;
            //std::cout << "target point = " << (*it).second.x() << " / " << (*it).second.y() << " / "<< (*it).second.z() << std::endl;

            (*currentGoals_)[replaceIndex[targetIndex]] = (*it).second;
            targetIndex++;
           } 
      }else if (searchTargetsMap_.size() >= 0){
        //Populate search targets with what we can, and then duplicate the existing ones. 
        int targetIndex = 0;
        for(auto it = searchTargetsMap_.begin(); it != searchTargetsMap_.end(); ++it){
          (*currentGoals_)[replaceIndex[targetIndex]] = (*it).second;
          replaceIndex[targetIndex] = -1;
          targetIndex++;
        }
        //get a valid search target from the current search targets to double up on. 
        int duplicateIndex = 0;
        for(int index = 0; index < replaceIndex.size(); index++){
            if(duplicateIndex == replaceIndex[index]){
              duplicateIndex++;
            }else{
              break;
            }
          }
        for(int x = targetIndex; x < replaceIndex.size(); x++){
          //For the remainder, just add the current unsearched duplicate. 
          (*currentGoals_)[replaceIndex[targetIndex]] = (*currentGoals_)[duplicateIndex];
          targetIndex++;
        }
      }
      // }else/*searchTargetsMap_.size == 0*/{
      //   //Do nothing for the current goals. 
      // }
  }

  std::vector<int> MultiMacroManagerNode::checkSearchTargets(){
    return gymInstance_->plannerInstance()->plannerManager()->checkSearchTargets((*currentGoals_), gymInstance_->agentManager()->getAgentByIndex(0)->map());
  }


//TODO integrate observations into a specific planner manager object maybe? or a specific nanomaptapir object that we update with planner manager?
//For now we are on time crunch, keep it simple.
//Might need gymInstance for ease of data retrieval later, maybe just work with the observations stuff for now and keep tapir interface isolated 
//observation sequences is a vector of observations. with observations being a pair with an int-id, and a vector of int based observations.
  MultiActionManager::MultiActionManager(nanomap::instance::GymInstance& gymInstance,
                        nanomaptapir::planner::multisearch::Definition* definition,
                  std::vector<nanomap_ros::multi_control::MultiAgentInfo>&  agentInfoSequence,
                std::vector<std::pair<int, int>>&                              actionSequence,
                std::tuple<int, std::vector<bool>, int, std::vector<Eigen::Vector3f>>& searchGoals,
                std::tuple<int, int, int, std::vector<Eigen::Vector3f>>& transitGoals)
  : Node("Agent_"+std::to_string(definition->agentId())+"_action_manager"), count_(0), gymInstance_(&gymInstance), definition_(definition), 
        agentInfoSequence_(&agentInfoSequence), actionSequence_(&actionSequence),
        searchGoals_(&searchGoals), transitGoals_(&transitGoals)
  {
    agentId_ = definition_->agentId();
    nTargets_ = definition_->nTargets();
    searchStatus_.resize(nTargets_+1, false);
    //foundLast_.resize(definition_->nTargets(), false);
    infoId_ = 0;
    Eigen::Array<float, 7, 1> poseAsFloat = gymInstance_->getAgentPoseAsFloatByIndex(0);
              nanomap::Pose pose;
              pose.position.x() = poseAsFloat(0);
              pose.position.y() = poseAsFloat(1);
              pose.position.z() = poseAsFloat(2);
              std::tie(currentRealCluster_, currentBoundary_) = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose.position);
              //std::cout << "current Real, Planner and Target Cluster =  " << currentRealCluster_  << std::endl;
    currentTargetCluster_ = currentRealCluster_;
    currentPlannerCluster_ = currentRealCluster_;         
    actionPending_ = false;
    actionComplete_ = false;
    actionId_ = 0;
    std::string topic = "actionObsNode";
    auto timer_callback =
      [this]() -> void {
        std::vector<int> obsVec;
        if(actionPending_ == false){
          if(actionSequence_->size() > 0){
            std::pair<int, int> latestAction = actionSequence_->back();

            if(latestAction.first > actionId_){
                        //std::cout << "latestActionId = " << latestAction.first << "actionId = " << actionId_ << std::endl;
              //New action
              if(latestAction.second == 0){
                
                //getsearchgoal gets the search goals for the current agent in its current cluster. 
                currentTargetCluster_ = currentPlannerCluster_;
                std::vector<Eigen::Vector3f> searchGoals  = gymInstance_->getSearchGoalsVec(0, currentTargetCluster_);
                searchStatus_.clear();
                searchStatus_.resize(nTargets_+1,false);

                std::get<1>(*searchGoals_) = searchStatus_;
                std::get<2>(*searchGoals_) = currentTargetCluster_;
                std::get<3>(*searchGoals_) = searchGoals;
                std::get<0>(*searchGoals_) = searchGoals.size();
                //std::cout << "searchGoalsSize = " << searchGoals.size() << std::endl;
                //foundLast_, currentTargetCluster_, searchGoals);
                mode_ = 0;
                actionPending_ = true;
              }else{
                  Eigen::Array<float, 7, 1> poseAsFloat = gymInstance_->getAgentPoseAsFloatByIndex(0);
                  nanomap::Pose pose;
                  pose.position.x() = poseAsFloat(0);
                  pose.position.y() = poseAsFloat(1);
                  pose.position.z() = poseAsFloat(2);
                if(latestAction.second == 1){
                  if(mode_ != -1){
                  //wait, set goal as current position
                  //a second index of -1 and an empty goal vector communicate to the macro agent that we want to wait for an action
                  //normal goals start at 0
                    std::vector<Eigen::Vector3f> waitGoal;
                    waitGoal.push_back(Eigen::Vector3f(pose.position.x(), pose.position.y(), pose.position.z()));

                    std::get<1>(*transitGoals_) = -1;
                    std::get<2>(*transitGoals_) = currentPlannerCluster_;
                    std::get<3>(*transitGoals_) = waitGoal;
                    std::get<0>(*transitGoals_) = 0;
                    mode_ = -1;
                    actionPending_ = false;
                  }
                }else{
                    //get actual goals. 
                  std::tie(currentRealCluster_, currentBoundary_) = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose.position);
                  //std::cout << "current real Cluster " << currentRealCluster_  << std::endl;
                  //std::cout << "current planner cluster " << currentPlannerCluster_ << std::endl;
                  //getTransitGoalForindexAndtargetCluster
                  //gets the goal locations for the transit from the agents current position to the provided cluster
                  currentTargetCluster_ = definition_->getClusterMove(currentPlannerCluster_, 0, latestAction.second).first.first;
                  //std::cout << " targetCluster after move action = " << currentTargetCluster_ << std::endl;
                  
                  std::vector<Eigen::Vector3f> transitGoals = gymInstance_->getTransitGoalsVec(0,currentTargetCluster_);

                  std::get<1>(*transitGoals_) = currentPlannerCluster_;
                  std::get<2>(*transitGoals_) = currentTargetCluster_;
                  std::get<3>(*transitGoals_) = transitGoals;
                  std::get<0>(*transitGoals_) = transitGoals.size();
                  mode_ = 1;
                  actionPending_ = true;
                }
              }
              actionId_ = latestAction.first;
              actionComplete_ = false;
            }
          }
        }else if(actionPending_){
          if(mode_ == 0){
            if(std::get<0>(*searchGoals_) == 0){
              //search complete.
              searchStatus_ = std::get<1>(*searchGoals_);// if(std::get<1>(*searchGoals_) > 0){
              //   //search successful!
              //   isFound_ = 1;
              // }else{
              //   isFound_ = 0;
              // }
              currentPlannerCluster_ = currentTargetCluster_;
              actionComplete_ = true;
            }
          }else if(mode_ == 1){
            if(std::get<0>(*transitGoals_) == 0){
              //transit complete
              currentPlannerCluster_ = currentTargetCluster_;
              searchStatus_.clear();
              searchStatus_.resize(nTargets_+1, false);
              actionComplete_ = true;
            }
          }
          if(actionComplete_){
            //updateinfo
            nanomap_ros::multi_control::MultiAgentInfo agentInfo;
            agentInfo.infoId_ = infoId_;
            agentInfo.agentId_ = agentId_;
            //std::cout << "action complete cluster" << currentPlannerCluster_ << std::endl;;
            agentInfo.currentCluster_ = currentPlannerCluster_;
            agentInfo.searchStatus_ = searchStatus_;
            agentInfo.actionCompletion_ = true;
            //std::cout << (searchStatus_[0] ? 1 : 0) << " / " << (searchStatus_[1] ? 1 : 0) << std::endl;
            //agentInfo.action_ = latestAction.second;
            //agentInfo.actionComplete_ = 1;
            //Because we just finished our action, our current action becomes waiting
            //agentInfo.actionComplete_ = 1;
            //agentInfo.lastCluster_ = currentPlannerCluster_;
            //agentInfo.lastAction_ = latestAction.second;
            // std::vector<bool> foundLast;
            // foundLast.resize(definition->nTargets(),false);
            // if(mode_ == 0){
            //   //We completed a search, so check the search goals for completion
            //   foundLast = std::get<2>(*searchGoals_);
            // }
            //agentInfo.targetsFoundByLastAction = foundLast;
            agentInfoSequence_->push_back(agentInfo);
            //Increment infoid
            infoId_++;
            //currentPlannerCluster_ = currentTargetCluster_;
            //std::cout << "action completed, updating agentInfo: (" << currentObservation_ << ", "<< isFound_ << ")"<< std::endl;
            //generate observation.
            //std::vector<int> obsVec;
            //obsVec.push_back(isFound_);
            //observationsSequence_->push_back(std::make_pair(currentObservation_, obsVec));
            //currentObservation_++;
            actionPending_ = false;
            actionComplete_ = false;
          }
        }
      };
    timer_ = this->create_wall_timer(100ms, timer_callback);
  }


//And numAgents-1 of these. (one for each other agent)

// MultiObservationPublisher::MultiObservationPublisher(int agentId, std::string topicName, std::vector<nanomap_ros::multi_control::MultiAgentInfo>& agentStampedInfo)
// : Node("agent_" + std::to_string(agentId_) + "_info_publisher"), agentId_(agentId), topicName_(topicName), agentStampedInfo_(&agentStampedInfo)
// {
          
//           // std::string topic = "boundary_node_visualizer";
//           publisher_ = this->create_publisher<nanomap_msgs::msg::MultiAgentInfo>(topic, 10);
//           latestInfo_.infoId_ = -1;
//           //Setting this to world, unsure if necessary, or if ROS would complain about no frame_id
//           msg_.header.frame_id = "world";
//           auto timer_callback =
//             [this]() -> void {
//                 rclcpp::Time now = this->get_clock()->now();
//                 bool msgUpdated = false;
//                 if(agentStampedInfo_->size() > 0){
//                   nanomap_ros::multi_control::MultiAgentInfo latestInfo = (*agentStampedInfo_)[agentStampedInfo_->size()-1];  
//                   if(latestInfo.infoId_ > latestInfo_.infoId_){
//                     latestInfo_ = latestInfo;
//                     msgUpdated = true;
//                   }
//                 }
//                 if(latestInfo_.infoId_ >= 0){
//                   msg_.header.stamp = now;  
//                   //If there is new information to be transmitted, update the msg
//                   //Otherwise we retransmit old info with a new header time stamp
//                   if(msgUpdated){
//                     msg_.info_stamp_ = latestInfo_.timeStamp_;
//                     msg_.info_id = latestInfo_.infoId_;  
//                     msg_.agent_id = latestInfo_.agentId_;
//                     msg_.current_cluster = latestInfo_.currentCluster_;
//                     msg_.current_action = latestInfo_.currentAction_;
//                     msg_.last_cluster = latestInfo_.lastCluster_;
//                     msg_.last_action = latestInfo_.lastAction_;
//                     msg_.found_last = latestInfo_.targetsFoundByLastAction_;
//                   }
//                   this->publisher_->publish(msg_);
//                 }
//             };
//   timer_ = this->create_wall_timer(100ms, timer_callback);
// }

//And numAgents-1 of these. (one for each other agent)

MultiObservationPublisher::MultiObservationPublisher(int agentId, std::string topicName, std::vector<nanomap_ros::multi_control::MultiAgentInfo>& agentStampedInfo)
: Node("agent_" + std::to_string(agentId) + "_info_publisher"), agentId_(agentId), topicName_(topicName), agentStampedInfo_(&agentStampedInfo)
{
          
          // std::string topic = "boundary_node_visualizer";
          publisher_ = this->create_publisher<nanomap_msgs::msg::MultiAgentInfo>(topicName_, 10);
          latestInfo_.infoId_ = -1;
          //Setting this to world, unsure if necessary, or if ROS would complain about no frame_id
          msg_.header.frame_id = "world";
          auto timer_callback =
            [this]() -> void {
                rclcpp::Time now = this->get_clock()->now();
                bool msgUpdated = false;
                if(agentStampedInfo_->size() > 0){
                  nanomap_ros::multi_control::MultiAgentInfo latestInfo = (*agentStampedInfo_)[agentStampedInfo_->size()-1];  
                  if(latestInfo.infoId_ > latestInfo_.infoId_){
                    latestInfo_ = latestInfo;
                    msgUpdated = true;
                  }
                }
                if(latestInfo_.infoId_ >= 0){
                  msg_.header.stamp = now;  
                  //If there is new information to be transmitted, update the msg
                  //Otherwise we retransmit old info with a new header time stamp
                  if(msgUpdated){
                    msg_.info_stamp = latestInfo_.timeStamp_;
                    msg_.info_id = latestInfo_.infoId_;  
                    msg_.agent_id = latestInfo_.agentId_;
                    msg_.current_cluster = latestInfo_.currentCluster_;
                    //msg_.current_action = latestInfo_.currentAction_;
                    //msg_.last_cluster = latestInfo_.lastCluster_;
                    //msg_.last_action = latestInfo_.lastAction_;
                    msg_.search_status = latestInfo_.searchStatus_;
                  }
                  this->publisher_->publish(msg_);
                }
            };
  timer_ = this->create_wall_timer(100ms, timer_callback);
}



// //And numAgents-1 of these. (one for each other agent)

// MultiObservationSubscriber::MultiObservationSubscriber(int agentId_, std::string topicName, std::vector<nanomap_ros::multi_control::MultiAgentInfo>& agentStampedInfo)
// : Node("agent_" + std::to_string(agentId_) + "_info_subscriber"), agentId_(agentId), topicName_(topicName), agentStampedInfo_(&agentStampedInfo)
// {          // std::string topic = "boundary_node_visualizer";
//           subscription_ = this->create_subscription<nanomap_msgs::msg::MultiAgentInfo>(topicName_, 10, std::bind(&MultiObservationSubscriber::topic_callback), this, _1);
//   latestInfo_.infoId_ = -1;
// }

// MultiObservationSubscriber::topicCallback(const nanomap_msgs::msg::MultiAgentInfo::SharedPtr msg) const{
//   infoId = msg->info_id;
//   if(infoId != latestInfo_){
//     latestInfo_.timeStamp_ = msg->info_stamp;
//     latestInfo_.infoId_ = msg->info_id;
//     latestInfo_.agentId_ = msg->agent_id;
//     latestInfo_.currentCluster_ = msg->current_cluster;
//     latestInfo_.currentAction_ = msg->current_action;
//     latestInfo_.lastCluster_ = msg->last_cluster;
//     latestInfo_.lastAction_ = msg->last_action;
//     latestInfo_.targetsFoundByLastAction_ = msg->found_last;
//     agentStampedInfo->push_back(latestInfo_);
//   }
// }

MultiObservationSubscriber::MultiObservationSubscriber(int agentId, std::string topicName, std::vector<nanomap_ros::multi_control::MultiAgentInfo>& agentStampedInfo)
: Node("agent_" + std::to_string(agentId) + "_info_subscriber"), agentId_(agentId), topicName_(topicName), agentStampedInfo_(&agentStampedInfo)
{          // std::string topic = "boundary_node_visualizer";
          subscription_ = this->create_subscription<nanomap_msgs::msg::MultiAgentInfo>(topicName_, 10, std::bind(&MultiObservationSubscriber::topic_callback, this, std::placeholders::_1));
  latestInfo_.infoId_ = -1;
}


//Organizes the agent info according to age and creates the necessary observations for the planner.
  MultiObservationManager::MultiObservationManager(nanomap::instance::GymInstance& gymInstance,
                        nanomaptapir::planner::multisearch::Definition* definition,
                  std::vector<std::vector<nanomap_ros::multi_control::MultiAgentInfo>>& agentStampedInfo,
                  std::vector<std::pair<bool, std::pair<std::vector<int>, std::vector<std::vector<bool>>>>>& plannerObservations)
  : Node("agent_" + std::to_string(definition->agentId()) + "_observation_manager"), 
    gymInstance_(&gymInstance), definition_(definition), agentStampedInfo_(&agentStampedInfo),
    plannerObservations_(&plannerObservations), latestObservationInfo_(definition)
  {
    //get initial cluster search status; 

    nAgents_ = definition_->nAgents_;
    infoIds_.clear();
    infoIds_.resize(nAgents_, 0);
          auto timer_callback =
            [this]() -> void {
              //bool needNewAction =;
              newInfo_.clear();
              for(int x = 0; x < nAgents_; x++){
                if((*agentStampedInfo_)[x].size() > infoIds_[x]){       
                  //unprocessed messages.
                  // if(x == definition_->agentId_){
                  //   //New action completion from this agent, request new action;
                  //   needNewAction = true;
                  // }
                  newInfo_.push_back((*agentStampedInfo_)[x][infoIds_[x]]);
                  
                  infoIds_[x]++; 
                }
              }
            if(newInfo_.size()>0){
              latestObservationInfo_.processLatestInfo(newInfo_);
              plannerObservations_->push_back(std::make_pair(latestObservationInfo_.actionCompletion(),std::make_pair(latestObservationInfo_.agentClusters(),
                                                                latestObservationInfo_.searchStatus())));
            }
          };
    timer_ = this->create_wall_timer(1000ms, timer_callback);
  }


LatestObservationInfo::LatestObservationInfo(nanomaptapir::planner::multisearch::Definition* definition)
:definition_(definition)
{
  nAgents_ = definition_->nAgents_;
  nTargets_ = definition_->nTargets_;
  agentClusters_ = definition_->initialAgentClusters_;
  for(int x = 0; x < nAgents_; x++){
    std::vector<bool> agentSearchStatus;
    agentSearchStatus.resize(nTargets_+1, false);
    searchStatus_.push_back(agentSearchStatus);
  }
}

void LatestObservationInfo::processLatestInfo(std::vector<nanomap_ros::multi_control::MultiAgentInfo> agentInfo){
  std::vector<std::vector<bool>> newSearchStatus;
  actionCompletion_ = false;

  for(int x = 0; x < nAgents_; x++){
    std::vector<bool> agentSearchStatus;
    agentSearchStatus.resize(nTargets_+1, false);
    newSearchStatus.push_back(agentSearchStatus);
  }
  for(auto info : agentInfo){
    if(info.agentId_ == definition_->agentId()){
      if(info.actionCompletion_ = true){
        actionCompletion_ = true;
      }
    }
    agentClusters_[info.agentId_] = info.currentCluster_;
    newSearchStatus[info.agentId_] = info.searchStatus_;
  }
  searchStatus_ = newSearchStatus;
  int agentIndex = 0;
  //DEBUG PRINT
  // for(int agentCluster : agentClusters_){
  //   std::cout << "agent " << agentIndex << "cluster = " << agentCluster << std::endl;
  //   agentIndex++;
  // }
  // for(auto searchStatus : searchStatus_){
  //   for(bool status : searchStatus){
  //     std::cout << " " << (status ? 1 : 0);
  //   }
  //   std::cout << std::endl;
  // }
}




  MultiAgentTapirNode::MultiAgentTapirNode(int agentId,
                  nanomaptapir::planner::multisearch::Interface& tapirInterface, 
                  std::vector<std::pair<bool, std::pair<std::vector<int>, std::vector<std::vector<bool>>>>>&             plannerObservations,
                std::vector<std::pair<int,int>>&                                                actionSequence)
  : Node("agent_" + std::to_string(agentId)+ "_tapir_node"), agentId_(agentId), tapirInterface_(&tapirInterface), plannerObservations_(&plannerObservations), actionSequence_(&actionSequence)
  {

    currentObservation_ = 0;
    actionId_ = 1;
    actionSequence_->push_back(std::make_pair(actionId_, tapirInterface_->getPreferredAction()));
    //std::cout << "ACTION FROM POLICY = " << tapirInterface_->getPreferredAction() << std::endl;
    lastAction_ = tapirInterface_->getPreferredAction();
    //DEBUG PRINT
    //tapirInterface_->printAgentBeliefProportions();
    //std::cout << std::endl;
    //tapirInterface_->printBeliefProportions();
    actionId_++;
    auto timer_callback =
      [this]() -> void {

          //PLANNER LOOP HERE
        if(plannerObservations_->size()>currentObservation_){
          //int agentTurn = (*plannerObservations_)[currentObservation_].agentTurn();
          tapirInterface_->addObservation((*plannerObservations_)[currentObservation_].second);
          
          //tapirInterface_->addObservation(&((*observations_)[currentObservation_]));
          tapirInterface_->stepSolver();
            //DEBUG PRINT
            // std::cout << "belief after observation ^"  << std::endl;
            // tapirInterface_->printAgentBeliefProportions();
            // std::cout << std::endl;
            // tapirInterface_->printBeliefProportions();
            // std::cout << std::endl;
          if((*plannerObservations_)[currentObservation_].first || lastAction_ == 1){
            // std::cout << "ACTION FROM POLICY = " << tapirInterface_->lastAction_->getAction() << std::endl;

            //We only want to update our working action if we just completed an action (agentTurn = agentId), or if
            //our last action was to wait. Then we might need an action.  
            //if(agentTurn == agentId_ || lastAction_ == 1){
            actionSequence_->push_back(std::make_pair(actionId_, tapirInterface_->getPreferredAction()));      
            lastAction_ = tapirInterface_->getPreferredAction();
            actionId_++;
          }
          currentObservation_++;
          
        }
      };
    timer_ = this->create_wall_timer(100ms, timer_callback);
  }


CompletionCheck::CompletionCheck( nanomaptapir::planner::multisearch::Definition* definition,
                                  std::vector<std::vector<nanomap_ros::multi_control::MultiAgentInfo>>& agentStampedInfo)
: Node("completion_check_node"), definition_(definition), agentStampedInfo_(&agentStampedInfo)                              
{
    clusterSearchStatus_ = definition_->clusterSearchStatus_;
    nAgents_ = definition_->nAgents_;
    nTargets_ = definition_->nTargets_;
    //std::cout << "nTargets according to definition " << nTargets_ << std::endl;
    targetFoundStatus_.clear();
    targetFoundStatus_.resize(nTargets_,false);
    startTime_ = std::chrono::high_resolution_clock::now();
    infoIds_.clear();
    infoIds_.resize(nAgents_, 0);
      auto timer_callback =
      [this]() -> void {
        for(int x = 0; x < nAgents_; x++){
          while((*agentStampedInfo_)[x].size() > infoIds_[x]){                   
            if((*agentStampedInfo_)[x][infoIds_[x]].searchStatus_[0] == true){
              //Search of cluster was completed;
              clusterSearchStatus_[(*agentStampedInfo_)[x][infoIds_[x]].currentCluster_] = true;
              for(int target = 0; target < nTargets_; target++){
                if((*agentStampedInfo_)[x][infoIds_[x]].searchStatus_[1+target] == true){
                  targetFoundStatus_[target] = true;
                }
              }
            }
            infoIds_[x]++; 
          }
        }
        bool isSearchComplete = true;
        for(bool status : clusterSearchStatus_){
          if(!status){
            isSearchComplete = false;
            break;
          }
        }
        if(isSearchComplete == false){
          bool isFoundStatusTrue = true;
          for(bool foundStatus : targetFoundStatus_){
            if(!foundStatus){
              isFoundStatusTrue = false;
              break;
            }
          }
          if(isFoundStatusTrue){
            isSearchComplete = true;
          }
        }
        if(isSearchComplete){
          auto endTime = std::chrono::high_resolution_clock::now();
          std::cout << "Search took "
          << std::chrono::duration_cast<std::chrono::seconds>(endTime-startTime_).count()
          << " seconds\n";
          exit(1);
        }
        
      };
    timer_ = this->create_wall_timer(50ms, timer_callback);
}

  }
}
