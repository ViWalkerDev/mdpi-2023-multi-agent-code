
#include "nanomap_ros/visualization/VisualizerNodes.hpp"

namespace nanomap_ros{
  namespace visualization{
    using Pose = nanomap::Pose;
    using namespace std::chrono_literals;

      std::string string_thread_id()
      {
        auto hashed = std::hash<std::thread::id>()(std::this_thread::get_id());
        return std::to_string(hashed);
      }

/*****************************************************************************/


        FramePublisher::FramePublisher(nanomap::instance::GymInstance& gymInstance, std::string agentName)
        : Node("agent_frame_publisher"), gymInstance_(&gymInstance), agentname_(agentName)
        {
          //this->declare_parameter<std::string>("agentname", );
          //this->get_parameter("agentname", agentname_);

          // Initialize the transform broadcaster
          tf_broadcaster_ =
            std::make_unique<tf2_ros::TransformBroadcaster>(*this);

          auto timer_callback =
          [this]() -> void {
            rclcpp::Time now = this->get_clock()->now();
            geometry_msgs::msg::TransformStamped t;
            //std::vector<nanomap::Pose> poses = manager_->agentPoses();
            //std::shared_ptr<SensorData> sensorData = gymInstance_->agentManager()->getAgent(0)->sensor(sensorIndex_)->sensorData();
            //nanomap::Pose* agentPose = gymInstance_->agentManager()->getAgent(0)->agentData()->pose();
            t.header.stamp = now;
            t.header.frame_id = "world";
            t.child_frame_id = agentname_.c_str();

            t.transform.translation.x = gymInstance_->agentManager()->getAgent(0)->agentData()->pose().position(0);
            t.transform.translation.y = gymInstance_->agentManager()->getAgent(0)->agentData()->pose().position(1);
            t.transform.translation.z = gymInstance_->agentManager()->getAgent(0)->agentData()->pose().position(2);

            t.transform.rotation.x = (double)(gymInstance_->agentManager()->getAgent(0)->agentData()->pose().orientation.x());
            t.transform.rotation.y = (double)(gymInstance_->agentManager()->getAgent(0)->agentData()->pose().orientation.y());
            t.transform.rotation.z = (double)(gymInstance_->agentManager()->getAgent(0)->agentData()->pose().orientation.z());
            t.transform.rotation.w = (double)(gymInstance_->agentManager()->getAgent(0)->agentData()->pose().orientation.w());

            tf_broadcaster_->sendTransform(t);

          };

            timer_ = this->create_wall_timer(10ms, timer_callback);
        }




/*****************************************************************************/

        BoundaryVisualizer::BoundaryVisualizer(nanomap::instance::GymInstance& gymInstance, VisualizerColors& colorsObject)
        : Node("boundary_node_visualizer"), count_(0), gymInstance_(&gymInstance), colorsObject_(&colorsObject)
        {

          
          std::string topic = "boundary_node_visualizer";
          publisher_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(topic, 10);

          auto timer_callback =
            [this]() -> void {
                int id = 0; 
                std::vector<visualization_msgs::msg::Marker> markerVector;
                rclcpp::Time now = this->get_clock()->now();
                  
                  std::vector<std::vector<Eigen::Vector3f>> boundaryPoints = gymInstance_->plannerInstance()->plannerManager()->getBoundaryPointsFromGraph();
                  for(int clusterIndex = 0; clusterIndex < boundaryPoints.size(); clusterIndex++){
                    visualization_msgs::msg::Marker marker;
                    marker.header.frame_id = "world";
                    marker.header.stamp = now;
                    marker.id = id;
                    id++;
                    marker.type = visualization_msgs::msg::Marker::POINTS;
                    marker.action = visualization_msgs::msg::Marker::ADD;
                    marker.scale.x = 0.8;
                    marker.scale.y = 0.8;
                    marker.color.a = 1.0;
                    marker.color.r = (float)colorsObject_->getColorComponent(clusterIndex,0);
                    marker.color.g = (float)colorsObject_->getColorComponent(clusterIndex,1);
                    marker.color.b = (float)colorsObject_->getColorComponent(clusterIndex,2);
                    std::vector<geometry_msgs::msg::Point> pointsVector;
                    for(int boundaryIndex = 0; boundaryIndex < boundaryPoints[clusterIndex].size(); boundaryIndex++){
                      geometry_msgs::msg::Point point;
                      point.x = boundaryPoints[clusterIndex][boundaryIndex].x();
                      point.y = boundaryPoints[clusterIndex][boundaryIndex].y();
                      point.z = boundaryPoints[clusterIndex][boundaryIndex].z();
                      pointsVector.push_back(point);
                    }
                    marker.points = pointsVector;
                    markerVector.push_back(marker);
                  }
                  markerArray_.markers=markerVector;

            this->publisher_->publish(markerArray_);
            };
          timer_ = this->create_wall_timer(1000ms, timer_callback);
        }

/*****************************************************************************/

        ClusterSearchNodeVisualizer::ClusterSearchNodeVisualizer(nanomap::instance::GymInstance& gymInstance, VisualizerColors& colorsObject)
        : Node("cluster_node_visualizer"), count_(0), gymInstance_(&gymInstance), colorsObject_(&colorsObject)
        {
          std::string topic = "cluster_node_visualizer";
          publisher_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(topic, 10);
          auto timer_callback =
            [this]() -> void {
                int id = 0; 
                std::vector<visualization_msgs::msg::Marker> markerVector;
                rclcpp::Time now = this->get_clock()->now();
                  for(int clusterIndex = 0; clusterIndex < gymInstance_->plannerInstance()->plannerManager()->getClusterCount(); clusterIndex++){
                    std::vector<Eigen::Vector3f> clusterSearchTargets = gymInstance_->plannerInstance()->plannerManager()->getClusterSearchNodesInWorld(clusterIndex);
                    visualization_msgs::msg::Marker marker;
                    marker.header.frame_id = "world";
                    marker.header.stamp = now;
                    marker.id = id;
                    id++;
                    marker.type = visualization_msgs::msg::Marker::POINTS;
                    marker.action = visualization_msgs::msg::Marker::ADD;
                    marker.scale.x = 0.8;
                    marker.scale.y = 0.8;
                    marker.color.a = 1.0;
                    marker.color.r = (float)colorsObject_->getColorComponent(clusterIndex,0);
                    marker.color.g = (float)colorsObject_->getColorComponent(clusterIndex,1);
                    marker.color.b = (float)colorsObject_->getColorComponent(clusterIndex,2);
                    std::vector<geometry_msgs::msg::Point> pointsVector;
                    for(int targetIndex = 0; targetIndex < clusterSearchTargets.size(); targetIndex++){
                      geometry_msgs::msg::Point point;
                        point.x = clusterSearchTargets[targetIndex].x();
                        point.y = clusterSearchTargets[targetIndex].y();
                        point.z = clusterSearchTargets[targetIndex].z();
                        pointsVector.push_back(point);
                    }
                    if(pointsVector.size() > 0){
                    marker.points = pointsVector;
                    markerVector.push_back(marker);
                    }
                  }
                  if(markerVector.size()>0){
                    markerArray_.markers=markerVector;
                    this->publisher_->publish(markerArray_);
                  }

            
            };
          timer_ = this->create_wall_timer(1000ms, timer_callback);
        }

/*****************************************************************************/

        OpenVDBGridPublisher::OpenVDBGridPublisher(openvdb::FloatGrid::Ptr grid, std::string node_name, std::string topicName)
        : Node(node_name), count_(0) , grid_(grid), topicName_(topicName)
        {
          std::string topic = grid_->getName();
          publisher_ = this->create_publisher<nanomap_msgs::msg::OpenvdbGrid>(topicName_, 10);
          auto timer_callback =
            [this]() -> void {
              auto curr_thread = string_thread_id();
              msg_.header.frame_id = "world";
              msg_.header.stamp = now();
              std::ostringstream ostr(std::ios_base::binary);
              openvdb::GridPtrVecPtr grids(new openvdb::GridPtrVec);
              gridCopy_ = grid_->deepCopy();
              grids->push_back(gridCopy_);
              openvdb::io::Stream(ostr).write(*grids);
              int size = ostr.str().size();
              msg_.size = size;
              msg_.data.resize(size);
              std::memcpy(msg_.data.data(), reinterpret_cast<unsigned char*>(const_cast<char*>(ostr.str().c_str())), size);
              gridCopy_->clear();
              this->publisher_->publish(msg_);
            };
          timer_ = this->create_wall_timer(500ms, timer_callback);
        }

/*****************************************************************************/

        GraphVisualizer::GraphVisualizer(nanomap::instance::GymInstance& gymInstance)
        : Node("graph_visualizer"), count_(0), gymInstance_(&gymInstance)
        {
          std::string topic = "graph_visualizer";
          publisher_ = this->create_publisher<visualization_msgs::msg::Marker>(topic, 10);

          auto timer_callback =
            [this]() -> void {

            int id = 0; 
                
                rclcpp::Time now = this->get_clock()->now();
                  marker.header.frame_id = "world";
                  marker.header.stamp = now;
                  marker.id = id;
                  id++;
                  marker.type = visualization_msgs::msg::Marker::LINE_LIST;
                  marker.action = visualization_msgs::msg::Marker::ADD;
                  std::vector<geometry_msgs::msg::Point> pointsVector;

                  std::vector<Eigen::Vector3f> boundaryLines = gymInstance_->plannerInstance()->plannerManager()->getBoundaryLinesFromGraph();
                  for(int point = 0; point < int(boundaryLines.size()); point+=2){
                    geometry_msgs::msg::Point startPoint;
                    geometry_msgs::msg::Point endPoint;
                    
                    startPoint.x = boundaryLines[point].x();
                    startPoint.y = boundaryLines[point].y();
                    startPoint.z = boundaryLines[point].z();
                    endPoint.x = boundaryLines[point+1].x();
                    endPoint.y = boundaryLines[point+1].y();
                    endPoint.z = boundaryLines[point+1].z();
                    pointsVector.push_back(startPoint);
                    pointsVector.push_back(endPoint);
                  }
                  marker.scale.z = 0.1;
                  marker.scale.y = 0.1;
                  marker.scale.x = 0.1;
                  marker.points = pointsVector;
                  marker.color.a = 1.0;
                  marker.color.r = 0.0;
                  marker.color.g = 1.0;
                  marker.color.b = 0.0;

            this->publisher_->publish(marker);
            };
          timer_ = this->create_wall_timer(20ms, timer_callback);
        }

/*****************************************************************************/

        AgentPublisher::AgentPublisher(nanomap::instance::GymInstance& gymInstance)
        : Node("agent_publisher"),count_(0), gymInstance_(&gymInstance)
        {
          std::string topic = "agent_publisher";
          publisher_ = this->create_publisher<geometry_msgs::msg::PointStamped>(topic, 10);

          auto timer_callback =
          [this]() -> void {
            Eigen::Array<float, 7, 1> poseAsFloat = gymInstance_->getAgentPoseAsFloatByIndex(0);
            rclcpp::Time now = this->get_clock()->now();
            
            msg_.header.stamp = now;
            msg_.header.frame_id = "world";
            //std::cout << "goalObs " << goalObs(0) << " / " << goalObs(1) << " / " << goalObs(2) << std::endl;
            msg_.point.x = poseAsFloat(0);
            msg_.point.y =  poseAsFloat(1);
            msg_.point.z =  poseAsFloat(2);
            // Send the transformation
            this->publisher_->publish(msg_);
          };
          timer_ = this->create_wall_timer(50ms, timer_callback);
        }

/*****************************************************************************/

        TargetPublisher::TargetPublisher(nanomap::instance::GymInstance& gymInstance)
        : Node("target_publisher"),count_(0), gymInstance_(&gymInstance)
        {
          std::string topic = "target_publisher";
          publisher_ = this->create_publisher<geometry_msgs::msg::PointStamped>(topic, 10);

          auto timer_callback =
          [this]() -> void {
            //Eigen::Array<float, 11, 1> goalObs = gymInstance_->getGoalObservationsByIndex(0);
            std::vector<Eigen::Vector3f> targetPositions = gymInstance_->targetPositions();
            rclcpp::Time now = this->get_clock()->now();
            
            msg_.header.stamp = now;
            msg_.header.frame_id = "world";

            msg_.point.x = targetPositions[0].x();
            msg_.point.y =  targetPositions[0].y();
            msg_.point.z =  targetPositions[0].z();
            // Send the transformation
            this->publisher_->publish(msg_);
          };
          timer_ = this->create_wall_timer(100ms, timer_callback);
        }

/*************************************************************************/
TransitGoalVisualizer::TransitGoalVisualizer(int agentId, nanomap::instance::GymInstance& gymInstance, std::vector<Eigen::Vector3f>& currentGoals)
  : Node("agent_"+std::to_string(agentId)+"_transit_goal_visualizer"),count_(0), agentId_(agentId), gymInstance_(&gymInstance), currentGoals_(&currentGoals)
  {
    std::string topic = "agent_"+std::to_string(agentId_)+"_transit_goal_visualizer";
    publisher_ = this->create_publisher<geometry_msgs::msg::PointStamped>(topic, 10);

    auto timer_callback =
    [this]() -> void {
      //Eigen::Array<float, 11, 1> goalObs = gymInstance_->getGoalObservationsByIndex(0);
      rclcpp::Time now = this->get_clock()->now();
      
      msg_.header.stamp = now;
      msg_.header.frame_id = "world";
      // msg_.header.frame_id = "agent_"+std::to_string(agentId_);
      //std::cout << "goalObs " << goalObs(0) << " / " << goalObs(1) << " / " << goalObs(2) << std::endl;
      msg_.point.x = (*currentGoals_)[0].x();
      msg_.point.y =  (*currentGoals_)[0].y();
      msg_.point.z =  (*currentGoals_)[0].z();

      // msg_.pose.orientation.x = (double)sensorData->sharedParameters()._pose.orientation.x();
      // msg_.pose.orientation.y = (double)sensorData->sharedParameters()._pose.orientation.y();
      // msg_.pose.orientation.z = (double)sensorData->sharedParameters()._pose.orientation.z();
      // msg_.pose.orientation.w = (double)sensorData->sharedParameters()._pose.orientation.w();

      // Send the transformation
      this->publisher_->publish(msg_);
    };
    timer_ = this->create_wall_timer(10ms, timer_callback);
  }
/*************************************************************************/

  SearchGoalVisualizer::SearchGoalVisualizer(int agentId, nanomap::instance::GymInstance& gymInstance, std::vector<Eigen::Vector3f>& currentGoals)
  : Node("agent_"+std::to_string(agentId)+"_search_goal_visualizer"), agentId_(agentId), count_(0), gymInstance_(&gymInstance), currentGoals_(&currentGoals)
  {

    
    std::string topic = "agent_"+std::to_string(agentId_)+"_search_goal_visualizer";
    publisher_ = this->create_publisher<visualization_msgs::msg::Marker>(topic, 10);

    //(&distanceArray[0], distanceArray.data()+distanceArray.size());
    //distanceData.resize(distanceArray.size());
    //Eigen::Map<float>(distanceData.data(), distanceData.size()) = distanceArray;
    auto timer_callback =
      [this]() -> void {
      //std::vector<visualization_msgs::msg::Marker> markerVector;
      // for(int boundaryPair){
      //   std::
      
      // }
      int id = 0; 
      // for(int x = 0; x < 3; x++){
      //   for(int y = 0; y < 3; y++){
      //     for int z = 0; z < 3; z++{
      //Eigen::Array<float, 15, 1> goalObs = gymInstance_->getGoalObservationsByIndex(0);

      //std::cout << "goalObs " << goalObs(0) << " / " << goalObs(1) << " / " << goalObs(2) << std::endl;
          rclcpp::Time now = this->get_clock()->now();
            markerMsg_.header.stamp = now;
            markerMsg_.header.frame_id = "world";
            //markerMsg_.header.frame_id = "agent_"+std::to_string(agentId_);
            markerMsg_.id = id;
            id++;
            markerMsg_.type = visualization_msgs::msg::Marker::POINTS;
            markerMsg_.action = visualization_msgs::msg::Marker::ADD;
            std::vector<geometry_msgs::msg::Point> pointsVector;
            //std::vector<geometry_msgs::msgs::Point> points2Vector;
            
            //std::vector<Eigen::Vector3f> boundaryLines = gymInstance_->plannerInstance()->plannerManager()->getBoundaryLinesFromGraph();
            for(int goal = 0; goal < 5; goal++){
              geometry_msgs::msg::Point point;
              
              //startPoint.header.frame_id = "world";
              //endPoint.header.frame_id = "world";
              //std::cout << "goalObs " << goalObs(0) << " / " << goalObs(1) << " / " << goalObs(2) << std::endl;
              
              // < " / " << goalObs(1) << " / " << goalObs(2) << std::endl;
              point.x = (*currentGoals_)[goal].x();
              point.y = (*currentGoals_)[goal].y();
              point.z = (*currentGoals_)[goal].z();
              pointsVector.push_back(point);
            }
            markerMsg_.scale.z = 0.4;
            markerMsg_.scale.y = 0.4;
            markerMsg_.scale.x = 0.4;
            markerMsg_.points = pointsVector;
            markerMsg_.color.a = 1.0;
            markerMsg_.color.r = 0.0;
            markerMsg_.color.g = 1.0;
            markerMsg_.color.b = 0.0;

      this->publisher_->publish(markerMsg_);
      };
    timer_ = this->create_wall_timer(20ms, timer_callback);
  }

  }
}