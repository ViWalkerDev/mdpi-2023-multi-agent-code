#include "rclcpp/rclcpp.hpp"
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <thread>
#include <array>
#include <regex>
#include "openvdb/openvdb.h"
#include <openvdb/io/Stream.h>
#include "std_msgs/msg/string.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/point_stamped.hpp"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include "nanomap_msgs/msg/openvdb_grid.hpp"
#include "nanomap_msgs/msg/policy_observations.hpp"
#include "nanomap_msgs/srv/policy_query.hpp"

#include "nanomap/instance/GymInstance.h"
#include "nanomap/map/Map.h"
#include "nanomap/agent/Agent.h"
#include "nanomap/config/Config.h"
#include "nanomap/nanomap.h"
#include "nanomap/sensor/SensorData.h"

#include <Eigen/Geometry>
#include <Eigen/Core>
#include <Eigen/Dense>
#include "visualization_msgs/msg/marker.hpp"
#include "visualization_msgs/msg/marker_array.hpp"

#include "nanomap_ros/visualization/VisualizerNodes.hpp"
#include "nanomap_ros/control/ControlNodes.hpp"


#include "nanomaptapir/planner/problems/singlesearch/Definition.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Observation.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Action.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Interface.hpp"


#include <ament_index_cpp/get_package_share_directory.hpp>

using Pose = nanomap::Pose;
using namespace std::chrono_literals;

std::string string_thread_id()
{
  auto hashed = std::hash<std::thread::id>()(std::this_thread::get_id());
  return std::to_string(hashed);
}

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  openvdb::initialize();
  int seed = time(0);
  srand(seed);
  std::cout << seed << std::endl;
  // if(!(argc == 2)){
  //   std::cout << "please provide config path" << std::endl;
  //   return 0;
  // }
  nanomap_ros::visualization::VisualizerColors colorsObject;

  std::string package_share_directory = ament_index_cpp::get_package_share_directory("nanomap_ros");
  // std::string gymConfig = "/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/config.txt";
  // std::string plannerProblemPath = "/home/vi/github/first-party/src/nanomaptapir/problems/singlesearch/config";
  // std::string plannerConfig = "/home/vi/github/first-party/src/nanomaptapir/problems/singlesearch/config/default.cfg";
  std::string gymConfig = package_share_directory + "/config/gym/frustumSim/config.txt";
  std::string plannerProblemPath = package_share_directory + "/config/planner/singlesearch";
  std::string plannerConfig = package_share_directory + "/config/planner/singlesearch/default.cfg";
  //CREATE GYM INSTANCE
  nanomap::instance::GymInstance gymInstance(gymConfig);
  gymInstance.setObjectsOnPath(false);
  int environmentKnowledge = 1;
  float knowledgeRadius = 2.0;
  gymInstance.setEnvironmentKnowledge(environmentKnowledge, knowledgeRadius);
  gymInstance.createManager();
  gymInstance.createHandler();
  gymInstance.resetAgentByIndex(0);
  gymInstance.onAgentReset();

  Eigen::Vector3f rpy(0,0,0);
  Eigen::Vector3f xyz(0,0,0);

  Eigen::Array<float, 7, 1> poseAsFloat = gymInstance.getAgentPoseAsFloatByIndex(0);
  nanomap::Pose pose;
  std::cout << poseAsFloat(0) << " / " 
            << poseAsFloat(1) << " / " 
            << poseAsFloat(2) << " / " 
            << poseAsFloat(3) << " / " 
            << poseAsFloat(4) << " / " 
            << poseAsFloat(5) << " / " 
            << poseAsFloat(6) << " / " << std::endl; 
  pose.position.x() = poseAsFloat(0);
  pose.position.y() = poseAsFloat(1);
  pose.position.z() = poseAsFloat(2);
  pose.orientation.w() = poseAsFloat(3);
  pose.orientation.x() = poseAsFloat(4);
  pose.orientation.y() = poseAsFloat(5);
  pose.orientation.z()= poseAsFloat(6);

  //std::vector<nanomap::Pose> poses;
  gymInstance.updateAgentPose(0, pose);
  //Random map created, solved and agent spawned in with views calculated. 
  int clusterCount = gymInstance.plannerInstance()->plannerManager()->getClusterCount();
  std::vector<int> occupancy;
  occupancy.resize(clusterCount);
  int numRandomOccupiedClusters = 5;
  std::set<int> randomOccupiedClusters;
  while(randomOccupiedClusters.size() < 5){
    randomOccupiedClusters.insert(rand()%clusterCount);
  }
  //occupancy[rand()%clusterCount] = ;
  for(int occupiedCluster : randomOccupiedClusters){
    occupancy[occupiedCluster] = std::floor(std::sqrt(gymInstance.plannerInstance()->plannerManager()->getSafeCountForCluster(occupiedCluster)));
  }
  //DEFINE GRAPH SEARCH DEFINITION
  std::cout << "FinishedMapSolve, Beginning Planning" << std::endl;
  //Initialising tapir planner definition using planner info from nanomap plannermanager
  std::shared_ptr<nanomaptapir::planner::singlesearch::Definition> plannerDefinition
                  = std::make_shared<nanomaptapir::planner::singlesearch::Definition>();


  gymInstance.generateRandomTargetPositions(1);
  std::vector<Eigen::Vector3f> targetPositions = gymInstance.targetPositions();
  int targetCluster =  gymInstance.plannerInstance()->plannerManager()->getClusterFromPosition(targetPositions[0]); 
  occupancy[targetCluster] = std::floor(std::sqrt(gymInstance.plannerInstance()->plannerManager()->getSafeCountForCluster(targetCluster)));
  plannerDefinition->setPlannerManager(gymInstance.plannerInstance()->plannerManager());
  plannerDefinition->setCfgPath(plannerConfig);
  plannerDefinition->getClusterInfoFromManager();
  plannerDefinition->setInitialOccupancy(occupancy);
  //plannerDefinition->setUniformOccupancy();
  std::pair<int, int> initialPosition = gymInstance.plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose.position);
  plannerDefinition->setInitialPosition(initialPosition);

  nanomaptapir::planner::singlesearch::Interface  tapirInterface;
  std::vector<std::pair<int, std::vector<int>>> observationsSequence;
  std::vector<nanomaptapir::planner::singlesearch::Observation> observations;
  std::vector<std::pair<int,int>> actionSequence;

  //Creating the shared objects that ferry information between nodes. 
  std::tuple<int, int, int, std::vector<Eigen::Vector3f>> searchGoals;
  std::tuple<int, int, int, std::vector<Eigen::Vector3f>> transitGoals;
  std::vector<Eigen::Vector3f> currentGoals;
  currentGoals.resize(5);

  bool transitMode = false;
  bool searchMode = false;

  float maxGoalObsDist = 10.0;
  std::vector<float> maxVelocities;
  //Xforward
  maxVelocities.push_back(2.0);
  //Xbackward
  maxVelocities.push_back(0.75);
  //Yforward
  maxVelocities.push_back(0.75);
  //Ybackward
  maxVelocities.push_back(0.75);
  //Zforward
  maxVelocities.push_back(0.75);
  //Zbackward
  maxVelocities.push_back(0.75);
  //yaw right
  maxVelocities.push_back(0.5);
  //yaw left
  maxVelocities.push_back(0.5);

  //Initializing the tapir interface using the tapirDefinition we created earlier.
  tapirInterface.initialisePlanner(plannerDefinition, plannerProblemPath);

  //CREATE THE MULTITHREADED EXECUTOR
  rclcpp::executors::MultiThreadedExecutor executor;

  //VISUALIZATION NODES
  auto occupiedVoxelPubNode = std::make_shared<nanomap_ros::visualization::OpenVDBGridPublisher>(gymInstance.agentManager()->getAgentByIndex(0)->map()->occupiedGrid(),"OccupiedGrid", "occupied_grid_0");
  auto simGridPubNode = std::make_shared<nanomap_ros::visualization::OpenVDBGridPublisher>(gymInstance.getSimGrid(),"SimulatedGrid", "sim_grid");
  auto graphVisualizer = std::make_shared<nanomap_ros::visualization::GraphVisualizer>(gymInstance);
  auto boundaryVisualizer = std::make_shared<nanomap_ros::visualization::BoundaryVisualizer>(gymInstance, colorsObject);
  auto searchNodeVisualizer = std::make_shared<nanomap_ros::visualization::ClusterSearchNodeVisualizer>(gymInstance, colorsObject);
  auto agentPublisher = std::make_shared<nanomap_ros::visualization::AgentPublisher>(gymInstance);
  auto targetPublisher = std::make_shared<nanomap_ros::visualization::TargetPublisher>(gymInstance);
  auto framePublisher = std::make_shared<nanomap_ros::visualization::FramePublisher>(gymInstance, "agent0");
  //CONTROL NODES
  //Adding the tapir interface to a ros node for looping. 
  auto tapirLoop = std::make_shared<nanomap_ros::control::SingleAgentTapirNode>(tapirInterface, observationsSequence, actionSequence, observations);
  auto actionObservationNode = std::make_shared<nanomap_ros::control::ActionObservationNode>(gymInstance,plannerDefinition.get(),observationsSequence, actionSequence, searchGoals, transitGoals);
  auto macroManagerNode = std::make_shared<nanomap_ros::control::SingleMacroManagerNode>(gymInstance, searchGoals, transitGoals, xyz, rpy, transitMode, searchMode, currentGoals);
  auto searchPolicyClient = std::make_shared<nanomap_ros::control::SearchPolicyClient>("search_policy_query",
                                                                                        gymInstance,
                                                                                        xyz,
                                                                                        rpy,
                                                                                        searchMode,
                                                                                        currentGoals,
                                                                                        maxGoalObsDist,
                                                                                        maxVelocities);
  auto transitPolicyClient = std::make_shared<nanomap_ros::control::TransitPolicyClient>("transit_policy_query",
                                                                                        gymInstance,
                                                                                        xyz,
                                                                                        rpy,
                                                                                        transitMode,
                                                                                        currentGoals,
                                                                                        maxGoalObsDist,
                                                                                        maxVelocities);
  auto viewSimLoop = std::make_shared<nanomap_ros::control::ViewSimLoop>(gymInstance, "viewLoop");
  auto poseSimLoop = std::make_shared<nanomap_ros::control::PoseSimLoop>(gymInstance, xyz, rpy, "poseUpdateLoop");
  //ADDING NODES TO EXECUTOR
  executor.add_node(framePublisher);
  executor.add_node(agentPublisher);
  executor.add_node(targetPublisher);
  executor.add_node(occupiedVoxelPubNode);
  executor.add_node(simGridPubNode);
  executor.add_node(macroManagerNode);
  executor.add_node(searchNodeVisualizer);
  executor.add_node(boundaryVisualizer);
  executor.add_node(graphVisualizer);
  executor.add_node(tapirLoop);
  executor.add_node(actionObservationNode);

  executor.add_node(transitPolicyClient);
  executor.add_node(searchPolicyClient);
  executor.add_node(viewSimLoop);
  executor.add_node(poseSimLoop);
  std::cout << "spinning nodes" << std::endl;
  executor.spin();
  rclcpp::shutdown();
}
