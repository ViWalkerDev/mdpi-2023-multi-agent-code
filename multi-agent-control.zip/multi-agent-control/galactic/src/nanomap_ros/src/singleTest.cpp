#include "rclcpp/rclcpp.hpp"
#include "rclcpp/utilities.hpp"
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <thread>
#include <array>
#include <regex>
#include "openvdb/openvdb.h"
#include <openvdb/io/Stream.h>
#include "std_msgs/msg/string.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/point_stamped.hpp"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include "nanomap_msgs/msg/openvdb_grid.hpp"
#include "nanomap_msgs/msg/policy_observations.hpp"
#include "nanomap_msgs/srv/policy_query.hpp"

#include "nanomap/instance/GymInstance.h"
#include "nanomap/map/Map.h"
#include "nanomap/agent/Agent.h"
#include "nanomap/config/Config.h"
#include "nanomap/nanomap.h"
#include "nanomap/sensor/SensorData.h"

#include <Eigen/Geometry>
#include <Eigen/Core>
#include <Eigen/Dense>
#include "visualization_msgs/msg/marker.hpp"
#include "visualization_msgs/msg/marker_array.hpp"

#include "nanomap_ros/visualization/VisualizerNodes.hpp"
#include "nanomap_ros/control/ControlNodes.hpp"


#include "nanomaptapir/planner/problems/singlesearch/Definition.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Observation.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Action.hpp"
#include "nanomaptapir/planner/problems/singlesearch/Interface.hpp"

#include <ament_index_cpp/get_package_share_directory.hpp>

using Pose = nanomap::Pose;
using namespace std::chrono_literals;

std::string string_thread_id()
{
  auto hashed = std::hash<std::thread::id>()(std::this_thread::get_id());
  return std::to_string(hashed);
}

void readAgentConfig(std::string agentConfig, std::vector<nanomap::Pose>& agentStartPositions, std::vector<Eigen::Vector3f>& targetStartPositions){
  std::cout <<"reading in multiAgentConfig file: " << agentConfig << std::endl;
      std::ifstream *input = new std::ifstream(agentConfig.c_str(), std::ios::in | std::ios::binary);
      //bool end = false;
      std::string file, line;
      int nAgents, nTargets;
      float x,y,z, w, qx, qy, qz;
      *input >> line; // NumAgents
      *input >> nAgents;
      *input >> line; // Agent Positions
      for(int i = 0; i < nAgents; i++){
        *input >> x >> y >> z >> w >> qx >> qy >> qz;
        agentStartPositions.push_back(nanomap::Pose(Eigen::Vector3f(x,y,z),Eigen::Quaternionf(w, qx, qy, qz)));
      }
      *input >> line; // numTargets
      *input >> nTargets;
      *input >> line; //targetPositions
      for(int i = 0; i < nTargets; i++){
        *input >> x >> y >> z;
        targetStartPositions.push_back(Eigen::Vector3f(x,y,z));
      }
      //std::cout << line << std::endl;
}

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  openvdb::initialize();
  int seed = time(0);
  srand(seed);
  std::cout << seed << std::endl;
  std::vector<std::string> nonRosArgs = rclcpp::remove_ros_arguments(argc, argv);
  if(!(nonRosArgs.size() >= 3)){
    std::cout << "please provide sim type and search type" << std::endl;
    return 0;
  }

  int simType_ = std::stoi(argv[1]);
  int searchType_ = std::stoi(argv[2]);
  nanomap_ros::visualization::VisualizerColors colorsObject;
  std::string package_share_directory = ament_index_cpp::get_package_share_directory("nanomap_ros");
  // std::string gymConfig = "/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/config.txt";
  // std::string plannerProblemPath = "/home/vi/github/first-party/src/nanomaptapir/problems/singlesearch/config";
  // std::string plannerConfig = "/home/vi/github/first-party/src/nanomaptapir/problems/singlesearch/config/default.cfg";
    std::string agentConfig = package_share_directory + "/config/planner/singlesearch/agentConfig.cfg";
  std::string gymConfig = package_share_directory + "/config/gym/frustumSim/config.txt";
  std::string plannerProblemPath = package_share_directory + "/config/planner/singlesearch";
  std::string plannerConfig = package_share_directory + "/config/planner/singlesearch/default.cfg";
  
  //CREATE GYM INSTANCE
  nanomap::instance::GymInstance gymInstance(gymConfig);
  gymInstance.setObjectsOnPath(false);
  int environmentKnowledge = 1;
  float knowledgeRadius = 2.0;
  gymInstance.setEnvironmentKnowledge(environmentKnowledge, knowledgeRadius);
  gymInstance.createManager();
  gymInstance.createHandler();
  auto clusterGraph_ = gymInstance.plannerInstance()->plannerManager()->returnClusterGraph();
    std::vector<nanomap::Pose> agentStartPoses;
  std::vector<int> agentStartClusters;
  std::vector<Eigen::Vector3f> targetPositions;
  readAgentConfig(agentConfig, agentStartPoses, targetPositions);
  // gymInstance.resetAgentByIndex(0);
  // gymInstance.onAgentReset();

  Eigen::Vector3f rpy(0,0,0);
  Eigen::Vector3f xyz(0,0,0);

  //std::vector<nanomap::Pose> poses;
  gymInstance.updateAgentPose(0, agentStartPoses[0]);
  gymInstance.onAgentReset();
  //Random map created, solved and agent spawned in with views calculated. 
  // int clusterCount = gymInstance.plannerInstance()->plannerManager()->getClusterCount();
  // std::vector<int> occupancy;
  // occupancy.resize(clusterCount);
  // int numRandomOccupiedClusters = 5;
  // std::set<int> randomOccupiedClusters;
  // while(randomOccupiedClusters.size() < 5){
  //   randomOccupiedClusters.insert(rand()%clusterCount);
  // }
  // //occupancy[rand()%clusterCount] = ;
  // for(int occupiedCluster : randomOccupiedClusters){
  //   occupancy[occupiedCluster] = std::floor(std::sqrt(gymInstance.plannerInstance()->plannerManager()->getSafeCountForCluster(occupiedCluster)));
  // }
  //DEFINE GRAPH SEARCH DEFINITION
  std::cout << "FinishedMapSolve, Beginning Planning" << std::endl;
  //Initialising tapir planner definition using planner info from nanomap plannermanager
  std::shared_ptr<nanomaptapir::planner::singlesearch::Definition> plannerDefinition
                  = std::make_shared<nanomaptapir::planner::singlesearch::Definition>();


  gymInstance.setTargetPositions(targetPositions);
  // std::vector<Eigen::Vector3f> targetPositions = gymInstance.targetPositions();
  // int targetCluster =  gymInstance.plannerInstance()->plannerManager()->getClusterFromPosition(targetPositions[0]); 
  plannerDefinition->setPlannerManager(gymInstance.plannerInstance()->plannerManager());
  plannerDefinition->setCfgPath(plannerConfig);
  plannerDefinition->getClusterInfoFromManager();
  //plannerDefinition->setInitialOccupancy(occupancy);
  plannerDefinition->setUniformOccupancy();
  //plannerDefinition->setUniformOccupancy();
  std::pair<int, int> initialPosition = gymInstance.plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(agentStartPoses[0].position);
  plannerDefinition->setInitialPosition(initialPosition);

  nanomaptapir::planner::singlesearch::Interface  tapirInterface;
  std::vector<std::pair<int, std::vector<int>>> observationsSequence;
  std::vector<nanomaptapir::planner::singlesearch::Observation> observations;
  std::vector<std::pair<int,int>> actionSequence;

  //Creating the shared objects that ferry information between nodes. 
  std::tuple<int, int, int, std::vector<Eigen::Vector3f>> searchGoals;
  std::tuple<int, int, int, std::vector<Eigen::Vector3f>> transitGoals;
  std::vector<Eigen::Vector3f> currentGoals;
  currentGoals.resize(5);
  bool transitMode = false;
  bool searchMode = false;
      float maxGoalObsDist = 10.0;
      std::vector<float> maxVelocities;
      //Xforward
      maxVelocities.push_back(2.0);
      //Xbackward
      maxVelocities.push_back(0.75);
      //Yforward
      maxVelocities.push_back(0.75);
      //Ybackward
      maxVelocities.push_back(0.75);
      //Zforward
      maxVelocities.push_back(0.75);
      //Zbackward
      maxVelocities.push_back(0.75);
      //yaw right
      maxVelocities.push_back(1.0);
      //yaw left
      maxVelocities.push_back(1.0);

  //Initializing the tapir interface using the tapirDefinition we created earlier.
  tapirInterface.initialisePlanner(plannerDefinition, plannerProblemPath);

  //CREATE THE MULTITHREADED EXECUTOR
  rclcpp::executors::MultiThreadedExecutor executor;

  //VISUALIZATION NODES
  auto occupiedVoxelPubNode = std::make_shared<nanomap_ros::visualization::OpenVDBGridPublisher>(
                                                          gymInstance.agentManager()->getAgentByIndex(0)->map()->occupiedGrid(),
                                                          "Agent_0_OccupiedGrid_node", 
                                                          "Agent_0_OccupiedGrid");
  //auto simGridPubNode = std::make_shared<nanomap_ros::visualization::OpenVDBGridPublisher>(gymInstance.getSimGrid(),"SimulatedGrid", "sim_grid");
  auto graphVisualizer = std::make_shared<nanomap_ros::visualization::GraphVisualizer>(gymInstance);
  auto boundaryVisualizer = std::make_shared<nanomap_ros::visualization::BoundaryVisualizer>(gymInstance, colorsObject);
  auto framePublisher = std::make_shared<nanomap_ros::visualization::FramePublisher>(gymInstance, "agent_0");
          
  //auto searchNodeVisualizer = std::make_shared<nanomap_ros::visualization::ClusterSearchNodeVisualizer>(gymInstance, colorsObject);
  //auto agentPublisher = std::make_shared<nanomap_ros::visualization::AgentPublisher>(gymInstance);
  //auto targetPublisher = std::make_shared<nanomap_ros::visualization::TargetPublisher>(gymInstance);

  //CONTROL NODES
  //Adding the tapir interface to a ros node for looping. 
  auto tapirLoop = std::make_shared<nanomap_ros::control::SingleAgentTapirNode>(tapirInterface, observationsSequence, actionSequence, observations);
  auto actionObservationNode = std::make_shared<nanomap_ros::control::ActionObservationNode>(gymInstance,plannerDefinition.get(),observationsSequence, actionSequence, searchGoals, transitGoals);
  auto macroManagerNode = std::make_shared<nanomap_ros::control::SingleMacroManagerNode>(simType_, searchType_, gymInstance, searchGoals, transitGoals, xyz, rpy, transitMode, searchMode, currentGoals);
  auto completionCheck = std::make_shared<nanomap_ros::control::CompletionCheck>(plannerDefinition.get(), observationsSequence, actionSequence);
  std::string searchQueryTopic = "agent_0_search_policy_query";
  std::string transitQueryTopic = "agent_0_transit_policy_query";
  auto searchPolicyClient = std::make_shared<nanomap_ros::control::SearchPolicyClient>(searchQueryTopic,
                                                                                                gymInstance,
                                                                                                xyz,
                                                                                                rpy,
                                                                                                searchMode,
                                                                                                currentGoals,
                                                                                                maxGoalObsDist,
                                                                                                maxVelocities);
  auto transitPolicyClient = std::make_shared<nanomap_ros::control::TransitPolicyClient>(transitQueryTopic,
                                                                                        gymInstance,
                                                                                        xyz,
                                                                                        rpy,
                                                                                        transitMode,
                                                                                        currentGoals,
                                                                                        maxGoalObsDist,
                                                                                        maxVelocities);
   auto viewSimLoop = std::make_shared<nanomap_ros::control::ViewSimLoop>(gymInstance, "agent_0_view_loop");
   auto poseSimLoop = std::make_shared<nanomap_ros::control::PoseSimLoop>(gymInstance, xyz, rpy, "agent_0_pose_loop");

  //ADDING NODES TO EXECUTOR
  if(simType_ == 0){
    executor.add_node(searchPolicyClient);
    executor.add_node(transitPolicyClient);
    executor.add_node(viewSimLoop);
    executor.add_node(poseSimLoop);
  }
  //executor.add_node(agentPublisher);
  //executor.add_node(targetPublisher);
  executor.add_node(framePublisher);
  executor.add_node(completionCheck);
  executor.add_node(occupiedVoxelPubNode);
  //executor.add_node(simGridPubNode);
  executor.add_node(macroManagerNode);
  //executor.add_node(searchNodeVisualizer);
  executor.add_node(boundaryVisualizer);
  executor.add_node(graphVisualizer);
  executor.add_node(tapirLoop);
  executor.add_node(actionObservationNode);
  std::cout << "spinning nodes" << std::endl;
  executor.spin();
  rclcpp::shutdown();
}
