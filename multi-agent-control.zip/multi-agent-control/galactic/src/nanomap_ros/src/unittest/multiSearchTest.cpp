#include "rclcpp/rclcpp.hpp"
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <thread>
#include <array>
#include <regex>
#include "openvdb/openvdb.h"
#include <openvdb/io/Stream.h>
#include "std_msgs/msg/string.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/point_stamped.hpp"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include "nanomap_msgs/msg/openvdb_grid.hpp"
#include "nanomap_msgs/msg/policy_observations.hpp"
#include "nanomap_msgs/srv/policy_query.hpp"

#include "nanomap/instance/GymInstance.h"
#include "nanomap/map/Map.h"
#include "nanomap/agent/Agent.h"
#include "nanomap/config/Config.h"
#include "nanomap/nanomap.h"
#include "nanomap/sensor/SensorData.h"

#include <Eigen/Geometry>
#include <Eigen/Core>
#include <Eigen/Dense>
#include "visualization_msgs/msg/marker.hpp"
#include "visualization_msgs/msg/marker_array.hpp"

#include "nanomaptapir/planner/problems/boundarysearch/BoundarySearchDefinition.hpp"
#include "nanomaptapir/planner/problems/boundarysearch/BoundarySearchObservation.hpp"
#include "nanomaptapir/planner/problems/boundarysearch/BoundarySearchAction.hpp"
#include "nanomaptapir/planner/problems/boundarysearch/BoundarySearchInterface.hpp"

using Pose = nanomap::Pose;
using namespace std::chrono_literals;

std::string string_thread_id()
{
  auto hashed = std::hash<std::thread::id>()(std::this_thread::get_id());
  return std::to_string(hashed);
}


class LeafPublisherNode : public rclcpp::Node
{
public:
  LeafPublisherNode(openvdb::FloatGrid::Ptr grid, std::string node_name)
  : Node(node_name), count_(0) , grid_(grid)
  {
    std::string topic = grid_->getName();
    publisher_ = this->create_publisher<nanomap_msgs::msg::OpenvdbGrid>(topic, 10);
    auto timer_callback =
      [this]() -> void {
        auto curr_thread = string_thread_id();
        msg_.header.frame_id = "world";
        msg_.header.stamp = now();
        std::ostringstream ostr(std::ios_base::binary);
        openvdb::GridPtrVecPtr grids(new openvdb::GridPtrVec);
        gridCopy_ = grid_->deepCopy();
        grids->push_back(gridCopy_);
        openvdb::io::Stream(ostr).write(*grids);
        int size = ostr.str().size();
        msg_.size = size;
        msg_.data.resize(size);
        std::memcpy(msg_.data.data(), reinterpret_cast<unsigned char*>(const_cast<char*>(ostr.str().c_str())), size);
        gridCopy_->clear();
        this->publisher_->publish(msg_);
      };
    timer_ = this->create_wall_timer(500ms, timer_callback);
  }


private:
  nanomap_msgs::msg::OpenvdbGrid msg_;
  openvdb::FloatGrid::Ptr grid_;
  openvdb::FloatGrid::Ptr gridCopy_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<nanomap_msgs::msg::OpenvdbGrid>::SharedPtr publisher_;
  size_t count_;
};

class GraphVisualizer : public rclcpp::Node
{
public:
  GraphVisualizer(nanomap::instance::GymInstance& gymInstance)
  : Node("graph_visualizer"), count_(0), gymInstance_(&gymInstance)
  {
    std::string topic = "graph_visualizer";
    publisher_ = this->create_publisher<visualization_msgs::msg::Marker>(topic, 10);

    //(&distanceArray[0], distanceArray.data()+distanceArray.size());
    //distanceData.resize(distanceArray.size());
    //Eigen::Map<float>(distanceData.data(), distanceData.size()) = distanceArray;
    auto timer_callback =
      [this]() -> void {
      //std::vector<visualization_msgs::msg::Marker> markerVector;
      // for(int boundaryPair){
      //   std::
      
      // }
      int id = 0; 
      // for(int x = 0; x < 3; x++){
      //   for(int y = 0; y < 3; y++){
      //     for int z = 0; z < 3; z++{
          
          rclcpp::Time now = this->get_clock()->now();
            marker.header.frame_id = "world";
            marker.header.stamp = now;
            marker.id = id;
            id++;
            marker.type = visualization_msgs::msg::Marker::LINE_LIST;
            marker.action = visualization_msgs::msg::Marker::ADD;
            std::vector<geometry_msgs::msg::Point> pointsVector;
            //std::vector<geometry_msgs::msgs::Point> points2Vector;
            
            std::vector<Eigen::Vector3f> boundaryLines = gymInstance_->plannerInstance()->plannerManager()->getBoundaryLinesFromGraph();
            for(int point = 0; point < int(boundaryLines.size()); point+=2){
              geometry_msgs::msg::Point startPoint;
              geometry_msgs::msg::Point endPoint;
              
              //startPoint.header.frame_id = "world";
              //endPoint.header.frame_id = "world";
              //std::cout << "goalObs " << goalObs(0) << " / " << goalObs(1) << " / " << goalObs(2) << std::endl;
              startPoint.x = boundaryLines[point].x();
              startPoint.y = boundaryLines[point].y();
              startPoint.z = boundaryLines[point].z();
              // < " / " << goalObs(1) << " / " << goalObs(2) << std::endl;
              endPoint.x = boundaryLines[point+1].x();
              endPoint.y = boundaryLines[point+1].y();
              endPoint.z = boundaryLines[point+1].z();
              pointsVector.push_back(startPoint);
              pointsVector.push_back(endPoint);
            }
            marker.scale.z = 0.1;
            marker.scale.y = 0.1;
            marker.scale.x = 0.1;
            marker.points = pointsVector;
            marker.color.a = 1.0;
            marker.color.r = 0.0;
            marker.color.g = 1.0;
            marker.color.b = 0.0;
            //marker.lifetime = 1000ms; 
      //     }
      //   }
      // }

      // Eigen::ArrayXf goalArray = gymInstance_->getGoalObservationsByIndex(0);
      // Eigen::ArrayXf distanceArray = gymInstance_->getObservationsByIndex(0);
      // std::vector<float> goalData;
      // for(int x = 0; x < goalArray.size(); x++){
      //   goalData.push_back(goalArray(x));
      // }
      // //goalData.resize(goalArray.size());
      // //Eigen::Map<float>(goalData.data(), goalData.size()) = goalArray;//(&goalArray[0], goalArray.data()+goalArray.size());
      // std::vector<float> distanceData;
      // for(int x = 0; x<distanceArray.size(); x++){
      //   distanceData.push_back(distanceArray(x));
      // }
      // msg_.header.stamp = now();
      // msg_.goaldatasize = goalData.size();
      // msg_.distancedatasize = distanceData.size();
      // msg_.goaldata = goalData;
      // msg_.distancedata = distanceData;
      //msg_.markers = markerVector;
      this->publisher_->publish(marker);
      };
    timer_ = this->create_wall_timer(20ms, timer_callback);
  }

private:
  nanomap::instance::GymInstance* gymInstance_;
  visualization_msgs::msg::Marker marker;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<visualization_msgs::msg::Marker>::SharedPtr publisher_;
  size_t count_;
};

class BoundaryVisualizer : public rclcpp::Node
{
public:
  BoundaryVisualizer(nanomap::instance::GymInstance& gymInstance, std::vector<std::array<int,3>>& rgbColors)
  : Node("boundary_node_visualizer"), count_(0), gymInstance_(&gymInstance), rgbColors_(&rgbColors)
  {

    
    std::string topic = "boundary_node_visualizer";
    publisher_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(topic, 10);

    //(&distanceArray[0], distanceArray.data()+distanceArray.size());
    //distanceData.resize(distanceArray.size());
    //Eigen::Map<float>(distanceData.data(), distanceData.size()) = distanceArray;
    auto timer_callback =
      [this]() -> void {
      //std::vector<visualization_msgs::msg::Marker> markerVector;
      // for(int boundaryPair){
      //   std::
      
      // }
          int id = 0; 
      // for(int x = 0; x < 3; x++){
      //   for(int y = 0; y < 3; y++){
      //     for int z = 0; z < 3; z++{
          std::vector<visualization_msgs::msg::Marker> markerVector;
          rclcpp::Time now = this->get_clock()->now();
            // visualization_msgs::msg:Marker marker;
            // marker.header.frame_id = "world";
            // marker.header.stamp = now;
            // marker.id = id;
            // id++;
            // marker.type = visualization_msgs::msg::Marker::POINTS;
            // marker.action = visualization_msgs::msg::Marker::ADD;
            //std::vector<geometry_msgs::msgs::Point> points2Vector;
            
            std::vector<std::vector<Eigen::Vector3f>> boundaryPoints = gymInstance_->plannerInstance()->plannerManager()->getBoundaryPointsFromGraph();
            for(int clusterIndex = 0; clusterIndex < boundaryPoints.size(); clusterIndex++){
              visualization_msgs::msg::Marker marker;
              marker.header.frame_id = "world";
              marker.header.stamp = now;
              marker.id = id;
              id++;
              marker.type = visualization_msgs::msg::Marker::POINTS;
              marker.action = visualization_msgs::msg::Marker::ADD;
              marker.scale.x = 0.8;
              marker.scale.y = 0.8;
              marker.color.a = 1.0;
              marker.color.r = (float)((*rgbColors_)[clusterIndex][0]);
              marker.color.g = (float)((*rgbColors_)[clusterIndex][1]);
              marker.color.b = (float)((*rgbColors_)[clusterIndex][2]);
              std::vector<geometry_msgs::msg::Point> pointsVector;
              for(int boundaryIndex = 0; boundaryIndex < boundaryPoints[clusterIndex].size(); boundaryIndex++){
                geometry_msgs::msg::Point point;
                point.x = boundaryPoints[clusterIndex][boundaryIndex].x();
                point.y = boundaryPoints[clusterIndex][boundaryIndex].y();
                point.z = boundaryPoints[clusterIndex][boundaryIndex].z();
                pointsVector.push_back(point);
              }
              marker.points = pointsVector;
              markerVector.push_back(marker);
            }
            markerArray_.markers=markerVector;
            //marker.lifetime = 1000ms; 
      //     }
      //   }
      // }

      // Eigen::ArrayXf goalArray = gymInstance_->getGoalObservationsByIndex(0);
      // Eigen::ArrayXf distanceArray = gymInstance_->getObservationsByIndex(0);
      // std::vector<float> goalData;
      // for(int x = 0; x < goalArray.size(); x++){
      //   goalData.push_back(goalArray(x));
      // }
      // //goalData.resize(goalArray.size());
      // //Eigen::Map<float>(goalData.data(), goalData.size()) = goalArray;//(&goalArray[0], goalArray.data()+goalArray.size());
      // std::vector<float> distanceData;
      // for(int x = 0; x<distanceArray.size(); x++){
      //   distanceData.push_back(distanceArray(x));
      // }
      // msg_.header.stamp = now();
      // msg_.goaldatasize = goalData.size();
      // msg_.distancedatasize = distanceData.size();
      // msg_.goaldata = goalData;
      // msg_.distancedata = distanceData;
      //msg_.markers = markerVector;
      this->publisher_->publish(markerArray_);
      };
    timer_ = this->create_wall_timer(1000ms, timer_callback);
  }

private:
  nanomap::instance::GymInstance* gymInstance_;
  std::vector<std::array<int, 3>>* rgbColors_;
  visualization_msgs::msg::MarkerArray markerArray_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr publisher_;
  size_t count_;
};

class ClusterSearchNodeVisualizer : public rclcpp::Node
{
public:
  ClusterSearchNodeVisualizer(nanomap::instance::GymInstance& gymInstance, std::vector<std::array<int,3>>& rgbColors)
  : Node("cluster_node_visualizer"), count_(0), gymInstance_(&gymInstance), rgbColors_(&rgbColors)
  {

    
    std::string topic = "cluster_node_visualizer";
    publisher_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(topic, 10);

    //(&distanceArray[0], distanceArray.data()+distanceArray.size());
    //distanceData.resize(distanceArray.size());
    //Eigen::Map<float>(distanceData.data(), distanceData.size()) = distanceArray;
    auto timer_callback =
      [this]() -> void {
      //std::vector<visualization_msgs::msg::Marker> markerVector;
      // for(int boundaryPair){
      //   std::
      
      // }
          int id = 0; 
      // for(int x = 0; x < 3; x++){
      //   for(int y = 0; y < 3; y++){
      //     for int z = 0; z < 3; z++{
          std::vector<visualization_msgs::msg::Marker> markerVector;
          rclcpp::Time now = this->get_clock()->now();
            // visualization_msgs::msg:Marker marker;
            // marker.header.frame_id = "world";
            // marker.header.stamp = now;
            // marker.id = id;
            // id++;
            // marker.type = visualization_msgs::msg::Marker::POINTS;
            // marker.action = visualization_msgs::msg::Marker::ADD;
            //std::vector<geometry_msgs::msgs::Point> points2Vector;
            //std::cout << "WHAT IS HAPPENING " << std::endl;
            //std::vector<std::vector<Eigen::Vector3f>> clusterSearchTargets = gymInstance_->plannerInstance()->plannerManager()->getBoundaryPointsFromGraph();
            for(int clusterIndex = 0; clusterIndex < gymInstance_->plannerInstance()->plannerManager()->getClusterCount(); clusterIndex++){
              //std::cout << "tryting to get serach targets" << std::endl;
              std::vector<Eigen::Vector3f> clusterSearchTargets = gymInstance_->plannerInstance()->plannerManager()->getClusterSearchNodesInWorld(clusterIndex);
              //std::vector<Eigen::Vector3f> clusterSearchTargets;
              //clusterSearchTargets.push_back(Eigen::Vector3f(1.0,1.0,1.0));
              // std::cout << "success " << std::endl;
              // std::cout << "success " << std::endl;
              // std::cout << "success " << std::endl;
              // std::cout << "success " << std::endl;
              // std::cout << "success " << std::endl;
              // std::cout << "success " << std::endl;
              // std::cout << "what " << std::endl;
              // std::cout << "clusterSearchTargetsSize " << clusterSearchTargets.size();
              visualization_msgs::msg::Marker marker;
              marker.header.frame_id = "world";
              marker.header.stamp = now;
              marker.id = id;
              id++;
              marker.type = visualization_msgs::msg::Marker::POINTS;
              marker.action = visualization_msgs::msg::Marker::ADD;
              marker.scale.x = 0.8;
              marker.scale.y = 0.8;
              marker.color.a = 1.0;
              marker.color.r = (float)((*rgbColors_)[clusterIndex][0]);
              marker.color.g = (float)((*rgbColors_)[clusterIndex][1]);
              marker.color.b = (float)((*rgbColors_)[clusterIndex][2]);
              std::vector<geometry_msgs::msg::Point> pointsVector;
              for(int targetIndex = 0; targetIndex < clusterSearchTargets.size(); targetIndex++){
                geometry_msgs::msg::Point point;
                // if(clusterSearchTargets[targetIndex].x() == 0.0 && clusterSearchTargets[targetIndex].y() == 0.0 && clusterSearchTargets[targetIndex].z() == 0.0){
                //   std::cout << "zero cluster at clusterIndex " << clusterIndex << std::endl;
                // }else{
                  point.x = clusterSearchTargets[targetIndex].x();
                  point.y = clusterSearchTargets[targetIndex].y();
                  point.z = clusterSearchTargets[targetIndex].z();
                  pointsVector.push_back(point);
                // }
              }
              if(pointsVector.size() > 0){
              marker.points = pointsVector;
              markerVector.push_back(marker);
              }
            }
            if(markerVector.size()>0){
              markerArray_.markers=markerVector;
              this->publisher_->publish(markerArray_);
            }
            //marker.lifetime = 1000ms; 
      //     }
      //   }
      // }

      // Eigen::ArrayXf goalArray = gymInstance_->getGoalObservationsByIndex(0);
      // Eigen::ArrayXf distanceArray = gymInstance_->getObservationsByIndex(0);
      // std::vector<float> goalData;
      // for(int x = 0; x < goalArray.size(); x++){
      //   goalData.push_back(goalArray(x));
      // }
      // //goalData.resize(goalArray.size());
      // //Eigen::Map<float>(goalData.data(), goalData.size()) = goalArray;//(&goalArray[0], goalArray.data()+goalArray.size());
      // std::vector<float> distanceData;
      // for(int x = 0; x<distanceArray.size(); x++){
      //   distanceData.push_back(distanceArray(x));
      // }
      // msg_.header.stamp = now();
      // msg_.goaldatasize = goalData.size();
      // msg_.distancedatasize = distanceData.size();
      // msg_.goaldata = goalData;
      // msg_.distancedata = distanceData;
      //msg_.markers = markerVector;
      
      };
    timer_ = this->create_wall_timer(1000ms, timer_callback);
  }

private:
  nanomap::instance::GymInstance* gymInstance_;
  std::vector<std::array<int, 3>>* rgbColors_;
  visualization_msgs::msg::MarkerArray markerArray_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr publisher_;
  size_t count_;
};


class MacroManagerNode : public rclcpp::Node
{
public:
  MacroManagerNode(nanomap::instance::GymInstance& gymInstance,
                std::tuple<int, int, std::vector<Eigen::Vector3f>>& searchGoals,
                std::tuple<int, int, std::vector<Eigen::Vector3f>>& transitGoals,
                Eigen::Vector3f &xyz, Eigen::Vector3f &rpy, bool& transitMode, bool& searchMode, std::array<Eigen::Vector3f, 2>& currentGoals)
  : Node("MacroManagerNode"), count_(0), gymInstance_(&gymInstance),
        searchGoals_(&searchGoals), transitGoals_(&transitGoals), xyz_(&xyz), rpy_(&rpy), 
        searchMode_(&searchMode), transitMode_(&transitMode), currentGoals_(&currentGoals)
  {
    poseAsFloat_ = gymInstance_->getAgentPoseAsFloatByIndex(0);
    pose_.position.x() = poseAsFloat_(0);
    pose_.position.y() = poseAsFloat_(1);
    pose_.position.z() = poseAsFloat_(2);
    std::tie(currentCluster_, currentBoundary_) = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose_.position);
    goalExists_ = false;
    isSearchGoal_ = false;
    isGoalComplete_ = false;
    currentGoalIndex_ = 0;
    std::string topic = "MacroManagerNode";
    auto timer_callback =
      [this]() -> void {
        poseAsFloat_ = gymInstance_->getAgentPoseAsFloatByIndex(0);
        pose_.position.x() = poseAsFloat_(0);
        pose_.position.y() = poseAsFloat_(1);
        pose_.position.z() = poseAsFloat_(2);
        std::tie(currentCluster_, currentBoundary_) = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose_.position);
        
        // if(searchMode_ == 0 && transitMode_ == 0){
        //     (*xyz_).x() = 0.0;
        //     (*xyz_).y() = 0.0;
        //     (*xyz_).z() = 0.0;
        //     (*rpy_).x() = 0.0;
        //     (*rpy_).y() = 0.0;
        //     (*rpy_).z() = 0.0;
        // }

        if(!goalExists_){
          if(std::get<0>(*searchGoals_)>0){
          //We are performing search routine
            goalExists_ = true;
            std::vector<Eigen::Vector3f> goals = std::get<2>(*searchGoals_);
            float dist = FLT_MAX;
            int closestGoalIndex = -1;
            int goalIndex = 0;
            for(auto goalPos : goals){
              float goalDist = gymInstance_->plannerInstance()->plannerManager()->getDistanceBetweenPositions(pose_.position, goalPos);
              if(goalDist < dist){
                dist = goalDist;
                closestGoalIndex = goalIndex;
              }
              goalIndex++;
            }
            currentGoalIndex_ = closestGoalIndex;
            (*currentGoals_)[0] = goals[currentGoalIndex_];
            (*currentGoals_)[1] = goals[currentGoalIndex_];
            isSearchGoal_ = true;
            *searchMode_ = true;
            *transitMode_ = false;
          }else if(std::get<0>(*transitGoals_)>0){
          currentGoalIndex_ = 0;
          //We are performing transit routine.
          goalExists_ = true; 
          std::vector<Eigen::Vector3f> goals= std::get<2>(*transitGoals_);
          (*currentGoals_)[0] = goals[0];
          if(std::get<0>(*transitGoals_)>1){
            (*currentGoals_)[1] = goals[1];
          }else{
            (*currentGoals_)[1] = goals[1]; 
          }
          // std::cout << std::get<0>(*transitGoals_)<< std::endl;
          // std::cout << std::get<1>(*transitGoals_) << std::endl;
          // std::cout << std::get<2>(*transitGoals_)[0].x() << std::endl;
          // std::cout << "newPosition = " << pose_.position.x() << " / " << pose_.position.y() << " / " << pose_.position.z() << " nextGoalLocationsAre " 
          //    << (*currentGoals_)[0].x() << " / " << (*currentGoals_)[0].y() << " / " << (*currentGoals_)[0].z() << " and " 
          //    << (*currentGoals_)[1].x() << " / " << (*currentGoals_)[1].y() << " / " << (*currentGoals_)[1].z() << std::endl; 
          isSearchGoal_ = false;
          *transitMode_ = true;
          *searchMode_ = false;
          }
        }

        if(goalExists_){
          //We already have a goal. first check if that goal is completed
          //If it isn't completed command the agent to complete the goal. 
          if(isSearchGoal_){
            //we check to see if the search goal is complete. 

            if(testCounter_ > 10){
              pose_.position = (*currentGoals_)[0];
              gymInstance_->updateAgentPose(0, pose_);
              gymInstance_->simulateAgentSearch(0, (*currentGoals_)[0]);
              testCounter_ = 0;
              //isGoalComplete_ = true;
            }
            //std::cout <<(*currentGoals_)[0].x() << " / " <<(*currentGoals_)[0].y() <<" / " << (*currentGoals_)[0].z() << std::endl;
            Eigen::Vector3f position;
            position(0) = (*currentGoals_)[0].x();
            position(1) = (*currentGoals_)[0].y();
            position(2) = (*currentGoals_)[0].z();
            bool what = gymInstance_->getSearchComplete(0, position);
            isGoalComplete_ = what;
            if(isGoalComplete_){
              //the search of the current search goal is complete! 
              std::get<0>(*searchGoals_) -= 1;
              //Update the list of search goals, removing the one just completed.
              std::get<2>(*searchGoals_).erase(std::get<2>(*searchGoals_).begin()+currentGoalIndex_);
              //now check if the entire search is completed!
              if(std::get<0>(*searchGoals_) <= 0){
                //Search is completed!
                //bool isTargetFound = gymInstance->isTargetFound(0);
                bool isTargetFound = false;
                if(gymInstance_->isTargetLocalToAgentCluster(0,0)){
                  isTargetFound = true;
                }
                std::get<1>(*searchGoals_) = isTargetFound;
                goalExists_ = false;
                currentGoalIndex_ = 0;
                //We now have to wait for the next action. so lets set out velocity to 0
                // (*xyz_).x() = 0.0;
                // (*xyz_).y() = 0.0;
                // (*xyz_).z() = 0.0;
                // (*rpy_).x() = 0.0;
                // (*rpy_).y() = 0.0;
                // (*rpy_).z() = 0.0;
              }else{
                //We still have more nodes to search!
                std::vector<Eigen::Vector3f> goals = std::get<2>(*searchGoals_);
                float dist = FLT_MAX;
                int closestGoalIndex = -1;
                int goalIndex = 0;
                for(auto goalPos : goals){
                  float goalDist = gymInstance_->plannerInstance()->plannerManager()->getDistanceBetweenPositions(pose_.position, goalPos);
                  if(goalDist < dist){
                    dist = goalDist;
                    closestGoalIndex = goalIndex;
                  }
                  goalIndex++;
                }
                currentGoalIndex_ = closestGoalIndex;
                (*currentGoals_)[0] = goals[currentGoalIndex_];
                (*currentGoals_)[1] = goals[currentGoalIndex_];
              }
            }
          }
          if(!isSearchGoal_){
            if(testCounter_>10){
              //isGoalComplete_ = true;
              pose_.position = (*currentGoals_)[0];
              gymInstance_->updateAgentPose(0, pose_);
              testCounter_ = 0;
            }
            Eigen::Vector3f positionDelta = pose_.position - (*currentGoals_)[0];
            if(std::abs(positionDelta(0)) < 0.1 && 
                  std::abs(positionDelta(1)) < 0.1 &&
                      std::abs(positionDelta(2)) < 0.1){
              isGoalComplete_ = true;
            }
            if(isGoalComplete_){
              std::vector<Eigen::Vector3f> goals = std::get<2>(*transitGoals_);
              //The current transit goal has been met.
              std::get<1>(*transitGoals_)+=1;
              currentGoalIndex_+=1;
              if(std::get<1>(*transitGoals_)>=std::get<0>(*transitGoals_)){
                //we reached the last goal in the series.
                //Set first entry to 0 to signal planner to get new action. 
                std::get<0>(*transitGoals_) = 0;
                goalExists_ = false;
                currentGoalIndex_ = 0;
              }else{
                (*currentGoals_)[0] = goals[currentGoalIndex_];
                if(std::get<0>(*transitGoals_)-2 <=std::get<1>(*transitGoals_)){
                  //We are on the last goal in teh series
                  (*currentGoals_)[1] = goals[currentGoalIndex_];
                }else{
                  (*currentGoals_)[1] = goals[currentGoalIndex_+1];
                }
              }
              // std::cout << std::get<0>(*transitGoals_)<< std::endl;
              // std::cout << std::get<1>(*transitGoals_) << std::endl;
              // std::cout << std::get<2>(*transitGoals_)[0].x() << std::endl; 
            // std::cout << "newPosition = " << pose_.position.x() << " / " << pose_.position.y() << " / " << pose_.position.z() << " nextGoalLocationsAre " 
            //  << (*currentGoals_)[0].x() << " / " << (*currentGoals_)[0].y() << " / " << (*currentGoals_)[0].z() << " and " 
            //  << (*currentGoals_)[1].x() << " / " << (*currentGoals_)[1].y() << " / " << (*currentGoals_)[1].z() << std::endl; 
              // for(int x = 0; x < goals.size(); x++){
              //   std::cout << goals[x].x() << " / " << goals[x].y() << " / " << goals[x].z() << std::endl;
              // }
            }
          }
          testCounter_++;
          isGoalComplete_ = false;
        }
        
      };
    timer_ = this->create_wall_timer(100ms, timer_callback);
  }
private:
  int targetCluster_ = 0;
  nanomap::instance::GymInstance* gymInstance_;
  //nanomaptapir::planner::boundarysearch::BoundarySearchDefinition* definition_;
  std::tuple<int, int, std::vector<Eigen::Vector3f>>* transitGoals_;
  std::tuple<int, int, std::vector<Eigen::Vector3f>>* searchGoals_;
  int currentCluster_;
  int currentBoundary_;
  int currentGoalIndex_;
  bool isSearchGoal_;
  bool isGoalComplete_;
  bool goalExists_;
  bool* searchMode_;
  bool* transitMode_;
  int testCounter_ = 0;
  Eigen::Vector3f* xyz_;
  Eigen::Vector3f* rpy_;
  Eigen::Array<float, 7, 1> poseAsFloat_;
  nanomap::Pose pose_;
  std::array<Eigen::Vector3f, 2>* currentGoals_;
  
  rclcpp::TimerBase::SharedPtr timer_;
  size_t count_;
};

//TODO integrate observations into a specific planner manager object maybe? or a specific nanomaptapir object that we update with planner manager?
//For now we are on time crunch, keep it simple.
//Might need gymInstance for ease of data retrieval later, maybe just work with the observations stuff for now and keep tapir interface isolated 
//observation sequences is a vector of observations. with observations being a pair with an int-id, and a vector of int based observations.
class ActionObservationNode : public rclcpp::Node
{
public:
  ActionObservationNode(nanomap::instance::GymInstance& gymInstance,
                        nanomaptapir::planner::boundarysearch::BoundarySearchDefinition* definition,
                  std::vector<std::pair<int, std::vector<int>>>&            observationsSequence,
                std::vector<std::pair<int, int>>&                                                actionSequence,
                std::tuple<int, int, std::vector<Eigen::Vector3f>>& searchGoals,
                std::tuple<int, int, std::vector<Eigen::Vector3f>>& transitGoals)
  : Node("actionObsNode"), count_(0), gymInstance_(&gymInstance), definition_(definition), 
        observationsSequence_(&observationsSequence), actionSequence_(&actionSequence),
        searchGoals_(&searchGoals), transitGoals_(&transitGoals)
  {

    currentObservation_ = 0;
    actionPending_ = false;
    actionComplete_ = false;
    actionId_ = 0;
    std::string topic = "actionObsNode";
    auto timer_callback =
      [this]() -> void {
        std::vector<int> obsVec;
        if(actionSequence_->size() > 0){
          std::pair<int, int> latestAction = actionSequence_->back();

          if(latestAction.first >= actionId_){
                      std::cout << "latestActionId = " << latestAction.first << "actionId = " << actionId_ << std::endl;
            //New action
            if(latestAction.second == 0){
              
              //getsearchgoal gets the search goals for the current agent in its current cluster. 
              *searchGoals_ = gymInstance_->getSearchGoalsForAgentByIndex(0);
              mode_ = 0;
            }else{
               Eigen::Array<float, 7, 1> poseAsFloat = gymInstance_->getAgentPoseAsFloatByIndex(0);
              nanomap::Pose pose;
              pose.position.x() = poseAsFloat(0);
              pose.position.y() = poseAsFloat(1);
              pose.position.z() = poseAsFloat(2);
              std::tie(currentCluster_, currentBoundary_) = gymInstance_->plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose.position);
              std::cout << "current Cluster " << currentCluster_  << std::endl;
              //getTransitGoalForindexAndtargetCluster
              //gets the goal locations for the transit from the agents current position to the provided cluster
              int targetCluster = definition_->getClusterMove(currentCluster_, currentBoundary_, latestAction.second).first.first;
              std::cout << " targetCluster " << targetCluster << std::endl;
              *transitGoals_ = gymInstance_->getTransitGoalsForClusterByIndex(0,targetCluster);
              mode_ = 1;
            }
            actionId_++;
            actionPending_ = true;
            actionComplete_ = false;
          }
        }
        if(actionPending_){
          if(mode_ == 0){
            if(std::get<0>(*searchGoals_) == 0){
              //search complete.
              if(std::get<1>(*searchGoals_) == 1){
                //search successful!
                isFound_ = 1;
              }else{
                isFound_ = 0;
              }
              actionComplete_ = true;
            }
          }else if(mode_ == 1){
            if(std::get<0>(*transitGoals_) == 0){
              //transit complete
              isFound_ = 0;
              actionComplete_ = true;
            }
          }
          if(actionComplete_){
            std::cout << "action completed, creating observation: (" << currentObservation_ << ", "<< isFound_ << ")"<< std::endl;
            //generate observation.
            std::vector<int> obsVec;
            obsVec.push_back(isFound_);
            observationsSequence_->push_back(std::make_pair(currentObservation_, obsVec));
            currentObservation_++;
            actionPending_ = false;
            actionComplete_ = false;
          }
        }
        //   //PLANNER LOOP HERE
        // if(observationsSequence_->size()>currentObservation_){
        //   currentObservation_++;
        //   std::shared_ptr<nanomaptapir::planner::boundarysearch::BoundarySearchObservation> observation = std::make_shared<nanomaptapir::planner::boundarysearch::BoundarySearchObservation>(false);
        //   tapirInterface_->addObservation(observation);
        //   tapirInterface_->stepSolver();
        //   std::cout << "ACTION FROM POLICY = " << tapirInterface_->lastAction_->getAction() << std::endl;
        // }else{
        //   //std::cout << "running policy improvement" << std::endl;
        //   //tapirInterface_->improvePolicy();
        //   std::cout << "CurrentActionFromPolicy =  " << tapirInterface_->getPreferredAction() << std::endl; 
        // }
      };
    timer_ = this->create_wall_timer(100ms, timer_callback);
  }
private:
  int targetCluster_ = 0;
  nanomap::instance::GymInstance* gymInstance_;
  nanomaptapir::planner::boundarysearch::BoundarySearchDefinition* definition_;
  std::tuple<int, int, std::vector<Eigen::Vector3f>>* transitGoals_;
  std::tuple<int, int, std::vector<Eigen::Vector3f>>* searchGoals_;
  bool actionComplete_;
  bool actionPending_;
  int currentCluster_;
  int currentBoundary_;
  int mode_ = -1;
  int isFound_ = 0;
  int actionId_ = 0;
  std::vector<std::pair<int,std::vector<int>>>* observationsSequence_;
  int currentObservation_;
  std::vector<std::pair<int, int>>* actionSequence_;
  rclcpp::TimerBase::SharedPtr timer_;
  size_t count_;
};


class TapirLoopNode : public rclcpp::Node
{
public:
  TapirLoopNode(nanomaptapir::planner::boundarysearch::BoundarySearchInterface& tapirInterface, 
                std::vector<std::pair<int, std::vector<int>>>&            observationsSequence,
                std::vector<std::pair<int,int>>&                                                actionSequence,
                std::vector<nanomaptapir::planner::boundarysearch::BoundarySearchObservation>& observations)
  : Node("TapirLoopNode"), count_(0), /*gymInstance_(&gymInstance),*/ tapirInterface_(&tapirInterface), observationsSequence_(&observationsSequence), actionSequence_(&actionSequence), observations_(&observations)
  {

    currentObservation_ = 0;
    actionId_ = 0;
    std::string topic = "tapir_loop_node";
    actionSequence_->push_back(std::make_pair(actionId_, tapirInterface_->getPreferredAction()));
     std::cout << "ACTION FROM POLICY = " << tapirInterface_->getPreferredAction() << std::endl;
    actionId_++;
    auto timer_callback =
      [this]() -> void {

          //PLANNER LOOP HERE
        if(observationsSequence_->size()>currentObservation_){


          //nanomaptapir::planner::boundarysearch::BoundarySearchObservation observation((*observationsSequence_)[currentObservation_].second[0]);
          //observations_->push_back(nanomaptapir::planner::boundarysearch::BoundarySearchObservation((*observationsSequence_)[currentObservation_].second[0]));
          
          //std::cout << "attempting to add observation" << std::endl;
          tapirInterface_->addObservation((*observationsSequence_)[currentObservation_].second);
          
          //tapirInterface_->addObservation(&((*observations_)[currentObservation_]));
          tapirInterface_->stepSolver();
          std::cout << "ACTION FROM POLICY = " << tapirInterface_->lastAction_->getAction() << std::endl;
          actionSequence_->push_back(std::make_pair(actionId_, tapirInterface_->getPreferredAction()));      
          currentObservation_++;
          actionId_++;
        }else{
          //std::cout << "running policy improvement" << std::endl;
          //tapirInterface_->improvePolicy();
          //std::cout << "CurrentActionFromPolicy =  " << tapirInterface_->getPreferredAction() << std::endl; 
        }
      };
    timer_ = this->create_wall_timer(1000ms, timer_callback);
  }
private:
  //nanomap::instance::GymInstance* gymInstance_;
  nanomaptapir::planner::boundarysearch::BoundarySearchInterface* tapirInterface_;
  std::vector<std::pair<int,std::vector<int>>>* observationsSequence_;
  std::vector<nanomaptapir::planner::boundarysearch::BoundarySearchObservation>* observations_;
  int actionId_;
  int currentObservation_;
  std::vector<std::pair<int,int>>* actionSequence_;

  rclcpp::TimerBase::SharedPtr timer_;
  size_t count_;
};
//  plannerDefinition->setInitialOccupancy(occupancy);
//   std::cout << "DefinitionPopulated" << std::endl;
//   nanomap::planner::graphsearch::GraphSearchInterface plannerInterface;
//   plannerInterface.initialisePlanner(plannerDefinition);
//   std::cout << "plannerInitialised" << std::endl;
//   //NOW PLAN FOR THE MAP
//   int step = 0;
//   int robotStart = rand()%(map_ptr->_clusterIDs.size());
//   int opponentEnd = occupiedNodes[rand()%(occupiedNodes.size())];
//   std::cout << "robotStart = " << robotStart << " opponentPosition = " << opponentEnd << std::endl;
//   std::cout << "potentialLocations = ";
//   for(int x = 0; x < occupiedNodes.size(); x++){
//     std::cout << "/" << occupiedNodes[x];
//   }
//   std::cout << std::endl;
//   bool found = false;
//   while(step < 10){
//     std::cout << "step = " << step << std::endl;
//     if(step > 0){
//     found = (opponentEnd == plannerInterface.lastAction_->getAction());
//       if(found){
//         std::cout << "opponent found" << std::endl;
//         break;
//       }else{
//         std::cout << "opponent not found" << std::endl;
//         std::shared_ptr<nanomap::planner::graphsearch::GraphSearchObservation> obs =
//           std::make_shared<nanomap::planner::graphsearch::GraphSearchObservation>(found);
//           plannerInterface.addObservation(obs);
//       }
//     }
//     plannerInterface.stepSolver();
//     std::cout << "action = " << plannerInterface.lastAction_->getAction() << std::endl;
//     step++;
//   }

class AgentPublisher : public rclcpp::Node
{
public:
  AgentPublisher(nanomap::instance::GymInstance& gymInstance)
  : Node("agent_publisher"),count_(0), gymInstance_(&gymInstance)
  {
    std::string topic = "agent_publisher";
    publisher_ = this->create_publisher<geometry_msgs::msg::PointStamped>(topic, 10);

    auto timer_callback =
    [this]() -> void {
      Eigen::Array<float, 7, 1> poseAsFloat = gymInstance_->getAgentPoseAsFloatByIndex(0);
      rclcpp::Time now = this->get_clock()->now();
      
      msg_.header.stamp = now;
      msg_.header.frame_id = "world";
      //std::cout << "goalObs " << goalObs(0) << " / " << goalObs(1) << " / " << goalObs(2) << std::endl;
      msg_.point.x = poseAsFloat(0);
      msg_.point.y =  poseAsFloat(1);
      msg_.point.z =  poseAsFloat(2);

      // msg_.pose.orientation.x = (double)sensorData->sharedParameters()._pose.orientation.x();
      // msg_.pose.orientation.y = (double)sensorData->sharedParameters()._pose.orientation.y();
      // msg_.pose.orientation.z = (double)sensorData->sharedParameters()._pose.orientation.z();
      // msg_.pose.orientation.w = (double)sensorData->sharedParameters()._pose.orientation.w();

      // Send the transformation
      this->publisher_->publish(msg_);
    };
    timer_ = this->create_wall_timer(10ms, timer_callback);
  }

private:
  geometry_msgs::msg::PointStamped msg_;

  nanomap::instance::GymInstance* gymInstance_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<geometry_msgs::msg::PointStamped>::SharedPtr publisher_;
  size_t count_;
};

class TargetPublisher : public rclcpp::Node
{
public:
  TargetPublisher(nanomap::instance::GymInstance& gymInstance)
  : Node("target_publisher"),count_(0), gymInstance_(&gymInstance)
  {
    std::string topic = "target_publisher";
    publisher_ = this->create_publisher<geometry_msgs::msg::PointStamped>(topic, 10);

    auto timer_callback =
    [this]() -> void {
      //Eigen::Array<float, 11, 1> goalObs = gymInstance_->getGoalObservationsByIndex(0);
      std::vector<Eigen::Vector3f> targetPositions = gymInstance_->targetPositions();
      rclcpp::Time now = this->get_clock()->now();
      
      msg_.header.stamp = now;
      msg_.header.frame_id = "world";

      msg_.point.x = targetPositions[0].x();
      msg_.point.y =  targetPositions[0].y();
      msg_.point.z =  targetPositions[0].z();

      // msg_.pose.orientation.x = (double)sensorData->sharedParameters()._pose.orientation.x();
      // msg_.pose.orientation.y = (double)sensorData->sharedParameters()._pose.orientation.y();
      // msg_.pose.orientation.z = (double)sensorData->sharedParameters()._pose.orientation.z();
      // msg_.pose.orientation.w = (double)sensorData->sharedParameters()._pose.orientation.w();

      // Send the transformation
      this->publisher_->publish(msg_);
    };
    timer_ = this->create_wall_timer(10ms, timer_callback);
  }

private:
  geometry_msgs::msg::PointStamped msg_;

  nanomap::instance::GymInstance* gymInstance_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<geometry_msgs::msg::PointStamped>::SharedPtr publisher_;
  size_t count_;
};




int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  openvdb::initialize();
  int seed = time(0);
  srand(seed);
  std::cout << seed << std::endl;
  // if(!(argc == 2)){
  //   std::cout << "please provide config path" << std::endl;
  //   return 0;
  // }
  std::vector<std::string> hexColors = {
        "#000000", "#FFFF00", "#1CE6FF", "#FF34FF", "#FF4A46", "#008941", "#006FA6", "#A30059",
        "#FFDBE5", "#7A4900", "#0000A6", "#63FFAC", "#B79762", "#004D43", "#8FB0FF", "#997D87",
        "#5A0007", "#809693", "#FEFFE6", "#1B4400", "#4FC601", "#3B5DFF", "#4A3B53", "#FF2F80",
        "#61615A", "#BA0900", "#6B7900", "#00C2A0", "#FFAA92", "#FF90C9", "#B903AA", "#D16100",
        "#DDEFFF", "#000035", "#7B4F4B", "#A1C299", "#300018", "#0AA6D8", "#013349", "#00846F",
        "#372101", "#FFB500", "#C2FFED", "#A079BF", "#CC0744", "#C0B9B2", "#C2FF99", "#001E09",
        "#00489C", "#6F0062", "#0CBD66", "#EEC3FF", "#456D75", "#B77B68", "#7A87A1", "#788D66",
        "#885578", "#FAD09F", "#FF8A9A", "#D157A0", "#BEC459", "#456648", "#0086ED", "#886F4C",
        "#34362D", "#B4A8BD", "#00A6AA", "#452C2C", "#636375", "#A3C8C9", "#FF913F", "#938A81",
        "#575329", "#00FECF", "#B05B6F", "#8CD0FF", "#3B9700", "#04F757", "#C8A1A1", "#1E6E00",
        "#7900D7", "#A77500", "#6367A9", "#A05837", "#6B002C", "#772600", "#D790FF", "#9B9700",
        "#549E79", "#FFF69F", "#201625", "#72418F", "#BC23FF", "#99ADC0", "#3A2465", "#922329",
        "#5B4534", "#FDE8DC", "#404E55", "#0089A3", "#CB7E98", "#A4E804", "#324E72", "#6A3A4C",
        "#83AB58", "#001C1E", "#D1F7CE", "#004B28", "#C8D0F6", "#A3A489", "#806C66", "#222800",
        "#BF5650", "#E83000", "#66796D", "#DA007C", "#FF1A59", "#8ADBB4", "#1E0200", "#5B4E51",
        "#C895C5", "#320033", "#FF6832", "#66E1D3", "#CFCDAC", "#D0AC94", "#7ED379", "#012C58",
        "#7A7BFF", "#D68E01", "#353339", "#78AFA1", "#FEB2C6", "#75797C", "#837393", "#943A4D",
        "#B5F4FF", "#D2DCD5", "#9556BD", "#6A714A", "#001325", "#02525F", "#0AA3F7", "#E98176",
        "#DBD5DD", "#5EBCD1", "#3D4F44", "#7E6405", "#02684E", "#962B75", "#8D8546", "#9695C5",
        "#E773CE", "#D86A78", "#3E89BE", "#CA834E", "#518A87", "#5B113C", "#55813B", "#E704C4",
        "#00005F", "#A97399", "#4B8160", "#59738A", "#FF5DA7", "#F7C9BF", "#643127", "#513A01",
        "#6B94AA", "#51A058", "#A45B02", "#1D1702", "#E20027", "#E7AB63", "#4C6001", "#9C6966",
        "#64547B", "#97979E", "#006A66", "#391406", "#F4D749", "#0045D2", "#006C31", "#DDB6D0",
        "#7C6571", "#9FB2A4", "#00D891", "#15A08A", "#BC65E9", "#FFFFFE", "#C6DC99", "#203B3C",
        "#671190", "#6B3A64", "#F5E1FF", "#FFA0F2", "#CCAA35", "#374527", "#8BB400", "#797868",
        "#C6005A", "#3B000A", "#C86240", "#29607C", "#402334", "#7D5A44", "#CCB87C", "#B88183",
        "#AA5199", "#B5D6C3", "#A38469", "#9F94F0", "#A74571", "#B894A6", "#71BB8C", "#00B433",
        "#789EC9", "#6D80BA", "#953F00", "#5EFF03", "#E4FFFC", "#1BE177", "#BCB1E5", "#76912F",
        "#003109", "#0060CD", "#D20096", "#895563", "#29201D", "#5B3213", "#A76F42", "#89412E",
        "#1A3A2A", "#494B5A", "#A88C85", "#F4ABAA", "#A3F3AB", "#00C6C8", "#EA8B66", "#958A9F",
        "#BDC9D2", "#9FA064", "#BE4700", "#658188", "#83A485", "#453C23", "#47675D", "#3A3F00",
        "#061203", "#DFFB71", "#868E7E", "#98D058", "#6C8F7D", "#D7BFC2", "#3C3E6E", "#D83D66",
        "#2F5D9B", "#6C5E46", "#D25B88", "#5B656C", "#00B57F", "#545C46", "#866097", "#365D25",
        "#252F99", "#00CCFF", "#674E60", "#FC009C", "#92896B", "#1E2324", "#DEC9B2", "#9D4948",
        "#85ABB4", "#342142", "#D09685", "#A4ACAC", "#00FFFF", "#AE9C86", "#742A33", "#0E72C5",
        "#AFD8EC", "#C064B9", "#91028C", "#FEEDBF", "#FFB789", "#9CB8E4", "#AFFFD1", "#2A364C",
        "#4F4A43", "#647095", "#34BBFF", "#807781", "#920003", "#B3A5A7", "#018615", "#F1FFC8",
        "#976F5C", "#FF3BC1", "#FF5F6B", "#077D84", "#F56D93", "#5771DA", "#4E1E2A", "#830055",
        "#02D346", "#BE452D", "#00905E", "#BE0028", "#6E96E3", "#007699", "#FEC96D", "#9C6A7D",
        "#3FA1B8", "#893DE3", "#79B4D6", "#7FD4D9", "#6751BB", "#B28D2D", "#E27A05", "#DD9CB8",
        "#AABC7A", "#980034", "#561A02", "#8F7F00", "#635000", "#CD7DAE", "#8A5E2D", "#FFB3E1",
        "#6B6466", "#C6D300", "#0100E2", "#88EC69", "#8FCCBE", "#21001C", "#511F4D", "#E3F6E3",
        "#FF8EB1", "#6B4F29", "#A37F46", "#6A5950", "#1F2A1A", "#04784D", "#101835", "#E6E0D0",
        "#FF74FE", "#00A45F", "#8F5DF8", "#4B0059", "#412F23", "#D8939E", "#DB9D72", "#604143",
        "#B5BACE", "#989EB7", "#D2C4DB", "#A587AF", "#77D796", "#7F8C94", "#FF9B03", "#555196",
        "#31DDAE", "#74B671", "#802647", "#2A373F", "#014A68", "#696628", "#4C7B6D", "#002C27",
        "#7A4522", "#3B5859", "#E5D381", "#FFF3FF", "#679FA0", "#261300", "#2C5742", "#9131AF",
        "#AF5D88", "#C7706A", "#61AB1F", "#8CF2D4", "#C5D9B8", "#9FFFFB", "#BF45CC", "#493941",
        "#863B60", "#B90076", "#003177", "#C582D2", "#C1B394", "#602B70", "#887868", "#BABFB0",
        "#030012", "#D1ACFE", "#7FDEFE", "#4B5C71", "#A3A097", "#E66D53", "#637B5D", "#92BEA5",
        "#00F8B3", "#BEDDFF", "#3DB5A7", "#DD3248", "#B6E4DE", "#427745", "#598C5A", "#B94C59",
        "#8181D5", "#94888B", "#FED6BD", "#536D31", "#6EFF92", "#E4E8FF", "#20E200", "#FFD0F2",
        "#4C83A1", "#BD7322", "#915C4E", "#8C4787", "#025117", "#A2AA45", "#2D1B21", "#A9DDB0",
        "#FF4F78", "#528500", "#009A2E", "#17FCE4", "#71555A", "#525D82", "#00195A", "#967874",
        "#555558", "#0B212C", "#1E202B", "#EFBFC4", "#6F9755", "#6F7586", "#501D1D", "#372D00",
        "#741D16", "#5EB393", "#B5B400", "#DD4A38", "#363DFF", "#AD6552", "#6635AF", "#836BBA",
        "#98AA7F", "#464836", "#322C3E", "#7CB9BA", "#5B6965", "#707D3D", "#7A001D", "#6E4636",
        "#443A38", "#AE81FF", "#489079", "#897334", "#009087", "#DA713C", "#361618", "#FF6F01",
        "#006679", "#370E77", "#4B3A83", "#C9E2E6", "#C44170", "#FF4526", "#73BE54", "#C4DF72",
        "#ADFF60", "#00447D", "#DCCEC9", "#BD9479", "#656E5B", "#EC5200", "#FF6EC2", "#7A617E",
        "#DDAEA2", "#77837F", "#A53327", "#608EFF", "#B599D7", "#A50149", "#4E0025", "#C9B1A9",
        "#03919A", "#1B2A25", "#E500F1", "#982E0B", "#B67180", "#E05859", "#006039", "#578F9B",
        "#305230", "#CE934C", "#B3C2BE", "#C0BAC0", "#B506D3", "#170C10", "#4C534F", "#224451",
        "#3E4141", "#78726D", "#B6602B", "#200441", "#DDB588", "#497200", "#C5AAB6", "#033C61",
        "#71B2F5", "#A9E088", "#4979B0", "#A2C3DF", "#784149", "#2D2B17", "#3E0E2F", "#57344C",
        "#0091BE", "#E451D1", "#4B4B6A", "#5C011A", "#7C8060", "#FF9491", "#4C325D", "#005C8B",
        "#E5FDA4", "#68D1B6", "#032641", "#140023", "#8683A9", "#CFFF00", "#A72C3E", "#34475A",
        "#B1BB9A", "#B4A04F", "#8D918E", "#A168A6", "#813D3A", "#425218", "#DA8386", "#776133",
        "#563930", "#8498AE", "#90C1D3", "#B5666B", "#9B585E", "#856465", "#AD7C90", "#E2BC00",
        "#E3AAE0", "#B2C2FE", "#FD0039", "#009B75", "#FFF46D", "#E87EAC", "#DFE3E6", "#848590",
        "#AA9297", "#83A193", "#577977", "#3E7158", "#C64289", "#EA0072", "#C4A8CB", "#55C899",
        "#E78FCF", "#004547", "#F6E2E3", "#966716", "#378FDB", "#435E6A", "#DA0004", "#1B000F",
        "#5B9C8F", "#6E2B52", "#011115", "#E3E8C4", "#AE3B85", "#EA1CA9", "#FF9E6B", "#457D8B",
        "#92678B", "#00CDBB", "#9CCC04", "#002E38", "#96C57F", "#CFF6B4", "#492818", "#766E52",
        "#20370E", "#E3D19F", "#2E3C30", "#B2EACE", "#F3BDA4", "#A24E3D", "#976FD9", "#8C9FA8",
        "#7C2B73", "#4E5F37", "#5D5462", "#90956F", "#6AA776", "#DBCBF6", "#DA71FF", "#987C95",
        "#52323C", "#BB3C42", "#584D39", "#4FC15F", "#A2B9C1", "#79DB21", "#1D5958", "#BD744E",
        "#160B00", "#20221A", "#6B8295", "#00E0E4", "#102401", "#1B782A", "#DAA9B5", "#B0415D",
        "#859253", "#97A094", "#06E3C4", "#47688C", "#7C6755", "#075C00", "#7560D5", "#7D9F00",
        "#C36D96", "#4D913E", "#5F4276", "#FCE4C8", "#303052", "#4F381B", "#E5A532", "#706690",
        "#AA9A92", "#237363", "#73013E", "#FF9079", "#A79A74", "#029BDB", "#FF0169", "#C7D2E7",
        "#CA8869", "#80FFCD", "#BB1F69", "#90B0AB", "#7D74A9", "#FCC7DB", "#99375B", "#00AB4D",
        "#ABAED1", "#BE9D91", "#E6E5A7", "#332C22", "#DD587B", "#F5FFF7", "#5D3033", "#6D3800",
        "#FF0020", "#B57BB3", "#D7FFE6", "#C535A9", "#260009", "#6A8781", "#A8ABB4", "#D45262",
        "#794B61", "#4621B2", "#8DA4DB", "#C7C890", "#6FE9AD", "#A243A7", "#B2B081", "#181B00",
        "#286154", "#4CA43B", "#6A9573", "#A8441D", "#5C727B", "#738671", "#D0CFCB", "#897B77",
        "#1F3F22", "#4145A7", "#DA9894", "#A1757A", "#63243C", "#ADAAFF", "#00CDE2", "#DDBC62",
        "#698EB1", "#208462", "#00B7E0", "#614A44", "#9BBB57", "#7A5C54", "#857A50", "#766B7E",
        "#014833", "#FF8347", "#7A8EBA", "#274740", "#946444", "#EBD8E6", "#646241", "#373917",
        "#6AD450", "#81817B", "#D499E3", "#979440", "#011A12", "#526554", "#B5885C", "#A499A5",
        "#03AD89", "#B3008B", "#E3C4B5", "#96531F", "#867175", "#74569E", "#617D9F", "#E70452",
        "#067EAF", "#A697B6", "#B787A8", "#9CFF93", "#311D19", "#3A9459", "#6E746E", "#B0C5AE",
        "#84EDF7", "#ED3488", "#754C78", "#384644", "#C7847B", "#00B6C5", "#7FA670", "#C1AF9E",
        "#2A7FFF", "#72A58C", "#FFC07F", "#9DEBDD", "#D97C8E", "#7E7C93", "#62E674", "#B5639E",
        "#FFA861", "#C2A580", "#8D9C83", "#B70546", "#372B2E", "#0098FF", "#985975", "#20204C",
        "#FF6C60", "#445083", "#8502AA", "#72361F", "#9676A3", "#484449", "#CED6C2", "#3B164A",
        "#CCA763", "#2C7F77", "#02227B", "#A37E6F", "#CDE6DC", "#CDFFFB", "#BE811A", "#F77183",
        "#EDE6E2", "#CDC6B4", "#FFE09E", "#3A7271", "#FF7B59", "#4E4E01", "#4AC684", "#8BC891",
        "#BC8A96", "#CF6353", "#DCDE5C", "#5EAADD", "#F6A0AD", "#E269AA", "#A3DAE4", "#436E83",
        "#002E17", "#ECFBFF", "#A1C2B6", "#50003F", "#71695B", "#67C4BB", "#536EFF", "#5D5A48",
        "#890039", "#969381", "#371521", "#5E4665", "#AA62C3", "#8D6F81", "#2C6135", "#410601",
        "#564620", "#E69034", "#6DA6BD", "#E58E56", "#E3A68B", "#48B176", "#D27D67", "#B5B268",
        "#7F8427", "#FF84E6", "#435740", "#EAE408", "#F4F5FF", "#325800", "#4B6BA5", "#ADCEFF",
        "#9B8ACC", "#885138", "#5875C1", "#7E7311", "#FEA5CA", "#9F8B5B", "#A55B54", "#89006A",
        "#AF756F", "#2A2000", "#576E4A", "#7F9EFF", "#7499A1", "#FFB550", "#00011E", "#D1511C",
        "#688151", "#BC908A", "#78C8EB", "#8502FF", "#483D30", "#C42221", "#5EA7FF", "#785715",
        "#0CEA91", "#FFFAED", "#B3AF9D", "#3E3D52", "#5A9BC2", "#9C2F90", "#8D5700", "#ADD79C",
        "#00768B", "#337D00", "#C59700", "#3156DC", "#944575", "#ECFFDC", "#D24CB2", "#97703C",
        "#4C257F", "#9E0366", "#88FFEC", "#B56481", "#396D2B", "#56735F", "#988376", "#9BB195",
        "#A9795C", "#E4C5D3", "#9F4F67", "#1E2B39", "#664327", "#AFCE78", "#322EDF", "#86B487",
        "#C23000", "#ABE86B", "#96656D", "#250E35", "#A60019", "#0080CF", "#CAEFFF", "#323F61",
        "#A449DC", "#6A9D3B", "#FF5AE4", "#636A01", "#D16CDA", "#736060", "#FFBAAD", "#D369B4",
        "#FFDED6", "#6C6D74", "#927D5E", "#845D70", "#5B62C1", "#2F4A36", "#E45F35", "#FF3B53",
        "#AC84DD", "#762988", "#70EC98", "#408543", "#2C3533", "#2E182D", "#323925", "#19181B",
        "#2F2E2C", "#023C32", "#9B9EE2", "#58AFAD", "#5C424D", "#7AC5A6", "#685D75", "#B9BCBD",
        "#834357", "#1A7B42", "#2E57AA", "#E55199", "#316E47", "#CD00C5", "#6A004D", "#7FBBEC",
        "#F35691", "#D7C54A", "#62ACB7", "#CBA1BC", "#A28A9A", "#6C3F3B", "#FFE47D", "#DCBAE3",
        "#5F816D", "#3A404A", "#7DBF32", "#E6ECDC", "#852C19", "#285366", "#B8CB9C", "#0E0D00",
        "#4B5D56", "#6B543F", "#E27172", "#0568EC", "#2EB500", "#D21656", "#EFAFFF", "#682021",
        "#2D2011", "#DA4CFF", "#70968E", "#FF7B7D", "#4A1930", "#E8C282", "#E7DBBC", "#A68486",
        "#1F263C", "#36574E", "#52CE79", "#ADAAA9", "#8A9F45", "#6542D2", "#00FB8C", "#5D697B",
        "#CCD27F", "#94A5A1", "#790229", "#E383E6", "#7EA4C1", "#4E4452", "#4B2C00", "#620B70",
        "#314C1E", "#874AA6", "#E30091", "#66460A", "#EB9A8B", "#EAC3A3", "#98EAB3", "#AB9180",
        "#B8552F", "#1A2B2F", "#94DDC5", "#9D8C76", "#9C8333", "#94A9C9", "#392935", "#8C675E",
        "#CCE93A", "#917100", "#01400B", "#449896", "#1CA370", "#E08DA7", "#8B4A4E", "#667776",
        "#4692AD", "#67BDA8", "#69255C", "#D3BFFF", "#4A5132", "#7E9285", "#77733C", "#E7A0CC",
        "#51A288", "#2C656A", "#4D5C5E", "#C9403A", "#DDD7F3", "#005844", "#B4A200", "#488F69",
        "#858182", "#D4E9B9", "#3D7397", "#CAE8CE", "#D60034", "#AA6746", "#9E5585", "#BA6200"};
  std::vector<std::array<int,3>> RGBColors;
  for(int x = 0; x < hexColors.size(); x++){
    std::string l_strHexValue = hexColors[x];
    std::regex pattern("#([0-9a-fA-F]{6})");
    std::smatch match;
    if (std::regex_match(l_strHexValue, match, pattern))
    {
        int r, g, b;
        sscanf(match.str(1).c_str(), "%2x%2x%2x", &r, &g, &b);
        RGBColors.push_back({r,g,b});
        //std::cout << "R: " << r << ", G: " << g << ", B: " << b << "\n";
    }
  }

  std::string gymConfig = "/home/vi/github/first-party/src/nanomap/config/gym/frustumSim/config.txt";
  std::string plannerConfig = "/home/vi/github/first-party/src/nanomaptapir/problems/boundarysearch/config/default.cfg";
  //CREATE GYM INSTANCE
  nanomap::instance::GymInstance gymInstance(gymConfig);
  gymInstance.setObjectsOnPath(false);
  int environmentKnowledge = 1;
  float knowledgeRadius = 2.0;
  gymInstance.setEnvironmentKnowledge(environmentKnowledge, knowledgeRadius);
  gymInstance.createManager();
  gymInstance.createHandler();
  gymInstance.resetAgentByIndex(0);
  gymInstance.onAgentReset();

  Eigen::Vector3f rpy(0,0,0);
  Eigen::Vector3f xyz(0,0,0);

  Eigen::Array<float, 7, 1> poseAsFloat = gymInstance.getAgentPoseAsFloatByIndex(0);
  nanomap::Pose pose;
  std::cout << poseAsFloat(0) << " / " 
            << poseAsFloat(1) << " / " 
            << poseAsFloat(2) << " / " 
            << poseAsFloat(3) << " / " 
            << poseAsFloat(4) << " / " 
            << poseAsFloat(5) << " / " 
            << poseAsFloat(6) << " / " << std::endl; 
  pose.position.x() = poseAsFloat(0);
  pose.position.y() = poseAsFloat(1);
  pose.position.z() = poseAsFloat(2);
  pose.orientation.w() = poseAsFloat(3);
  pose.orientation.x() = poseAsFloat(4);
  pose.orientation.y() = poseAsFloat(5);
  pose.orientation.z()= poseAsFloat(6);

  //std::vector<nanomap::Pose> poses;
  gymInstance.updateAgentPose(0, pose);
  //Random map created, solved and agent spawned in with views calculated. 
  int clusterCount = gymInstance.plannerInstance()->plannerManager()->getClusterCount();
  std::vector<int> occupancy;
  occupancy.resize(clusterCount);
  int numRandomOccupiedClusters = 5;
  std::set<int> randomOccupiedClusters;
  while(randomOccupiedClusters.size() < 5){
    randomOccupiedClusters.insert(rand()%clusterCount);
  }
  //occupancy[rand()%clusterCount] = ;
  for(int occupiedCluster : randomOccupiedClusters){
    occupancy[occupiedCluster] = std::floor(std::sqrt(gymInstance.plannerInstance()->plannerManager()->getSafeCountForCluster(occupiedCluster)));
  }
  //DEFINE GRAPH SEARCH DEFINITION
  std::cout << "FinishedMapSolve, Beginning Planning" << std::endl;
  std::shared_ptr<nanomaptapir::planner::boundarysearch::BoundarySearchDefinition> plannerDefinition
                  = std::make_shared<nanomaptapir::planner::boundarysearch::BoundarySearchDefinition>();
  gymInstance.generateRandomTargetPositions(1);
  std::vector<Eigen::Vector3f> targetPositions = gymInstance.targetPositions();
  int targetCluster =  gymInstance.plannerInstance()->plannerManager()->getClusterFromPosition(targetPositions[0]); 
  occupancy[targetCluster] = std::floor(std::sqrt(gymInstance.plannerInstance()->plannerManager()->getSafeCountForCluster(targetCluster)));
  plannerDefinition->setPlannerManager(gymInstance.plannerInstance()->plannerManager());
  plannerDefinition->setCfgPath(plannerConfig);
  plannerDefinition->getClusterInfoFromManager();
  plannerDefinition->setInitialOccupancy(occupancy);
  //plannerDefinition->setUniformOccupancy();
  std::pair<int, int> initialPosition = gymInstance.plannerInstance()->plannerManager()->getClusterBoundaryPairFromPos(pose.position);
  plannerDefinition->setInitialPosition(initialPosition);

  rclcpp::executors::MultiThreadedExecutor executor;
  auto occupiedVoxelPubNode = std::make_shared<LeafPublisherNode>(gymInstance.agentManager()->getAgentByIndex(0)->map()->occupiedGrid(),"OccupiedGrid");
  auto simGridPubNode = std::make_shared<LeafPublisherNode>(gymInstance.getSimGrid(),"SimulatedGrid");
  
  
  
  //std::shared_ptr<nanomaptapir::planner::boundarysearch::BoundarySearchInterface> tapirInterface = std::make_shared<nanomaptapir::planner::boundarysearch::BoundarySearchInterface>();
  nanomaptapir::planner::boundarysearch::BoundarySearchInterface  tapirInterface;
  //tapirInterface.initialisePlanner(plannerDefinition);
  std::vector<std::pair<int, std::vector<int>>> observationsSequence;
  std::vector<nanomaptapir::planner::boundarysearch::BoundarySearchObservation> observations;
  std::vector<std::pair<int,int>> actionSequence;

  std::tuple<int, int, std::vector<Eigen::Vector3f>> searchGoals;
  std::tuple<int, int, std::vector<Eigen::Vector3f>> transitGoals;
  std::array<Eigen::Vector3f, 2> currentGoals;
  bool transitMode = false;
  bool searchMode = false;

  tapirInterface.initialisePlanner(plannerDefinition);
  auto tapirLoop = std::make_shared<TapirLoopNode>(tapirInterface, observationsSequence, actionSequence, observations);
  auto actionObservationNode = std::make_shared<ActionObservationNode>(gymInstance,plannerDefinition.get(),observationsSequence, actionSequence, searchGoals, transitGoals);
  auto macroManagerNode = std::make_shared<MacroManagerNode>(gymInstance, searchGoals, transitGoals, xyz, rpy, transitMode, searchMode, currentGoals);
  auto agentPublisher = std::make_shared<AgentPublisher>(gymInstance);
  auto targetPublisher = std::make_shared<TargetPublisher>(gymInstance);
  // auto policyClient = std::make_shared<PolicyClientNode>(instance, xyz, rpy);
  // auto viewLoop = std::make_shared<ViewLoopNode>(instance, "viewLoop");
  // auto framePublisher = std::make_shared<FramePublisher>(instance, instance.agentManager()->getAgent(0)->agentData()->agentName());
  // auto sensorPublisher = std::make_shared<SensorPublisher>(instance);
  // auto goalPublisher = std::make_shared<GoalPublisher>(instance);
  // auto goalTwoPublisher = std::make_shared<GoalTwoPublisher>(instance);
  // //auto observationPublisher = std::make_shared<ObservationPublisher>(instance);
  // auto hazardPublisher = std::make_shared<HazardPublisher>(instance);
  // auto unknownPublisher = std::make_shared<UnknownPublisher>(instance);
  // auto joyListener = std::make_shared<JoyListenerNode>(xyz, rpy, "joyListener");
  auto graphVisualizer = std::make_shared<GraphVisualizer>(gymInstance);
  auto boundaryVisualizer = std::make_shared<BoundaryVisualizer>(gymInstance, RGBColors);
  auto searchNodeVisualizer = std::make_shared<ClusterSearchNodeVisualizer>(gymInstance, RGBColors);
  
  // executor.add_node(joyListener);
  // executor.add_node(poseLoop);
  // executor.add_node(viewLoop);
  executor.add_node(agentPublisher);
  executor.add_node(targetPublisher);
  executor.add_node(occupiedVoxelPubNode);
  executor.add_node(simGridPubNode);
  // executor.add_node(framePublisher);
  // executor.add_node(sensorPublisher);
  // executor.add_node(goalPublisher);
  // executor.add_node(goalTwoPublisher);
  // //executor.add_node(observationPublisher);
  // executor.add_node(hazardPublisher);
  // executor.add_node(unknownPublisher);
  // executor.add_node(policyClient);
  executor.add_node(macroManagerNode);
  executor.add_node(searchNodeVisualizer);
  executor.add_node(boundaryVisualizer);
  executor.add_node(graphVisualizer);
  executor.add_node(tapirLoop);
  executor.add_node(actionObservationNode);
  std::cout << "spinning nodes" << std::endl;
  executor.spin();
  rclcpp::shutdown();

            // std::cout << "initialise definition" << std::endl;
            // // plannerDefinition->graphSearchReward_ = 20.0;
            // // plannerDefinition->searchPenalty_ = 1.0;

            // // std::vector<int> occupancy = {0,  //0
            // //                               0,  //1
            // //                               0,  //2
            // //                               0,  //3
            // //                               100,  //4
            // //                               0,  //5
            // //                               0,  //6
            // //                               0,  //7
            // //                               0,  //8
            // //                               100,  //9
            // //                               0,  //10
            // //                               0,  //11
            // //                               100,  //12
            // //                               0}; //13
            // std::vector<int> occupancy;
            // occupancy.resize(map_ptr->_clusterIDs.size());
            // std::vector<int> occupiedNodes;
            // std::srand(std::time(0));
            // for(int x = 0; x < map_ptr->_clusterIDs.size(); x++){
            //   if((rand()%100)>50){
            //     occupancy[x] = 100;
            //     occupiedNodes.push_back(x);
            //   }
            // }
            // // plannerDefinition->setInitialOccupancy(occupancy);
            // // std::cout << "DefinitionPopulated" << std::endl;
            // // nanomap::planner::graphsearch::GraphSearchInterface plannerInterface;
            // plannerInterface.initialisePlanner(plannerDefinition);
            // std::cout << "plannerInitialised" << std::endl;
            // //NOW PLAN FOR THE MAP
            // int step = 0;
            // int robotStart = rand()%(map_ptr->_clusterIDs.size());
            // int opponentEnd = occupiedNodes[rand()%(occupiedNodes.size())];
            // std::cout << "robotStart = " << robotStart << " opponentPosition = " << opponentEnd << std::endl;
            // std::cout << "potentialLocations = ";
            // for(int x = 0; x < occupiedNodes.size(); x++){
            //   std::cout << "/" << occupiedNodes[x];
            // }
            // std::cout << std::endl;
            // bool found = false;
            // while(step < 10){
            //   std::cout << "step = " << step << std::endl;
            //   if(step > 0){
            //   found = (opponentEnd == plannerInterface.lastAction_->getAction());
            //     if(found){
            //       std::cout << "opponent found" << std::endl;
            //       break;
            //     }else{
            //       std::cout << "opponent not found" << std::endl;
            //       std::shared_ptr<nanomap::planner::graphsearch::GraphSearchObservation> obs =
            //         std::make_shared<nanomap::planner::graphsearch::GraphSearchObservation>(found);
            //         plannerInterface.addObservation(obs);
            //     }
            //   }
            //   plannerInterface.stepSolver();
            //   std::cout << "action = " << plannerInterface.lastAction_->getAction() << std::endl;
            //   step++;
            // }



            // //allocationfactor
            // //std::cout << "print" << std::endl;
            // //handle_start = std::chrono::high_resolution_clock::now();
            // // for(auto itr = clouds.begin(); itr != clouds.end(); itr++){
            // //
            // //   index = std::distance(clouds.begin(), itr);
            // //   if(index >= indexTarget && index < indexEnd){//&& index < indexTarget+1){
            // //     //if(index==1){
            // //     //    handle_start = std::chrono::high_resolution_clock::now();
            // //     //}
            // //     tf::transformStampedMsgToTF(tfs[index], sensorToWorldTf);
            // //     tf::vectorTFToEigen(sensorToWorldTf.getOrigin(), pos);
            // //     tf::quaternionTFToEigen(sensorToWorldTf.getRotation(), quat);
            // //     pose.position = pos.cast<float>();
            // //     pose.orientation = quat.cast<float>();
            // //
            // //     parallelManager.insertPointCloud("640x480", clouds[index]->width, clouds[index]->height ,
            // //                                  clouds[index]->point_step , &(clouds[index]->data[0]), pose, parallel_map_ptr);
            // //
            // //   if(index >= indexEnd-1){
            // //      break;
            // //     }
            // //   }
            // // }

            // plannerManager.closeHandler();
            // return 0;
}
