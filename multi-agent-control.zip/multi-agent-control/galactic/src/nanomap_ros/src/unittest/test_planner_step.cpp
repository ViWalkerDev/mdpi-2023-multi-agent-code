#include "rclcpp/rclcpp.hpp"
#include "rclcpp/time.hpp"
#include "nanomap/manager/PlannerManager.h"
#include "nanomap/map/OccupancyMap.h"
#include "nanomap/nanomap.h"
#include <chrono>
#include <openvdb/openvdb.h>
#include <nanovdb/util/OpenToNanoVDB.h> // converter from OpenVDB to NanoVDB (includes NanoVDB.h and GridManager.h)
#include <nanovdb/util/IO.h>
#include <nanovdb/util/CudaDeviceBuffer.h>
#include "nanomap/planner/problems/boundarysearch/BoundarySearchInterface.hpp"
#include "nanomap/planner/problems/boundarysearch/BoundarySearchDefinition.hpp"
#include "nanomap/planner/problems/boundarysearch/BoundarySearchObservation.hpp"
#include "nanomap/planner/problems/boundarysearch/BoundarySearchAction.hpp"
using Pose = nanomap::Pose;
int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  openvdb::initialize();

  if(!(argc == 2)){
    std::cout << "please provide config path" << std::endl;
    return 0;
  }



  std::string simConfig = argv[1];//"/home/vi/github/galactic/src/nanomap_ros/config/sim/config.txt";
  std::shared_ptr<nanomap::config::Config> config = std::make_shared<nanomap::config::Config>(nanomap::config::Config(simConfig));
  std::shared_ptr<nanomap::map::PlannerMap> map_ptr = std::make_shared<nanomap::map::PlannerMap>(nanomap::map::PlannerMap(
                                                                                                      config->mappingRes(),

                                                                                                     config->probHitThres(),
                                                                                                     config->probMissThres(),
                                                                                                      0.1, 0.8, 8));
  nanomap::manager::PlannerManager plannerManager(config);
  openvdb::FloatGrid::Ptr gridTest;
  gridTest = openvdb::FloatGrid::create(0.0);
  gridTest->setTransform(openvdb::math::Transform::createLinearTransform(0.1));

  std::vector<std::vector<std::vector<int>>> map = {
    {
    {1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1}
    },
    {
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,1,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0}
    },
    {
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,1,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0}
    },
    {
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,1,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0}
    },
    {
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,1,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0}
    },
    {
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,1,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0}
    },
    {
    {1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1}
    },
  };
  ////////
  // 0  (-1,-1,-1) //VERTEX
  // 1  (-1,-1, 0) //EDGE
  // 2  (-1,-1, 1) //VERTEX
  // 3  (-1, 0,-1) //EDGE
  // 4  (-1, 0, 0) //FACE
  // 5  (-1, 0, 1) //EDGE
  // 6  (-1, 1,-1) //VERTEX
  // 7  (-1, 1, 0) //EDGE
  // 8  (-1, 1, 1) //VERTEX
  // 9  ( 0,-1,-1) //EDGE
  // 10 ( 0,-1, 0) //FACE
  // 11 ( 0,-1, 1) //EDGE
  // 12 ( 0, 0,-1) //FACE
  // 13 ( 0, 0, 0) //ORIGIN
  // 14 ( 0, 0, 1) //FACE
  // 15 ( 0, 1,-1) //EDGE
  // 16 ( 0, 1, 0) //FACE
  // 17 ( 0, 1, 1) //EDGE
  // 18 ( 1,-1,-1) //VERTEX
  // 19 ( 1,-1, 0) //EDGE
  // 20 ( 1,-1, 1) //VERTEX
  // 21 ( 1, 0,-1) //EDGE
  // 22 ( 1, 0, 0) //FACE
  // 23 ( 1, 0, 1) //EDGE
  // 24 ( 1, 1,-1) //VERTEX
  // 25 ( 1, 1, 0) //EDGE
  // 26 ( 1, 1, 1) //VERTEX


  auto acc = gridTest->getAccessor();
  auto setObstacle = [](float& voxel_value, bool& active) {
     voxel_value = 1.0;
     active = true;
  };
  auto setFree = [](float& voxel_value, bool& active) {
     voxel_value = 1.0;
     active = false;
  };
  openvdb::io::File file("/home/vi/github/galactic/src/nanomap_ros/config/sim/frustumSim/rngCave.vdb");
  // Open the file.  This reads the file header, but not any grids.
  file.open();
  // Loop over all grids in the file and retrieve a shared pointer
  // to the one named "LevelSetSphere".  (This can also be done
  // more simply by calling file.readGrid("LevelSetSphere").)
  openvdb::GridBase::Ptr baseGrid;
  for (openvdb::io::File::NameIterator nameIter = file.beginName();
      nameIter != file.endName(); ++nameIter)
  {
      // Read in only the grid we are interested in.
      if (nameIter.gridName() == "grid") {
          baseGrid = file.readGrid(nameIter.gridName());
      } else {
          std::cout << "skipping grid " << nameIter.gridName() << std::endl;
      }
  }
  file.close();
//
//   int tileEdge = 8;
   openvdb::FloatGrid::Ptr grid = openvdb::gridPtrCast<openvdb::FloatGrid>(baseGrid);
   auto newacc = grid->getAccessor();

  openvdb::FloatGrid::ValueOnIter oniter = grid->beginValueOn();
bool mapFromFile = true;
if(mapFromFile){
  for (oniter; oniter.test(); ++oniter) {

     acc.modifyValueAndActiveState(oniter.getCoord(), setObstacle);

  }
  openvdb::FloatGrid::ValueOffIter offiter = grid->beginValueOff();
  for (offiter; offiter.test(); ++offiter) {

         if(newacc.getValue(offiter.getCoord()) < 0.0){
           //std::cout << newacc.getValue(offiter.getCoord()) << std::endl;
          acc.modifyValueAndActiveState(offiter.getCoord(), setFree);
        }
  }
}else{
int tileEdge = 8;
  for(int z = 0; z<map.size(); z++){
    for(int y = 0; y<map[z].size();y++){
      for(int x = 0; x<map[z][y].size(); x++){
        if(map[z][y][x]==0){
          for(int a = 0; a < tileEdge; a++){
            for(int b = 0; b < tileEdge; b++){
              for(int c = 0; c < tileEdge; c++){
                acc.modifyValueAndActiveState(openvdb::Coord(x*tileEdge+a,y*tileEdge+b,z*tileEdge+c), setFree);
              }
            }
          }
        }else{
          for(int a = 0; a < tileEdge; a++){
            for(int b = 0; b < tileEdge; b++){
              for(int c = 0; c < tileEdge; c++){
                acc.modifyValueAndActiveState(openvdb::Coord(x*tileEdge+a,y*tileEdge+b,z*tileEdge+c), setObstacle);
              }
            }
          }
        }
      }
    }
  }
}
  // using FloatGrid = openvdb::FloatGrid;
  // using FloatTreeT = openvdb::FloatGrid::TreeType;
  // using FloatLeafT = FloatTreeT::LeafNodeType;
  // using FloatAccessorT = openvdb::tree::ValueAccessor<FloatTreeT>;
  //
  // using RootType = FloatTreeT::RootNodeType;   // level 3 RootNode
  // //assert(RootType::LEVEL == 3);
  // using Int1Type = RootType::ChildNodeType;  // level 2 InternalNode
  // using Int2Type = Int1Type::ChildNodeType;  // level 1 InternalNode
  // using LeafType = FloatTreeT::LeafNodeType;
  // FloatTreeT::LeafIter leafiter{grid->tree()};
  // for ( ; leafiter; ++leafiter) {
  //     LeafType* leaf = nullptr;
  //     leaf = leafiter.getLeaf();
  //   float value;
  //   bool state;
  //   //if(leaf){
  //     if(leaf->isConstant(value, state)){
  //       std::cout << "inactive leaf value: " << leaf->getValue(0) << std::endl;
  //     }
  //   //}//else{
  //       //
  //   //}
  // }
  //int depth = grid->tree().treeDepth();
  //grid_info->node_counts_.clear();
  //grid_info->node_counts_.resize(depth,0);
  //node_info->active_counts_.resize(depth,0);
  //node_info->inactive_counts_.resize(depth,0);
  // for ( ; iter; ++iter) {
  // //if we are in a leaf node perform leaf/tile logic for building planner map
  //   if(iter.getDepth()==3){
  //     LeafType* node = nullptr;
  //     iter.getNode(node);
  //     if (node){
  //       openvdb::Coord indexCoord = openvdb::Coord(iter.getCoord().x()/_tileEdge, iter.getCoord().y()/_tileEdge, iter.getCoord().z()/_tileEdge);
  //       //In a tile/leaf, do planner map construction logic.
  //       //auto worldCoord = targetGrid->indexToWorld(iter.getCoord());
  //       //openvdb::Coord indexCoord = openvdb::Coord(std::floor(_plannerGrid->worldToIndex(worldCoord).x()),
  //       //                                          std::floor(_plannerGrid->worldToIndex(worldCoord).y()),
  //       //                                          std::floor(_plannerGrid->worldToIndex(worldCoord).z()));
  //       //std::cout << "Voxel Count = "<<node->onVoxelCount() << std::endl;
  //       if(node->onVoxelCount()==0){
  //
  //         //this is a safe leaf node
  //         _plannerAccessor->setValue(indexCoord,index);
  //         safeCount+=1;
  //       }else{
  //         _plannerAccessor->setValue(indexCoord,-1*index);
  //         //this is a non-safe but potentially still valid leaf node.
  //       }
  //       index += 1;
  //       validCount+=1;
  //     }
  //   }
  // }
  //int tileEdge = 8;
  // for(int z = 0; z<map.size(); z++){
  //   for(int y = 0; y<map[z].size();y++){
  //     for(int x = 0; x<map[z][y].size(); x++){
  //       if(map[z][y][x]==0){
  //         for(int a = 0; a < tileEdge; a++){
  //           for(int b = 0; b < tileEdge; b++){
  //             for(int c = 0; c < tileEdge; c++){
  //               acc.modifyValueAndActiveState(openvdb::Coord(x*tileEdge+a,y*tileEdge+b,z*tileEdge+c), setFree);
  //             }
  //           }
  //         }
  //       }else{
  //         for(int a = 0; a < tileEdge; a++){
  //           for(int b = 0; b < tileEdge; b++){
  //             for(int c = 0; c < tileEdge; c++){
  //               acc.modifyValueAndActiveState(openvdb::Coord(x*tileEdge+a,y*tileEdge+b,z*tileEdge+c), setObstacle);
  //             }
  //           }
  //         }
  //       }
  //     }
  //   }
  // }



  std::chrono::duration<double, std::milli> delay;
  auto start = std::chrono::high_resolution_clock::now();
  auto end = std::chrono::high_resolution_clock::now();
  for(int x = 0; x < 1; x++){
  start = std::chrono::high_resolution_clock::now();
 //
  plannerManager.updateMapTest(map_ptr, gridTest);
  end = std::chrono::high_resolution_clock::now();
  delay = end-start;
  std::cout << delay.count() << std::endl;
  }
  //MAP GEOMETRY IS NOW SOLVED
  //DEFINE GRAPH SEARCH DEFINITION
  std::cout << "FinishedMapSolve, Beginning Planning" << std::endl;
  std::shared_ptr<nanomap::planner::boundarysearch::BoundarySearchDefinition> plannerDefinition
                  = std::make_shared<nanomap::planner::boundarysearch::BoundarySearchDefinition>();

  std::cout << "initialise definition" << std::endl;
  plannerDefinition->setCfgPath("/home/vi/github/first-party/src/nanomap/include/nanomap/planner/problems/boundarysearch/config/default.cfg");
  plannerDefinition->clusterSearchReward_ = 50.0;
  plannerDefinition->clusterSearchCost_ = 50.0;
  plannerDefinition->populateFromMap(map_ptr);
  std::vector<int> occupancy = {100,  //0
                                100,  //1
                                0,  //2
                                0,  //3
                                0,  //4
                                0,  //5
                                100,  //6
                                0,  //7
                                0,  //8
                                0,  //9
                                100,  //10
                                0,  //11
                                100,  //12
                                100}; //13
  std::vector<int> occupiedNodes = {0,1,6,10,12,13};
  // std::vector<int> occupancy;
  // occupancy.resize(map_ptr->_clusterIDs.size());
  // std::vector<int> occupiedNodes;
  // std::srand(std::time(0));
  // for(int x = 0; x < map_ptr->_clusterIDs.size(); x++){
  //   if((rand()%100)>50){
  //     occupancy[x] = 100;
  //     occupiedNodes.push_back(x);
  //   }
  // }

  //occupiedNodes.push_back(3);
  //occupancy[3] = 100;

  plannerDefinition->setInitialOccupancy(occupancy);
  std::cout << "DefinitionPopulated" << std::endl;
  nanomap::planner::boundarysearch::BoundarySearchInterface plannerInterface;
  //int robotBoundaryNode = rand()%(plannerDefinition->nBoundaryNodes_);
  int robotBoundaryNode = 16;
  plannerDefinition->initialBoundaryNode_ = robotBoundaryNode;
  std::cout << "boundaryNodeCount = "<< plannerDefinition->nBoundaryNodes_ << std::endl;
  std::cout << "clusterCount = " << plannerDefinition->nClusters_ << std::endl;
  // for(int x = 0; x < plannerDefinition->nBoundaryNodes_ ; x++){
  //   for(int y = 0; y < plannerDefinition->nClusters_; y++){
  //     double place = plannerDefinition->getTransitSteps(x, y);
  //     std::cout << " boundary = " << x << " boundaryCluster = " << plannerDefinition->plannerMap_->_globalClusterMap[plannerDefinition->boundaryNodes_[x]] << " cluster = " << y << " steps = " << place << std::endl;
  //   }
  // }
  //return 0;
  plannerInterface.initialisePlanner(plannerDefinition);
  std::cout << "plannerInitialised" << std::endl;
  //NOW PLAN FOR THE MAP
  int step = 0;
  //int robotStart = 0;
  int opponentEnd = occupiedNodes[rand()%(occupiedNodes.size())];
  std::cout << "robotBoundaryStartNode = " << robotBoundaryNode << " opponentPosition = " << opponentEnd << std::endl;
  std::cout << "potentialLocations = ";
  std::vector<int> clusterPath;
  for(int x = 0; x < occupiedNodes.size(); x++){
    std::cout << "/" << occupiedNodes[x];
  }
  std::set<int> occupiedTracker;
  for(int x = 0; x < occupiedNodes.size(); x++){
    occupiedTracker.insert(occupiedNodes[x]);
  }
  std::cout << std::endl;
  bool found = false;
  bool searched = false;
  int pathPosition = -1;
  int currentAction = -1;
  int robotClusterPos = plannerDefinition->getBoundaryCluster(robotBoundaryNode);
  bool triggerObs = false;
  int robotGlobalNode = plannerDefinition->boundaryNodes_[robotBoundaryNode];
  std::vector<int> nodePath;
  std::vector<int> clusterSearchPath;
  //plannerInterface.phantomInit();
  int actionInt;
  //std::shared_ptr<nanomap::planner::boundarysearch::BoundarySearchAction> action;
  //action = std::make_shared<nanomap::planner::boundarysearch::BoundarySearchAction>(plannerInterface.getPhantomAction());
  //std::
  //action = std::make_shared<nanomap::planner::boundarysearch::BoundarySearchAction>(static_cast<nanomap::planner::boundarysearch::BoundarySearchAction*>(plannerInterface.getPhantomAction()));
  //actionInt = action->getAction();
  // for(int x = 0; x < 10; x++){
  //   plannerInterface.phantomImprove();
  // }
  // actionInt = plannerInterface.getPhantomAction();
  // for(int x = 0; x < 100; x++){
  //   searched = false;
  //   triggerObs = false;
  //   found = false;
  //   if(actionInt == 0){
  //     //do nothing
  //     //Search current cluster
  //     searched = true;
  //     triggerObs = true;
  //     std::cout << "robotNode " << robotBoundaryNode << std::endl;
  //     std::cout << "robotCluster " << robotClusterPos << std::endl;
  //     std::cout << "ACTION = SEARCHING CLUSTER "<< robotClusterPos << std::endl;
  //     //std::cout << "newrobotNode " << robotBoundaryNode << std::endl;
  //     //std::cout << "newrobotCluster " << robotClusterPos << std::endl;
  //     //if(opponentEnd == robotClusterPos){
  //     //  found = true;
  //     //  std::cout << "OPPONENT FOUND!" << std::endl;
  //     //}else{
  //     //  std::cout << "OPPONENT NOT FOUND!" << std::endl;
  //     //}
  //   }else{
  //     int newBoundaryNode;
  //     bool valid;
  //     std::cout << "oldrobotNode " << robotBoundaryNode << std::endl;
  //     std::cout << "oldrobotCluster " << robotClusterPos << std::endl;
  //     //std::cout << "oldrobotNeighbourCount" << plannerDefinition->boundaryMap_[robotBoundaryNode].size() << std::endl;
  //     std::cout << "action: " << actionInt << std::endl;
  //     std::tie(newBoundaryNode, valid) = plannerDefinition->getRobotMovedNode(robotBoundaryNode, actionInt);
  //     if(valid){
  //       robotBoundaryNode = newBoundaryNode;
  //       robotClusterPos = plannerDefinition->getBoundaryCluster(robotBoundaryNode);
  //       robotGlobalNode = plannerDefinition->boundaryNodes_[robotBoundaryNode];
  //       searched = false;
  //       found = false;
  //       triggerObs = true;
  //     }else{
  //       std::cout << "INVALID ACTION ERROR" << std::endl;
  //       return 0;
  //     }
  //     std::cout << "newrobotNode " << robotBoundaryNode << std::endl;
  //     std::cout << "newrobotCluster " << robotClusterPos << std::endl;
  //
  //   }
  //   std::cout << std::endl << "---------------" << std::endl;
  //   std::shared_ptr<nanomap::planner::boundarysearch::BoundarySearchObservation> obs =
  //     std::make_shared<nanomap::planner::boundarysearch::BoundarySearchObservation>(robotBoundaryNode, searched, found);
  //   std::shared_ptr<nanomap::planner::boundarysearch::BoundarySearchAction> action =
  //     std::make_shared<nanomap::planner::boundarysearch::BoundarySearchAction>(actionInt);
  //
  //   plannerInterface.phantomStep(action, obs);
  //   //action = std::shared_ptr<nanomap::planner::boundarysearch::BoundarySearchAction>((plannerInterface.getPhantomAction().get()));
  //   //action = std::make_shared<nanomap::planner::boundarysearch::BoundarySearchAction>(static_cast<nanomap::planner::boundarysearch::BoundarySearchAction*>(plannerInterface.getPhantomAction().get()));
  //   actionInt = plannerInterface.getPhantomAction();
  // }
  // return 0;
  // nodePath = map_ptr->pathBetweenNodeAndCluster(robotNodePos, 1);
  // std::cout << "nodePath: ";
  // for(int x = 0; x < nodePath.size(); x++){
  //   std::cout << nodePath[x] << " / ";
  // }
  // std::cout << std::endl;
  //
  // std::cout << "clusterPath: ";
  // for(int x = 0; x < nodePath.size(); x++){
  //   std::cout << map_ptr->_globalClusterMap[nodePath[x]] << " / ";
  // }
  // std::cout << std::endl;// << std::endl;

  //nodePath.clear();
  bool finished = false;
  step = 0;
  plannerInterface.stepSolver();
  step++;
  while(step < 100 && !found && !finished){
    std::cout << step << std::endl;
    triggerObs = false;
    searched = false;
    found = false;
    actionInt = plannerInterface.lastAction_->getAction();
    if(actionInt == 0){
      //do nothing
      //Search current cluster
      searched = true;
      triggerObs = true;
      std::cout << "SEARCHING CLUSTER "<< robotClusterPos << std::endl;
      occupiedTracker.erase(robotClusterPos);
      clusterSearchPath.push_back(robotClusterPos);
      // if(opponentEnd == robotClusterPos){
      //   found = true;
      // }
    }else{
      int newBoundaryNode;
      bool valid;
      //std::cout << "robotNode" << robotBoundaryNode << std::endl;
      //std::cout << "robotNeighbourCount" << plannerDefinition->boundaryMap_[robotBoundaryNode].size() << std::endl;
      //std::cout << "action: " << actionInt << std::endl;
      std::tie(newBoundaryNode, valid) = plannerDefinition->getRobotMovedNode(robotBoundaryNode, actionInt);
      if(valid){
        robotBoundaryNode = newBoundaryNode;
        robotClusterPos = plannerDefinition->getBoundaryCluster(robotBoundaryNode);
        robotGlobalNode = plannerDefinition->boundaryNodes_[robotBoundaryNode];
        searched = false;
        found = false;
        triggerObs = true;
      }else{
        //std::cout << "INVALID ACTION ERROR" << std::endl;
        return 0;
      }

    }
    //std::cout << "what" << std::endl;
    //std::cout << occupiedTracker.empty() << std::endl;
    if(occupiedTracker.size()==1){
      //finished = true;
      std::cout << "cluster search path";
      for(int x = 0; x < clusterSearchPath.size(); x++){
        std::cout << " / " << clusterSearchPath[x]; //<< std::endl;
      }
      std::cout << " / "<< *occupiedTracker.begin() << std::endl;
      occupiedTracker.erase(*occupiedTracker.begin());
      break;
      //return 0;
    }
    //std::cout << "step = " << step << std::endl;
    if(triggerObs){
        //found = (opponentEnd == robotClusterPos && opponentEnd == plannerInterface.lastAction_->getAction());
          //if(found){
          //  std::cout << "opponent found" << std::endl;
            //break;
          //}else{
          //  std::cout << "opponent not found" << std::endl;
            std::shared_ptr<nanomap::planner::boundarysearch::BoundarySearchObservation> obs =
              std::make_shared<nanomap::planner::boundarysearch::BoundarySearchObservation>(robotBoundaryNode, searched, found);
              plannerInterface.addObservation(obs);
          //}

      plannerInterface.stepSolver();
      step++;
    }
    //actionInt = plannerInterface.lastAction_->getAction();
    //std::cout << "action = " << actionInt << std::endl;
    //std::cout << "robotNode = " << robotBoundaryNode << std::endl;
    //std::cout << "robotGlobalNode = " << robotGlobalNode << std::endl;
    //std::cout << "robotClusterPos = " << robotClusterPos << std::endl;




  //std::cout << "-----------" << std::endl;
    //
    //   if(robotClusterPos == currentAction){
    //     searched = true;
    //     triggerObs = true;
    //   }else{
    //     pathPosition++;
    //     robotNodePos = nodePath[pathPosition];
    //     //robotClusterPos = map_ptr->_globalClusterMap[robotNodePos];
    //     if(robotClusterPos != map_ptr->_globalClusterMap[robotNodePos]){
    //       //new cluster, trigger Obs.
    //       triggerObs = true;
    //       robotClusterPos = map_ptr->_globalClusterMap[robotNodePos];
    //     }
    //   }
    // }else{
    //   if(plannerInterface.lastAction_->getAction() == robotClusterPos){
    //     searched = true;
    //     triggerObs = true;
    //     //clusterPath.clear();
    //     //clusterPath.push_back(robotPos);
    //     //nodePath = map_ptr->getNodePath(robotNodePos);
    //   }else{
    //     nodePath.clear();
    //     nodePath = map_ptr->pathBetweenNodeAndCluster(robotNodePos, plannerInterface.lastAction_->getAction());
    //     std::cout << "nodePath: ";
    //     for(int x = 0; x < nodePath.size(); x++){
    //       std::cout << nodePath[x] << " / ";
    //     }
    //     std::cout << std::endl;
    //
    //     std::cout << "clusterPath: ";
    //     for(int x = 0; x < nodePath.size(); x++){
    //       std::cout << map_ptr->_globalClusterMap[nodePath[x]] << " / ";
    //     }
    //     std::cout << std::endl;// << std::endl;
    //
    //     pathPosition = 1;
    //     robotNodePos = nodePath[pathPosition];
    //     if(robotClusterPos != map_ptr->_globalClusterMap[robotNodePos]){
    //       //new cluster, trigger Obs.
    //       triggerObs = true;
    //       robotClusterPos = map_ptr->_globalClusterMap[robotNodePos];
    //     }
    //
    //     //clusterPath = map_ptr->pathBetweenClusters(robotPos, plannerInterface.lastAction_->getAction());
    //   }
    // }
    //std::cout << "pathPosition  = " << pathPosition << std::endl << std::endl;
    //currentAction = plannerInterface.lastAction_->getAction();
    //std::cout << "------------------------" << std::endl;
  }

  //std::cout << "Opponent Found In Cluster: " << robotClusterPos << std::endl;


  //allocationfactor
  //std::cout << "print" << std::endl;
  //handle_start = std::chrono::high_resolution_clock::now();
  // for(auto itr = clouds.begin(); itr != clouds.end(); itr++){
  //
  //   index = std::distance(clouds.begin(), itr);
  //   if(index >= indexTarget && index < indexEnd){//&& index < indexTarget+1){
  //     //if(index==1){
  //     //    handle_start = std::chrono::high_resolution_clock::now();
  //     //}
  //     tf::transformStampedMsgToTF(tfs[index], sensorToWorldTf);
  //     tf::vectorTFToEigen(sensorToWorldTf.getOrigin(), pos);
  //     tf::quaternionTFToEigen(sensorToWorldTf.getRotation(), quat);
  //     pose.position = pos.cast<float>();
  //     pose.orientation = quat.cast<float>();
  //
  //     parallelManager.insertPointCloud("640x480", clouds[index]->width, clouds[index]->height ,
  //                                  clouds[index]->point_step , &(clouds[index]->data[0]), pose, parallel_map_ptr);
  //
  //   if(index >= indexEnd-1){
  //      break;
  //     }
  //   }
  // }

  plannerManager.closeHandler();
  return 0;
}
