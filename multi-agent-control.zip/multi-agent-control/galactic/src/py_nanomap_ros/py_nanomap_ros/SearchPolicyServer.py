from stable_baselines3 import SAC, PPO
from nanomap_msgs.srv import PolicyQuery
import numpy as np
import rclpy
from rclpy.node import Node
import sys

class SearchPolicyServer(Node):

    def __init__(self, agentId):
        self.agentId = agentId
        self.num_dist_obs = 512
        self.num_goal_obs = 15
        self.num_actions = 4
        self.num_agent_velocities = 4
        self.num_step_obs = 1
        self.x_vel = 2.0
        self.y_vel = 0.75
        self.z_vel = 0.75
        self.yaw_vel = 1.0
        self.step = np.array([0.5])
        self.observations = np.zeros(self.num_dist_obs*2)
        self.goal_obs = np.zeros(self.num_goal_obs)
        self.agent_velocity = np.zeros(self.num_agent_velocities)
        self.old_agent_velocity = np.zeros(self.num_agent_velocities)
        self.prior_actions = np.zeros(self.num_actions)
        self.path_to_policy = "/home/vi/github/galactic/src/py_nanomap_ros/policies/search_policy.zip"
        self.model = SAC.load(self.path_to_policy)
        super().__init__('agent_'+ str(self.agentId)+'_self_policy_service')
        self.srv = self.create_service(PolicyQuery, 'agent_'+str(self.agentId)+'_search_policy_query', self.policy_query_callback)

    def policy_query_callback(self, request, response):
        # if self.step[0] <0.2 :
            # self.step[0] = 0.5
        self.goal_obs = request.goalobservations
        self.observations = request.distanceobservations
        self.agent_velocity = request.agentvelocities
        obs = np.concatenate((self.prior_actions, self.old_agent_velocity, self.agent_velocity, self.goal_obs, self.observations, self.step))
        actions, _states = self.model.predict(obs, deterministic=True)
        self.old_agent_velocity = self.agent_velocity
        xVelocity = float(actions[0])
        if xVelocity < 0.0:
            xVelocity=xVelocity*self.y_vel
        else:
            xVelocity=xVelocity*self.x_vel
        
        response.actions = [xVelocity, float(actions[1])*self.y_vel, float(actions[2])*self.z_vel, float(actions[3])*self.yaw_vel]
        self.prior_actions = np.array([float(actions[0]), float(actions[1]), float(actions[2]), float(actions[3])])
        # self.step[0] -= 1/200.0
        # self.get_logger().info('Incoming request')

        return response


def main(args=None):
    rclpy.init(args=args)
    agentId = sys.argv[1]
    minimal_service = SearchPolicyServer(agentId)

    rclpy.spin(minimal_service)

    rclpy.shutdown()


if __name__ == '__main__':
    main()
