/** @file Agent.cpp
 *
 * Contains the implementation of the Agent class.
 */
#include "tapirsolver/solver/Agent.hpp"

#include "tapirsolver/solver/BeliefNode.hpp"
#include "tapirsolver/solver/BeliefTree.hpp"
#include "tapirsolver/solver/Solver.hpp"

namespace solver {

Agent::Agent(Solver *solver) :
        solver_(solver),
        currentBelief_(solver_->getPolicy()->getRoot()) {
}

Solver *Agent::getSolver() const {
    return solver_;
}
std::unique_ptr<Action> Agent::getPreferredAction() const {
    return currentBelief_->getRecommendedAction();
}
BeliefNode *Agent::getCurrentBelief() const {
    return currentBelief_;
}

void Agent::setCurrentBelief(BeliefNode *belief) {
    currentBelief_ = belief;
}
void Agent::updateBelief(Action const &action, Observation const &observation) {
    currentBelief_ = currentBelief_->createOrGetChild(action, observation);
}
} /* namespace solver */
